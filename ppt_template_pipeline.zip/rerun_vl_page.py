#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path
from typing import Any

from build_prompt_template_system import (
    build_visual_role_prompt,
    parse_visual_report_payload,
    read_config,
    request_vl_report,
    role_from_template_contract,
    short_hash,
    write_json,
)


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def find_page_record(styles: dict[str, Any], page: int) -> tuple[str, dict[str, Any]]:
    for role, items in (styles.get("roles") or {}).items():
        for item in items:
            if isinstance(item, dict) and int(item.get("page") or 0) == page:
                return str(role), item
    raise RuntimeError(f"page {page} was not found in styles.json")


def rendered_image(styles: dict[str, Any], output_dir: Path, page: int) -> Path:
    for item in ((styles.get("vision") or {}).get("rendered_pages") or []):
        if int(item.get("page") or 0) != page:
            continue
        raw = Path(str(item.get("output") or item.get("path") or ""))
        path = raw if raw.is_absolute() else output_dir / raw
        if path.exists():
            return path
        alt = output_dir / "_vl_pages" / f"page_{page:03d}.jpg"
        if alt.exists():
            return alt
    alt = output_dir / "_vl_pages" / f"page_{page:03d}.jpg"
    if alt.exists():
        return alt
    raise RuntimeError(f"rendered image for page {page} was not found")


def update_roles(styles: dict[str, Any], page: int, role: str, record: dict[str, Any]) -> None:
    roles = styles.setdefault("roles", {})
    for key in list(roles):
        roles[key] = [item for item in (roles.get(key) or []) if int((item or {}).get("page") or 0) != page]
        if not roles[key]:
            roles.pop(key, None)
    roles.setdefault(role, []).append(record)
    for key in roles:
        roles[key] = sorted(roles[key], key=lambda item: int(item.get("page") or 0))


def main() -> int:
    try:
        import certifi

        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass

    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("output_px_vl"))
    parser.add_argument("--config", type=Path, default=Path("config.json"))
    parser.add_argument("--style-prompt", type=Path, default=Path("prompts/extra_image.txt"))
    parser.add_argument("--page", type=int, default=1)
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()

    styles_path = args.output_dir / "styles.json"
    styles = read_json(styles_path)
    old_role, old_record = find_page_record(styles, args.page)
    config = read_config(args.config)
    vision = config.get("vision") or {}
    retry_codes = list(config.get("vl_retry_status_codes") or [408, 429, 500, 502, 503, 504])
    style_prompt_template = args.style_prompt.read_text(encoding="utf-8")
    page_images = old_record.get("page_images") or ((old_record.get("template_contract") or {}).get("page_images") or [])
    metadata = {
        "font_analysis": str(old_record.get("font_analysis") or ""),
        "color_analysis": str(old_record.get("color_analysis") or ""),
    }
    prompt = build_visual_role_prompt(style_prompt_template, metadata, page_images)
    image_path = rendered_image(styles, args.output_dir, args.page)
    raw = request_vl_report(
        image_path,
        prompt,
        str(vision.get("base_url") or ""),
        str(vision.get("model") or ""),
        str(vision.get("api_key") or ""),
        args.timeout,
        int(config.get("vl_retry_attempts") or 3),
        float(config.get("vl_retry_backoff_seconds") or 2.0),
        retry_codes,
    )
    payload = parse_visual_report_payload(
        raw,
        fallback_role=old_role,
        fallback_layout=str(old_record.get("layout_affordance") or "unknown"),
        font_analysis=metadata["font_analysis"],
    )
    contract = payload.get("template_contract") or {}
    if page_images and isinstance(contract, dict):
        contract["page_images"] = page_images
    role = role_from_template_contract(contract, str(payload.get("page_role") or old_role)) if contract else str(payload.get("page_role") or old_role)
    record = {
        **old_record,
        **payload,
        "page": args.page,
        "source": "vl_model",
        "font_analysis": metadata["font_analysis"],
        "color_analysis": metadata["color_analysis"],
    }
    if page_images:
        record["page_images"] = page_images
    update_roles(styles, args.page, role, record)
    write_json(styles_path, styles)

    resume_dir = args.output_dir / "_resume"
    prompt_hash = short_hash(style_prompt_template + "\nimage_asset_policy.v2")
    write_json(
        resume_dir / "visual_report_raw" / f"page_{args.page:03d}.json",
        {
            "status": "ok",
            "page": args.page,
            "source": str(styles.get("source") or ""),
            "model": str(vision.get("model") or ""),
            "base_url": str(vision.get("base_url") or ""),
            "prompt_hash": prompt_hash,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "visual_report": raw,
        },
    )
    write_json(
        resume_dir / "visual_reports" / f"page_{args.page:03d}.json",
        {
            "status": "ok",
            "page": args.page,
            "source": str(styles.get("source") or ""),
            "model": str(vision.get("model") or ""),
            "base_url": str(vision.get("base_url") or ""),
            "prompt_hash": prompt_hash,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "report": record,
        },
    )
    print(f"page {args.page:03d}: role={role}")
    print("background_strategy:", json.dumps(contract.get("background_strategy") or {}, ensure_ascii=False))
    print("image_asset_policy:", json.dumps(contract.get("image_asset_policy") or {}, ensure_ascii=False)[:1200])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
