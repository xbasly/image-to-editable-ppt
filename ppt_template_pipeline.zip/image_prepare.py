from __future__ import annotations

from pathlib import Path
from typing import Any

from PIL import Image


def compress_image_for_vl(source: str | Path, output: str | Path, profile: str = "analysis") -> dict[str, Any]:
    """Convert an image to a model-friendly JPEG and return render metadata."""
    source_path = Path(source)
    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    max_side = 1600 if profile == "analysis" else 1280
    quality = 88 if profile == "analysis" else 84

    with Image.open(source_path) as img:
        image = img.convert("RGB")
        width, height = image.size
        scale = min(1.0, max_side / max(width, height))
        if scale < 1.0:
            new_size = (max(1, int(width * scale)), max(1, int(height * scale)))
            image = image.resize(new_size, Image.Resampling.LANCZOS)
        image.save(output_path, "JPEG", quality=quality, optimize=True)

    with Image.open(output_path) as img:
        out_width, out_height = img.size

    return {
        "path": str(output_path),
        "output": str(output_path),
        "width": out_width,
        "height": out_height,
        "source": str(source_path),
        "profile": profile,
    }


def render_pdf_pages_for_vl(source: str | Path, output_dir: str | Path, profile: str = "analysis") -> list[dict[str, Any]]:
    """Render every PDF page to JPEG images suitable for VL analysis."""
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("Install pymupdf to render PDF pages: python -m pip install pymupdf") from exc

    source_path = Path(source)
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rendered: list[dict[str, Any]] = []
    zoom = 1.6 if profile == "analysis" else 1.3
    with fitz.open(source_path) as doc:
        for index in range(len(doc)):
            page_num = index + 1
            raw_path = out_dir / f"page_{page_num:03d}_raw.png"
            final_path = out_dir / f"page_{page_num:03d}.jpg"
            pix = doc[index].get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            pix.save(raw_path)
            item = compress_image_for_vl(raw_path, final_path, profile=profile)
            raw_path.unlink(missing_ok=True)
            item["page"] = page_num
            rendered.append(item)
    return rendered
