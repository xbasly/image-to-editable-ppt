#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def extract_paths(svg: str) -> list[str]:
    body = re.sub(r"(?is)<defs\b.*?</defs>", "", svg)
    return re.findall(r"<path\b[^>]*?/?>", body, flags=re.I | re.S)


def path_d(path: str) -> str:
    match = re.search(r'\sd="([^"]+)"', path, flags=re.I)
    return match.group(1) if match else ""


def fill(path: str) -> str:
    match = re.search(r'\sfill="([^"]+)"', path, flags=re.I)
    return (match.group(1) if match else "").lower()


def stroke(path: str) -> str:
    match = re.search(r'\sstroke="([^"]+)"', path, flags=re.I)
    return (match.group(1) if match else "").lower()


def bbox(path: str) -> tuple[float, float, float, float] | None:
    """Return a rough path bbox from path data.

    This intentionally uses a tolerant numeric scan. It is good enough for
    role filtering: separating full-slide/chrome shapes from small motifs.
    """
    nums = [float(x) for x in re.findall(r"[-+]?\d*\.?\d+(?:e[-+]?\d+)?", path_d(path), flags=re.I)]
    if len(nums) < 2:
        return None
    xs = nums[0::2]
    ys = nums[1::2]
    if not xs or not ys:
        return None
    return min(xs), min(ys), max(xs), max(ys)


def bbox_size(path: str) -> tuple[float, float]:
    box = bbox(path)
    if not box:
        return 0.0, 0.0
    x0, y0, x1, y1 = box
    return abs(x1 - x0), abs(y1 - y0)


def paths_bbox(paths: list[str]) -> dict[str, float] | None:
    boxes = [bbox(path) for path in paths]
    boxes = [box for box in boxes if box is not None]
    if not boxes:
        return None
    x0 = min(box[0] for box in boxes)
    y0 = min(box[1] for box in boxes)
    x1 = max(box[2] for box in boxes)
    y1 = max(box[3] for box in boxes)
    return {
        "x": round(x0, 3),
        "y": round(y0, 3),
        "width": round(abs(x1 - x0), 3),
        "height": round(abs(y1 - y0), 3),
    }


def path_colors(paths: list[str]) -> list[str]:
    colors = sorted({value for path in paths for value in (fill(path), stroke(path)) if value and value != "none"})
    return colors


def is_full_canvas_background(path: str) -> bool:
    d = path_d(path).replace(" ", "")
    if fill(path) not in {"#ffffff", "white"}:
        return False
    full_canvas_markers = [
        "M0540H959",
        "M0540H960",
        "M0.028H959",
        "M0.028H960",
        "H959.981V.028H0V540",
        "H960.009V0H0V540",
    ]
    return any(marker in d for marker in full_canvas_markers)


def vector_role(path: str) -> str:
    width, height = bbox_size(path)
    area = width * height
    aspect = width / max(height, 1.0)
    path_fill = fill(path)
    path_stroke = stroke(path)
    has_stroke = bool(path_stroke and path_stroke != "none")
    fill_none = path_fill in {"", "none"}

    if is_full_canvas_background(path):
        return "background_chrome"
    if path_fill in {"#f49ea4", "#6b6680"} and 90 <= width <= 180 and 180 <= height <= 320:
        return "diagram_structure"
    if path_fill == "#595959" and 80 <= width <= 280 and 40 <= height <= 260 and area <= 80000:
        return "diagram_structure"
    if width >= 420 or height >= 260 or area >= 90000:
        return "background_chrome"
    if not fill_none and width >= 120 and height >= 35:
        return "layout_container"
    if not fill_none and width >= 80 and height >= 18 and aspect >= 2.2:
        return "layout_container"
    if has_stroke and width >= 80 and height >= 18 and aspect >= 2.2:
        return "layout_container"
    if has_stroke and area <= 25000:
        return "connector"
    if path_fill == "#ffffff" and width <= 120 and height <= 120:
        return "icon"
    if width <= 170 and height <= 150 and area <= 26000:
        return "local_motif"
    return "layout_container"


def reusable_role(role: str) -> bool:
    return role in {"connector", "diagram_structure", "icon", "local_motif"}


def group_svg(paths: list[str], view_box: str) -> str:
    return (
        f'<svg viewBox="{view_box}" xmlns="http://www.w3.org/2000/svg">\n'
        + "<g>"
        + "\n".join(paths)
        + "</g>\n</svg>"
    )


def svg_view_box(svg: str) -> str:
    match = re.search(r'\sviewBox="([^"]+)"', svg, flags=re.I)
    return match.group(1) if match else "0 0 960 540"


def write_page_assets(page_num: int, svg: str, out_dir: Path) -> int:
    view_box = svg_view_box(svg)
    role_paths: dict[str, list[str]] = {"connector": [], "diagram_structure": [], "icon": [], "local_motif": []}
    skipped: dict[str, int] = {"background_chrome": 0, "layout_container": 0}
    for path in extract_paths(svg):
        role = vector_role(path)
        if reusable_role(role):
            role_paths[role].append(path)
        else:
            skipped[role] = skipped.get(role, 0) + 1

    assets = []
    for role, paths in role_paths.items():
        if not paths:
            continue
        # Many tiny paths usually indicate a complex layout fragment or traced
        # artwork, not a reusable local motif. Let GLM/CSS handle those.
        if role == "local_motif" and len(paths) > 40:
            skipped["layout_container"] = skipped.get("layout_container", 0) + len(paths)
            continue
        if role == "connector" and len(paths) > 24:
            skipped["layout_container"] = skipped.get("layout_container", 0) + len(paths)
            continue
        if role == "icon" and len(paths) > 60:
            skipped["layout_container"] = skipped.get("layout_container", 0) + len(paths)
            continue
        assets.append(
            {
                "id": role,
                "role": role,
                "usage": {
                    "connector": "fixed short connector lines, arrows, or endpoints",
                    "diagram_structure": "central vector diagram structure that should be reused exactly",
                    "icon": "small fixed icons extracted from the source slide",
                    "local_motif": "small decorative motifs that should keep exact geometry",
                }[role],
                "path_count": len(paths),
                "bbox": paths_bbox(paths),
                "colors": path_colors(paths),
                "svg": group_svg(paths, view_box),
            }
        )

    if not assets:
        return 0
    payload = {
        "page": page_num,
        "viewBox": view_box,
        "binding_version": "vector_assets.v2",
        "policy": "Only local reusable vectors are exported. Background chrome, layout containers, cards, buttons, and large blocks are intentionally skipped.",
        "skipped": skipped,
        "assets": assets,
    }
    path = out_dir / f"slide_{page_num:03d}_vector_assets.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return sum(len(asset.get("svg", "").split("<path")) - 1 for asset in assets)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--overwrite-curated", action="store_true")
    args = ap.parse_args()

    import fitz

    args.output_dir.mkdir(parents=True, exist_ok=True)
    totals: list[tuple[int, int]] = []
    with fitz.open(args.pdf) as doc:
        for index, page in enumerate(doc, start=1):
            svg_path = args.output_dir / f"slide_{index:03d}_from_lo_pdf.svg"
            svg = page.get_svg_image(text_as_path=False)
            svg_path.write_text(svg, encoding="utf-8")

            asset_path = args.output_dir / f"slide_{index:03d}_vector_assets.json"
            if asset_path.exists() and not args.overwrite_curated:
                totals.append((index, -1))
                continue
            count = write_page_assets(index, svg, args.output_dir)
            totals.append((index, count))

    created = sum(1 for _, count in totals if count > 0)
    kept = sum(1 for _, count in totals if count == -1)
    empty = sum(1 for _, count in totals if count == 0)
    print(f"pages: {len(totals)}")
    print(f"created: {created}")
    print(f"kept_existing: {kept}")
    print(f"empty: {empty}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
