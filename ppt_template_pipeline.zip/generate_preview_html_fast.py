#!/usr/bin/env python
from __future__ import annotations

import argparse
import html
import json
import os
import re
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize_base_url(url: str) -> str:
    return url.rstrip("/").removesuffix("/v1").rstrip("/") + "/v1"


def response_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") or []
    msg = (choices[0] or {}).get("message") if choices else {}
    content = (msg or {}).get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(x.get("text") or "") for x in content if isinstance(x, dict))
    return str((msg or {}).get("reasoning_content") or "")


def stream_delta_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") or []
    if not choices or not isinstance(choices[0], dict):
        return ""
    choice = choices[0]
    delta = choice.get("delta") if isinstance(choice.get("delta"), dict) else {}
    content = delta.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(x.get("text") or "") for x in content if isinstance(x, dict))
    for key in ("reasoning_content", "reasoning"):
        value = delta.get(key)
        if isinstance(value, str):
            return value
    return response_text({"choices": [{"message": choice.get("message") or {}}]})


def read_stream(resp: Any) -> str:
    chunks: list[str] = []
    for raw in resp:
        line = raw.decode("utf-8", errors="ignore").strip()
        if not line or not line.startswith("data:"):
            continue
        payload = line.removeprefix("data:").strip()
        if payload == "[DONE]":
            break
        data = json.loads(payload)
        while isinstance(data, str):
            data = json.loads(data)
        text = stream_delta_text(data)
        if text:
            chunks.append(text)
    return "".join(chunks)


def pages(styles: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    for role, items in (styles.get("roles") or {}).items():
        for item in items:
            if isinstance(item, dict) and item.get("template_contract"):
                out.append({"role": role, **item})
    return sorted(out, key=lambda x: int(x.get("page") or 0))


def summarize(item: dict[str, Any]) -> str:
    contract = item.get("template_contract") or {}
    style = contract.get("style") or {}
    slots = contract.get("slots") or {}
    image_policy = contract.get("image_asset_policy") or {}
    background_strategy = contract.get("background_strategy") or {}
    vector_assets = vector_assets_summary(item)
    colors = ", ".join(
        f'{c.get("role")} {c.get("hex")}' for c in (style.get("colors") or [])[:5] if isinstance(c, dict)
    )
    images = []
    for im in item.get("page_images") or []:
        if not im.get("oversized"):
            images.append(
                f'../{im["file"]} at {im["left_pct"]}%/{im["top_pct"]}% size {im["width_pct"]}%x{im["height_pct"]}%'
            )
    blank_ref = str(item.get("blank_template") or "")
    blank_note = "none"
    if blank_ref:
        blank_note = (
            f"{blank_ref}; available shared background/chrome. "
            "Use it only when it fits the slide by placing {{BLANK_TEMPLATE}} once as a direct body child."
        )
    return f"""role={item.get('role')}
layout_kind={contract.get('layout_kind')}
title_slot={slots.get('title')}
subtitle_slot={slots.get('subtitle')}
sections={slots.get('sections')}
chart={slots.get('chart')}
images_slot={slots.get('images')}
colors={colors}
typography={style.get('typography')}
background={style.get('background')}
image_asset_policy={json.dumps(image_policy, ensure_ascii=False)[:1000]}
background_strategy={json.dumps(background_strategy, ensure_ascii=False)[:700]}
vector_assets={vector_assets}
blank_template={blank_note}
visual={str(item.get('visual_report') or '')[:500]}
assets={'; '.join(images) if images else 'none'}"""


def blank_template_excerpt(item: dict[str, Any]) -> str:
    output_dir = item.get("_output_dir")
    blank_ref = str(item.get("blank_template") or "")
    if not output_dir or not blank_ref:
        return ""
    path = Path(output_dir) / blank_ref
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="ignore")[:4500]


def strip(text: str) -> str:
    text = text.strip()
    fenced = re.findall(r"(?is)```(?:html)?\s*(.*?)```", text)
    html_fenced = [block.strip() for block in fenced if "<" in block]
    if html_fenced:
        text = html_fenced[-1]
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n", "", text)
        text = re.sub(r"\n```\s*$", "", text)
    complete = re.findall(r"(?is)(?:<!doctype\s+html[^>]*>\s*)?<html\b.*?</html>", text)
    if complete:
        text = complete[-1]
    else:
        match = re.search(r"(?is)(<!doctype\s+html|<html\b)", text)
        if match:
            text = text[match.start():]
        elif re.search(r"(?is)<(style|div|svg|section|main|body)\b", text):
            text = (
                '<!doctype html><html><head><meta charset="utf-8"></head>'
                f"<body>{text}</body></html>"
            )
    return text.strip()


def call_glm(prompt: str, cfg: dict[str, Any], timeout: int, max_tokens: int, stream: bool) -> str:
    gen = cfg["generation"]
    payload = {
        "model": gen["model"],
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.2,
        "max_tokens": max_tokens,
        "stream": stream,
    }
    if "glm" in str(gen["model"]).lower():
        payload["extra_body"] = {"enable_thinking": False}
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {gen['api_key']}"}
    req = urllib.request.Request(
        f"{normalize_base_url(gen['base_url'])}/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=timeout) as resp:
        if stream:
            return strip(read_stream(resp))
        return strip(response_text(json.loads(resp.read().decode("utf-8"))))


def write_index(output_dir: Path, verify_dir: Path) -> None:
    files = sorted(verify_dir.glob("verify_*.html"))
    frames = "\n".join(
        f'<iframe src="{html.escape(verify_dir.name)}/{html.escape(p.name)}" width="1280" height="720"></iframe>'
        for p in files
    )
    (output_dir / "presentation.html").write_text(
        '<!doctype html><html><head><meta charset="utf-8"><title>Verification Presentation</title>'
        '<style>body{margin:0;background:#111;display:flex;flex-direction:column;align-items:center;gap:16px;padding:16px}'
        'iframe{border:0;background:white}</style></head><body>' + frames + "</body></html>\n",
        encoding="utf-8",
    )


def vector_assets_summary(item: dict[str, Any]) -> str:
    page = int(item.get("page") or 0)
    output_dir = item.get("_output_dir")
    if not page or not output_dir:
        return "none"
    asset_path = Path(output_dir) / "lo_export" / f"slide_{page:03d}_vector_assets.json"
    if not asset_path.exists():
        return "none"
    data = load_json(asset_path)
    assets = data.get("assets") or []
    if not assets:
        return "none"
    contract = item.get("template_contract") or {}
    bindings = contract.get("vector_bindings") or item.get("vector_bindings") or data.get("vector_bindings") or []
    if not isinstance(bindings, list):
        bindings = []
    binding_by_asset = {
        str(binding.get("asset_id")): binding
        for binding in bindings
        if isinstance(binding, dict) and binding.get("asset_id") and binding.get("status") == "bound"
    }
    missing = [binding for binding in bindings if isinstance(binding, dict) and binding.get("status") == "missing"]
    lines = [
        "Vector binding pipeline: VL identifies SVG-worthy graphics in vector_plan; the parser binds them to exact SVG assets when available. "
        "You decide whether each bound SVG asset fits this preview. To reuse one exact SVG asset, place {{VECTOR_ASSET:asset_id}} once as a direct body child. "
        "If you use an SVG placeholder, do not also redraw the same structure. If a vector candidate is missing, recreate only that missing graphic from the fallback description. "
        "When a reused SVG usage describes fixed nodes, circles, icons, arrows, connectors, or diagram shapes, treat those visible shapes as occupied graphic areas; place body text and headings around them unless the original visual report explicitly shows text inside those shapes. "
        f"Coordinate system for bound SVG layers: {data.get('viewBox') or '0 0 960 540'} scaled to the 1280x720 slide."
    ]
    bound_roles = sorted({str(binding.get("role")) for binding in binding_by_asset.values() if binding.get("role")})
    if bound_roles:
        lines.append("Bound SVG roles available for optional exact reuse: " + ", ".join(bound_roles) + ".")
    for asset in assets[:10]:
        if not isinstance(asset, dict):
            continue
        binding = binding_by_asset.get(str(asset.get("id")))
        if not binding:
            continue
        lines.append(
            f"- bound asset id={asset.get('id')}; role={asset.get('role')}; render_mode={binding.get('render_mode')}; "
            f"priority={binding.get('reuse_priority')}; confidence={binding.get('confidence')}; usage={asset.get('usage')}"
        )
    for binding in missing[:5]:
        lines.append(
            f"- missing vector plan_id={binding.get('plan_id')}; role={binding.get('role')}; "
            f"fallback={binding.get('fallback')}; recreate this only if needed."
        )
    return "\n".join(lines)[:8000]


def load_vector_assets(item: dict[str, Any]) -> dict[str, str]:
    page = int(item.get("page") or 0)
    output_dir = item.get("_output_dir")
    if not page or not output_dir:
        return {}
    asset_path = Path(output_dir) / "lo_export" / f"slide_{page:03d}_vector_assets.json"
    if not asset_path.exists():
        return {}
    data = load_json(asset_path)
    assets: dict[str, str] = {}
    for asset in data.get("assets") or []:
        if isinstance(asset, dict) and asset.get("id") and asset.get("svg"):
            assets[str(asset["id"])] = str(asset["svg"])
    return assets


def wrap_vector_asset(asset_id: str, svg: str) -> str:
    styled_svg = svg.replace("<svg ", '<svg style="width:1280px;height:720px;display:block" ', 1)
    return (
        f'<div class="injected-vector injected-vector-{html.escape(asset_id)}" '
        f'style="position:fixed;left:0;top:0;width:1280px;height:720px;'
        'pointer-events:none;z-index:1;overflow:hidden">'
        f"{styled_svg}"
        "</div>"
    )


def replace_vector_placeholders(text: str, assets: dict[str, str]) -> str:
    """Replace model-selected exact SVG placeholders; leave unselected assets alone."""
    for asset_id, svg in assets.items():
        placeholder = f"{{{{VECTOR_ASSET:{asset_id}}}}}"
        if placeholder not in text:
            continue
        text = text.replace(placeholder, wrap_vector_asset(asset_id, svg), 1)
        text = text.replace(placeholder, "")
    return text


def apply_blank_template_frame(text: str, item: dict[str, Any]) -> str:
    """Replace the model-selected blank-template placeholder with an iframe."""
    blank_ref = str(item.get("blank_template") or "")
    if not blank_ref or "{{BLANK_TEMPLATE}}" not in text:
        return text
    src = html.escape("../" + blank_ref if not blank_ref.startswith("../") else blank_ref)
    frame = (
        f'<iframe class="blank-template-frame" src="{src}" '
        'style="position:fixed;left:0;top:0;width:1280px;height:720px;'
        'border:0;z-index:0;pointer-events:none;background:#fff"></iframe>'
    )
    style = (
        "<style>"
        "html,body{background:transparent!important;}"
        "body>*:not(.blank-template-frame):not(.injected-vector){z-index:1;}"
        "</style>"
    )
    text = re.sub("(?i)</head>", style + "</head>", text, count=1) if "</head>" in text.lower() else style + text
    return text.replace("{{BLANK_TEMPLATE}}", frame, 1).replace("{{BLANK_TEMPLATE}}", "")


def inject_vector_assets(text: str, item: dict[str, Any]) -> str:
    assets = load_vector_assets(item)
    if not assets:
        return text
    return replace_vector_placeholders(text, assets)


def main() -> int:
    try:
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", type=Path, default=Path("output_full_qwen_vl"))
    ap.add_argument("--config", type=Path, default=Path("config.json"))
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--timeout", type=int, default=420)
    ap.add_argument("--max-tokens", type=int, default=2600)
    ap.add_argument("--pages", help="Comma-separated page numbers to generate, e.g. 7,8,9")
    ap.add_argument("--no-stream", action="store_true")
    args = ap.parse_args()
    styles = load_json(args.output_dir / "styles.json")
    cfg = load_json(args.config)
    verify_dir = args.output_dir / "verify_render"
    verify_dir.mkdir(exist_ok=True)
    work = []
    selected_pages = None
    if args.pages:
        selected_pages = {int(x.strip()) for x in args.pages.split(",") if x.strip()}
    for item in pages(styles):
        page = int(item.get("page") or 0)
        if selected_pages is not None and page not in selected_pages:
            continue
        item["_output_dir"] = str(args.output_dir)
        role = str(item.get("role") or "support")
        out = verify_dir / f"verify_{page:03d}_{role}.html"
        if not out.exists():
            work.append((item, out))

    def one(pair: tuple[dict[str, Any], Path]) -> tuple[int, str, str | None]:
        item, out = pair
        page = int(item.get("page") or 0)
        prompt = (
            "Generate a standalone polished 1280x720 HTML slide preview. Output HTML only. "
            "Use inline CSS, fictional English text, and respect the template summary. "
            "Use CSS font sizes in px only, never pt, with sane slide-scale hierarchy. "
            "Keep the HTML concise; no external fonts or scripts. "
            "Use listed image assets exactly when the image_asset_policy says to reuse them. "
            "If blank_template is available, decide whether it fits this slide. To use it, emit {{BLANK_TEMPLATE}} once as a direct body child and then generate foreground content over it; if you use it, do not redraw the same background/chrome. "
            "When using {{BLANK_TEMPLATE}} or any {{VECTOR_ASSET:...}}, do not create a full-canvas opaque foreground background; keep root/slide wrappers transparent so selected exact layers remain visible. "
            "The visual field is authoritative for the main composition: for concept_diagram, framework, process, timeline, or chart-like slides, render the described central diagram/framework visibly even when SVG assets cover only local details. "
            "When vector_assets mention bound assets, decide whether each one fits. To reuse one, emit {{VECTOR_ASSET:asset_id}} once as a direct body child; if you use it, do not redraw that same structure. Draw unselected or missing graphics with HTML/CSS/SVG. "
            "When using exact SVG nodes/icons/connectors, keep generated text outside the occupied graphic shapes unless the template summary says the original text sits inside those shapes. "
            "If background_strategy says use_asset_background or duplicate_drawing_forbidden=true, use that asset as the background/chrome and do not redraw its decorative motifs with CSS/SVG. "
            "For topic_bound_content that does not match the fictional preview topic, use a placeholder instead.\n\n"
            + summarize(item)
            + (
                "\n\nShared blank template HTML excerpt (do not rewrite it; renderer mounts it behind your foreground):\n"
                + blank_template_excerpt(item)
                if blank_template_excerpt(item)
                else ""
            )
        )
        try:
            text = call_glm(prompt, cfg, args.timeout, args.max_tokens, not args.no_stream)
            if "<" not in text:
                raise RuntimeError("no HTML returned")
            text = re.sub(r"(?<!\.\./)backgrounds/", "../backgrounds/", text)
            text = inject_vector_assets(text, item)
            text = apply_blank_template_frame(text, item)
            out.write_text(text, encoding="utf-8")
            return page, "written", None
        except Exception as exc:  # noqa: BLE001
            return page, "failed", f"{type(exc).__name__}: {str(exc)[:220]}"

    results = []
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        for fut in as_completed([ex.submit(one, x) for x in work]):
            r = fut.result()
            results.append(r)
            print(f"page {r[0]:03d}: {r[1]}" + (f" - {r[2]}" if r[2] else ""), flush=True)
    write_index(args.output_dir, verify_dir)
    failed = [r for r in results if r[1] == "failed"]
    print(f"done: {len(results) - len(failed)}/{len(results)} newly generated")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
