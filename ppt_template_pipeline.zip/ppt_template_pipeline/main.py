#!/usr/bin/env python
"""Single entry point for PPT template extraction.

Public function:

    extract_template(sn, user_id, ppt_dir, template_id, debug=False) -> dict

It parses the PPT/PDF found under `ppt_dir` into a fixed tmp working directory
(`tmp/<user_id><template_id>/`), produces `styles.json` + the distilled template
library + the blank-template/background assets (NO verify-render HTML step), then
zips the necessary files. Core logs are tagged with sn / user_id for retrieval.

CLI:  python main.py --sn S123 --user-id u01 --ppt-dir ./decks --template-id t9 [--debug]
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any

# Everything else lives in the ppt_pipeline package; expose it for the modules'
# bare intra-package imports (e.g. `import llm_client`, `from image_prepare import ...`).
_PKG = Path(__file__).resolve().parent / "ppt_pipeline"
sys.path.insert(0, str(_PKG))

import build_prompt_template_system as builder  # noqa: E402
import distill_templates  # noqa: E402

# What a finished, self-contained template package must contain.
KEEP_FILES = ["styles.json", "template_library.json", "template_library.md"]
KEEP_DIRS = ["blank_templates", "backgrounds"]
# Intermediates only kept when debug=True.
DEBUG_ONLY = [
    "tmp", "_vl_pages", "verify_render", "deck", "lo_export", "_resume",
    "_structure.json", "_background_clusters.json", "slide_plan.json",
    "presentation.html", "_plan_raw.txt",
]

PPT_SUFFIXES = (".pptx", ".ppt", ".pdf")


def _find_source(ppt_dir: Path) -> Path:
    """Pick the PPT/PDF to parse from the given directory (or accept a file path)."""
    p = Path(ppt_dir)
    if p.is_file() and p.suffix.lower() in PPT_SUFFIXES:
        return p
    candidates = sorted(
        (f for f in p.iterdir() if f.is_file() and f.suffix.lower() in PPT_SUFFIXES),
        key=lambda f: (f.suffix.lower() != ".pptx", f.name),  # prefer .pptx
    )
    if not candidates:
        raise FileNotFoundError(f"no .pptx/.ppt/.pdf found under {p}")
    return candidates[0]


def _zip_package(out_dir: Path, zip_path: Path) -> int:
    n = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in KEEP_FILES:
            f = out_dir / name
            if f.exists():
                zf.write(f, f.name)
                n += 1
        for d in KEEP_DIRS:
            base = out_dir / d
            if base.exists():
                for f in base.rglob("*"):
                    if f.is_file():
                        zf.write(f, str(f.relative_to(out_dir)))
                        n += 1
    return n


def _prune_intermediates(out_dir: Path) -> None:
    for name in DEBUG_ONLY:
        target = out_dir / name
        if target.is_dir():
            shutil.rmtree(target, ignore_errors=True)
        elif target.exists():
            try:
                target.unlink()
            except OSError:
                pass
    # also drop stray prescan/background sheets (_*.jpg) and any other dotfiles
    for f in out_dir.glob("_*"):
        if f.is_file():
            try:
                f.unlink()
            except OSError:
                pass


def extract_template(
    sn: str,
    user_id: str,
    ppt_dir: str | Path,
    template_id: str,
    *,
    debug: bool = False,
    config_path: str | Path | None = None,
) -> dict[str, Any]:
    """Parse one template and package it.

    Returns a dict with the completion marker and the zip path:
        {"status": "done", "sn", "user_id", "template_id", "work_dir", "zip", ...}
    """
    builder.set_log_context(sn, user_id)
    log = builder.log
    source = _find_source(Path(ppt_dir))
    work_root = _PKG.parent / "tmp"
    out_dir = work_root / f"{user_id}{template_id}"
    cfg = Path(config_path) if config_path else builder.DEFAULT_CONFIG

    log(f"[entry] START extract_template template_id={template_id} debug={debug}")
    log(f"[entry] source={source} work_dir={out_dir} config={cfg}")

    # 1) Extraction — NO verify-render (we only need style.json + assets).
    builder.build_prompt_template_system(
        source, out_dir,
        force=True, verify_render=False, resume=True, config_path=cfg,
    )

    # 2) Distill the reusable template library from styles.json.
    styles = distill_templates.load_json(out_dir / "styles.json")
    library = distill_templates.distill(styles)
    (out_dir / "template_library.json").write_text(
        json.dumps(library, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "template_library.md").write_text(
        distill_templates.to_markdown(library), encoding="utf-8")
    log(f"[entry] distilled {len(library.get('templates', []))} templates")

    # 3) Strip intermediates unless debugging.
    if not debug:
        _prune_intermediates(out_dir)
        log("[entry] pruned intermediate files (debug=False)")

    # 4) Package the necessary files into a zip.
    zip_path = work_root / f"{user_id}{template_id}.zip"
    file_count = _zip_package(out_dir, zip_path)
    log(f"[entry] zipped {file_count} file(s) -> {zip_path}")

    log("[entry] DONE")
    return {
        "status": "done",
        "sn": sn,
        "user_id": user_id,
        "template_id": template_id,
        "source": str(source),
        "work_dir": str(out_dir),
        "zip": str(zip_path),
        "templates": len(library.get("templates", [])),
        "debug": debug,
    }


def main() -> int:
    try:
        import certifi, os
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Extract a reusable PPT template package.")
    ap.add_argument("--sn", required=True)
    ap.add_argument("--user-id", required=True)
    ap.add_argument("--ppt-dir", required=True, help="directory containing the .pptx/.ppt/.pdf (or a file path)")
    ap.add_argument("--template-id", required=True)
    ap.add_argument("--config", default=None)
    ap.add_argument("--debug", action="store_true", help="keep all intermediate outputs")
    args = ap.parse_args()
    result = extract_template(
        args.sn, args.user_id, args.ppt_dir, args.template_id,
        debug=args.debug, config_path=args.config,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
