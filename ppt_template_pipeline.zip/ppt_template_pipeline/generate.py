#!/usr/bin/env python
"""Separate entry point for the GENERATION branch: document -> HTML deck.

This is intentionally NOT part of main.py (template extraction). Extraction only
produces the reusable template package; generation consumes an already-extracted
template library + a source document and lays the document's real content onto the
templates (封面 → 摘要 → 目录 → [章节封面 → 内容] × N → 总结).

Public function:
    generate_deck(sn, user_id, doc, deck_dir, debug=False) -> dict

`deck_dir` is an extracted template directory (contains template_library.json +
blank_templates/). Output: <deck_dir>/deck/slide_###.html + presentation.html.

CLI:  python generate.py --sn S1 --user-id u01 --doc report.docx --deck-dir output_kaiti [--debug]
"""
from __future__ import annotations

import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

_PKG = Path(__file__).resolve().parent / "ppt_pipeline"
sys.path.insert(0, str(_PKG))

import build_prompt_template_system as builder  # noqa: E402
import plan_deck  # noqa: E402
import render_from_plan  # noqa: E402
from generate_preview_html_fast import call_glm, load_json  # noqa: E402


def generate_deck(
    sn: str,
    user_id: str,
    doc: str | Path,
    deck_dir: str | Path,
    *,
    debug: bool = False,
    config_path: str | Path | None = None,
    workers: int = 4,
    plan_timeout: int = 1200,
    plan_max_tokens: int = 20000,
    render_timeout: int = 900,
    render_max_tokens: int = 4600,
) -> dict[str, Any]:
    builder.set_log_context(sn, user_id)
    log = builder.log
    deck_dir = Path(deck_dir)
    cfg = load_json(Path(config_path) if config_path else builder.DEFAULT_CONFIG)
    library = load_json(deck_dir / "template_library.json")
    valid = {str(t.get("id")) for t in (library.get("templates") or [])}
    templates = {str(t.get("id")): t for t in (library.get("templates") or [])}
    common_style = library.get("common_style") or {}
    design_kit = library.get("design_kit") or {}
    chrome_ref = (library.get("canonical_chrome") or {}).get("content") or next(
        ((t.get("blank_template") or {}).get("ref", "") for t in (library.get("templates") or [])
         if str(t.get("layout_kind")) not in ("cover", "chapter_cover")), "")
    default_bg = {"ref": chrome_ref}

    log(f"[gen] START doc={doc} deck_dir={deck_dir} debug={debug}")

    # 1) Plan: deterministic structure + numbering; LLM only condenses content.
    outline = plan_deck.parse_docx(Path(doc))
    log(f"[gen] parsed {len(outline['chapters'])} chapters, abstract {len(outline['abstract'])} chars")
    prompt = plan_deck.build_plan_prompt(outline, library)
    raw = call_glm(prompt, cfg, plan_timeout, plan_max_tokens, True)
    if debug:
        (deck_dir / "_plan_raw.txt").write_text(raw, encoding="utf-8")
    plan = plan_deck.extract_json(raw)
    slides = plan_deck.assemble(plan, outline, valid)
    (deck_dir / "slide_plan.json").write_text(
        json.dumps({"slides": slides}, ensure_ascii=False, indent=2), encoding="utf-8")
    from collections import Counter
    log(f"[gen] planned {len(slides)} slides; roles={dict(Counter(s['role'] for s in slides))}")

    # 2) Render each slide onto its template / custom layout.
    out_dir = deck_dir / "deck"
    out_dir.mkdir(parents=True, exist_ok=True)

    def one(slide: dict[str, Any]) -> tuple[int, str, str | None]:
        idx = int(slide.get("index") or 0)
        try:
            html = render_from_plan.render_slide(
                slide, templates, common_style, default_bg, deck_dir, cfg,
                timeout=render_timeout, max_tokens=render_max_tokens, stream=True,
                design_kit=design_kit,
            )
            (out_dir / f"slide_{idx:03d}.html").write_text(html, encoding="utf-8")
            return idx, "written", None
        except Exception as exc:  # noqa: BLE001
            return idx, "failed", f"{type(exc).__name__}: {str(exc)[:200]}"

    results: list[tuple[int, str, str | None]] = []
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        for fut in as_completed([ex.submit(one, s) for s in slides]):
            r = fut.result()
            results.append(r)
            log(f"[gen] slide {r[0]:03d}: {r[1]}" + (f" - {r[2]}" if r[2] else ""))
    render_from_plan.write_presentation(out_dir)

    ok = sum(1 for r in results if r[1] == "written")
    log(f"[gen] DONE {ok}/{len(results)} slides -> {out_dir / 'presentation.html'}")
    return {
        "status": "done", "sn": sn, "user_id": user_id,
        "deck_dir": str(deck_dir), "slides": len(slides), "rendered_ok": ok,
        "presentation": str(out_dir / "presentation.html"),
    }


def main() -> int:
    try:
        import certifi, os
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Generate an HTML deck from a document + extracted template.")
    ap.add_argument("--sn", required=True)
    ap.add_argument("--user-id", required=True)
    ap.add_argument("--doc", required=True)
    ap.add_argument("--deck-dir", required=True, help="extracted template dir (has template_library.json)")
    ap.add_argument("--config", default=None)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()
    result = generate_deck(
        args.sn, args.user_id, args.doc, args.deck_dir,
        debug=args.debug, config_path=args.config, workers=args.workers,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["rendered_ok"] == result["slides"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
