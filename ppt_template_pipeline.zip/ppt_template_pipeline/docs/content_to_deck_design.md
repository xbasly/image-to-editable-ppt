# Content → Deck: reusing an extracted template to generate a PPT from a document

Status: design (for review). Target output: HTML preview deck (same shape as
`presentation.html` produced today). No code yet.

## 0. Goal

Take a template already extracted by `build_prompt_template_system.py` (e.g.
`output_kaiti/`) plus a source document (e.g. a long `.docx` report) and produce
a good-looking, on-brand HTML slide deck whose **chrome comes from the template**
and whose **content comes from the document**.

The deck must look like it was made in this template: every slide mounts one of
the template's blank backgrounds and only the foreground text/diagram is new.

## 1. What the extracted output already gives us (the reusable template)

From `output_<deck>/`:

- `styles.json`
  - `theme`, `canvas` — colors, fonts, 1280×720.
  - `roles[*][*].template_contract` — one per parsed source page. Each is a
    **layout archetype**:
    - `layout_kind` (`cover`, `chapter_cover`/`section_divider`, `process_flow`,
      `framework`, `timeline`, `insight`, `support`, `gallery`, …)
    - `slots` — capacities: `title.max_chars`, `subtitle`, `sections.count_min/
      count_max` + `per_section.{heading_max_chars, body_max_chars, has_icon,
      has_image}`, `chart`, `images`, `callouts_max`.
    - `content_prerequisites` — `requires`, `qualitative_axes_allowed`, `notes`
      (what content fits this layout).
    - `forbid` — e.g. "long paragraphs", "more than 5 sections".
    - `style`, `visual_report` — palette + a prose description of the look.
    - `blank_template` — ref to the background HTML for this page.
- `blank_templates/*.html` — perimeter chrome per page/cluster, center empty.

Each archetype therefore couples **"what it looks like"** (blank background) with
**"what content it can hold"** (slots + prerequisites + forbid). That pairing is
exactly what a content-driven generator needs.

### 1a. The one reuse gap: canonical backgrounds

Content slides currently have **per-source-page** blank templates
(`page_004.html`, …) that are visually near-identical (same deck chrome). A
generated deck has a different number of slides than the source, so we cannot map
new slides to source pages. We need a **small set of reusable backgrounds keyed
by role**, not per source page:

| role | canonical background (picked from extraction) |
|------|-----------------------------------------------|
| `cover` | `blank_templates/cover_p001.html` |
| `agenda`/`category` | `blank_templates/category_p002.html` |
| `chapter_cover` | `blank_templates/chapter_cover_bg.html` |
| `content` | a representative content background (e.g. the most common `page_0NN.html`) |
| `ending` | `blank_templates/ending_p0NN.html` |

The manifest step (below) selects these canonical backgrounds.

## 2. New artifact: `template_manifest.json`

A distilled, deduplicated catalog the planner consumes (so the planner never sees
raw `styles.json`). Built deterministically from `styles.json`.

```jsonc
{
  "theme": { "colors": [...], "fonts": "...", "canvas": {"w":1280,"h":720} },
  "backgrounds": {            // canonical reusable background per role
    "cover": "blank_templates/cover_p001.html",
    "agenda": "blank_templates/category_p002.html",
    "chapter_cover": "blank_templates/chapter_cover_bg.html",
    "content": "blank_templates/page_004.html",
    "ending": "blank_templates/ending_p024.html"
  },
  "archetypes": [            // deduplicated layout catalog
    {
      "id": "process_flow",
      "role": "content",          // cover | agenda | chapter_cover | content | ending
      "layout_kind": "process_flow",
      "background": "blank_templates/page_004.html",
      "slots": { "title": 10, "subtitle": 20,
                 "sections": {"min":3,"max":5,
                   "per_section":{"heading":20,"body":40,"icon":true,"image":false}},
                 "chart": false, "images": 0, "callouts": 5 },
      "good_for": ["sequential content","chapters/steps/phases","short headings"],
      "forbid": ["long paragraphs","complex data charts","more than 5 sections"],
      "look": "<= 240 chars from visual_report"
    }
    // ... one per distinct (role, layout_kind)
  ]
}
```

Dedup rule: group `template_contract`s by `(role, layout_kind)`; keep one
representative per group (median slot capacities), so the planner sees ~6–10
archetypes instead of 24 pages.

Module: `template_manifest.py` → reads `styles.json`, writes
`output_<deck>/template_manifest.json`.

## 3. Pipeline (4 stages)

```
docx ──①outline──> outline.json
     ──②plan─────> slide_plan.json   (uses template_manifest.json)
     ──③render───> verify_render/*.html  (mounts blank backgrounds)
     ──④assemble─> presentation.html
```

### ① Outline extraction — `docx_outline.py`

- Parse the `.docx` (zip → `word/document.xml`; no extra deps needed, or
  `python-docx` if we add it).
- Recover hierarchy from heading/TOC styles → chapters → subsections, with body
  text and any tables/lists grouped under each node.
- For a 50k-char report this is far more than a deck can hold, so this stage also
  **condenses**: per subsection, an LLM pass produces 2–5 slide-sized key points
  (heading + ≤2 sentences) and flags any data worth a chart/timeline/comparison.
- Output `outline.json`:

```jsonc
{
  "title": "...", "subtitle": "...",
  "chapters": [
    { "heading": "...", "summary": "...",
      "subsections": [
        { "heading": "...", "points": ["...", "..."],
          "data_shape": "timeline|comparison|process|stats|none" }
      ] } ]
}
```

### ② Deck planning — `plan_deck.py` (the key stage)

- Input: `outline.json` + `template_manifest.json`.
- An LLM planner maps content → archetypes, respecting each archetype's slots,
  `good_for`, and `forbid`. It decides slide order and fills slots with **real**
  content.
- Heuristics it follows: title → `cover`; a TOC/agenda → `agenda`; each chapter →
  `chapter_cover`; `data_shape` drives layout choice (timeline→timeline,
  comparison→comparison/framework, sequence→process_flow, key takeaways→insight,
  otherwise→support); closing → `ending`.
- Output `slide_plan.json`:

```jsonc
{
  "slides": [
    { "index": 1, "archetype": "cover", "background": "blank_templates/cover_p001.html",
      "content": { "title": "西方绘画史", "subtitle": "人性、观念与权力的视觉演进" } },
    { "index": 2, "archetype": "agenda", "background": "...",
      "content": { "title": "目录", "sections": [{"heading":"史前与古典"}, ...] } },
    { "index": 5, "archetype": "timeline", "background": "...",
      "content": { "title": "...", "sections": [{"heading":"文艺复兴","body":"..."}, ...] } }
  ]
}
```

Validation pass: clamp text to slot `max_chars`, drop overflow sections, never
exceed `count_max`, honor `forbid` (split overlong content into more slides).

### ③ Render — adapt the existing renderer

`generate_preview_html_fast.py` **already** mounts a blank background and has GLM
produce the transparent foreground. Today it injects *fictional* content. Change:
feed each planned slide's **real** slotted content + its archetype contract +
`background`, reuse `apply_blank_template_frame`, `template_image_guidance`, the
short-output retry, and the diagram-style guidance unchanged.

New thin module `render_deck.py` (or a `--plan slide_plan.json` flag on the
existing script) iterates `slide_plan.json` instead of `styles.json` roles.

### ④ Assemble — `presentation.html`

Reuse the existing `write_index` / presentation writer. Output a browsable deck.

## 4. Module / file plan

```
template_manifest.py     styles.json            -> template_manifest.json
docx_outline.py          source.docx            -> outline.json   (+ LLM condense)
plan_deck.py             outline + manifest      -> slide_plan.json (LLM)
render_deck.py           slide_plan + blanks     -> verify_render/*.html, presentation.html
generate_deck_from_doc.py  driver chaining the four, into output_<deck>/deck/
```

Reused as-is: blank backgrounds, `apply_blank_template_frame`,
`template_image_guidance`, the generation prompt + retry, `call_glm`,
presentation writer.

New code: docx parsing + condense (①), planner (②), the plan-driven loop (③ glue),
manifest builder.

## 5. Open decisions

1. **Condensation depth** — how aggressively to summarize 50k chars (target slide
   count? e.g. ~25–40 slides for a 12-chapter report).
2. **Charts/timelines** — render qualitatively from points, or only when the doc
   has real numbers/tables.
3. **Per-deck vs generic manifest** — manifest is per extracted template; a new
   document reuses the same manifest.
4. **Language** — deck language follows the document (Chinese here).
5. **Images** — this template's chrome supplies imagery; content image slots stay
   placeholders unless the doc provides figures.

## 6. Suggested build order

1. `template_manifest.py` (deterministic, no LLM) — lets us inspect the archetype
   catalog immediately.
2. `docx_outline.py` (parse + condense).
3. `plan_deck.py` (planner) — review `slide_plan.json` before rendering.
4. `render_deck.py` + driver — produce `presentation.html`.
