# How a template matches a document

This explains the matching layer: given document content, pick the right template
archetype and fill it. It is grounded in the real archetypes extracted from the
kaiti template (`output_kaiti/styles.json`).

The core idea: the extraction already recorded, per page, **what content fits it**
(`content_prerequisites.requires`), **how much fits** (`slots`), and **what it must
not hold** (`forbid`). Matching = read those and route content to the best fit.

## 1. The template side — archetypes the kaiti deck exposes

| archetype (layout_kind) | role | capacity (title / sections / per-section / images) | fits when (requires) | forbids |
|---|---|---|---|---|
| `big_statement` | cover / insight | title ≤30; no sections | a main title + year/version + presenter/org | >2 lines body, charts, >2 badges |
| `process_flow` | process / agenda | title ≤10; **3–5** sections; head ≤20 | sequential content (chapters/steps/phases), short headings | long paragraphs, charts, >5 sections |
| `section_divider` | chapter header | title ≤20; no sections | a section number (01,02) + section title | body paragraphs, charts, lists |
| `timeline` | timeline | title ≤30; **4** sections; head ≤15 body ≤80 | 4 distinct phases / periods, short text each | >4 items, charts/photos in cards |
| `concept_diagram` | framework | title ≤40; **4** sections; body ≤100; 4 imgs | 4 related concepts + a central theme | >4 sections, long paragraphs, tables |
| `grid_cards` | support | title ≤30; **3** sections; body ≤100; 3 imgs | 3 distinct topics + 3 photos | >3 sections, charts, >100 chars/card |
| `support` | support | title ≤30; **2** sections; body ≤150; visuals | 2 text blocks (heading+body) + visuals | >2 blocks, dark bg |

Two things matter most for routing: the **layout_kind** (semantic shape) and the
**section count** (cardinality: 2 / 3 / 4 / 3–5).

## 2. The document side — features to detect per content unit

Split the document by its heading hierarchy (chapters → subsections). For each unit
detect a small feature vector:

- **shape**: `title` | `agenda` | `section_header` | `sequence` (steps/phases) |
  `chronology` (dated periods) | `parallel_set` (N sibling points) | `two_part`
  (compare / cause-effect) | `key_point` (one takeaway/quote) | `prose` (narrative).
- **cardinality**: number of sibling items (1, 2, 3, 4, many).
- **has_data**: contains numbers, dates, or a comparison.
- **length**: short labels vs long paragraphs (chars).
- **references_figure**: the text points at an image/figure.

`shape` + `cardinality` do most of the routing; `length` and `has_data` break ties
and trigger compression/splitting.

## 3. Routing rules (content shape → archetype)

| detected content | → archetype | reason |
|---|---|---|
| document title block | `big_statement` | requires title+year+presenter |
| table of contents / agenda (≤5 groups) | `process_flow` | sequential short headings, 3–5 |
| a chapter / part boundary | `section_divider` | number + section title |
| dated/staged evolution, **4** periods | `timeline` | 4 distinct periods |
| **4** concepts around one theme | `concept_diagram` | 4 concepts + central theme |
| **3** parallel topics (ideally with imagery) | `grid_cards` | 3 topics + 3 photos |
| **2**-part contrast or explanation | `support` | 2 text blocks + visuals |
| one strong takeaway / quote | `big_statement` | short, impactful |
| long narrative prose | compress → `grid_cards`/`support`, or split | no prose archetype; never dump paragraphs |

## 4. Fitting and overflow (capacity + forbid)

After choosing a candidate, fit the content to the slots, never violating `forbid`:

1. **Cardinality fit** — if item count is outside `[count_min, count_max]`:
   - too many → **split** across N slides (e.g. 8 steps → two `process_flow` of 4),
     or regroup (12 chapters → ~4 eras for one agenda).
   - too few → pick a lower-count archetype (3→`grid_cards`, 2→`support`).
2. **Length clamp** — summarize each heading to `heading_max_chars` and each body
   to `body_max_chars`. If the source can't be compressed that far, the unit is
   "too dense" → split it into more slides rather than overflow.
3. **Forbid enforcement** — if the unit is a long paragraph and the archetype
   forbids "long paragraphs", either compress to bullets or re-route to `support`
   (which allows ≤150-char blocks); never emit forbidden content.
4. **Images** — slots that ask for photos stay as labelled placeholders unless the
   document actually supplies a figure (the template chrome provides decoration,
   not content photos).

## 5. Matching as a scoring step

For each content unit, score every archetype and take the max:

```
score(archetype, unit) =
   + 3   if archetype.layout_kind matches unit.shape
   + 2   if unit.cardinality within [count_min, count_max]
   + 1   if unit fits capacity without heavy truncation
   - 4   if unit would violate any forbid (hard veto unless content is reshaped)
   - 1   per slot the content overflows (drives a split instead)
```

If the best score is below a floor, fall back to the most generic content
archetype (`support` or `process_flow`) and split the unit. This makes the matcher
**template-agnostic**: a different deck exposes a different archetype set, and the
same scoring picks from whatever is available (a deck with no `timeline` would
route chronologies to `process_flow`).

## 6. Worked example — 西方绘画史 report → kaiti template

The report has a title, ~12 chapters, ~37 subsections, prose, and references.

| document content | → archetype | fill |
|---|---|---|
| report title | `big_statement` | title「西方绘画史」, year「2026」, author「小艺研究」 |
| 12-chapter TOC | `process_flow` ×N | regroup 12 chapters into ~4–5 eras → 1 agenda (or 3 agenda slides of ≤5) |
| each chapter start | `section_divider` | 「01 / 史前与古典艺术」 |
| period-by-period evolution in a chapter | `timeline` (4 periods) | 文艺复兴→样式主义→巴洛克→洛可可, ≤80 chars each; >4 periods → split |
| the「人性 / 观念 / 权力」three lenses | `grid_cards` (3) | 3 cards, ≤100 chars each |
| a 4-part analytical framework | `concept_diagram` (4) | 4 concepts + central theme |
| 文艺复兴 vs 巴洛克 contrast | `support` (2) | 2 blocks, ≤150 chars each |
| a chapter's key takeaway | `big_statement` | one-line statement |
| closing | `ending` | thanks / contact |

Result: a deck of ~30–40 slides where each slide mounts the kaiti blue-ribbon
background and the foreground is real, compressed report content placed into the
archetype that fits its shape.

## 7. Where this plugs into the pipeline

This matcher is **stage ② (plan_deck)** of `content_to_deck_design.md`. Inputs:
`template_manifest.json` (the archetype catalog from §1) + `outline.json` (the
document features from §2). Output: `slide_plan.json` (chosen archetype + filled
slots per slide), which the existing renderer (`generate_deck`) turns into HTML.
