#!/usr/bin/env python
"""Build a prompt-driven HTML PPT template system from a PDF/PPTX source.

This stage extracts reusable design evidence. It does not generate a new deck.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import html
import io
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import llm_client
from image_prepare import compress_image_for_vl, render_pdf_pages_for_vl

import logging

_LOGGER: logging.Logger | None = None


# Retrieval context (sn / user_id) prepended to every core log line so a run can be
# grepped out of a shared log. Set via set_log_context() from the entry point.
_LOG_CTX = ""


def set_log_context(sn: str = "", user_id: str = "") -> None:
    """Bind sn / user_id so every subsequent log() line is tagged for retrieval."""
    global _LOG_CTX
    bits = []
    if sn:
        bits.append(f"sn={sn}")
    if user_id:
        bits.append(f"uid={user_id}")
    _LOG_CTX = ("[" + "][".join(bits) + "] ") if bits else ""


def _get_logger() -> logging.Logger:
    """Logger writing to ./log/stage_a_<timestamp>.log AND stdout for retrieval."""
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER
    logger = logging.getLogger("stage_a")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not logger.handlers:
        fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        logger.addHandler(sh)
        log_dir = Path.cwd().parent / "log"
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(log_dir / f"stage_a_{time.strftime('%Y%m%d_%H%M%S')}.log", encoding="utf-8")
            fh.setFormatter(fmt)
            logger.addHandler(fh)
        except Exception:
            pass
    _LOGGER = logger
    return logger


def log(message: str) -> None:
    """Write a tagged line (sn/user_id) to the Stage A log and stdout."""
    try:
        _get_logger().info(_LOG_CTX + message)
    except Exception:
        pass

try:
    from pydantic import BaseModel, Field, field_validator, model_validator
except ImportError:  # pragma: no cover - pydantic is expected in the runtime, fallback keeps imports usable.
    BaseModel = None  # type: ignore[assignment]
    Field = None  # type: ignore[assignment]
    field_validator = None  # type: ignore[assignment]
    model_validator = None  # type: ignore[assignment]

SERIF_KEYWORDS = {
    "song",
    "simsun",
    "songti",
    "stsong",
    "simkai",
    "kaiti",
    "fangsong",
    "times",
    "georgia",
    "palatino",
    "garamond",
    "bodoni",
    "didot",
    "cambria",
    "constantia",
    "serif",
    "mbcorpoatitle",
    "mbcorpo a title",
}

SANSSERIF_KEYWORDS = {
    "hei",
    "simhei",
    "heiti",
    "microsoft yahei",
    "yahei",
    "pingfang",
    "roboto",
    "arial",
    "helvetica",
    "sans",


    "mbcorpostext",
    "mbcorpo s text",
}

DEFAULT_CONFIG = Path(__file__).resolve().parents[1] / "config.json"
DEFAULT_STYLE_PROMPT = Path(__file__).resolve().parent / "prompts" / "extra_image.txt"

FIXED_ROLE_ALIASES = {
    "cover": ["cover"],
    "agenda": ["agenda"],
    "ending": ["ending", "summary"],
}

CONTENT_ROLES = [
    "chart",
    "timeline",
    "process",
    "framework",
    "comparison",
    "climax",
    "insight",
    "gallery",
    "support",
]
MAX_VISUAL_CONTENT_PAGES = 20
PAGE_ROLE_DEFINITIONS = {
    "climax": "Key-figures page: 1-3 core numbers or key figures; no real images, no charts.",
    "insight": "Insight page: one strong judgment or quote with large centered text and whitespace; no images or charts.",
    "support": "Support page: one conclusion backed by 2-4 arguments or metrics; chart only with complete source data.",
    "comparison": "Comparison page: 2-4 comparable objects, before/after, pros/cons, regions, options, or lessons/actions.",
    "gallery": "Gallery page: 3-4 concrete visual subjects that each need a real image; use image-text cards.",
    "timeline": "Timeline page: years, phases, milestones, or staged evolution; pure HTML/CSS timeline.",
    "process": "Process page: mechanisms, cause-effect chains, steps, funnels, cycles, branches, or action flows.",
    "framework": "Framework page: models, dimensions, matrices, pyramids, architectures, Venn, radial, or classification systems.",
    "chart": "Chart page: only when structured numeric source data is sufficient; otherwise use support/framework.",
    "section_divider": "Section divider: decorative chapter-transition page with no body text slots; carries only a short chapter title. Single-use; never assigned body content.",
    "legal_disclaimer": "Legal/boilerplate page: dense legal disclaimer or forward-looking statement; single-use template, never reused for normal content.",
}
# Roles that must NEVER receive body content during generation. Kept separate
# from CONTENT_ROLES so Stage B can exclude them from the content template pool.
NONCONTENT_ROLES = ["cover", "chapter_cover", "section_divider", "legal_disclaimer"]
LAYOUT_KIND_TO_ROLE = {
    "quant_chart": "chart",
    "concept_diagram": "framework",
    "comparison": "comparison",
    "timeline": "timeline",
    "process_flow": "process",
    "framework": "framework",
    "grid_cards": "support",
    "table": "support",
    "data_highlight": "climax",
    "big_statement": "insight",
    "image_showcase": "gallery",
    "cover": "cover",
    "chapter_cover": "chapter_cover",
    "section_divider": "section_divider",
    "legal_disclaimer": "legal_disclaimer",
    "support": "support",
    "other": "support",
}
VALID_LAYOUT_KINDS = set(LAYOUT_KIND_TO_ROLE)

# Phrase markers for boilerplate detection in the post-extraction classifier.
_LEGAL_MARKERS = (
    "forward-looking statement", "forward looking statement", "safe harbor",
    "legal disclaimer", "disclaimers", "certain statements in this presentation",
    "risks and uncertainties", "non-gaap", "sec filing",
    "免责声明", "前瞻性陈述", "法律声明", "本演示文稿",
)
_DIVIDER_MARKERS = (
    "section divider", "divider slide", "section break", "transition slide",
    "branding", "chapter divider", "title slide",
)


def classify_noncontent_role(contract: dict[str, Any], font_analysis: str = "") -> str | None:
    """Deterministic post-extraction check: is this a single-use boilerplate page?

    Returns a noncontent kind ('cover' | 'chapter_cover' | 'legal_disclaimer')
    when the contract describes a non-reusable page, else None. Runs on structured
    fields + text evidence, so it corrects VL mislabels (e.g. a divider tagged
    image_showcase, a legal page tagged support) without trusting the VL
    layout_kind enum alone.
    """
    # Respect an explicit noncontent classification the VL already made; the new
    # prompt distinguishes cover vs chapter_cover (helped by the structural hint),
    # so do not collapse them back into a generic divider.
    explicit = str(contract.get("layout_kind") or "").strip().lower()
    if explicit not in {"cover", "chapter_cover", "legal_disclaimer"}:
        explicit = str(contract.get("noncontent_kind") or "").strip().lower()
    if explicit in {"cover", "chapter_cover", "legal_disclaimer"}:
        return explicit
    slots = contract.get("slots") or {}

    def present(name: str) -> bool:
        return bool((slots.get(name) or {}).get("present"))

    sections = slots.get("sections") or {}
    has_text_slot = present("title") or present("subtitle") or int(sections.get("count_max") or 0) > 0
    images = int((slots.get("images") or {}).get("count") or 0)

    notes = str((contract.get("content_prerequisites") or {}).get("notes") or "").lower()
    report = str(contract.get("visual_report") or "").lower()
    font_sample = str(font_analysis or "").lower()
    haystack = " ".join((notes, report, font_sample))

    # Legal / forward-looking boilerplate — strongest signal is the text itself.
    if any(m in haystack for m in _LEGAL_MARKERS):
        return "legal_disclaimer"
    # Chapter divider — no body text slots, decorative only. (The structural
    # prescan separately distinguishes a true cover from a chapter divider for
    # clustering; here we only flag the page as non-reusable.)
    if not has_text_slot and images <= 1:
        return "chapter_cover"
    # VL explicitly described a divider even if it filled slots oddly.
    if any(m in haystack for m in _DIVIDER_MARKERS) and not has_text_slot:
        return "chapter_cover"
    return None


if BaseModel is not None:
    class TemplateTextSlot(BaseModel):
        present: bool = False
        max_chars: int = 0

        @field_validator("max_chars", mode="before")
        @classmethod
        def _int_value(cls, value: Any) -> int:
            return int(value or 0)


    class TemplateSectionSlot(BaseModel):
        count_min: int = 0
        count_max: int = 0
        per_section: dict[str, Any] = Field(default_factory=dict)


    class TemplateChartSlot(BaseModel):
        present: bool = False
        series_min: int | None = None
        series_max: int | None = None
        points_per_series_min: int | None = None
        points_per_series_max: int | None = None


    class TemplateImageSlot(BaseModel):
        count: int = 0
        aspect: str | None = None


    class TemplateSlots(BaseModel):
        title: TemplateTextSlot = Field(default_factory=TemplateTextSlot)
        subtitle: TemplateTextSlot = Field(default_factory=TemplateTextSlot)
        sections: TemplateSectionSlot = Field(default_factory=TemplateSectionSlot)
        chart: TemplateChartSlot = Field(default_factory=TemplateChartSlot)
        images: TemplateImageSlot = Field(default_factory=TemplateImageSlot)
        callouts_max: int = 0


    class TemplatePrerequisites(BaseModel):
        requires: list[str] = Field(default_factory=list)
        qualitative_axes_allowed: bool = False
        notes: str = ""


    class TemplateStrokeLanguage(BaseModel):
        kind: str = "straight_geometric"
        details: str = ""
        reproduction_hint: str = ""


    class TemplateStyle(BaseModel):
        design_style: dict[str, Any] = Field(default_factory=dict)
        colors: list[dict[str, Any]] = Field(default_factory=list)
        typography: str = ""
        typography_tokens: dict[str, Any] = Field(default_factory=dict)
        stroke_language: TemplateStrokeLanguage = Field(default_factory=TemplateStrokeLanguage)
        text_box_decoration: str = ""
        background: str = ""


    class TemplateContract(BaseModel):
        schema_version: str = "template_contract.v1"
        layout_kind: str = "other"
        layout_kind_confidence: str = "low"
        chart_subtype: str | None = None
        slots: TemplateSlots = Field(default_factory=TemplateSlots)
        title_zone: dict[str, Any] = Field(default_factory=dict)
        content_prerequisites: TemplatePrerequisites = Field(default_factory=TemplatePrerequisites)
        forbid: list[str] = Field(default_factory=list)
        suggested_fallbacks: list[str] = Field(default_factory=list)
        style: TemplateStyle = Field(default_factory=TemplateStyle)
        image_asset_policy: dict[str, Any] = Field(default_factory=dict)
        background_strategy: dict[str, Any] = Field(default_factory=dict)
        visual_report: str = ""
        noncontent_kind: str | None = None

        @field_validator("layout_kind")
        @classmethod
        def _valid_layout_kind(cls, value: str) -> str:
            normalized = str(value or "other").strip().lower()
            return normalized if normalized in VALID_LAYOUT_KINDS else "other"

        @model_validator(mode="before")
        @classmethod
        def _normalize_null_strings(cls, data: Any) -> Any:
            return normalize_contract_nulls(data)


def normalize_contract_nulls(value: Any) -> Any:
    if isinstance(value, dict):
        # Only coerce explicit nulls on the stroke_language keys; do NOT inject
        # these keys into unrelated dicts (e.g. typography_tokens) that never had
        # them, which would pollute the captured style data.
        for key in ("kind", "details", "reproduction_hint"):
            if key in value and value[key] is None:
                value[key] = ""
        return {key: normalize_contract_nulls(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_contract_nulls(item) for item in value]
    if isinstance(value, str) and value.strip().lower() == "null":
        return None
    return value


def font_sizes_from_analysis(font_analysis: str) -> list[float]:
    # New metadata format reports measured sizes as "Sizes(px): 40px, 24px, ...";
    # fall back to the legacy "Font size: X pt" form for older cached metadata.
    px = [float(m) for m in re.findall(r"([0-9.]+)\s*px", font_analysis)]
    if px:
        return px
    return [float(match) for match in re.findall(r"Font size:\s*([0-9.]+)\s*pt", font_analysis)]


def realistic_font_sizes(font_analysis: str) -> list[float]:
    sizes = font_sizes_from_analysis(font_analysis)
    return [size for size in sizes if 6 <= size <= 96]


def max_chars_for_font_size(size: float, width_ratio: float = 0.78) -> int:
    if size >= 64:
        return 32
    if size >= 48:
        return 46
    if size >= 36:
        return 70
    if size >= 28:
        return 100
    if size >= 20:
        return 140
    return 180


def clamp_contract_capacity(contract: dict[str, Any], font_analysis: str) -> dict[str, Any]:
    sizes = realistic_font_sizes(font_analysis)
    title_size = max(sizes) if sizes else 48
    subtitle_size = sorted(sizes, reverse=True)[1] if len(sizes) > 1 else min(title_size, 36)
    slots = contract.setdefault("slots", {})
    title = slots.setdefault("title", {})
    subtitle = slots.setdefault("subtitle", {})
    if isinstance(title, dict) and title.get("present"):
        current = int(title.get("max_chars") or 0)
        title["max_chars"] = min(current or max_chars_for_font_size(title_size), max_chars_for_font_size(title_size))
    if isinstance(subtitle, dict) and subtitle.get("present"):
        current = int(subtitle.get("max_chars") or 0)
        subtitle["max_chars"] = min(current or max_chars_for_font_size(subtitle_size), max_chars_for_font_size(subtitle_size))
    sections = slots.setdefault("sections", {})
    per_section = sections.setdefault("per_section", {}) if isinstance(sections, dict) else {}
    if isinstance(per_section, dict):
        for key, cap in [("heading_max_chars", 60), ("body_max_chars", 180)]:
            current = int(per_section.get(key) or 0)
            if current:
                per_section[key] = min(current, cap)
    return contract


def parse_template_contract(text: str, font_analysis: str = "") -> dict[str, Any]:
    data = extract_json_object(text)
    if not isinstance(data, dict) or data.get("schema_version") != "template_contract.v1":
        return {}
    data = normalize_contract_nulls(data)
    if BaseModel is not None:
        contract = TemplateContract.model_validate(data).model_dump()
    else:
        contract = data
    contract = clamp_contract_capacity(contract, font_analysis)
    # Deterministic boilerplate correction: overrides a VL mislabel (e.g. divider
    # tagged image_showcase, legal page tagged support) so downstream gating and
    # the Stage B content pool treat these pages as single-use, not reusable.
    noncontent = classify_noncontent_role(contract, font_analysis)
    if noncontent:
        prev = contract.get("layout_kind")
        contract["layout_kind"] = noncontent
        contract["noncontent_kind"] = noncontent
        if prev != noncontent:
            contract.setdefault("classification_notes", []).append(
                f"reclassified from '{prev}' to '{noncontent}' by post-extraction boilerplate check"
            )
    return contract


def role_from_template_contract(contract: dict[str, Any], fallback: str = "support") -> str:
    noncontent = contract.get("noncontent_kind")
    if noncontent in NONCONTENT_ROLES:
        return noncontent
    layout_kind = str(contract.get("layout_kind") or "other")
    return LAYOUT_KIND_TO_ROLE.get(layout_kind, fallback)


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_config(path: Path) -> dict[str, Any]:
    config = read_json(path)
    retry_status_codes = config.get("vl_retry_status_codes") or [408, 429, 500, 502, 503, 504]
    vision = config.get("vision") or {}
    # GLM (or any text LLM) used to synthesize blank layout-skeleton HTML in Stage A.
    # Falls back to the vision endpoint/key when a dedicated one isn't configured.
    generation = config.get("generation") or config.get("glm") or {}
    return {
        "vl_concurrency": int(config.get("vl_concurrency") or 3),
        "vl_retry_attempts": max(1, int(config.get("vl_retry_attempts") or 3)),
        "vl_retry_backoff_seconds": max(0.0, float(config.get("vl_retry_backoff_seconds") or 2.0)),
        "vl_retry_status_codes": [int(code) for code in retry_status_codes],
        "vision": {
            "api_key": str(vision.get("api_key") or ""),
            "base_url": str(vision.get("base_url") or ""),
            "model": str(vision.get("model") or ""),
        },
        "generation": {
            "api_key": str(generation.get("api_key") or vision.get("api_key") or ""),
            "base_url": str(generation.get("base_url") or vision.get("base_url") or ""),
            "model": str(generation.get("model") or "glm-4.6"),
        },
        # Per-page extraction budgets: how many pages to extract when the deck has
        # chapter structure vs when it doesn't.
        "extraction_budget_with_chapters": int(config.get("extraction_budget_with_chapters") or 20),
        "extraction_budget_without_chapters": int(config.get("extraction_budget_without_chapters") or 10),
        "structure_max_pages": int(config.get("structure_max_pages") or 80),
    }


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def safe_read_json(path: Path) -> dict[str, Any]:
    try:
        return read_json(path)
    except (OSError, json.JSONDecodeError):
        return {}


def short_hash(text: str) -> str:
    """Stable short hash used to key caches on prompt content."""
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()[:16]


def _page_from_rendered_name(path: Path) -> int:
    match = re.search(r"(?:page|verify)_(\d+)", path.stem)
    return int(match.group(1)) if match else 0


def load_existing_rendered_pages(vl_dir: Path, styles: dict[str, Any] | None = None) -> tuple[list[dict[str, Any]], dict[int, dict[str, str]], list[str]]:
    """Restore Stage A rendered-page state from existing files."""
    styles = styles or {}
    existing = {path.resolve(): path for path in vl_dir.glob("page_*.jpg") if path.is_file()}
    rendered: list[dict[str, Any]] = []
    for item in ((styles.get("vision") or {}).get("rendered_pages") or []):
        if not isinstance(item, dict):
            continue
        page = int(item.get("page") or 0)
        path = Path(str(item.get("output") or item.get("path") or ""))
        if not path.is_absolute():
            path = vl_dir.parent / path
        if page and path.exists():
            restored = dict(item)
            restored["page"] = page
            restored["output"] = str(path)
            restored.setdefault("path", str(path))
            rendered.append(restored)
            existing.pop(path.resolve(), None)
    for path in sorted(existing.values(), key=_page_from_rendered_name):
        page = _page_from_rendered_name(path)
        if page:
            rendered.append({"page": page, "output": str(path), "path": str(path)})
    return rendered, {}, []


def styles_have_roles(styles: dict[str, Any]) -> bool:
    roles = styles.get("roles")
    return isinstance(roles, dict) and any(isinstance(items, list) and items for items in roles.values())


def styles_pages_with_contracts(styles: dict[str, Any]) -> set[int]:
    pages: set[int] = set()
    for items in (styles.get("roles") or {}).values():
        if not isinstance(items, list):
            continue
        for item in items:
            if isinstance(item, dict) and item.get("template_contract"):
                page = int(item.get("page") or 0)
                if page:
                    pages.add(page)
    return pages


def styles_complete_for_pages(styles: dict[str, Any], pages: set[int]) -> bool:
    return bool(pages) and pages.issubset(styles_pages_with_contracts(styles))


def copy_tree(src: Path, dst: Path) -> None:
    if dst.exists():
        shutil.rmtree(dst)
    if src.exists():
        shutil.copytree(src, dst)


def remove_obsolete_outputs(output_dir: Path, keep_cache: bool = False) -> None:
    # When keep_cache is set, preserve the per-page extraction cache and rendered
    # page images so a re-run skips the expensive VL pass for already-done pages.
    cache_names = {"_resume", "_vl_pages", "backgrounds", "blank_templates", "lo_export", "styles.json", "_structure.json", "_layout_clusters.json", "_background_clusters.json"}
    for name in [
        "_resume",
        "_vl_pages",
        "assets",
        "backgrounds",
        "blank_templates",
        "lo_export",
        "components",
        "fixed_pages",
        "fixed_templates",
        "reference_html",
        "visual_briefs",
        "vl_pages",
        "analysis.json",
        "asset_manifest.json",
        "global_design_brief.md",
        "negative_constraints.md",
        "styles.json",
    ]:
        if keep_cache and name in cache_names:
            continue
        path = output_dir / name
        if path.is_dir():
            shutil.rmtree(path)
        elif path.exists():
            path.unlink()


def normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/").removesuffix("/v1").rstrip("/") + "/v1"


def response_text(data: dict[str, Any]) -> str:
    if not isinstance(data, dict):
        return ""
    choices = data.get("choices") or []
    if not choices or not isinstance(choices[0], dict):
        return ""
    message = choices[0].get("message")
    if not isinstance(message, dict):
        return ""
    content = message.get("content")
    text = ""
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        text = "\n".join(str(item.get("text") or "") for item in content if isinstance(item, dict))
    # Some reasoning models (e.g. GLM) may leave content empty and place the
    # answer in reasoning_content; fall back to it so we don't treat it as empty.
    if not text.strip():
        rc = message.get("reasoning_content")
        if isinstance(rc, str):
            text = rc
    return text


def stream_delta_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") or []
    if not choices or not isinstance(choices[0], dict):
        return ""
    choice = choices[0]
    if choice.get("finish_reason") == "aborted":
        raise RuntimeError(f"generation aborted: {json.dumps(data, ensure_ascii=False)[:500]}")
    delta = choice.get("delta") if isinstance(choice.get("delta"), dict) else {}
    content = delta.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(item.get("text") or "") for item in content if isinstance(item, dict))
    # reasoning = delta.get("reasoning")
    # if isinstance(reasoning, str):
    #     return reasoning
    # rc = delta.get("reasoning_content")
    # if isinstance(rc, str):
    #     return rc
    message = choice.get("message") if isinstance(choice.get("message"), dict) else {}
    return response_text({"choices": [{"message": message}]})


def read_streaming_text_chat_response(resp: Any, trace_label: str) -> str:
    chunks: list[str] = []
    first_payload = True
    for raw_line in resp:
        line = raw_line.decode("utf-8", errors="ignore").strip()
        if not line:
            continue
        if not line.startswith("data:"):
            if first_payload:
                raise RuntimeError(f"generation service returned non-SSE response: {line[:500]}")
            continue
        first_payload = False
        payload = line.removeprefix("data:").strip()
        if payload == "[DONE]":
            break
        try:
            data = json.loads(payload)
            unwrap_guard = 0
            while isinstance(data, str) and unwrap_guard < 3:
                data = json.loads(data)
                unwrap_guard += 1
            if not isinstance(data, dict):
                raise RuntimeError(f"generation service returned unexpected streaming payload: {str(data)[:500]}")
        except json.JSONDecodeError as exc:
            log(f"[{trace_label}] streaming JSON parse failed ({exc}); payload head: {payload[:1000]}")
            raise json.JSONDecodeError("generation stream contained invalid JSON", exc.doc, exc.pos) from exc
        delta_text = stream_delta_text(data)
        if delta_text:
            print(delta_text, end="", flush=True)
            chunks.append(delta_text)
    return "".join(chunks)


def trace_step(tmp_dir: Path | None, step: str, *, prompt: str = "", response: str = "", image: Path | None = None, meta: dict[str, Any] | None = None) -> None:
    """Persist a model interaction (prompt / image ref / response) under tmp/ for inspection."""
    if tmp_dir is None:
        return
    try:
        d = tmp_dir / step
        d.mkdir(parents=True, exist_ok=True)
        if prompt:
            (d / "prompt.txt").write_text(prompt, encoding="utf-8")
        if response:
            response_name = "response.txt"
            (d / response_name).write_text(response, encoding="utf-8")
        if image is not None and Path(image).exists():
            import shutil as _sh
            _sh.copy(image, d / Path(image).name)
        if meta:
            (d / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def strip_code_fences(text: str) -> str:
    s = (text or "").strip()
    if s.startswith("```"):
        s = re.sub(r"^```[a-zA-Z]*\n", "", s)
        s = re.sub(r"\n```\s*$", "", s)
    return s


def extract_json_object(text: str) -> dict[str, Any]:
    try:
        return json.loads(text)
    except Exception:
        pass
    import re

    match = re.search(r"\{.*\}", text, flags=re.S)
    if not match:
        return {}
    try:
        return json.loads(match.group(0))
    except Exception:
        return {}


def role_definitions_prompt() -> str:
    return "\n".join(f"- {role}: {definition}" for role, definition in PAGE_ROLE_DEFINITIONS.items())


def normalize_page_role(role: Any, fallback: str = "support") -> str:
    value = str(role or "").strip().lower().replace("-", "_")
    aliases = {"summary": "ending", "directory": "agenda", "closing": "ending"}
    value = aliases.get(value, value)
    return value if value in PAGE_ROLE_DEFINITIONS else fallback


def extract_layout_zones_payload(text: str) -> dict[str, Any]:
    candidates: list[str] = []
    candidates.extend(re.findall(r"```json\s*(\{.*?\})\s*```", text, flags=re.I | re.S))
    candidates.extend(re.findall(r"```\s*(\{.*?\})\s*```", text, flags=re.S))
    if not candidates:
        match = re.search(r"\{\s*\"layout_family\".*\}", text, flags=re.S)
        if match:
            candidates.append(match.group(0))
    for candidate in reversed(candidates):
        try:
            data = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict) and ("layout_zones" in data or "fixed_elements" in data):
            return data
    return {}


def image_asset_prompt_summary(images: list[dict[str, Any]] | None) -> str:
    items = images or []
    if not items:
        return "No extracted image assets were found on this page."
    lines = [
        "Extracted image assets from this page. Classify each asset before deciding whether generation should reuse it:",
    ]
    for idx, im in enumerate(items, 1):
        left = float(im.get("left_pct") or 0)
        top = float(im.get("top_pct") or 0)
        width = float(im.get("width_pct") or 0)
        height = float(im.get("height_pct") or 0)
        full_canvas = left <= 3 and top <= 3 and width >= 94 and height >= 88
        lines.append(
            f"- asset_{idx}: file={im.get('file', '')}; position=left {left:.1f}%, top {top:.1f}%, "
            f"size {width:.1f}% x {height:.1f}%; likely_full_canvas_background={str(full_canvas).lower()}; "
            f"oversized={str(bool(im.get('oversized'))).lower()}"
        )
    return "\n".join(lines)


def build_visual_role_prompt(style_prompt_template: str, metadata: dict[str, str], image_assets: list[dict[str, Any]] | None = None, structural_role: str = "") -> str:
    prompt = style_prompt_template.replace("{font_analysis}", metadata.get("font_analysis", ""))
    prompt = prompt.replace("{color_analysis}", metadata.get("color_analysis", ""))
    prompt = prompt.replace("{image_asset_analysis}", image_asset_prompt_summary(image_assets))
    prompt = prompt.replace("{structural_role}", structural_role or "未知（以截图为准）")
    if "template_contract.v1" in prompt:
        return prompt
    return f"""{prompt}

Keep the original Markdown report format and section structure above. Append only the following two sections at the end:

## 6. Page Role Judgment

Choose the best page role from the definitions below based on visible content structure, layout capacity, and visual arrangement. Do not use code heuristics. Do not output JSON.

Available page role definitions:
{role_definitions_prompt()}

The appended section must use exactly this format:

## 6. Page Role Judgment
- page_role: support|timeline|process|framework|comparison|insight|chart|climax|gallery

## 7. Layout Zones And Reusable Fixed Elements
Output one compact JSON object in a fenced json block. Estimate 1280x720 pixel coordinates from the screenshot.
Do not assume every page has a title zone. Set has_title_zone=false for section covers, chapter dividers, full-bleed pages, quote pages, or pages whose content intentionally starts near the top.
Identify reusable fixed elements only when visibly present: title system, section label, footer text, page number, logo/brand mark, decorative line/block.

```json
{{
  "layout_family": "normal_content|chapter_divider|cover_like|summary|full_bleed|special",
  "layout_zones": {{
    "has_title_zone": true,
    "title_zone": {{"x": 48, "y": 36, "width": 900, "height": 105, "bottom": 141}},
    "main_content_zone": {{"x": 48, "y": 155, "width": 1184, "height": 500}},
    "footer_zone": {{"exists": true, "x": 48, "y": 660, "width": 1184, "height": 32}}
  }},
  "fixed_elements": [
    {{"type": "section_label|page_number|footer_text|logo|decorative_line|decorative_block", "exists": true, "position": "top-left|top-right|bottom-left|bottom-right", "x": 0, "y": 0, "width": 0, "height": 0, "style": "short visual style"}}
  ],
  "layout_constraints": {{
    "main_content_start_y": 155,
    "main_content_bottom_y": 650,
    "card_top_min": 155,
    "card_height_max": 360,
    "overflow_risk": "low|medium|high"
  }}
}}
```
"""


def parse_visual_report_payload(text: str, fallback_role: str, fallback_layout: str, font_analysis: str = "") -> dict[str, Any]:
    contract = parse_template_contract(text, font_analysis)
    if contract:
        role = role_from_template_contract(contract, normalize_page_role(fallback_role))
        return {
            "page_role": role,
            "page_role_definition": PAGE_ROLE_DEFINITIONS.get(role, ""),
            "template_contract": contract,
            "visual_report": contract.get("visual_report") or text,
            "layout_affordance": fallback_layout,
            "layout_zones": {},
            "fixed_elements": [],
            "layout_constraints": {},
            "layout_family": str(contract.get("layout_kind") or ""),
        }
    match = re.search(r"page_role\s*:\s*([a-zA-Z_/-]+)", text, flags=re.I)
    role = normalize_page_role(match.group(1) if match else "", normalize_page_role(fallback_role))
    structured = extract_layout_zones_payload(text)
    return {
        "page_role": role,
        "page_role_definition": PAGE_ROLE_DEFINITIONS.get(role, ""),
        "visual_report": text,
        "layout_affordance": fallback_layout,
        "layout_zones": structured.get("layout_zones") or {},
        "fixed_elements": structured.get("fixed_elements") or [],
        "layout_constraints": structured.get("layout_constraints") or {},
        "layout_family": structured.get("layout_family") or "",
    }


def is_retryable_vl_error(exc: Exception, retry_status_codes: set[int]) -> bool:
    if isinstance(exc, urllib.error.HTTPError):
        return int(exc.code) in retry_status_codes
    if isinstance(exc, (urllib.error.URLError, TimeoutError, socket.timeout, json.JSONDecodeError, RuntimeError)):
        return True
    return False


def request_vl_report_once(
    image_path: Path,
    prompt: str,
    base_url: str,
    model: str,
    api_key: str,
    timeout: int,
) -> str:
    # All VL HTTP lives in the shared llm_client; this keeps the retry wrapper here.
    return llm_client.vl_complete(
        image_path, prompt,
        cfg=llm_client.LLMConfig(base_url=base_url, api_key=api_key, model=model, timeout=timeout),
    )


# Pluggable VL backend. Register your own VL function via set_vl_backend(fn).
# The function receives (image_path: Path, prompt: str) and must return the model's
# answer text (a string). If it returns a dict with "answer"/"think", "answer" is used.
_VL_BACKEND = None


def set_vl_backend(fn) -> None:
    """Register a custom VL backend. fn(image_path: Path, prompt: str) -> str | dict.

    Use this to route all VL calls (prescan, per-page extraction, clustering) to a
    self-hosted endpoint instead of the built-in OpenAI-style client. If fn returns
    a dict, the 'answer' field is used (a 'think' field, if present, is ignored).
    """
    global _VL_BACKEND
    _VL_BACKEND = fn


def _vl_backend_answer(result: Any) -> str:
    """Normalize a custom backend's return into the answer text used downstream."""
    if isinstance(result, dict):
        return str(result.get("answer") or result.get("content") or "")
    return str(result or "")


def request_vl_report(
    image_path: Path,
    prompt: str,
    base_url: str,
    model: str,
    api_key: str,
    timeout: int,
    retry_attempts: int,
    retry_backoff_seconds: float,
    retry_status_codes: list[int],
) -> str:
    # If a custom VL backend is registered, route through it (with the same retry policy).
    if _VL_BACKEND is not None:
        attempts = max(1, retry_attempts)
        last_error: Exception | None = None
        for attempt in range(1, attempts + 1):
            try:
                answer = _vl_backend_answer(_VL_BACKEND(image_path, prompt))
                if not str(answer).strip():
                    raise RuntimeError("custom VL backend returned empty answer")
                return answer
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                if attempt >= attempts:
                    raise
                delay = retry_backoff_seconds * (2 ** (attempt - 1))
                if delay > 0:
                    time.sleep(delay)
        if last_error:
            raise last_error
        raise RuntimeError("custom VL backend failed without an error")

    attempts = max(1, retry_attempts)
    retry_status_set = {int(code) for code in retry_status_codes}
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return request_vl_report_once(image_path, prompt, base_url, model, api_key, timeout)
        except Exception as exc:
            last_error = exc
            if attempt >= attempts or not is_retryable_vl_error(exc, retry_status_set):
                raise
            delay = retry_backoff_seconds * (2 ** (attempt - 1))
            if delay > 0:
                time.sleep(delay)
    if last_error:
        raise last_error
    raise RuntimeError("VL request failed without an error")


def request_text_chat(
    prompt: str,
    base_url: str,
    model: str,
    api_key: str,
    timeout: int,
    retry_attempts: int = 3,
    retry_backoff_seconds: float = 2.0,
    retry_status_codes: list[int] | None = None,
    tmp_dir: Path | None = None,
    trace_label: str = "text_chat",
    stream: bool = True,
) -> str:
    """Plain text chat completion (used for GLM blank-skeleton HTML generation).

    stream=True reads an SSE response; stream=False reads one JSON body (use this
    for endpoints that do not support server-sent events). extra_body is only sent
    for GLM models, since it is a GLM-specific field other OpenAI-compatible
    endpoints reject.
    """
    retry_set = {int(c) for c in (retry_status_codes or [408, 429, 500, 502, 503, 504])}
    cfg = llm_client.LLMConfig(base_url=base_url, api_key=api_key, model=model, timeout=timeout)
    last_error: Exception | None = None
    for attempt in range(1, max(1, retry_attempts) + 1):
        try:
            # All chat HTTP/streaming lives in the shared llm_client.
            return llm_client.chat_complete(prompt, cfg=cfg, max_tokens=16000, stream=stream, log=log)
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            status = getattr(exc, "code", None)
            # On HTTP errors, GLM usually returns an error body — log it.
            if isinstance(exc, urllib.error.HTTPError):
                try:
                    err_body = exc.read().decode("utf-8", "ignore")[:2000]
                    log(f"[{trace_label}] HTTP {status} error; body: {err_body}")
                except Exception:
                    log(f"[{trace_label}] HTTP {status} error (no readable body)")
            if attempt >= max(1, retry_attempts) or (status is not None and status not in retry_set):
                raise
            delay = retry_backoff_seconds * (2 ** (attempt - 1))
            log(f"[{trace_label}] retrying generation request after attempt {attempt}/{max(1, retry_attempts)}")
            if delay > 0:
                time.sleep(delay)
    if last_error:
        raise last_error
    raise RuntimeError("generation request failed without an error")


def cluster_layouts_with_vl(
    rendered_pages: list[dict[str, Any]],
    contracts_by_page: dict[int, dict[str, Any]],
    output_dir: Path,
    *,
    vision_base_url: str,
    vision_model: str,
    vision_api_key: str,
    vision_timeout: int,
    vl_retry_attempts: int,
    vl_retry_backoff_seconds: float,
    vl_retry_status_codes: list[int],
    tmp_dir: Path | None = None,
) -> list[dict[str, Any]]:
    """Group content pages into shared layout clusters (layout_kind seed + VL refine).

    Each cluster = pages that share a layout skeleton (background, logo position,
    decorative motifs, primary partition like full-bleed/left-right/top-bottom).
    One blank skeleton HTML is later generated per cluster so same-cluster pages
    render with identical chrome. Returns a list of cluster dicts.
    """
    log("layout seletion")
    if not vision_api_key or not rendered_pages:
        return []
    # Seed: coarse groups from layout_kind so the VL refines within structure, not noise.
    seed = {}
    for page, contract in contracts_by_page.items():
        seed[str(page)] = str(contract.get("layout_kind") or "other")
    sheet = build_contact_sheet(rendered_pages, output_dir / "_cluster_contact_sheet.jpg")
    if sheet is None:
        return []
    sheet_path, order = sheet
    prompt = f"""You are grouping slide pages into shared LAYOUT SKELETON clusters.
This is a contact sheet, each cell labeled p<number>. Page order: {order}.
A coarse seed grouping by layout type is provided; refine it by actual visual skeleton.

Seed (page -> layout_kind): {json.dumps(seed, ensure_ascii=False)}

Cluster pages that share the SAME reusable skeleton — meaning same background treatment,
same logo placement, same decorative motifs, and the same primary partition
(e.g. full-bleed / left-right split / top-title-bottom-content / centered). Pages with
different content but identical chrome belong to the SAME cluster.

Return JSON only:
{{
  "clusters": [
    {{
      "cluster_id": "layout_a",
      "label": "short human name (e.g. 左右分栏 / 上标题下内容 / 黑底全幅)",
      "pages": [<page numbers>],
      "skeleton": {{
        "background": "<bg description: color/image/gradient>",
        "logo": "<logo position or none>",
        "decorations": "<recurring decorative motifs/lines/shapes>",
        "partition": "<full_bleed | left_right | top_bottom | centered | grid | other>",
        "representative_page": <the clearest page number for this cluster>
      }}
    }}
  ]
}}
Rules:
- EXCLUDE the cover/title page and the table-of-contents/agenda page entirely — do NOT put them in any cluster (they are standalone and handled separately).
- Every remaining content page must belong to exactly one cluster; aim for 2-5 clusters.
- Do not over-split (minor content differences are not new clusters)."""
    try:
        # Contact-sheet calls are one big request; give them a longer ceiling than
        # per-page extraction so a slow VL endpoint doesn't time out.
        heavy_timeout = max(int(vision_timeout) * 3, 300)
        raw = request_vl_report(
            sheet_path, prompt, vision_base_url, vision_model, vision_api_key,
            heavy_timeout, vl_retry_attempts, vl_retry_backoff_seconds, vl_retry_status_codes,
        )
        trace_step(tmp_dir, "02_cluster", prompt=prompt, response=raw, image=sheet_path)
        data = extract_json_object(raw)
    except Exception as exc:  # noqa: BLE001
        log(f"[cluster] WARNING: layout clustering failed ({type(exc).__name__}: {str(exc)[:160]}); no shared skeletons")
        return []
    clusters = data.get("clusters") if isinstance(data, dict) else None
    if not isinstance(clusters, list) or not clusters:
        return []
    cleaned = []
    for i, c in enumerate(clusters, 1):
        if not isinstance(c, dict):
            continue
        pages = [int(p) for p in (c.get("pages") or []) if str(p).strip().isdigit()]
        if not pages:
            continue
        cleaned.append({
            "cluster_id": str(c.get("cluster_id") or f"layout_{i}"),
            "label": str(c.get("label") or f"cluster {i}"),
            "pages": pages,
            "skeleton": c.get("skeleton") if isinstance(c.get("skeleton"), dict) else {},
        })
    if cleaned:
        log(f"[cluster] {len(cleaned)} layout clusters: " + ", ".join(f"{c['label']}({len(c['pages'])}p)" for c in cleaned))
    return cleaned


def style_records_by_page(styles: dict[str, Any]) -> dict[int, dict[str, Any]]:
    records: dict[int, dict[str, Any]] = {}
    for role, items in (styles.get("roles") or {}).items():
        for item in items or []:
            if not isinstance(item, dict):
                continue
            page = int(item.get("page") or 0)
            if not page:
                continue
            record = dict(item)
            record.setdefault("role", role)
            records[page] = record
    return records


def rendered_pages_for_numbers(rendered_pages: list[dict[str, Any]], pages: set[int]) -> list[dict[str, Any]]:
    return [
        item for item in rendered_pages
        if int(item.get("page") or 0) in pages
        and Path(str(item.get("output") or item.get("path") or "")).exists()
    ]


def cluster_backgrounds_with_vl(
    rendered_pages: list[dict[str, Any]],
    styles: dict[str, Any],
    structure_scan: dict[str, Any],
    output_dir: Path,
    *,
    vision_base_url: str,
    vision_model: str,
    vision_api_key: str,
    vision_timeout: int,
    vl_retry_attempts: int,
    vl_retry_backoff_seconds: float,
    vl_retry_status_codes: list[int],
    tmp_dir: Path | None = None,
) -> list[dict[str, Any]]:
    """Build shared blank-background clusters from already-extracted pages only.

    The structure prescan supplies semantic roles (chapter_cover/content), while
    styles supplies the pages that were actually selected and parsed under the VL
    budget. This stage never expands beyond that parsed page set.
    """
    log("background cluster selection")
    if not vision_api_key:
        return []
    records = style_records_by_page(styles)
    if not records:
        return []
    page_roles = {int(k): str(v) for k, v in (structure_scan.get("page_roles") or {}).items()}
    rendered_by_page = {int(item.get("page") or 0): item for item in rendered_pages}
    parsed_pages = set(records)
    clusters: list[dict[str, Any]] = []

    chapter_pages = sorted(p for p in parsed_pages if page_roles.get(p) == "chapter_cover")
    chapter_rendered = rendered_pages_for_numbers(list(rendered_by_page.values()), set(chapter_pages))
    if len(chapter_rendered) == 1:
        pg = int(chapter_rendered[0].get("page") or 0)
        rec = records.get(pg) or {}
        clusters.append({
            "cluster_id": "chapter_cover_bg",
            "cluster_kind": "chapter_cover_background",
            "label": "chapter_cover shared background",
            "pages": [pg],
            "skeleton": {"background": "single chapter_cover page background", "representative_page": pg},
            "representative_visual_report": str(rec.get("visual_report") or ""),
        })
    elif len(chapter_rendered) > 1:
        sheet = build_contact_sheet(chapter_rendered, output_dir / "_chapter_cover_background_sheet.jpg")
        if sheet is not None:
            sheet_path, order = sheet
            prompt = f"""You are checking whether chapter divider pages share one reusable BACKGROUND.
This contact sheet contains only pages classified earlier as chapter_cover. Page order: {order}.

Judge ONLY the background layer: base color, gradient, decorative shapes, background image treatment, and recurring ornaments.
Ignore all text content, section titles, page numbers, and foreground content placement.

Return JSON only:
{{
  "reusable": true,
  "representative_page": <one page number from {order}>,
  "background": "<short description of the shared background>",
  "reason": "<why it is or is not reusable>"
}}

Rules:
- reusable=true only if these chapter_cover pages have basically the same background color family AND same background composition.
- If obvious chapter accent colors or background structures differ, return reusable=false.
- Do not group by title placement or text length."""
            try:
                raw = request_vl_report(
                    sheet_path, prompt, vision_base_url, vision_model, vision_api_key,
                    max(int(vision_timeout) * 3, 300), vl_retry_attempts, vl_retry_backoff_seconds, vl_retry_status_codes,
                )
                trace_step(tmp_dir, "02_background_chapter_cover", prompt=prompt, response=raw, image=sheet_path)
                data = extract_json_object(raw)
            except Exception as exc:  # noqa: BLE001
                log(f"[background] chapter_cover check failed ({type(exc).__name__}: {str(exc)[:160]})")
                data = {}
            if data.get("reusable") is True:
                rep = int(data.get("representative_page") or order[0])
                if rep not in chapter_pages:
                    rep = order[0]
                rec = records.get(rep) or {}
                clusters.append({
                    "cluster_id": "chapter_cover_bg",
                    "cluster_kind": "chapter_cover_background",
                    "label": "chapter_cover shared background",
                    "pages": chapter_pages,
                    "skeleton": {
                        "background": str(data.get("background") or ""),
                        "representative_page": rep,
                        "reason": str(data.get("reason") or ""),
                    },
                    "representative_visual_report": str(rec.get("visual_report") or ""),
                })
            else:
                log("[background] chapter_cover backgrounds differ -> skip blank template")

    content_pages = sorted(p for p in parsed_pages if page_roles.get(p) == "content")
    content_rendered = rendered_pages_for_numbers(list(rendered_by_page.values()), set(content_pages))
    if len(content_rendered) == 1:
        pg = int(content_rendered[0].get("page") or 0)
        rec = records.get(pg) or {}
        clusters.append({
            "cluster_id": "content_bg_a",
            "cluster_kind": "content_background",
            "label": "content shared background",
            "pages": [pg],
            "skeleton": {"background": "single content page background", "representative_page": pg},
            "representative_visual_report": str(rec.get("visual_report") or ""),
        })
    elif len(content_rendered) > 1:
        sheet = build_contact_sheet(content_rendered, output_dir / "_content_background_sheet.jpg")
        if sheet is not None:
            sheet_path, order = sheet
            prompt = f"""You are grouping already-extracted content pages by reusable BACKGROUND similarity.
This contact sheet contains only pages classified earlier as content and selected for detailed parsing. Page order: {order}.

Cluster pages using ONLY the background layer:
- base background color / gradient / texture
- decorative background graphics, waves, curves, blocks, ornaments
- recurring background image treatment

Ignore all foreground content layout: title location, columns, cards, tables, charts, image slots, text density, and section title wording.
Do NOT describe clusters as left-right, top-bottom, centered, grid, or other layout structures.

Return JSON only:
{{
  "clusters": [
    {{
      "cluster_id": "content_bg_a",
      "label": "short background name",
      "pages": [<page numbers>],
      "background": "<shared background description>",
      "representative_page": <the clearest page number for this background>
    }}
  ]
}}

Rules:
- Every page in {order} must belong to exactly one cluster.
- Split only when the background color family or background decorative system clearly differs.
- Keep clusters coarse; foreground layout differences are irrelevant."""
            try:
                raw = request_vl_report(
                    sheet_path, prompt, vision_base_url, vision_model, vision_api_key,
                    max(int(vision_timeout) * 3, 300), vl_retry_attempts, vl_retry_backoff_seconds, vl_retry_status_codes,
                )
                trace_step(tmp_dir, "02_background_content", prompt=prompt, response=raw, image=sheet_path)
                data = extract_json_object(raw)
            except Exception as exc:  # noqa: BLE001
                log(f"[background] content clustering failed ({type(exc).__name__}: {str(exc)[:160]})")
                data = {}
            raw_clusters = data.get("clusters") if isinstance(data, dict) else None
            if isinstance(raw_clusters, list):
                seen: set[int] = set()
                for i, cl in enumerate(raw_clusters, 1):
                    if not isinstance(cl, dict):
                        continue
                    pages = [int(p) for p in (cl.get("pages") or []) if str(p).strip().isdigit()]
                    pages = [p for p in pages if p in content_pages and p not in seen]
                    if not pages:
                        continue
                    seen.update(pages)
                    rep = int(cl.get("representative_page") or pages[0])
                    if rep not in pages:
                        rep = pages[0]
                    rec = records.get(rep) or {}
                    clusters.append({
                        "cluster_id": str(cl.get("cluster_id") or f"content_bg_{chr(96 + min(i, 26))}"),
                        "cluster_kind": "content_background",
                        "label": str(cl.get("label") or f"content background {i}"),
                        "pages": pages,
                        "skeleton": {
                            "background": str(cl.get("background") or ""),
                            "representative_page": rep,
                        },
                        "representative_visual_report": str(rec.get("visual_report") or ""),
                    })
                missing = [p for p in content_pages if p not in seen]
                if missing:
                    log(f"[background] content clustering omitted pages {missing}; assigning them to single-page background clusters")
                    for p in missing:
                        rec = records.get(p) or {}
                        clusters.append({
                            "cluster_id": f"content_bg_p{p:03d}",
                            "cluster_kind": "content_background",
                            "label": f"content background page {p}",
                            "pages": [p],
                            "skeleton": {"background": "fallback single-page background", "representative_page": p},
                            "representative_visual_report": str(rec.get("visual_report") or ""),
                        })
    # Fixed/non-content pages (cover, agenda, section dividers that are not
    # chapter_cover, ending, etc.) are usually one-of-a-kind but still carry
    # template chrome that should be preserved exactly. Give each its own
    # single-page blank template so its background/decorations are reused
    # instead of being redrawn from scratch per render.
    clustered_pages = {int(p) for cl in clusters for p in (cl.get("pages") or [])}
    noncontent_roles = {
        "cover", "category", "agenda", "toc", "summary",
        "section_divider", "ending", "back_cover", "thanks",
    }
    for p in sorted(parsed_pages):
        if p in clustered_pages:
            continue
        role = page_roles.get(p)
        if role not in noncontent_roles:
            continue
        rec = records.get(p) or {}
        clusters.append({
            "cluster_id": f"{role}_p{p:03d}",
            "cluster_kind": f"{role}_background",
            "label": f"{role} page {p}",
            "pages": [p],
            "skeleton": {"background": f"single {role} page background", "representative_page": p},
            "representative_visual_report": str(rec.get("visual_report") or ""),
        })

    if clusters:
        log("[background] clusters: " + ", ".join(f"{c['cluster_id']}({len(c.get('pages') or [])}p)" for c in clusters))
    return clusters


def build_contact_sheets(rendered_pages: list[dict[str, Any]], output_dir: Path, per_sheet: int = 20, max_pages: int = 80, cols: int = 4, cell_w: int = 320) -> tuple[list[Path], list[int]] | None:
    """Tile page thumbnails into MULTIPLE contact sheets, <= per_sheet pages each.

    Supports up to max_pages pages (default 80 => up to 4 sheets of 20). Returns
    (list of sheet paths, page-number order across all sheets) or None.
    """
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    def _img_path(it: dict[str, Any]) -> str:
        return str(it.get("output") or it.get("path") or "")
    items = [it for it in rendered_pages if _img_path(it) and Path(_img_path(it)).exists()]
    if not items:
        return None
    items = sorted(items, key=lambda it: int(it.get("page") or 0))[:max_pages]
    cell_h = int(cell_w * 9 / 16)
    label_h = 22
    sheets: list[Path] = []
    order: list[int] = []
    for s, start in enumerate(range(0, len(items), per_sheet)):
        chunk = items[start:start + per_sheet]
        rows = (len(chunk) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * cell_w, rows * (cell_h + label_h)), "white")
        draw = ImageDraw.Draw(sheet)
        for i, it in enumerate(chunk):
            page = int(it.get("page") or 0)
            order.append(page)
            r, c = divmod(i, cols)
            x, y = c * cell_w, r * (cell_h + label_h)
            try:
                thumb = Image.open(_img_path(it)).convert("RGB")
                thumb.thumbnail((cell_w, cell_h))
                sheet.paste(thumb, (x + (cell_w - thumb.width) // 2, y + label_h))
            except Exception:
                pass
            draw.text((x + 4, y + 4), f"p{page}", fill="black")
        out = output_dir / f"_prescan_sheet_{s + 1}.jpg"
        sheet.save(out, "JPEG", quality=65, optimize=True)
        sheets.append(out)
    return sheets, order


def build_contact_sheet(rendered_pages: list[dict[str, Any]], output_path: Path, cols: int = 4, cell_w: int = 320) -> tuple[Path, list[int]] | None:
    """Tile all page thumbnails into a single labeled contact sheet for one-shot prescan.

    Keeps prescan cost flat (one VL call) regardless of page count. Returns the
    sheet path and the page-number order of the cells, or None if PIL/pages absent.
    """
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    def _img_path(it: dict[str, Any]) -> str:
        return str(it.get("output") or it.get("path") or "")
    items = [it for it in rendered_pages if _img_path(it) and Path(_img_path(it)).exists()]
    if not items:
        return None
    items = sorted(items, key=lambda it: int(it.get("page") or 0))
    cell_h = int(cell_w * 9 / 16)
    label_h = 22
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell_w, rows * (cell_h + label_h)), "white")
    draw = ImageDraw.Draw(sheet)
    order: list[int] = []
    for i, it in enumerate(items):
        page = int(it.get("page") or 0)
        order.append(page)
        r, c = divmod(i, cols)
        x, y = c * cell_w, r * (cell_h + label_h)
        try:
            thumb = Image.open(_img_path(it)).convert("RGB")
            thumb.thumbnail((cell_w, cell_h))
            sheet.paste(thumb, (x + (cell_w - thumb.width) // 2, y + label_h))
        except Exception:
            pass
        draw.text((x + 4, y + 4), f"p{page}", fill="black")
    sheet.save(output_path, "JPEG", quality=70)
    return output_path, order


# Structural page roles the prescan may assign to each page.
_STRUCT_ROLES = {"cover", "summary", "category", "chapter_cover", "content", "ending"}


def run_structure_prescan(
    rendered_pages: list[dict[str, Any]],
    output_dir: Path,
    *,
    vision_base_url: str,
    vision_model: str,
    vision_api_key: str,
    vision_timeout: int,
    vl_retry_attempts: int,
    vl_retry_backoff_seconds: float,
    vl_retry_status_codes: list[int],
    tmp_dir: Path | None = None,
    per_sheet: int = 20,
    max_pages: int = 80,
) -> dict[str, Any]:
    """Classify every page's STRUCTURAL role from contact sheets (one VL call per sheet).

    Returns {"page_roles": {page:int -> role:str}, "structure_ran": bool}. The VL
    judges each page independently (cover / summary / category / chapter_cover /
    content / ending ); chapter ranges are derived in code from
    these per-page roles, so multi-sheet results merge without ambiguity.
    """
    empty = {"page_roles": {}, "structure_ran": False}
    if not vision_api_key or not rendered_pages:
        log("[structure] skip: no api_key or no rendered pages")
        return empty
    built = build_contact_sheets(rendered_pages, output_dir, per_sheet=per_sheet, max_pages=max_pages)
    if not built:
        log("[structure] skip: contact sheets build failed")
        return empty
    sheets, order = built
    log(f"[structure] {len(sheets)} sheet(s) for {len(order)} page(s); calling VL per sheet")
    page_roles: dict[int, str] = {}
    cursor = 0
    for s_idx, sheet_path in enumerate(sheets):
        chunk_pages = order[cursor:cursor + per_sheet]
        cursor += per_sheet
        prompt = f"""You are analyzing the STRUCTURE of a slide deck. This contact sheet shows {len(chunk_pages)} pages, each cell labeled p<number>. Pages on this sheet: {chunk_pages}.

For EACH page on this sheet, classify its structural role. Output JSON only:
{{ "roles": {{ "<page_number>": "cover | summary | category | chapter_cover | content | ending" }} }}

Role meanings:
- cover: the deck's title/opening page (usually only the first page).
- summary: an abstract/overview page summarizing the whole deck (often right after the cover).
- category: table-of-contents / outline / agenda listing the sections.
- chapter_cover: a section-divider page that opens a new chapter/section (big section title, little content).
- content: a normal content page that belongs to a chapter.
- ending: a closing page (Thank you / Q&A / contact / back cover).

Rules:
- Classify EVERY page listed for this sheet, using the exact page numbers.
- Use chapter_cover ONLY for genuine section-divider pages. If the deck has no sections, use normal for content pages (do not invent chapter_cover).
- Output raw JSON only, no comments."""
        try:
            raw = request_vl_report(
                sheet_path, prompt, vision_base_url, vision_model, vision_api_key,
                max(int(vision_timeout) * 2, 240), vl_retry_attempts, vl_retry_backoff_seconds, vl_retry_status_codes,
            )
            trace_step(tmp_dir, f"00_structure_sheet_{s_idx + 1}", prompt=prompt, response=raw, image=sheet_path)
            data = extract_json_object(raw)
        except Exception as exc:  # noqa: BLE001
            log(f"[structure] sheet {s_idx + 1} failed ({type(exc).__name__}: {str(exc)[:120]})")
            continue
        roles_obj = data.get("roles") if isinstance(data, dict) else None
        if isinstance(roles_obj, dict):
            for k, v in roles_obj.items():
                try:
                    pg = int(k)
                except (TypeError, ValueError):
                    continue
                role = str(v or "").strip().lower()
                if role in _STRUCT_ROLES:
                    page_roles[pg] = role
    if not page_roles:
        return empty
    log(f"[structure] classified {len(page_roles)} page(s): " + ", ".join(f"p{p}={r}" for p, r in sorted(page_roles.items())))
    return {"page_roles": page_roles, "structure_ran": True}


def derive_deck_structure(page_roles: dict[int, str], total_pages: int) -> dict[str, Any]:
    """Turn per-page roles into deck structure: fixed pages + ordered chapters.

    A chapter starts at a chapter_cover and runs until the next chapter_cover (or
    the next fixed page / end). Returns fixed page numbers and a list of chapters,
    each {cover: page|None, content: [pages], pages: [all pages incl. cover]}.
    """
    fixed = {"cover": None, "summary": None, "agenda": None, "ending": None}
    for pg in sorted(page_roles):
        role = page_roles[pg]
        if role in fixed and fixed[role] is None:
            fixed[role] = pg
    fixed_pages = {p for p in fixed.values() if p}

    has_chapters = any(r == "chapter_cover" for r in page_roles.values())
    chapters: list[dict[str, Any]] = []
    if has_chapters:
        ordered = sorted(p for p in page_roles if p not in fixed_pages)
        current: dict[str, Any] | None = None
        for pg in ordered:
            role = page_roles.get(pg)
            if role == "chapter_cover":
                if current:
                    chapters.append(current)
                current = {"cover": pg, "content": [], "pages": [pg]}
            else:
                if current is None:
                    current = {"cover": None, "content": [], "pages": []}
                current["content"].append(pg)
                current["pages"].append(pg)
        if current:
            chapters.append(current)
    return {
        "fixed": fixed,
        "fixed_pages": sorted(fixed_pages),
        "has_chapters": has_chapters,
        "chapters": chapters,
    }


def allocate_extraction_pages(
    structure: dict[str, Any],
    page_roles: dict[int, str],
    *,
    budget_with_chapters: int = 20,
    budget_without_chapters: int = 10,
) -> set[int]:
    """Pick which pages to extract: always the fixed pages, then spread the remaining
    budget across chapters weighted by each chapter's content size.

    No chapters -> flat sample of content pages up to budget_without_chapters.
    """
    fixed_pages = set(structure.get("fixed_pages") or [])
    has_chapters = structure.get("has_chapters")
    if not has_chapters:
        budget = budget_without_chapters
        selected = set(fixed_pages)
        content = sorted(p for p in page_roles if p not in fixed_pages)
        remaining = max(0, budget - len(selected))
        if content and remaining > 0:
            if len(content) <= remaining:
                selected.update(content)
            else:
                step = len(content) / remaining
                selected.update(content[int(i * step)] for i in range(remaining))
        return selected

    budget = budget_with_chapters
    selected = set(fixed_pages)
    chapters = structure.get("chapters") or []
    # Always include every chapter cover.
    for ch in chapters:
        if ch.get("cover"):
            selected.add(ch["cover"])
    remaining = max(0, budget - len(selected))
    # Weight remaining budget by each chapter's content-page count.
    total_content = sum(len(ch.get("content") or []) for ch in chapters)
    if total_content > 0 and remaining > 0:
        # Largest-remainder apportionment for fair integer division.
        raw = [(len(ch.get("content") or []) / total_content) * remaining for ch in chapters]
        floor = [int(x) for x in raw]
        leftover = remaining - sum(floor)
        order_by_frac = sorted(range(len(chapters)), key=lambda i: raw[i] - floor[i], reverse=True)
        for i in order_by_frac[:leftover]:
            floor[i] += 1
        for ch, take in zip(chapters, floor):
            content = sorted(ch.get("content") or [])
            if not content or take <= 0:
                continue
            if len(content) <= take:
                selected.update(content)
            else:
                step = len(content) / take
                selected.update(content[int(i * step)] for i in range(take))
    return selected


def font_type(font_name: str) -> str:
    name = font_name.lower()
    if any(key in name for key in SERIF_KEYWORDS):
        return "serif"
    if any(key in name for key in SANSSERIF_KEYWORDS):
        return "sans-serif"
    # Unknown fonts default to sans-serif: modern decks (Chinese 黑体 family,
    # Arial/Helvetica) are overwhelmingly sans, so serif was a systematic mislabel.
    return "sans-serif"


def display_font_name(font_name: str) -> str:
    """Return only the reusable font family/style name, without embedded subset prefixes."""
    name = str(font_name or "").strip()
    if "+" in name:
        name = name.split("+", 1)[1]
    return name or "not explicitly set"


def rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"


def is_black_or_white(rgb: tuple[int, int, int]) -> bool:
    return rgb in {(0, 0, 0), (255, 255, 255)}


def _font_size_to_px(size_pt: float, page_height_pt: float) -> int:
    """Font size in px after normalizing the page to a 1280x720 canvas.

    The page is treated as if resized to 1280x720; font size is a vertical
    measure, so it scales by the height ratio (720 / source height). For the
    usual 16:9 slide this equals the width ratio. Output is always px, never pt.
    """
    height = page_height_pt if page_height_pt and page_height_pt > 0 else 720.0
    return int(round(size_pt * (720.0 / height)))


def _format_font_lines(groups: dict[tuple[str, str], Counter], header_page: int) -> str:
    """Render grouped (type,name)->size_px counters into the metadata block."""
    lines = [
        f"==================== Page {header_page} Font Style Analysis ====================",
        "Each font lists its measured sizes converted to px on the 1280x720 canvas "
        "(most frequent first). Use these as the basis for text scale; refine visually only where a size is unknown.",
    ]
    ordered = sorted(groups.items(), key=lambda item: (-sum(item[1].values()), item[0][1]))
    for (kind, name), sizes in ordered:
        total = sum(sizes.values())
        known = Counter({s: c for s, c in sizes.items() if s > 0})
        if known:
            size_str = ", ".join(f"{s}px" for s, _ in known.most_common(4))
        else:
            size_str = "unknown"
        lines.append(f"Font family/style: {name}  |  Type: {kind}  |  Sizes(px): {size_str}  |  Text runs: {total}")
    return "\n".join(lines)


def _pdf_font_analysis_from_page(page: Any, page_num: int) -> str:
    """Font family/style + measured size analysis from an already-open fitz page.

    Sizes are reported in px against a normalized 1280x720 canvas (never pt).
    """
    page_height = float(getattr(page.rect, "height", 0) or 0)
    groups: dict[tuple[str, str], Counter] = defaultdict(Counter)
    for block in page.get_text("dict")["blocks"]:
        if "lines" not in block:
            continue
        for line in block["lines"]:
            for span in line["spans"]:
                text = str(span.get("text") or "").strip()
                if not text:
                    continue
                name = display_font_name(span.get("font") or "")
                size_px = _font_size_to_px(float(span.get("size") or 0), page_height)
                groups[(font_type(name), name)][size_px] += 1
    return _format_font_lines(groups, page_num)


def _pdf_color_analysis_from_page(page: Any) -> str:
    """Color analysis from an already-open fitz page (no file I/O)."""
    colors: set[tuple[int, int, int]] = set()
    for item in page.get_drawings():
        for key in ("fill", "stroke"):
            value = item.get(key)
            if value is not None:
                colors.add(tuple(max(0, min(255, round(c * 255))) for c in value[:3]))
    for block in page.get_text("dict")["blocks"]:
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                c = int(span.get("color") or 0)
                colors.add(((c >> 16) & 255, (c >> 8) & 255, c & 255))
    filtered = [rgb for rgb in sorted(colors) if not is_black_or_white(rgb)]
    lines = ["Extracted colors (black and white removed):"]
    lines.extend(f"RGB: {rgb}   HEX: {rgb_to_hex(rgb)}" for rgb in filtered)
    return "\n".join(lines)


def pdf_page_font_analysis(pdf_path: Path, page_num: int) -> str:
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("Install pymupdf to extract PDF fonts: python -m pip install pymupdf") from exc
    with fitz.open(pdf_path) as doc:
        return _pdf_font_analysis_from_page(doc[page_num - 1], page_num)


def pdf_page_color_analysis(pdf_path: Path, page_num: int) -> str:
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("Install pymupdf to extract PDF colors: python -m pip install pymupdf") from exc
    with fitz.open(pdf_path) as doc:
        return _pdf_color_analysis_from_page(doc[page_num - 1])


def pptx_rgb(value: Any) -> tuple[int, int, int] | None:
    if value is None:
        return None
    try:
        return int(value[0]), int(value[1]), int(value[2])
    except Exception:
        text = str(value)
        if len(text) == 6:
            try:
                return int(text[0:2], 16), int(text[2:4], 16), int(text[4:6], 16)
            except ValueError:
                return None
    return None


def pptx_color_from_format(color_format: Any) -> tuple[int, int, int] | None:
    try:
        if color_format is not None and color_format.rgb:
            return pptx_rgb(color_format.rgb)
    except Exception:
        return None
    return None


def pptx_shape_fill(shape: Any) -> tuple[int, int, int] | None:
    try:
        return pptx_color_from_format(shape.fill.fore_color)
    except Exception:
        return None


def pptx_shape_line(shape: Any) -> tuple[int, int, int] | None:
    try:
        return pptx_color_from_format(shape.line.color)
    except Exception:
        return None


def iter_pptx_shapes(shapes: Any):
    for shape in shapes:
        yield shape
        if hasattr(shape, "shapes"):
            yield from iter_pptx_shapes(shape.shapes)


def px_box(shape: Any, canvas_w: int, canvas_h: int, slide_w: int, slide_h: int) -> dict[str, float]:
    return {
        "left": float(shape.left) / slide_w * canvas_w,
        "top": float(shape.top) / slide_h * canvas_h,
        "width": float(shape.width) / slide_w * canvas_w,
        "height": float(shape.height) / slide_h * canvas_h,
    }


def pptx_page_font_analysis(slide: Any, page_num: int, canvas_w: int, canvas_h: int, slide_w: int, slide_h: int) -> str:
    # slide_h is in EMU (12700 per pt) -> height in pt; font size scales to the
    # normalized 1280x720 canvas by the height ratio (output in px, never pt).
    slide_h_pt = (float(slide_h) / 12700.0) if slide_h else 540.0
    groups: dict[tuple[str, str], Counter] = defaultdict(Counter)
    for shape in iter_pptx_shapes(slide.shapes):
        if not getattr(shape, "has_text_frame", False):
            continue
        for para in shape.text_frame.paragraphs:
            for run in para.runs:
                text = (run.text or "").strip()
                if not text:
                    continue
                font = run.font
                name = display_font_name(font.name or "")
                size_px = 0
                try:
                    if font.size is not None:
                        size_px = _font_size_to_px(float(font.size.pt), slide_h_pt)
                except Exception:
                    size_px = 0
                groups[(font_type(name), name)][size_px] += 1
    return _format_font_lines(groups, page_num)


def pptx_page_color_analysis(slide: Any) -> str:
    colors: Counter[tuple[int, int, int]] = Counter()
    for shape in iter_pptx_shapes(slide.shapes):
        for rgb in [pptx_shape_fill(shape), pptx_shape_line(shape)]:
            if rgb and not is_black_or_white(rgb):
                colors[rgb] += 1
        if getattr(shape, "has_text_frame", False):
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    rgb = pptx_color_from_format(run.font.color)
                    if rgb and not is_black_or_white(rgb):
                        colors[rgb] += 1
    lines = ["Extracted colors (black and white removed):"]
    for rgb, count in colors.most_common(24):
        lines.append(f"RGB: {rgb}   HEX: {rgb_to_hex(rgb)}   COUNT: {count}")
    return "\n".join(lines)


def selected_pptx_pages_for_render(total_pages: int, max_pages: int = 80) -> set[int]:
    # Render ALL pages (capped at max_pages) so the structural prescan can classify
    # every page; per-page extraction is sampled afterwards from the detected
    # structure (fixed pages + chapter-weighted budget).
    if total_pages <= 0:
        return set()
    return set(range(1, min(total_pages, max_pages) + 1))


def is_spire_trial_limit_image(path: Path) -> bool:
    try:
        from PIL import Image
    except ImportError:
        return False
    try:
        with Image.open(path) as img:
            image = img.convert("RGB")
            width, height = image.size
            pixels = list(image.crop((0, 0, min(width, 480), min(height, 140))).getdata())
            all_pixels = list(image.resize((80, 45)).getdata())
    except Exception:
        return False
    white_ratio = sum(1 for r, g, b in all_pixels if r > 235 and g > 235 and b > 235) / max(1, len(all_pixels))
    red_pixels = sum(1 for r, g, b in pixels if r > 150 and g < 80 and b < 80)
    blue_pixels = sum(1 for r, g, b in pixels if b > 120 and r < 90 and g < 120)
    return white_ratio > 0.88 and red_pixels > 20 and blue_pixels > 20


def render_pptx_pages_with_spire(source: Path, output_dir: Path, page_numbers: set[int] | None = None) -> dict[int, Path]:
    try:
        from spire.presentation import FileFormat, Presentation
    except ImportError as exc:
        raise RuntimeError("spire.presentation is not installed") from exc
    output_dir.mkdir(parents=True, exist_ok=True)
    ppt = Presentation()
    ppt.LoadFromFile(str(source))
    paths: dict[int, Path] = {}
    try:
        pages = sorted(page_numbers or set(range(1, ppt.Slides.Count + 1)))
        for page in pages:
            if page < 1 or page > ppt.Slides.Count:
                continue
            image = ppt.Slides[page - 1].SaveAsImage()
            out = output_dir / f"page_{page:03d}_raw.png"
            image.Save(str(out))
            if is_spire_trial_limit_image(out):
                raise RuntimeError(
                    "Spire.Presentation renderer produced a trial-license limit page. "
                    "The installed Spire renderer can only render the first 10 slides; install/configure a renderer "
                    "that can render the selected PPTX pages, such as a licensed Spire, Aspose.Slides, or another explicit PPTX renderer."
                )
            paths[page] = out
    finally:
        try:
            ppt.Dispose()
        except Exception:
            pass
    return paths


def render_pptx_pages_with_aspose(source: Path, output_dir: Path, page_numbers: set[int] | None = None) -> dict[int, Path]:
    try:
        import aspose.slides as slides
    except ImportError as exc:
        raise RuntimeError("aspose.slides is not installed") from exc
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: dict[int, Path] = {}
    source_for_aspose = source
    temp_source: Path | None = None
    try:
        # Aspose on Windows can fail on non-ASCII paths; feed it an ASCII temp copy.
        try:
            str(source.resolve()).encode("ascii")
        except UnicodeEncodeError:
            temp_source = output_dir / "_aspose_source.pptx"
            shutil.copy2(source, temp_source)
            source_for_aspose = temp_source
        presentation = slides.Presentation(str(source_for_aspose.resolve()))
        try:
            for index, slide in enumerate(presentation.slides, 1):
                if page_numbers and index not in page_numbers:
                    continue
                out = output_dir / f"page_{index:03d}_raw.png"
                if hasattr(slide, "get_thumbnail"):
                    image = slide.get_thumbnail(1.0, 1.0)
                    image.save(str(out), slides.ImageFormat.PNG)
                else:
                    image = slide.get_image(1.0, 1.0)
                    image.save(str(out))
                paths[index] = out
        finally:
            close = getattr(presentation, "dispose", None) or getattr(presentation, "close", None)
            if callable(close):
                close()
    finally:
        if temp_source is not None:
            temp_source.unlink(missing_ok=True)
    return paths


def find_libreoffice() -> str | None:
    for name in ["soffice", "libreoffice"]:
        path = shutil.which(name)
        if path:
            return path
    for path in [
        Path(r"C:\Program Files\LibreOffice\program\soffice.exe"),
        Path(r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"),
    ]:
        if path.exists():
            return str(path)
    return None


def render_pdf_subset_to_png(pdf_path: Path, output_dir: Path, page_numbers: set[int] | None = None) -> dict[int, Path]:
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("Install pymupdf to render LibreOffice-converted PDF pages: python -m pip install pymupdf") from exc
    paths: dict[int, Path] = {}
    with fitz.open(pdf_path) as doc:
        pages = sorted(page_numbers or set(range(1, len(doc) + 1)))
        for page_num in pages:
            if page_num < 1 or page_num > len(doc):
                continue
            out = output_dir / f"page_{page_num:03d}_raw.png"
            pix = doc[page_num - 1].get_pixmap(matrix=fitz.Matrix(1.6, 1.6), alpha=False)
            pix.save(out)
            paths[page_num] = out
    return paths


def render_pptx_pages_with_libreoffice(source: Path, output_dir: Path, page_numbers: set[int] | None = None) -> dict[int, Path]:
    soffice = find_libreoffice()
    if not soffice:
        raise RuntimeError("LibreOffice renderer is unavailable. Install LibreOffice and ensure `soffice` or `libreoffice` is on PATH.")
    output_dir.mkdir(parents=True, exist_ok=True)
    convert_dir = output_dir / "_lo_pdf"
    if convert_dir.exists():
        shutil.rmtree(convert_dir)
    convert_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        soffice,
        "--headless",
        "--convert-to",
        "pdf",
        "--outdir",
        str(convert_dir),
        str(source.resolve()),
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=180)
    if result.returncode != 0:
        raise RuntimeError(f"LibreOffice conversion failed: {result.stderr.strip() or result.stdout.strip()}")
    pdf_candidates = sorted(convert_dir.glob("*.pdf"))
    if not pdf_candidates:
        raise RuntimeError(f"LibreOffice conversion did not produce a PDF. Output: {result.stdout.strip()} {result.stderr.strip()}")
    return render_pdf_subset_to_png(pdf_candidates[0], output_dir, page_numbers)


def render_pptx_pages_with_powerpoint(source: Path, output_dir: Path, page_numbers: set[int] | None = None) -> dict[int, Path]:
    try:
        import win32com.client
    except ImportError as exc:
        raise RuntimeError("pywin32 is not installed; PowerPoint COM renderer requires pywin32.") from exc
    output_dir.mkdir(parents=True, exist_ok=True)
    ppt = None
    presentation = None
    paths: dict[int, Path] = {}
    try:
        ppt = win32com.client.Dispatch("PowerPoint.Application")
        presentation = ppt.Presentations.Open(str(source.resolve()), WithWindow=False)
        pages = sorted(page_numbers or set(range(1, int(presentation.Slides.Count) + 1)))
        for page in pages:
            if page < 1 or page > int(presentation.Slides.Count):
                continue
            out = output_dir / f"page_{page:03d}_raw.png"
            presentation.Slides(page).Export(str(out.resolve()), "PNG", 1280, 720)
            paths[page] = out
    finally:
        if presentation is not None:
            presentation.Close()
        if ppt is not None:
            ppt.Quit()
    return paths


def render_pptx_pages_python(source: Path, output_dir: Path, page_numbers: set[int] | None = None) -> tuple[dict[int, Path], list[str]]:
    errors: list[str] = []
    for renderer in [render_pptx_pages_with_libreoffice, render_pptx_pages_with_powerpoint, render_pptx_pages_with_spire, render_pptx_pages_with_aspose]:
        try:
            paths = renderer(source, output_dir, page_numbers)
            if paths:
                return paths, errors
        except Exception as exc:
            errors.append(str(exc))
            for raw in output_dir.glob("page_*_raw.*"):
                raw.unlink(missing_ok=True)
    errors.append(
        "No PPTX page renderer succeeded. Install/configure spire.presentation or aspose.slides, "
        "or modify the extraction script to use another explicit PPTX renderer such as PowerPoint COM."
    )
    return {}, errors


def prepare_pptx_pages_for_vl(source: Path, output_dir: Path, profile: str) -> tuple[list[dict[str, Any]], dict[int, dict[str, str]], list[str]]:
    try:
        from pptx import Presentation
    except ImportError as exc:
        raise RuntimeError("PPTX input requires python-pptx. Install it with: python -m pip install python-pptx") from exc
    prs = Presentation(source)
    canvas_w, canvas_h = 1280, 720
    metadata: dict[int, dict[str, str]] = {}
    rendered: list[dict[str, Any]] = []
    errors: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)
    selected_pages = selected_pptx_pages_for_render(len(prs.slides))
    raw_paths, render_errors = render_pptx_pages_python(source, output_dir, selected_pages)
    errors.extend(render_errors)
    for index, slide in enumerate(prs.slides, 1):
        if index not in selected_pages:
            continue
        try:
            metadata[index] = {
                "font_analysis": pptx_page_font_analysis(slide, index, canvas_w, canvas_h, int(prs.slide_width), int(prs.slide_height)),
                "color_analysis": pptx_page_color_analysis(slide),
            }
        except Exception as exc:
            errors.append(f"page {index} metadata: {exc}")
        raw = raw_paths.get(index)
        final = output_dir / f"page_{index:03d}.jpg"
        try:
            if raw is None or not raw.exists():
                continue
            item = compress_image_for_vl(raw, final, profile=profile)
            raw.unlink(missing_ok=True)
            item["page"] = index
            rendered.append(item)
        except Exception as exc:
            errors.append(f"page {index}: {exc}")
    return rendered, metadata, errors


def prepare_pdf_pages_for_vl(source: Path, output_dir: Path, profile: str) -> tuple[list[dict[str, Any]], dict[int, dict[str, str]], list[str]]:
    rendered = render_pdf_pages_for_vl(source, output_dir, profile=profile)
    metadata: dict[int, dict[str, str]] = {}
    errors: list[str] = []
    # Open the PDF once and reuse the handle for every page's font+color pass,
    # instead of reopening the file twice per page.
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("Install pymupdf to extract PDF metadata: python -m pip install pymupdf") from exc
    with fitz.open(source) as doc:
        for item in rendered:
            page = int(item.get("page") or 0)
            try:
                pg = doc[page - 1]
                metadata[page] = {
                    "font_analysis": _pdf_font_analysis_from_page(pg, page),
                    "color_analysis": _pdf_color_analysis_from_page(pg),
                }
            except Exception as exc:
                errors.append(f"page {page}: {exc}")
    return rendered, metadata, errors


def _save_image_asset(image_bytes: bytes, ext: str, page: int, idx: int, asset_dir: Path) -> str | None:
    try:
        asset_dir.mkdir(parents=True, exist_ok=True)
        ext = (ext or "png").lstrip(".").lower()
        if ext == "jpeg":
            ext = "jpg"
        out = asset_dir / f"p{page:03d}_img{idx}.{ext}"
        out.write_bytes(image_bytes)
        return out.name
    except Exception:
        return None


def extract_pptx_images(slide: Any, prs: Any, page: int, asset_dir: Path) -> list[dict[str, Any]]:
    """Extract every picture shape on a PPTX slide as a reusable asset with geometry.

    Returns a list of {file, left_pct, top_pct, width_pct, height_pct, oversized}.
    Does NOT decide what is a 'background' — generation places each image by the
    visual report. oversized flags art that spills well beyond the canvas.
    """
    try:
        from pptx.enum.shapes import MSO_SHAPE_TYPE
    except Exception:
        MSO_SHAPE_TYPE = None
    slide_w = int(prs.slide_width or 1) or 1
    slide_h = int(prs.slide_height or 1) or 1
    images: list[dict[str, Any]] = []
    idx = 0

    def _iter_picture_shapes(shapes):
        # Yield any shape that carries an embedded image — covers PICTURE shapes,
        # picture PLACEHOLDERs (common for cover art), and images nested in GROUPs.
        for sh in shapes:
            if MSO_SHAPE_TYPE is not None and sh.shape_type == MSO_SHAPE_TYPE.GROUP:
                yield from _iter_picture_shapes(sh.shapes)
                continue
            try:
                _ = sh.image  # raises if the shape has no embedded image
            except Exception:
                continue
            yield sh

    for shape in _iter_picture_shapes(slide.shapes):
        try:
            image = shape.image
        except Exception:
            continue
        try:
            w = int(shape.width or 0)
            h = int(shape.height or 0)
            left = int(getattr(shape, "left", 0) or 0)
            top = int(getattr(shape, "top", 0) or 0)
        except Exception:
            w = h = left = top = 0
        idx += 1
        fn = _save_image_asset(image.blob, image.ext, page, idx, asset_dir)
        if not fn:
            continue
        w_pct = round(100 * w / slide_w, 1)
        h_pct = round(100 * h / slide_h, 1)
        images.append({
            "file": fn,
            "left_pct": round(100 * left / slide_w, 1),
            "top_pct": round(100 * top / slide_h, 1),
            "width_pct": w_pct,
            "height_pct": h_pct,
            "oversized": (w_pct > 120 or h_pct > 120),
        })
    return images


def extract_pdf_images(source: Path, page: int, asset_dir: Path, min_pct: float = 8.0) -> list[dict[str, Any]]:
    """Extract embedded images on a PDF page with geometry, filtering tiny fragments.

    min_pct: skip images whose width OR height is below this percent of the page
    (drops sliced fragments and small icons). Returns same shape as extract_pptx_images.
    """
    try:
        import fitz
    except Exception:
        return []
    images: list[dict[str, Any]] = []
    try:
        with fitz.open(source) as doc:
            if page - 1 < 0 or page - 1 >= len(doc):
                return []
            pg = doc[page - 1]
            pw = float(pg.rect.width or 1) or 1
            ph = float(pg.rect.height or 1) or 1
            seen_xrefs: set[int] = set()
            idx = 0
            for info in pg.get_images(full=True):
                xref = info[0]
                if xref in seen_xrefs:
                    continue
                seen_xrefs.add(xref)
                try:
                    rects = pg.get_image_rects(xref)
                except Exception:
                    rects = []
                if not rects:
                    continue
                rect = max(rects, key=lambda r: r.width * r.height)
                w_pct = round(100 * rect.width / pw, 1)
                h_pct = round(100 * rect.height / ph, 1)
                if w_pct < min_pct or h_pct < min_pct:
                    continue
                try:
                    extracted = doc.extract_image(xref)
                except Exception:
                    continue
                idx += 1
                fn = _save_image_asset(extracted.get("image") or b"", extracted.get("ext") or "png", page, idx, asset_dir)
                if not fn:
                    continue
                images.append({
                    "file": fn,
                    "left_pct": round(100 * rect.x0 / pw, 1),
                    "top_pct": round(100 * rect.y0 / ph, 1),
                    "width_pct": w_pct,
                    "height_pct": h_pct,
                    "oversized": (w_pct > 120 or h_pct > 120),
                })
    except Exception:
        return images
    return images


def extract_page_images(source: Path, page: int, asset_dir: Path, slide: Any = None, prs: Any = None) -> list[dict[str, Any]]:
    """Format-agnostic entry: extract all real in-page images (with geometry).

    Replaces the old background-only extraction. Returns a list of image assets;
    each entry carries position/size (percent of canvas) and an oversized flag.
    Generation decides where each image goes based on the visual report.
    """
    suffix = source.suffix.lower()
    try:
        if suffix in {".pptx", ".ppt"} and slide is not None and prs is not None:
            imgs = extract_pptx_images(slide, prs, page, asset_dir)
        elif suffix == ".pdf":
            imgs = extract_pdf_images(source, page, asset_dir)
        else:
            imgs = []
    except Exception:
        imgs = []
    if imgs:
        log(f"[images] page {page}: extracted {len(imgs)} image(s)" + (f" ({sum(1 for i in imgs if i['oversized'])} oversized)" if any(i['oversized'] for i in imgs) else ""))
    return imgs


def render_source_pages_for_vl(source: Path, output_dir: Path, profile: str) -> tuple[list[dict[str, Any]], dict[int, dict[str, str]], list[str]]:
    log("prepare image")
    errors: list[str] = []
    suffix = source.suffix.lower()
    try:
        if suffix == ".pdf":
            return prepare_pdf_pages_for_vl(source, output_dir, profile=profile)
        if suffix in {".pptx", ".ppt"}:
            return prepare_pptx_pages_for_vl(source, output_dir, profile=profile)
    except Exception as exc:
        errors.append(str(exc))
    return [], {}, errors


def fallback_visual_report(slide: dict[str, Any], theme: dict[str, Any]) -> dict[str, Any]:
    raw_role = str(slide.get("page_role") or "support")
    role = "ending" if raw_role == "summary" else raw_role
    layout = slide.get("layout") or {}
    text_count = layout.get("text_block_count", 0)
    image_count = layout.get("image_block_count", 0)
    shape_count = layout.get("shape_count", 0)
    pattern = layout.get("pattern") or "unknown"
    role = normalize_page_role(role)
    return {
        "page_role": role,
        "page_role_definition": PAGE_ROLE_DEFINITIONS.get(role, ""),
        "visual_report": (
            f"Legacy metadata fallback visual report. page_role={role}; layout_pattern={pattern}; "
            f"text_blocks={text_count}; image_blocks={image_count}; shape_count={shape_count}. "
            f"Preserve the template rhythm, theme background {theme.get('background', '')}, "
            f"text color {theme.get('text', '')}, accent {theme.get('accent', '')}, "
            f"and font family {theme.get('font_family', '')}. Do not copy topic-bound images."
        ),
        "layout_affordance": pattern,
        "source": "legacy_metadata_fallback",
    }


def normalized_theme(legacy_analysis: dict[str, Any]) -> dict[str, Any]:
    theme = dict(legacy_analysis.get("theme") or {})
    role_counts = []
    for item in theme.get("role_counts") or []:
        if not isinstance(item, dict):
            continue
        normalized = dict(item)
        if normalized.get("role") == "summary":
            normalized["role"] = "ending"
        role_counts.append(normalized)
    if role_counts:
        theme["role_counts"] = role_counts
    return theme


def validate_template_extraction_inputs(
    source: Path,
    legacy_analysis: dict[str, Any],
    fixed_pages: dict[str, str],
    rendered_pages: list[dict[str, Any]],
    render_errors: list[str],
    explicit_fixed_pages: dict[str, int],
) -> None:
    suffix = source.suffix.lower()
    if suffix not in {".pptx", ".ppt"}:
        return
    missing: list[str] = []
    if not legacy_analysis.get("slides") and not explicit_fixed_pages and not rendered_pages:
        missing.append(
            "PPTX slide/page-role analysis and rendered pages are missing. Pass --legacy-builder with a builder that writes "
            "_reference_html/analysis.json, pass --fixed-pages role=page, or install/fix the renderer so pages can be analyzed."
        )
    if not rendered_pages:
        detail = "; ".join(str(item) for item in render_errors if item) or "no renderer error detail was produced"
        missing.append(
            "PPTX page images were not rendered for VL extraction. Required renderer is unavailable or failed. "
            f"Renderer detail: {detail}"
        )
    if missing:
        raise RuntimeError("PPTX template extraction stopped because required inputs are missing:\n- " + "\n- ".join(missing))


def content_page_numbers_from_rendered(rendered_pages: list[dict[str, Any]], fixed_page_numbers: dict[str, int]) -> set[int]:
    fixed = set(fixed_page_numbers.values())
    return {int(item.get("page") or 0) for item in rendered_pages if int(item.get("page") or 0) and int(item.get("page") or 0) not in fixed}


def cap_content_page_numbers(pages: set[int], limit: int = MAX_VISUAL_CONTENT_PAGES) -> set[int]:
    ordered = sorted(pages)
    if len(ordered) <= limit:
        return set(ordered)
    if limit <= 0:
        return set()
    if limit == 1:
        return {ordered[0]}
    selected: list[int] = []
    for index in range(limit):
        pos = round(index * (len(ordered) - 1) / (limit - 1))
        selected.append(ordered[pos])
    return set(selected)


COMMON_LAYOUT_ROLES = {"support", "timeline", "process", "framework", "comparison", "chart", "gallery"}
SPECIAL_LAYOUT_FAMILIES = {"chapter_divider", "cover_like", "summary", "full_bleed", "special"}


def numeric_values(items: list[dict[str, Any]], path: tuple[str, ...]) -> list[float]:
    values: list[float] = []
    for item in items:
        current: Any = item
        for key in path:
            if not isinstance(current, dict):
                current = None
                break
            current = current.get(key)
        try:
            values.append(float(current))
        except (TypeError, ValueError):
            pass
    return values


def median_number(values: list[float], default: float = 0.0) -> float:
    if not values:
        return default
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2


def median_box(items: list[dict[str, Any]], key: str) -> dict[str, int]:
    return {
        "x": round(median_number(numeric_values(items, (key, "x")))),
        "y": round(median_number(numeric_values(items, (key, "y")))),
        "width": round(median_number(numeric_values(items, (key, "width")))),
        "height": round(median_number(numeric_values(items, (key, "height")))),
        "bottom": round(median_number(numeric_values(items, (key, "bottom")))),
    }


def group_fixed_elements(reports: list[dict[str, Any]], threshold: float) -> list[dict[str, Any]]:
    buckets: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for report in reports:
        for element in report.get("fixed_elements") or []:
            if not isinstance(element, dict) or not element.get("exists", True):
                continue
            element_type = str(element.get("type") or "").strip()
            position = str(element.get("position") or "").strip()
            if not element_type:
                continue
            buckets.setdefault((element_type, position), []).append(element)
    common: list[dict[str, Any]] = []
    minimum = max(2, round(len(reports) * threshold))
    for (element_type, position), elements in sorted(buckets.items()):
        if len(elements) < minimum:
            continue
        common.append(
            {
                "type": element_type,
                "position": position,
                "frequency": round(len(elements) / max(1, len(reports)), 2),
                "x": round(median_number(numeric_values(elements, ("x",)))),
                "y": round(median_number(numeric_values(elements, ("y",)))),
                "width": round(median_number(numeric_values(elements, ("width",)))),
                "height": round(median_number(numeric_values(elements, ("height",)))),
                "style": str(elements[0].get("style") or "")[:180],
            }
        )
    return common


def infer_common_layout_system(roles: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    reports: list[dict[str, Any]] = []
    for role, items in roles.items():
        if role not in COMMON_LAYOUT_ROLES:
            continue
        for item in items:
            family = str(item.get("layout_family") or "normal_content")
            zones = item.get("layout_zones") or {}
            constraints = item.get("layout_constraints") or {}
            if family in SPECIAL_LAYOUT_FAMILIES:
                continue
            if not isinstance(zones, dict):
                continue
            reports.append({"role": role, "layout_zones": zones, "layout_constraints": constraints, "fixed_elements": item.get("fixed_elements") or []})
    if len(reports) < 2:
        return {"enabled": False, "reason": "Not enough normal content pages with structured layout zones."}

    title_reports = [r for r in reports if (r.get("layout_zones") or {}).get("has_title_zone") and isinstance((r.get("layout_zones") or {}).get("title_zone"), dict)]
    threshold = 0.6
    enabled_roles = sorted({r["role"] for r in reports})
    system: dict[str, Any] = {
        "enabled": True,
        "applies_to_roles": enabled_roles,
        "excluded_roles": ["cover", "ending", "agenda", "chapter", "summary", "climax", "insight"],
        "sample_count": len(reports),
        "use_rule": "Apply only to normal content slides whose selected visual report belongs to this common layout family. Do not apply to cover, ending, agenda, chapter divider, summary, climax, insight, full-bleed, or special pages.",
    }
    if len(title_reports) >= max(2, round(len(reports) * threshold)):
        title_zone = median_box([r["layout_zones"] for r in title_reports], "title_zone")
        starts = numeric_values([r.get("layout_constraints") or {} for r in title_reports], ("main_content_start_y",))
        card_tops = numeric_values([r.get("layout_constraints") or {} for r in title_reports], ("card_top_min",))
        main_start = round(max(title_zone.get("bottom", 0) + 14, median_number(starts + card_tops, title_zone.get("bottom", 0) + 18)))
        system["title_system"] = {
            "enabled": True,
            "frequency": round(len(title_reports) / len(reports), 2),
            "zone": title_zone,
            "main_content_start_y": main_start,
            "rule": "When enabled, no card, table, chart, diagram, or body panel may overlap this title zone.",
        }
    else:
        system["title_system"] = {"enabled": False, "reason": "Normal content pages do not share a consistent title zone."}

    footer_reports = [r for r in reports if ((r.get("layout_zones") or {}).get("footer_zone") or {}).get("exists")]
    if len(footer_reports) >= max(2, round(len(reports) * threshold)):
        footer_zone = median_box([r["layout_zones"] for r in footer_reports], "footer_zone")
        system["footer_system"] = {
            "enabled": True,
            "frequency": round(len(footer_reports) / len(reports), 2),
            "zone": footer_zone,
            "safe_bottom_y": max(48, int(footer_zone.get("y") or 660) - 10),
            "rule": "No main content may overlap footer, page number, source note, or bottom decorative elements.",
        }
    else:
        system["footer_system"] = {"enabled": False}

    common_elements = group_fixed_elements(reports, threshold)
    system["fixed_elements"] = common_elements
    page_numbers = [item for item in common_elements if item.get("type") == "page_number"]
    system["page_number_system"] = {"enabled": bool(page_numbers), "elements": page_numbers}
    return system


# Roles excluded when deriving the deck-wide content style: their titles and
# layouts intentionally differ from normal content pages.
COMMON_STYLE_EXCLUDED_ROLES = {
    "cover", "chapter_cover", "section_divider", "legal_disclaimer",
    "ending", "agenda", "category", "climax", "insight",
}


def derive_common_style(roles: dict[str, list[dict[str, Any]]], theme: dict[str, Any] | None = None) -> dict[str, Any]:
    """Aggregate ONE deck-wide style from the per-page content contracts.

    Content slides should share a single title style (position, color, size,
    font) and palette so generated pages stop drifting (title changing color or
    moving page to page). Computed by taking the mode of categorical fields and
    the median of numeric ones across content-page contracts.
    """
    import collections
    import statistics

    contracts: list[dict[str, Any]] = []
    for role, items in (roles or {}).items():
        if role in COMMON_STYLE_EXCLUDED_ROLES:
            continue
        for it in items:
            c = it.get("template_contract") if isinstance(it, dict) else None
            if isinstance(c, dict):
                contracts.append(c)
    if not contracts:
        return {"enabled": False, "reason": "no content-page contracts to aggregate"}

    def _num(v: Any) -> float | None:
        try:
            return float(v)
        except (TypeError, ValueError):
            return None

    def mode(values: list[Any]) -> str:
        vals = [str(v).strip() for v in values if v not in (None, "", 0)]
        return collections.Counter(vals).most_common(1)[0][0] if vals else ""

    def median(values: list[Any]) -> int:
        nums = [n for n in (_num(v) for v in values) if n is not None and n > 0]
        return int(round(statistics.median(nums))) if nums else 0

    title_zones = [c.get("title_zone") or {} for c in contracts]
    title_zones = [t for t in title_zones if isinstance(t, dict) and t.get("present") is not False]
    title_tokens = [((c.get("style") or {}).get("typography_tokens") or {}).get("title") or {} for c in contracts]

    def tz(key: str, token_key: str | None = None) -> list[Any]:
        vals = [t.get(key) for t in title_zones if t.get(key) not in (None, "", 0)]
        if not vals and token_key:
            vals = [t.get(token_key) for t in title_tokens if t.get(token_key) not in (None, "", 0)]
        return vals

    title = {
        "anchor": mode(tz("anchor")) or "top-left",
        "align": mode(tz("align")) or "left",
        "x_pct": median(tz("x_pct")),
        "y_pct": median(tz("y_pct")),
        "width_pct": median(tz("width_pct")),
        "color": mode(tz("color", "color")),
        "size_px": median(tz("size_px", "size_px")),
        "font_weight": mode(tz("font_weight", "font_weight")) or "bold",
        "font_family": mode(tz("font_family", "font_family")),
        "decoration": mode(tz("decoration")) or "无",
    }

    # Palette: the most frequent hex per color role across content pages.
    role_colors: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    for c in contracts:
        for col in ((c.get("style") or {}).get("colors") or []):
            if isinstance(col, dict) and col.get("role") and col.get("hex"):
                role_colors[str(col["role"]).strip()][str(col["hex"]).strip().lower()] += 1
    colors = {role: cnt.most_common(1)[0][0] for role, cnt in role_colors.items() if cnt}

    def token_size(token_key: str) -> int:
        return median([((c.get("style") or {}).get("typography_tokens") or {}).get(token_key, {}).get("size_px") for c in contracts])

    def token_color(token_key: str) -> str:
        return mode([((c.get("style") or {}).get("typography_tokens") or {}).get(token_key, {}).get("color") for c in contracts])

    body_font = mode([((c.get("style") or {}).get("typography_tokens") or {}).get("body", {}).get("font_family") for c in contracts])
    background = mode([(c.get("style") or {}).get("background") for c in contracts])

    return {
        "enabled": True,
        "sample_count": len(contracts),
        "applies_to": "content slides (excludes cover/chapter/ending/special pages)",
        "title": title,
        "colors": colors,
        "background": background or (theme or {}).get("background", ""),
        "font_family": title["font_family"] or body_font,
        "font_sizes": {
            "title": title["size_px"] or token_size("title"),
            "section_heading": token_size("section_heading"),
            "body": token_size("body"),
        },
        "text_colors": {
            "section_heading": token_color("section_heading"),
            "body": token_color("body"),
        },
    }


def build_styles_json(
    source: Path,
    input_kind: str,
    legacy_analysis: dict[str, Any],
    fixed_pages: dict[str, str],
    rendered_pages: list[dict[str, Any]],
    page_metadata: dict[int, dict[str, str]],
    vl_errors: list[str],
    style_prompt_template: str,
    vision_base_url: str,
    vision_model: str,
    vision_api_key: str,
    vision_timeout: int,
    vl_concurrency: int,
    vl_retry_attempts: int,
    vl_retry_backoff_seconds: float,
    vl_retry_status_codes: list[int],
    resume_dir: Path | None = None,
    resume: bool = True,
    background_dir: Path | None = None,
    fixed_page_numbers: dict[str, int] | None = None,
    fixed_rendered_pages: list[dict[str, Any]] | None = None,
    fixed_page_metadata: dict[int, dict[str, str]] | None = None,
    structural_roles: dict[int, str] | None = None,
    tmp_dir: Path | None = None,
) -> dict[str, Any]:
    structural_roles = structural_roles or {}
    slides = legacy_analysis.get("slides") or []
    theme = normalized_theme(legacy_analysis)
    rendered_by_page = {int(item.get("page") or 0): item for item in rendered_pages}
    sampled_pages = set(rendered_by_page) | set(page_metadata)
    # Extract real in-page images (with geometry) so each page can reference its own
    # assets. Generation places each image by the visual report; oversized art is
    # flagged, not forced as a full-bleed background.
    page_images: dict[int, list[dict[str, Any]]] = {}

    log("build style json")
    if background_dir is not None:
        prs_obj = None
        slide_by_page: dict[int, Any] = {}
        if source.suffix.lower() in {".pptx", ".ppt"}:
            try:
                from pptx import Presentation
                prs_obj = Presentation(source)
                slide_by_page = {i: s for i, s in enumerate(prs_obj.slides, 1)}
            except Exception:
                prs_obj = None
        for page in sorted(set(sampled_pages) | set((fixed_page_numbers or {}).values())):
            try:
                imgs = extract_page_images(source, page, background_dir, slide=slide_by_page.get(page), prs=prs_obj)
                if imgs:
                    for im in imgs:
                        im["file"] = f"backgrounds/{im['file']}"
                    page_images[page] = imgs
            except Exception:
                pass
        if page_images:
            log(f"[images] extracted images for pages {sorted(page_images)}")
    roles: dict[str, list[dict[str, Any]]] = {}
    vision_call_errors: list[str] = []
    candidates: list[dict[str, Any]] = []
    if not slides:
        slides = [
            {
                "id": f"page_{page}",
                "page_index": page,
                "page_role": "support",
                "layout": {"pattern": "unknown"},
            }
            for page in sorted(sampled_pages)
        ]
    for slide in slides:
        page = int(slide.get("page_index") or 0)
        raw_role = str(slide.get("page_role") or "support")
        role = "ending" if raw_role == "summary" else raw_role
        if role in fixed_pages:
            continue
        if sampled_pages and page not in sampled_pages:
            continue
        candidates.append({"slide": slide, "page": page, "raw_role": raw_role, "role": role})

    vl_reports: dict[int, dict[str, Any]] = {}
    resumed_pages: list[int] = []
    requested_pages: list[int] = []
    report_cache_dir = resume_dir / "visual_reports" if resume_dir else None
    raw_report_cache_dir = resume_dir / "visual_report_raw" if resume_dir else None
    if report_cache_dir:
        report_cache_dir.mkdir(parents=True, exist_ok=True)
    if raw_report_cache_dir:
        raw_report_cache_dir.mkdir(parents=True, exist_ok=True)
    # Tie the per-page cache to the style prompt template: editing the prompt
    # (e.g. prompts/extra_image.txt) must invalidate stale extractions.
    prompt_hash = short_hash(style_prompt_template + "\nimage_asset_policy.v2\ntemplate_contract.v1+typography_tokens+structural_role+title_zone+font_size_px")
    if vision_api_key:
        def call_one(item: dict[str, Any]) -> tuple[int, dict[str, Any] | None, str | None]:
            page = int(item["page"])
            role = str(item["role"])
            slide = item["slide"]
            rendered = rendered_by_page.get(page)
            image_path = Path(str(rendered.get("output"))) if rendered else None
            if not image_path or not image_path.exists():
                return page, None, f"page {page}: missing rendered image"
            metadata = page_metadata.get(page) or {}
            prompt = build_visual_role_prompt(style_prompt_template, metadata, page_images.get(page) or [], structural_roles.get(page, ""))
            try:
                raw_cache_path = raw_report_cache_dir / f"page_{page:03d}.json" if raw_report_cache_dir else None
                raw_cached = safe_read_json(raw_cache_path) if resume and raw_cache_path else {}
                raw_matches = (
                    raw_cached.get("status") == "ok"
                    and raw_cached.get("source") == str(source)
                    and raw_cached.get("model") == vision_model
                    and raw_cached.get("base_url") == vision_base_url
                    and raw_cached.get("prompt_hash") == prompt_hash
                    and isinstance(raw_cached.get("visual_report"), str)
                    and raw_cached.get("visual_report")
                )
                if raw_matches:
                    visual_report = str(raw_cached.get("visual_report") or "")
                else:
                    visual_report = request_vl_report(
                        image_path,
                        prompt,
                        vision_base_url,
                        vision_model,
                        vision_api_key,
                        vision_timeout,
                        vl_retry_attempts,
                        vl_retry_backoff_seconds,
                        vl_retry_status_codes,
                    )
                    trace_step(tmp_dir, f"01_extract_page_{page:03d}", prompt=prompt, response=visual_report, image=Path(image_path) if image_path else None)
                    if raw_cache_path:
                        write_json(
                            raw_cache_path,
                            {
                                "status": "ok",
                                "page": page,
                                "source": str(source),
                                "model": vision_model,
                                "base_url": vision_base_url,
                                "prompt_hash": prompt_hash,
                                "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                                "visual_report": visual_report,
                            },
                        )
                payload = parse_visual_report_payload(
                    visual_report,
                    fallback_role=role,
                    fallback_layout=(slide.get("layout") or {}).get("pattern") or "unknown",
                    font_analysis=metadata.get("font_analysis", ""),
                )
                report = dict(payload)
                report.update(
                    {
                        "source": "vl_model",
                        "font_analysis": metadata.get("font_analysis", ""),
                        "color_analysis": metadata.get("color_analysis", ""),
                    }
                )
                return page, report, None
            except Exception as exc:
                return page, None, f"page {page}: {str(exc)[:240]}"

        pending_candidates: list[dict[str, Any]] = []
        for item in candidates:
            page = int(item["page"])
            cache_path = report_cache_dir / f"page_{page:03d}.json" if report_cache_dir else None
            cached = safe_read_json(cache_path) if resume and cache_path else {}
            cache_matches = (
                cached.get("status") == "ok"
                and cached.get("source") == str(source)
                and cached.get("model") == vision_model
                and cached.get("base_url") == vision_base_url
                and cached.get("prompt_hash") == prompt_hash
            )
            report = cached.get("report") if cache_matches else None
            if isinstance(report, dict) and report:
                vl_reports[page] = report
                resumed_pages.append(page)
            else:
                pending_candidates.append(item)
        requested_pages = [int(item["page"]) for item in pending_candidates]
        with ThreadPoolExecutor(max_workers=max(1, vl_concurrency)) as executor:
            futures = [executor.submit(call_one, item) for item in pending_candidates]
            for future in as_completed(futures):
                page, report, error = future.result()
                if report:
                    vl_reports[page] = report
                    if report_cache_dir:
                        write_json(
                            report_cache_dir / f"page_{page:03d}.json",
                            {
                                "status": "ok",
                                "page": page,
                                "source": str(source),
                                "model": vision_model,
                                "base_url": vision_base_url,
                                "prompt_hash": prompt_hash,
                                "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                                "report": report,
                            },
                        )
                if error:
                    vision_call_errors.append(error)
                    if report_cache_dir:
                        write_json(
                            report_cache_dir / f"page_{page:03d}.json",
                            {
                                "status": "failed",
                                "page": page,
                                "source": str(source),
                                "model": vision_model,
                                "base_url": vision_base_url,
                                "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                                "error": error,
                            },
                        )

    for item in candidates:
        slide = item["slide"]
        page = int(item["page"])
        raw_role = str(item["raw_role"])
        role = str(item["role"])
        report: dict[str, Any] = {}
        if page in vl_reports:
            report = vl_reports[page]
        if not report:
            report = fallback_visual_report(slide, theme)
            metadata = page_metadata.get(page) or {}
            report["font_analysis"] = metadata.get("font_analysis", "")
            report["color_analysis"] = metadata.get("color_analysis", "")
        for unwanted_key in ("template_selection_hints", "avoid_copying", "role_reason"):
            report.pop(unwanted_key, None)
        selected_role = normalize_page_role(report.get("page_role"), role)
        role_info = ((legacy_analysis.get("roles") or {}).get(selected_role) or (legacy_analysis.get("roles") or {}).get(role) or (legacy_analysis.get("roles") or {}).get(raw_role) or {})
        record = {
            "page": page,
            "source_slide": slide.get("id") or f"slide_{page}",
            "template": role_info.get("template"),
            **report,
        }
        imgs = page_images.get(page)
        if imgs:
            # Real in-page image assets available for reuse. Generation places each
            # one by the visual report; it must NOT stretch any of them full-bleed.
            record["page_images"] = imgs
            contract = record.get("template_contract")
            if isinstance(contract, dict):
                contract["page_images"] = imgs
        roles.setdefault(selected_role, []).append(record)
    # Extract a contract for each fixed page (cover/ending) so Stage B can render
    # them with the visual scheme instead of slot-filling the extracted HTML.
    fixed_nums = fixed_page_numbers or {}
    fixed_rendered_by_page = {int(it.get("page") or 0): it for it in (fixed_rendered_pages or [])}
    fixed_meta = fixed_page_metadata or {}
    if vision_api_key and fixed_nums:
        def extract_fixed(role: str, page: int) -> tuple[str, dict[str, Any] | None, str | None]:
            rendered = fixed_rendered_by_page.get(int(page))
            image_path = Path(str(rendered.get("output"))) if rendered else None
            if not image_path or not image_path.exists():
                return role, None, None
            metadata = fixed_meta.get(int(page)) or {}
            prompt = build_visual_role_prompt(style_prompt_template, metadata, page_images.get(int(page)) or [], structural_roles.get(int(page), role))
            try:
                visual_report = request_vl_report(
                    image_path, prompt, vision_base_url, vision_model, vision_api_key,
                    vision_timeout, vl_retry_attempts, vl_retry_backoff_seconds, vl_retry_status_codes,
                )
                payload = parse_visual_report_payload(
                    visual_report, fallback_role=role, fallback_layout="unknown",
                    font_analysis=metadata.get("font_analysis", ""),
                )
                report = dict(payload)
                report.update({
                    "page": int(page),
                    "source": "vl_model",
                    "font_analysis": metadata.get("font_analysis", ""),
                    "color_analysis": metadata.get("color_analysis", ""),
                })
                imgs = page_images.get(int(page))
                if imgs:
                    report["page_images"] = imgs
                    contract = report.get("template_contract")
                    if isinstance(contract, dict):
                        contract["page_images"] = imgs
                return role, report, None
            except Exception as exc:
                return role, None, f"fixed page {role} (p{page}): {str(exc)[:200]}"

        # Extract every fixed page concurrently rather than one-at-a-time.
        with ThreadPoolExecutor(max_workers=max(1, vl_concurrency)) as executor:
            futures = [executor.submit(extract_fixed, role, int(page)) for role, page in fixed_nums.items()]
            for future in as_completed(futures):
                role, report, error = future.result()
                if report:
                    roles.setdefault(role, []).append(report)
                    log(f"[fixed-page] extracted contract for {role} (page {report.get('page')})")
                if error:
                    vision_call_errors.append(error)

    common_layout_system = infer_common_layout_system(roles)
    common_style = derive_common_style(roles, theme)
    return {
        "schema_version": "prompt_ppt_styles.v1",
        "source": str(source),
        "input_kind": input_kind,
        "canvas": {"width": 1280, "height": 720},
        "theme": theme,
        "fixed_pages": fixed_pages,
        "common_layout_system": common_layout_system,
        "common_style": common_style,
        "roles": roles,
        "vision": {
            "model": vision_model,
            "base_url": vision_base_url,
            "enabled": bool(vision_api_key),
            "concurrency": max(1, vl_concurrency),
            "retry_attempts": max(1, vl_retry_attempts),
            "retry_backoff_seconds": max(0.0, vl_retry_backoff_seconds),
            "retry_status_codes": vl_retry_status_codes,
            "resume_enabled": resume,
            "resumed_pages": sorted(resumed_pages),
            "requested_pages": sorted(requested_pages),
            "rendered_pages": rendered_pages,
            "render_errors": vl_errors,
            "call_errors": vision_call_errors,
        },
    }


def render_verification_pages(
    styles: dict[str, Any],
    output_dir: Path,
    verify_dir: Path,
    tmp_dir: Path | None,
    *,
    gen_base_url: str,
    gen_model: str,
    gen_api_key: str,
    gen_timeout: int,
) -> int:
    """Render one mounted HTML preview per extracted page via the shared renderer.

    Delegates to generate_preview_html_fast.generate_deck so the pipeline's
    --verify-render uses the exact same template-agnostic logic as the standalone
    CLI: mandatory blank-template mount, no reused source background imagery,
    diagram-style guidance, and thin-response retries. One rendering path only.
    """
    log("generate templates")
    import generate_preview_html_fast as gp

    cfg = {"generation": {"base_url": gen_base_url, "model": gen_model, "api_key": gen_api_key}}
    written, attempted = gp.generate_deck(
        output_dir,
        cfg,
        workers=3,
        timeout=max(int(gen_timeout) * 3, 420),
        max_tokens=4600,
        log=log,
    )
    log(f"[verify] {written}/{attempted} page(s) rendered -> {verify_dir}")
    return written



def build_prompt_template_system(
    source: Path,
    output_dir: Path,
    *,
    force: bool = True,
    vision_timeout: int = 120,
    vision_retry_attempts: int | None = None,
    vision_retry_backoff_seconds: float | None = None,
    vision_retry_status_codes: str | None = None,
    style_prompt: Path = Path(DEFAULT_STYLE_PROMPT),
    config_path: Path = DEFAULT_CONFIG,
    keep_intermediate: bool = True,
    verify_render: bool = False,
    resume: bool = True,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    if force:
        # Re-run from a clean slate but, when resuming, keep the per-page VL cache
        # so already-extracted pages are not re-requested.
        remove_obsolete_outputs(output_dir, keep_cache=resume)
    styles_path = output_dir / "styles.json"
    clusters_path = output_dir / "_background_clusters.json"
    existing_styles = safe_read_json(styles_path) if styles_path.exists() else {}
    # tmp/ keeps a full trace of every model interaction (prompt, image, response)
    # for each step, so each stage of extraction can be inspected after a run.
    tmp_dir = output_dir / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    log(f"[run] source={source} output={output_dir} verify_render={verify_render}")

    # legacy builder fully removed; extraction works purely from rendered pages.
    legacy_analysis: dict[str, Any] = {}
    vl_pages_dir = output_dir / "_vl_pages"
    if any(vl_pages_dir.glob("page_*.jpg")):
        rendered_pages, page_metadata, render_errors = load_existing_rendered_pages(vl_pages_dir, existing_styles)
        log(f"[render] existing _vl_pages -> skip render ({len(rendered_pages)} page(s))")
    else:
        rendered_pages, page_metadata, render_errors = render_source_pages_for_vl(source, vl_pages_dir, profile="analysis")
    log(f"[render] {len(rendered_pages)} page(s) rendered; errors={len(render_errors)}")
    config = read_config(config_path)
    vision_config = config.get("vision") or {}
    # Always bind these from config so they exist even when a key is absent;
    # an empty base_url/model surfaces clearly downstream instead of NameError.
    vision_base_url = str(vision_config.get("base_url") or "")
    vision_model = str(vision_config.get("model") or "")
    retry_status_codes = (
        [int(code.strip()) for code in vision_retry_status_codes.split(",") if code.strip()]
        if vision_retry_status_codes
        else list(config.get("vl_retry_status_codes") or [408, 429, 500, 502, 503, 504])
    )
    vl_retry_attempts = int(vision_retry_attempts or config.get("vl_retry_attempts") or 3)
    vl_retry_backoff = float(
        vision_retry_backoff_seconds
        if vision_retry_backoff_seconds is not None
        else config.get("vl_retry_backoff_seconds") or 2.0
    )
    vision_api_key = str(vision_config.get("api_key") or "")
    # Structural prescan: classify every rendered page (cover/summary/agenda/
    # chapter_cover/chapter_content/ending/normal) so extraction can sample by the
    # real deck structure instead of a flat first-N window.
    structure_path = output_dir / "_structure.json"
    if structure_path.exists():
        structure_scan = safe_read_json(structure_path)
        log("[structure] _structure.json exists -> skip")
    else:
        structure_scan = run_structure_prescan(
            rendered_pages,
            output_dir,
            vision_base_url=vision_base_url,
            vision_model=vision_model,
            vision_api_key=vision_api_key,
            vision_timeout=vision_timeout,
            vl_retry_attempts=vl_retry_attempts,
            vl_retry_backoff_seconds=vl_retry_backoff,
            vl_retry_status_codes=retry_status_codes,
            tmp_dir=tmp_dir,
            per_sheet=20,
            max_pages=int(config.get("structure_max_pages") or 80),
        )
        write_json(structure_path, structure_scan)
    log("Build overall thumbnail")
    fixed_detection_mode = "disabled"
    fixed_pages: dict[str, str] = {}
    validate_template_extraction_inputs(source, legacy_analysis, fixed_pages, rendered_pages, render_errors, {})
    all_content_pages = content_page_numbers_from_rendered(rendered_pages, {})
    if not all_content_pages:
        detail = "; ".join(str(item) for item in render_errors if item) or "no render errors"
        raise RuntimeError(f"No content pages identified. Render detail: {detail}")
    page_roles = {int(k): v for k, v in (structure_scan.get("page_roles") or {}).items()}
    if structure_scan.get("structure_ran") and page_roles:
        # Structure-driven sampling: fixed pages always extracted; remaining
        # budget spread across chapters weighted by content size.
        total = max(all_content_pages)
        structure = derive_deck_structure(page_roles, total)
        selected = allocate_extraction_pages(
                structure, page_roles,
                budget_with_chapters=int(config.get("extraction_budget_with_chapters") or 20),
                budget_without_chapters=int(config.get("extraction_budget_without_chapters") or 10),
            )
        # Restrict to pages we actually rendered.
        content_pages = {p for p in selected if p in all_content_pages}
        log(
            f"[structure] has_chapters={structure['has_chapters']} chapters={len(structure['chapters'])} "
            f"fixed={structure['fixed_pages']} -> extracting {len(content_pages)} page(s): {sorted(content_pages)}"
        )
        styles_structure = structure
    else:
        # Fallback: structure prescan returned nothing usable -> flat sampling,
        # still honoring an ending page if one was classified.
        log("[structure] no structure detected -> flat sampling fallback")
        ending_page = next((p for p, r in page_roles.items() if r == "ending"), None)
        if ending_page and all_content_pages:
            last = max(all_content_pages)
            second_last = max((p for p in all_content_pages if p < last), default=None)
            trailing = {p for p in (last, second_last) if p}
            if int(ending_page) in trailing:
                drop = trailing - {int(ending_page)}
                if drop:
                    all_content_pages = all_content_pages - drop
                    log(f"[ending] ending page {ending_page}; dropping trailing page(s) {sorted(drop)}")
        content_pages = cap_content_page_numbers(all_content_pages)
        styles_structure = None

    if styles_complete_for_pages(existing_styles, content_pages):
        styles = existing_styles
        log("[styles] styles.json covers selected pages -> skip contract extraction")
    else:
        if styles_have_roles(existing_styles):
            missing = sorted(content_pages - styles_pages_with_contracts(existing_styles))
            log(f"[styles] styles.json incomplete; missing selected page(s) {missing} -> rebuild contract extraction")
        rendered_pages = [item for item in rendered_pages if int(item.get("page") or 0) in content_pages]
        page_metadata = {page: data for page, data in page_metadata.items() if page in content_pages}
        style_prompt_template = style_prompt.read_text(encoding="utf-8")
        styles = build_styles_json(
            source=source,
            input_kind=source.suffix.lower().lstrip("."),
            legacy_analysis=legacy_analysis,
            fixed_pages=fixed_pages,
            rendered_pages=rendered_pages,
            page_metadata=page_metadata,
            vl_errors=render_errors,
            style_prompt_template=style_prompt_template,
            vision_base_url=vision_base_url,
            vision_model=vision_model,
            vision_api_key=vision_api_key,
            vision_timeout=vision_timeout,
            vl_concurrency=int(config.get("vl_concurrency") or 3),
            vl_retry_attempts=vl_retry_attempts,
            vl_retry_backoff_seconds=vl_retry_backoff,
            vl_retry_status_codes=retry_status_codes,
            resume_dir=output_dir / "_resume",
            resume=resume,
            background_dir=output_dir / "backgrounds",
            fixed_page_numbers={},
            fixed_rendered_pages=[],
            fixed_page_metadata={},
            structural_roles=page_roles,
            tmp_dir=tmp_dir,
        )
        styles.setdefault("vision", {})["content_page_total"] = len(all_content_pages)
        styles.setdefault("vision", {})["content_page_limit"] = MAX_VISUAL_CONTENT_PAGES
        styles.setdefault("vision", {})["sampled_content_pages"] = sorted(content_pages)
        if styles_structure is not None:
            styles["structure"] = styles_structure
        styles.setdefault("vision", {})["fixed_page_detection"] = {"mode": fixed_detection_mode}

    contracts_by_page: dict[int, dict[str, Any]] = {}
    for role, items in (styles.get("roles") or {}).items():
        for it in items:
            if isinstance(it, dict) and it.get("template_contract"):
                pg = int(it.get("page") or 0)
                if pg:
                    contracts_by_page[pg] = it["template_contract"]
    gen_cfg = config.get("generation") or {}
    log(f"[blank] generation config: model={gen_cfg.get('model')!r} base_url={'set' if gen_cfg.get('base_url') else 'EMPTY'} api_key={'set' if gen_cfg.get('api_key') else 'EMPTY'}")
    log(f"[background] contracts available for {len(contracts_by_page)} pages; rendered={len(rendered_pages)}")
    if isinstance(styles.get("background_clusters"), list) and styles.get("background_clusters"):
        clusters = list(styles["background_clusters"])
        log("[background] styles.json contains background_clusters -> skip")
    elif clusters_path.exists():
        cached_clusters = safe_read_json(clusters_path).get("clusters")
        clusters = cached_clusters if isinstance(cached_clusters, list) else []
        log("[background] _background_clusters.json exists -> skip")
    else:
        clusters = cluster_backgrounds_with_vl(
            rendered_pages, styles, structure_scan, output_dir,
            vision_base_url=vision_base_url, vision_model=vision_model, vision_api_key=vision_api_key,
            vision_timeout=vision_timeout, vl_retry_attempts=vl_retry_attempts,
            vl_retry_backoff_seconds=vl_retry_backoff, vl_retry_status_codes=retry_status_codes,
            tmp_dir=tmp_dir,
        )
        write_json(clusters_path, {"clusters": clusters})
    log(f"[background] result: {len(clusters)} cluster(s)")
    blank_dir = output_dir / "blank_templates"
    # Blank templates are built deterministically: convert each clustered page to
    # SVG and keep only the drawable elements (logo, decorations, shared
    # background) that repeat byte-for-byte across the cluster. Page-specific
    # content (text, per-slide graphics) is dropped, leaving the content area
    # empty. No model redraws the background.
    from blank_template_svg import prepare_source_pdf, render_pages_to_svg, write_blank_template, write_page_blank_template, deck_shared_path_keys

    cluster_svgs: dict[int, str] = {}
    shared_chrome: set = set()
    needed_pages = {int(p) for cl in clusters for p in (cl.get("pages") or []) if str(p).strip().isdigit()}
    if needed_pages:
        pdf_for_svg = prepare_source_pdf(source, output_dir)
        if pdf_for_svg is None:
            log("[blank] WARNING: no PDF/LibreOffice available for SVG conversion; blank templates skipped")
        else:
            cluster_svgs = render_pages_to_svg(pdf_for_svg, needed_pages)
            # Deck-wide recurring vector decorations (e.g. ribbons sweeping across
            # the canvas) are template chrome even though they fail the perimeter
            # test; keep them by recurrence.
            shared_chrome = deck_shared_path_keys(cluster_svgs)
            log(f"[blank] converted {len(cluster_svgs)}/{len(needed_pages)} clustered page(s) to SVG; {len(shared_chrome)} recurring chrome path(s)")
    blank_threshold = float(config.get("blank_template_shared_threshold") or 0.6)
    page_to_cluster: dict[int, str] = {}
    # Content slides decorate each page differently, so a cluster-wide
    # intersection would drop a corner that one page has but its siblings lack.
    # Build those PER PAGE from each page's own perimeter chrome. Chapter covers
    # and one-off fixed pages keep the shared cluster template (unified look).
    page_blank: dict[int, str | None] = {}
    for cl in clusters:
        cid = str(cl.get("cluster_id") or "")
        pages = [int(p) for p in (cl.get("pages") or []) if str(p).strip().isdigit()]
        if str(cl.get("cluster_kind") or "") == "content_background":
            for pg in pages:
                ref = page_blank.get(pg)
                existing = f"blank_templates/page_{pg:03d}.html"
                if (output_dir / existing).exists():
                    ref = existing
                    log(f"[blank] page {pg} exists -> skip")
                elif ref is None:
                    ref = write_page_blank_template(pg, cluster_svgs, blank_dir, shared_chrome=shared_chrome, log=log)
                page_blank[pg] = ref
                page_to_cluster[pg] = cid
            cl["blank_template"] = None
        else:
            existing_ref = str(cl.get("blank_template") or f"blank_templates/{cid}.html")
            if cid and (output_dir / existing_ref).exists():
                blank_ref: str | None = existing_ref
                log(f"[blank] cluster {cid} exists -> skip")
            else:
                blank_ref = write_blank_template(cl, cluster_svgs, blank_dir, threshold=blank_threshold, shared_chrome=shared_chrome, log=log)
            log(f"[blank] cluster {cl.get('cluster_id')} -> {blank_ref or 'none'}")
            cl["blank_template"] = blank_ref
            for pg in pages:
                page_blank[pg] = blank_ref
                page_to_cluster[pg] = cid
    for role, items in (styles.get("roles") or {}).items():
        for it in items:
            if not isinstance(it, dict):
                continue
            page = int(it.get("page") or 0)
            cid = page_to_cluster.get(page)
            if cid:
                it["background_cluster"] = cid
                it["layout_cluster"] = cid
                it["blank_template"] = page_blank.get(page)
                if isinstance(it.get("template_contract"), dict):
                    it["template_contract"]["background_cluster"] = cid
                    it["template_contract"]["layout_cluster"] = cid
    styles["background_clusters"] = clusters
    styles["layout_clusters"] = clusters

    write_json(output_dir / "styles.json", styles)
    log("[run] styles.json written")

    # Verify-render: synthesize a complete HTML page (fictional content) per
    # extracted page, to visually confirm the template was captured correctly.
    if verify_render:
        verify_dir = output_dir / "verify_render"
        rendered_count = render_verification_pages(
            styles, output_dir, verify_dir, tmp_dir,
            gen_base_url=str(gen_cfg.get("base_url") or vision_base_url),
            gen_model=str(gen_cfg.get("model") or "glm-4.6"),
            gen_api_key=str(gen_cfg.get("api_key") or vision_api_key),
            gen_timeout=vision_timeout,
        )
        log(f"[verify] rendered {rendered_count} verification page(s) -> {verify_dir}")

    if not keep_intermediate:
        vl_pages = output_dir / "_vl_pages"
        if vl_pages.exists():
            shutil.rmtree(vl_pages)


def run(input_path: str | Path, output_path: str | Path, *, verify_render: bool = False, force: bool = True, resume: bool = True) -> None:
    """Simple launcher: extract a template system from `input` into `output`.

    Everything else (models, retries, prompts) comes from config.json. Set
    verify_render=True to also generate per-page verification HTML. resume=True
    (default) reuses the per-page VL extraction cache so already-done pages are
    not re-requested, even with force=True.
    """
    build_prompt_template_system(
        Path(input_path),
        Path(output_path),
        force=force,
        verify_render=verify_render,
        resume=resume,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a prompt-driven HTML PPT template system from PDF/PPTX.")
    parser.add_argument("source", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--vision-timeout", type=int, default=120)
    parser.add_argument("--vision-retry-attempts", type=int, help="Total VL attempts per page, including the first request.")
    parser.add_argument("--vision-retry-backoff-seconds", type=float, help="Initial VL retry backoff in seconds; doubles after each failed attempt.")
    parser.add_argument("--vision-retry-status-codes", help="Comma-separated HTTP status codes that trigger a VL retry, e.g. 408,429,500,502,503,504.")
    parser.add_argument("--style-prompt", type=Path, default=Path(DEFAULT_STYLE_PROMPT))
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--keep-intermediate", action="store_true", default=True)
    parser.add_argument("--verify-render", action="store_true", help="Also generate per-page verification HTML (fictional content) to inspect extraction quality.")
    parser.add_argument("--no-resume", action="store_true", help="Ignore the per-page extraction cache and re-run VL for every page.")
    return parser.parse_args()


def main() -> None:
    try:
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass
    args = parse_args()
    # Vision endpoint/model/key come from config.json (read inside
    # build_prompt_template_system), so the CLI only forwards the args that the
    # function actually accepts.
    build_prompt_template_system(
        args.source,
        args.output_dir,
        force=args.force,
        vision_timeout=args.vision_timeout,
        vision_retry_attempts=args.vision_retry_attempts,
        vision_retry_backoff_seconds=args.vision_retry_backoff_seconds,
        vision_retry_status_codes=args.vision_retry_status_codes,
        style_prompt=args.style_prompt,
        config_path=args.config,
        keep_intermediate=args.keep_intermediate,
        verify_render=args.verify_render,
        resume=not args.no_resume,
    )


if __name__ == "__main__":
    main()
