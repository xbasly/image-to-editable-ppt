#!/usr/bin/env python
from __future__ import annotations

import argparse
import html
import json
import os
import re
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize_base_url(url: str) -> str:
    return url.rstrip("/").removesuffix("/v1").rstrip("/") + "/v1"


def response_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") or []
    msg = (choices[0] or {}).get("message") if choices else {}
    content = (msg or {}).get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(x.get("text") or "") for x in content if isinstance(x, dict))
    return str((msg or {}).get("reasoning_content") or "")


def stream_delta_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") or []
    if not choices or not isinstance(choices[0], dict):
        return ""
    choice = choices[0]
    delta = choice.get("delta") if isinstance(choice.get("delta"), dict) else {}
    content = delta.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(x.get("text") or "") for x in content if isinstance(x, dict))
    for key in ("reasoning_content", "reasoning"):
        value = delta.get(key)
        if isinstance(value, str):
            return value
    return response_text({"choices": [{"message": choice.get("message") or {}}]})


def read_stream(resp: Any) -> str:
    chunks: list[str] = []
    for raw in resp:
        line = raw.decode("utf-8", errors="ignore").strip()
        if not line or not line.startswith("data:"):
            continue
        payload = line.removeprefix("data:").strip()
        if payload == "[DONE]":
            break
        data = json.loads(payload)
        while isinstance(data, str):
            data = json.loads(data)
        text = stream_delta_text(data)
        if text:
            chunks.append(text)
    return "".join(chunks)


def pages(styles: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    for role, items in (styles.get("roles") or {}).items():
        for item in items:
            if isinstance(item, dict) and item.get("template_contract"):
                out.append({"role": role, **item})
    return sorted(out, key=lambda x: int(x.get("page") or 0))


def summarize(item: dict[str, Any]) -> str:
    contract = item.get("template_contract") or {}
    style = contract.get("style") or {}
    slots = contract.get("slots") or {}
    image_policy = contract.get("image_asset_policy") or {}
    background_strategy = contract.get("background_strategy") or {}
    colors = ", ".join(
        f'{c.get("role")} {c.get("hex")}' for c in (style.get("colors") or [])[:5] if isinstance(c, dict)
    )
    type_tokens = ", ".join(
        f'{role}:{t.get("size_px")}px/{t.get("color")}/{t.get("font_weight") or "regular"}'
        for role, t in (style.get("typography_tokens") or {}).items()
        if isinstance(t, dict) and t.get("size_px")
    )
    images = []
    for im in item.get("page_images") or []:
        if not im.get("oversized"):
            images.append(
                f'../{im["file"]} at {im["left_pct"]}%/{im["top_pct"]}% size {im["width_pct"]}%x{im["height_pct"]}%'
            )
    blank_ref = str(item.get("blank_template") or "")
    blank_note = "none (draw the background yourself)"
    if blank_ref:
        blank_note = (
            f"{blank_ref}; this shared background/chrome is ALREADY mounted behind your output. "
            "Do not redraw it; generate only transparent foreground content."
        )
    # When a blank template is mounted it already carries every background/logo/
    # chrome image, so the source image_asset_policy and page_images must not be
    # re-placed (otherwise the model drops a source background photo into the
    # slide as a small content image).
    if blank_ref:
        image_policy_line = "(provided by blank_template; do NOT place any background/logo/chrome image)"
        assets_line = "none (all imagery is in the mounted template)"
    else:
        image_policy_line = json.dumps(image_policy, ensure_ascii=False)[:1000]
        assets_line = '; '.join(images) if images else 'none'
    return f"""role={item.get('role')}
layout_kind={contract.get('layout_kind')}
title_slot={slots.get('title')}
subtitle_slot={slots.get('subtitle')}
sections={slots.get('sections')}
chart={slots.get('chart')}
images_slot={slots.get('images')}
colors={colors}
typography={style.get('typography')}
typography_tokens={type_tokens or 'none'}
background={style.get('background')}
image_asset_policy={image_policy_line}
background_strategy={json.dumps(background_strategy, ensure_ascii=False)[:700]}
blank_template={blank_note}
visual={str(item.get('visual_report') or '')[:500]}
assets={assets_line}"""


def blank_template_excerpt(item: dict[str, Any]) -> str:
    output_dir = item.get("_output_dir")
    blank_ref = str(item.get("blank_template") or "")
    if not output_dir or not blank_ref:
        return ""
    path = Path(output_dir) / blank_ref
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8", errors="ignore")
    # Templates that embed background photos are huge (base64); their head is just
    # clip-path defs and adds no useful signal, so skip it. template_image_guidance
    # already tells the model where those photos sit.
    if len(text) > 20000 or "base64," in text[:6000]:
        return ""
    return text[:4500]


def template_image_guidance(item: dict[str, Any]) -> str:
    """Tell the model which regions the mounted template already fills with a
    background photo, so it never overlays an image slot / placeholder there."""
    output_dir = item.get("_output_dir")
    blank_ref = str(item.get("blank_template") or "")
    if not output_dir or not blank_ref:
        return ""
    path = Path(output_dir) / blank_ref
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r"(?is)(<svg\b.*?</svg>)", text)
    if not match:
        return ""
    try:
        from blank_template_svg import template_image_bboxes, _viewbox_wh
    except Exception:
        return ""
    svg = match.group(1)
    canvas_w, canvas_h = _viewbox_wh(svg)
    area = canvas_w * canvas_h
    regions = []
    for x0, y0, x1, y1 in template_image_bboxes(svg):
        if (x1 - x0) * (y1 - y0) < 0.12 * area:
            continue  # ignore tiny decorative images
        lx, rx = max(0, round(100 * x0 / canvas_w)), min(100, round(100 * x1 / canvas_w))
        ty, by = max(0, round(100 * y0 / canvas_h)), min(100, round(100 * y1 / canvas_h))
        regions.append(f"x {lx}%-{rx}%, y {ty}%-{by}%")
    if not regions:
        return ""
    return (
        "The mounted template ALREADY fills these regions with a background photo: "
        + "; ".join(regions)
        + ". Do NOT place any <img>, content photo, image slot, or 'Image Placeholder' box anywhere on the slide — the template already supplies all imagery. "
        "Put your text/diagram foreground in the open area and keep it clear of those photo regions."
    )


def strip(text: str) -> str:
    text = text.strip()
    fenced = re.findall(r"(?is)```(?:html)?\s*(.*?)```", text)
    html_fenced = [block.strip() for block in fenced if "<" in block]
    if html_fenced:
        text = html_fenced[-1]
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n", "", text)
        text = re.sub(r"\n```\s*$", "", text)
    complete = re.findall(r"(?is)(?:<!doctype\s+html[^>]*>\s*)?<html\b.*?</html>", text)
    if complete:
        text = complete[-1]
    else:
        match = re.search(r"(?is)(<!doctype\s+html|<html\b)", text)
        if match:
            text = text[match.start():]
        elif re.search(r"(?is)<(style|div|svg|section|main|body)\b", text):
            text = (
                '<!doctype html><html><head><meta charset="utf-8"></head>'
                f"<body>{text}</body></html>"
            )
    return text.strip()


def call_glm(prompt: str, cfg: dict[str, Any], timeout: int, max_tokens: int, stream: bool) -> str:
    # Delegates all HTTP/streaming to the shared llm_client (single place to
    # configure url/key/model); keeps the local strip() post-processing.
    import llm_client
    chat = llm_client.chat_config(cfg, timeout=timeout)
    return strip(llm_client.chat_complete(
        prompt, cfg=chat, max_tokens=max_tokens, stream=stream, temperature=0.2, echo=False,
    ))


def write_index(output_dir: Path, verify_dir: Path) -> None:
    files = sorted(verify_dir.glob("verify_*.html"))
    frames = "\n".join(
        f'<iframe src="{html.escape(verify_dir.name)}/{html.escape(p.name)}" width="1280" height="720"></iframe>'
        for p in files
    )
    (output_dir / "presentation.html").write_text(
        '<!doctype html><html><head><meta charset="utf-8"><title>Verification Presentation</title>'
        '<style>body{margin:0;background:#111;display:flex;flex-direction:column;align-items:center;gap:16px;padding:16px}'
        'iframe{border:0;background:white}</style></head><body>' + frames + "</body></html>\n",
        encoding="utf-8",
    )


def apply_blank_template_frame(text: str, item: dict[str, Any]) -> str:
    """Always mount the page's shared blank template behind the foreground.

    The blank template carries the shared chrome (background, logo, decorations,
    full-canvas/edge images) for the page's cluster. Mounting it unconditionally
    keeps every page in a cluster visually consistent and on-brand, instead of
    letting the model redraw a different background per page.
    """
    blank_ref = str(item.get("blank_template") or "")
    if not blank_ref:
        return text
    src = html.escape("../" + blank_ref if not blank_ref.startswith("../") else blank_ref)
    frame = (
        f'<iframe class="blank-template-frame" src="{src}" '
        'style="position:fixed;left:0;top:0;width:1280px;height:720px;'
        'border:0;z-index:0;pointer-events:none;background:#fff"></iframe>'
    )
    style = (
        "<style>"
        "html,body{background:transparent!important;background-color:transparent!important;}"
        "body>*:not(.blank-template-frame){position:relative;z-index:1;}"
        "</style>"
    )
    # Drop any optional placeholder the model may still have emitted.
    text = text.replace("{{BLANK_TEMPLATE}}", "")
    text = re.sub("(?i)</head>", style + "</head>", text, count=1) if "</head>" in text.lower() else style + text
    # Mount the template as the first body child so it sits behind everything.
    if re.search(r"(?i)<body[^>]*>", text):
        text = re.sub(r"(?i)(<body[^>]*>)", lambda m: m.group(1) + frame, text, count=1)
    else:
        text = frame + text
    return text


def deck_style_guide(common_style: dict[str, Any] | None) -> str:
    """Render the deck-wide common style as a hard consistency instruction.

    The title style is fixed across the whole deck so generated slides stop
    drifting (title changing color or moving page to page); content layout may
    still adapt.
    """
    cs = common_style or {}
    if not cs.get("enabled"):
        return ""
    t = cs.get("title") or {}
    colors = cs.get("colors") or {}
    fs = cs.get("font_sizes") or {}
    parts: list[str] = []
    if t.get("color") or t.get("size_px"):
        deco = t.get("decoration")
        parts.append(
            "TITLE (render IDENTICALLY on every slide — never change its color, size, font, alignment, or position): "
            f"color {t.get('color')}, size {t.get('size_px')}px, weight {t.get('font_weight') or 'bold'}, "
            f"font {t.get('font_family')}, anchored {t.get('anchor') or 'top-left'}, aligned {t.get('align') or 'left'}"
            f", at about x{t.get('x_pct')}%/y{t.get('y_pct')}% of the canvas"
            + (f", with {deco}" if deco and deco != "无" else "")
            + ". "
        )
        # Reserve a top band for the title so content never overlaps it and the
        # title position stays stable across pages.
        if str(t.get("anchor") or "").startswith("top"):
            try:
                y_px = float(t.get("y_pct") or 5) / 100.0 * 720.0
                band = int(round(max(96.0, y_px + float(t.get("size_px") or 32) * 1.6 + 16)))
            except (TypeError, ValueError):
                band = 110
            parts.append(
                f"Reserve the top {band}px of the canvas for this title band; place ALL other content "
                f"(cards, diagrams, nodes, text, subtitle) strictly BELOW {band}px so nothing overlaps the title. "
            )
    if colors:
        parts.append("PALETTE (use these exact roles/colors): " + ", ".join(f"{r} {h}" for r, h in colors.items()) + ". ")
    if any(fs.values()):
        parts.append(f"FONT SIZES: title {fs.get('title')}px, heading {fs.get('section_heading')}px, body {fs.get('body')}px. ")
    if cs.get("font_family"):
        parts.append(f"FONT FAMILY: {cs.get('font_family')}. ")
    if not parts:
        return ""
    return (
        "DECK STYLE GUIDE — apply consistently across ALL slides. The TITLE style below is FIXED deck-wide: "
        "use the exact same title color, size, font, alignment, and position on every page. Content and body "
        "blocks may adapt their layout, but the title must not drift.\n" + "".join(parts) + "\n\n"
    )


# Shared foreground rules — used by both the template-QA renderer (fictional
# content) and the content-driven deck renderer (real content). Covers mounting,
# transparency, diagram planning, layout safety, connectors and charts.
FOREGROUND_RULES = (
    "Use CSS font sizes in px only, never pt, with sane slide-scale hierarchy. "
    "Keep the HTML concise; no external fonts or scripts. "
    "NEVER emit an <img> that points to ../backgrounds/ or otherwise reuse a source background/logo/chrome image — all template imagery is already mounted behind you; placing one drops a shrunken background photo into the slide. "
    "IMPORTANT — a shared background/chrome template is ALREADY mounted behind your output as a full-canvas layer (it carries the slide's background color, decorations, logo, and any template images). "
    "Generate ONLY the foreground content (titles, text, cards, diagrams) on a FULLY TRANSPARENT background. "
    "Do NOT set any background color or gradient on html/body/root/slide wrappers, and do NOT add a full-canvas background div, box, or image. Do NOT redraw the template's decorations, corner shapes, logo, or background photos — they are already shown behind you. Keep all wrappers transparent so the mounted template stays visible. "
    "For diagram slides (concept_diagram, framework, process, timeline, chart): you are RECONSTRUCTING the design intent, not tracing it pixel by pixel. First PLAN the diagram yourself — work out the real entities and exactly how they relate — then choose the clearest standard structure for those relationships (hub-and-spoke, layered hierarchy, process row, cycle, matrix) and lay it out for maximum clarity with even spacing and aligned nodes. You have FULL freedom over the arrangement; use the template only for STYLE (palette, shape language, icon treatment), never to justify a cluttered or distorted drawing. Render every entity with its label and a short description, and aim for a clean, professional, presentation-grade result. "
    "LAYOUT SAFETY — keep ALL content inside the 1280x720 canvas with about 48px safe margins on every side; nothing may overflow or clip past the right or bottom edge. Prefer flexbox/grid with even distribution (e.g. justify-content:space-between) over hand-placed absolute pixel coordinates; if you do use absolute positioning, every element's left+width must stay ≤1232 and top+height ≤672. For a timeline/process row, distribute the N nodes evenly across the width and pair EACH node with its own label+text block (never render only one labelled item and leave the rest empty), keeping every card fully on-canvas. "
    "CONNECTORS — draw a line or arrow ONLY where a real relationship exists, and make each one accurate and purposeful: it must begin and end exactly on the edges of the two specific nodes it links. Plan the node positions so connections stay short and untangled — put a parent directly above its children and keep related nodes adjacent so a line never has to cross the slide, cross another line, or pass through a label. Use clean straight or single right-angle paths with small arrowheads. Never draw a line into empty space, a loose bracket, a decorative stroke, or any connector below the lowest row. Every visible line must clearly mean something — a few precise, correct connectors are far better than many vague ones. "
    "CHARTS — render exactly ONE coherent chart, never two overlapping ones. Every bar or point must sit on the same baseline axis (bars grow from the x-axis, none floating mid-air). If two data series are shown, use two clearly distinct colors on aligned categories with a small legend; keep bar widths and gaps uniform. "
)


def render_page_html(item: dict[str, Any], cfg: dict[str, Any], *, common_style: dict[str, Any] | None = None, timeout: int = 420, max_tokens: int = 4600, stream: bool = True) -> str:
    """Generate the final mounted HTML for one slide item.

    Template-agnostic: it reads only the page's contract, summary, and assigned
    blank template, so it works for any extracted template. Mounts the blank
    background, forbids reusing source background imagery, and retries thin
    responses. `item['_output_dir']` must be set so template helpers can resolve
    the blank template file.
    """
    img_guidance = template_image_guidance(item)
    excerpt = blank_template_excerpt(item)
    prompt = (
        "Generate a standalone polished 1280x720 HTML slide preview. Output HTML only. "
        "Use inline CSS, fictional English text, and respect the template summary. "
        + FOREGROUND_RULES
        + "For topic_bound_content that does not match the fictional preview topic, use a placeholder instead.\n\n"
        + deck_style_guide(common_style)
        + (img_guidance + "\n\n" if img_guidance else "")
        + summarize(item)
        + (
            "\n\nShared blank template HTML excerpt (do not rewrite it; renderer mounts it behind your foreground):\n" + excerpt
            if excerpt
            else ""
        )
    )
    # The model sometimes under-produces a multi-block page (e.g. a timeline with
    # only one of four nodes filled). Scale the "complete enough" bar to the
    # number of content blocks the template holds, so such pages are retried;
    # sparse slides (a cover) keep the low default and stay short legitimately.
    sections = ((item.get("template_contract") or {}).get("slots") or {}).get("sections") or {}
    n_sections = int(sections.get("count_max") or sections.get("count_min") or 0)
    # Capped so a very dense page (many sections) doesn't demand an unreachable
    # length and burn every retry.
    min_chars = min(4200, max(1800, 1200 + n_sections * 450))
    best = ""
    for _attempt in range(3):
        candidate = call_glm(prompt, cfg, timeout, max_tokens, stream)
        if len(candidate) > len(best):
            best = candidate
        if "<" in candidate and len(candidate) >= min_chars:
            break
    text = best
    if "<" not in text:
        raise RuntimeError("no HTML returned")
    text = re.sub(r"(?<!\.\./)backgrounds/", "../backgrounds/", text)
    # Safety net: the blank template already carries all chrome imagery, so drop
    # any <img> still pointed at a source background asset (it would render as a
    # shrunken background photo inside the slide).
    text = re.sub(r"(?is)<img\b[^>]*\bsrc=\"[^\"]*backgrounds/[^\"]*\"[^>]*>", "", text)
    return apply_blank_template_frame(text, item)


def generate_deck(
    output_dir: Path,
    cfg: dict[str, Any],
    *,
    workers: int = 3,
    timeout: int = 420,
    max_tokens: int = 4600,
    only_pages: set[int] | None = None,
    stream: bool = True,
    log: Any = print,
) -> tuple[int, int]:
    """Render every extracted page in styles.json into verify_render/ + presentation.html.

    This is the single rendering path shared by the CLI and the extraction
    pipeline's --verify-render. Returns (written, attempted). Skips pages whose
    output already exists.
    """
    output_dir = Path(output_dir)
    styles = load_json(output_dir / "styles.json")
    common_style = styles.get("common_style") if isinstance(styles.get("common_style"), dict) else None
    verify_dir = output_dir / "verify_render"
    verify_dir.mkdir(exist_ok=True)
    work: list[tuple[dict[str, Any], Path]] = []
    for item in pages(styles):
        page = int(item.get("page") or 0)
        if only_pages is not None and page not in only_pages:
            continue
        item["_output_dir"] = str(output_dir)
        role = str(item.get("role") or "support")
        out = verify_dir / f"verify_{page:03d}_{role}.html"
        if not out.exists():
            work.append((item, out))

    def one(pair: tuple[dict[str, Any], Path]) -> tuple[int, str, str | None]:
        item, out = pair
        page = int(item.get("page") or 0)
        try:
            text = render_page_html(item, cfg, common_style=common_style, timeout=timeout, max_tokens=max_tokens, stream=stream)
            out.write_text(text, encoding="utf-8")
            return page, "written", None
        except Exception as exc:  # noqa: BLE001
            return page, "failed", f"{type(exc).__name__}: {str(exc)[:220]}"

    results = []
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        for fut in as_completed([ex.submit(one, x) for x in work]):
            r = fut.result()
            results.append(r)
            log(f"page {r[0]:03d}: {r[1]}" + (f" - {r[2]}" if r[2] else ""))
    write_index(output_dir, verify_dir)
    written = sum(1 for r in results if r[1] == "written")
    return written, len(results)


def main() -> int:
    try:
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", type=Path, default=Path("output_full_qwen_vl"))
    ap.add_argument("--config", type=Path, default=Path("config.json"))
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--timeout", type=int, default=420)
    ap.add_argument("--max-tokens", type=int, default=2600)
    ap.add_argument("--pages", help="Comma-separated page numbers to generate, e.g. 7,8,9")
    ap.add_argument("--no-stream", action="store_true")
    args = ap.parse_args()
    cfg = load_json(args.config)
    only_pages = {int(x.strip()) for x in args.pages.split(",") if x.strip()} if args.pages else None
    written, attempted = generate_deck(
        args.output_dir, cfg,
        workers=args.workers, timeout=args.timeout, max_tokens=args.max_tokens,
        only_pages=only_pages, stream=not args.no_stream,
    )
    print(f"done: {written}/{attempted} newly generated")
    return 1 if written < attempted else 0


if __name__ == "__main__":
    raise SystemExit(main())
