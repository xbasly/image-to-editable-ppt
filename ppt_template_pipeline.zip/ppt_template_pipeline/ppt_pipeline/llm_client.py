"""Common model client for the PPT template pipeline.

ALL VL (vision) and Chat (text) model calls go through here so endpoints, keys and
models are configured in ONE place. Configure either from a config.json dict via
`vision_config()` / `chat_config()`, or by constructing `LLMConfig` directly:

    cfg = LLMConfig(base_url="https://your-host", api_key="sk-...", model="qwen-vl")
    text = vl_complete(Path("page.jpg"), prompt, cfg=cfg)

Both calls speak the OpenAI-compatible /v1/chat/completions protocol.
"""
from __future__ import annotations

import base64
import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


@dataclass
class LLMConfig:
    """Endpoint configuration for one model (vision or chat). Edit these directly
    to point at a self-hosted endpoint, or build via vision_config()/chat_config()."""
    base_url: str = ""
    api_key: str = ""
    model: str = ""
    timeout: int = 120


def vision_config(config: dict[str, Any], *, timeout: int = 120) -> LLMConfig:
    v = config.get("vision") or {}
    return LLMConfig(str(v.get("base_url") or ""), str(v.get("api_key") or ""), str(v.get("model") or ""), timeout)


def chat_config(config: dict[str, Any], *, timeout: int = 600) -> LLMConfig:
    g = config.get("generation") or config.get("glm") or {}
    v = config.get("vision") or {}
    return LLMConfig(
        str(g.get("base_url") or v.get("base_url") or ""),
        str(g.get("api_key") or v.get("api_key") or ""),
        str(g.get("model") or "glm-4.6"),
        timeout,
    )


# ----------------------------------------------------------------- protocol
def normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/").removesuffix("/v1").rstrip("/") + "/v1"


def response_text(data: dict[str, Any]) -> str:
    if not isinstance(data, dict):
        return ""
    choices = data.get("choices") or []
    if not choices or not isinstance(choices[0], dict):
        return ""
    message = choices[0].get("message")
    if not isinstance(message, dict):
        return ""
    content = message.get("content")
    text = ""
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        text = "\n".join(str(item.get("text") or "") for item in content if isinstance(item, dict))
    # Reasoning models may leave content empty and put the answer in reasoning_content.
    if not text.strip():
        rc = message.get("reasoning_content")
        if isinstance(rc, str):
            text = rc
    return text


def _stream_delta(data: dict[str, Any]) -> str:
    choices = data.get("choices") or []
    if not choices or not isinstance(choices[0], dict):
        return ""
    choice = choices[0]
    if choice.get("finish_reason") == "aborted":
        raise RuntimeError(f"generation aborted: {json.dumps(data, ensure_ascii=False)[:500]}")
    delta = choice.get("delta") if isinstance(choice.get("delta"), dict) else {}
    content = delta.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(item.get("text") or "") for item in content if isinstance(item, dict))
    # Reasoning models (GLM-5) sometimes stream the answer as reasoning deltas with
    # an empty content field; capture those too or we get an "empty response".
    for key in ("reasoning_content", "reasoning"):
        value = delta.get(key)
        if isinstance(value, str):
            return value
    message = choice.get("message") if isinstance(choice.get("message"), dict) else {}
    return response_text({"choices": [{"message": message}]})


def _read_stream(resp: Any, *, echo: bool = True, log: Callable[[str], None] | None = None) -> str:
    chunks: list[str] = []
    first_payload = True
    for raw_line in resp:
        line = raw_line.decode("utf-8", errors="ignore").strip()
        if not line:
            continue
        if not line.startswith("data:"):
            if first_payload:
                raise RuntimeError(f"service returned non-SSE response: {line[:500]}")
            continue
        first_payload = False
        payload = line.removeprefix("data:").strip()
        if payload == "[DONE]":
            break
        data = json.loads(payload)
        guard = 0
        while isinstance(data, str) and guard < 3:
            data = json.loads(data)
            guard += 1
        if not isinstance(data, dict):
            raise RuntimeError(f"unexpected streaming payload: {str(data)[:500]}")
        delta = _stream_delta(data)
        if delta:
            if echo:
                print(delta, end="", flush=True)
            chunks.append(delta)
    return "".join(chunks)


def _post(cfg: LLMConfig, payload: dict[str, Any], *, stream: bool, echo: bool,
          log: Callable[[str], None] | None) -> str:
    headers = {"Content-Type": "application/json"}
    if cfg.api_key:
        headers["Authorization"] = f"Bearer {cfg.api_key}"
    req = urllib.request.Request(
        f"{normalize_base_url(cfg.base_url)}/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=cfg.timeout) as resp:
        if stream:
            return _read_stream(resp, echo=echo, log=log)
        return response_text(json.loads(resp.read().decode("utf-8")))


# ------------------------------------------------------------------- calls
def vl_complete(image_path: Path, prompt: str, *, cfg: LLMConfig,
                max_tokens: int = 4000, temperature: float = 0.0) -> str:
    """One vision call: image + prompt -> answer text (non-streaming)."""
    data_url = "data:image/jpeg;base64," + base64.b64encode(Path(image_path).read_bytes()).decode("ascii")
    payload = {
        "model": cfg.model,
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": data_url}},
        ]}],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    text = _post(cfg, payload, stream=False, echo=False, log=None)
    if not text.strip():
        raise RuntimeError("empty VL response")
    return text


def chat_complete(prompt: str, *, cfg: LLMConfig, max_tokens: int = 16000, stream: bool = True,
                  temperature: float = 0.3, echo: bool = True,
                  log: Callable[[str], None] | None = None) -> str:
    """One text chat call -> answer text. Streams SSE by default."""
    payload: dict[str, Any] = {
        "model": cfg.model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": stream,
    }
    if "glm" in str(cfg.model).lower():
        payload["extra_body"] = {"enable_thinking": False}
    text = _post(cfg, payload, stream=stream, echo=echo, log=log)
    if not text.strip():
        raise RuntimeError("empty generation response")
    return text
