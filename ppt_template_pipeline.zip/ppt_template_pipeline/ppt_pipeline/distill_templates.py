#!/usr/bin/env python
"""Distill styles.json into a compact template library for synthesizing new decks.

Each template (one per distinct layout archetype) is reduced to the three things a
generator needs:
  1. blank_template  - the mounted background ref + a prompt describing its chrome
  2. slots           - the content capacity (title_zone, sections, chart, images...)
  3. visual_prompt   - a generation-ready visual description (look + palette + type)

Run:  python distill_templates.py --output-dir output_kaiti
Writes: <output-dir>/template_library.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _clean(text: Any, limit: int = 600) -> str:
    return str(text or "").strip()[:limit]


def architecture_prompt(item: dict[str, Any], contract: dict[str, Any]) -> str:
    """A Chinese prompt describing this page's background/chrome architecture."""
    style = contract.get("style") or {}
    bg = _clean(style.get("background"), 200)
    strat = contract.get("background_strategy") or {}
    mode = str(strat.get("mode") or "")
    notes = _clean(strat.get("notes"), 200)
    blank_ref = str(item.get("blank_template") or contract.get("blank_template") or "")

    # Summarize the reusable image assets that make up the chrome.
    chrome_assets = []
    for a in ((contract.get("image_asset_policy") or {}).get("assets") or []):
        role = str(a.get("role") or "")
        if role in {"full_canvas_background", "background_art", "template_chrome", "logo"}:
            chrome_assets.append({"full_canvas_background": "整页背景图", "background_art": "背景装饰图",
                                  "template_chrome": "模板装饰", "logo": "logo徽标"}.get(role, role))
    parts: list[str] = []
    if bg:
        parts.append(f"背景：{bg}。")
    if chrome_assets:
        parts.append("固定装饰：" + "、".join(sorted(set(chrome_assets))) + "。")
    if blank_ref:
        parts.append(f"已提取空白模板 {blank_ref}，生成时作为整页底层挂载，中间留白用于内容；不要重绘其背景、装饰或角标。")
    elif mode == "draw_css_background":
        parts.append("无图片底图，背景用 CSS/SVG 简洁绘制即可。")
    if notes:
        parts.append(notes)
    return " ".join(parts).strip()


def visual_prompt(contract: dict[str, Any]) -> str:
    """A Chinese visual description prompt: look + palette + typography + lines."""
    style = contract.get("style") or {}
    parts: list[str] = []
    report = _clean(contract.get("visual_report"), 400)
    if report:
        parts.append(report)
    colors = style.get("colors") or []
    if colors:
        pal = "、".join(f"{c.get('role')}{c.get('hex')}" for c in colors[:6] if isinstance(c, dict) and c.get("hex"))
        if pal:
            parts.append(f"配色：{pal}。")
    typ = _clean(style.get("typography"), 160)
    if typ:
        parts.append(f"字体字号：{typ}。")
    stroke = style.get("stroke_language") or {}
    if stroke.get("kind") and stroke.get("kind") != "无":
        parts.append(f"线条语言：{stroke.get('kind')}{('，' + _clean(stroke.get('reproduction_hint'),80)) if stroke.get('reproduction_hint') else ''}。")
    deco = _clean(style.get("text_box_decoration"), 80)
    if deco and deco != "无":
        parts.append(f"文本框装饰：{deco}。")
    ds = style.get("design_style") or {}
    if ds:
        parts.append(f"风格：{ds.get('tone','')}/{ds.get('decoration_level','')}/{ds.get('layout_weight','')}。")
    return " ".join(parts).strip()


def distill_slots(contract: dict[str, Any]) -> dict[str, Any]:
    slots = contract.get("slots") or {}
    return {
        "title_zone": contract.get("title_zone") or {},
        "title": slots.get("title") or {},
        "subtitle": slots.get("subtitle") or {},
        "sections": slots.get("sections") or {},
        "chart": slots.get("chart") or {},
        "images": slots.get("images") or {},
        "callouts_max": slots.get("callouts_max") or 0,
    }


def build_design_kit(styles: dict[str, Any]) -> dict[str, Any]:
    """Aggregate a deck-wide design system (palette + type scale + components + spacing).

    This turns the prose/per-page style into a concrete, reusable kit the generator
    must obey, so cards / badges / dividers / type look identical on every slide.
    """
    cs = styles.get("common_style") or {}
    colors = cs.get("colors") or {}

    def pick(*roles: str, default: str = "") -> str:
        for r in roles:
            if colors.get(r):
                return str(colors[r])
        return default

    primary = pick("主色", "强调色", default="#317bdf")
    accent = pick("强调色", "辅助色", "主色", default=primary)
    text = pick("文字", default="#333333")
    subtext = pick("辅助文字", "文字", default="#666666")
    bg = pick("背景", default="#ffffff")
    line = pick("装饰", "分隔线", "辅助色", default=accent)
    inverse = pick("反白文字", default="#ffffff")

    fs = cs.get("font_sizes") or {}
    title = int(fs.get("title") or 32)
    heading = int(fs.get("section_heading") or 24)
    body = int(fs.get("body") or 16)
    type_scale = {
        "display": max(title * 2, 56),   # hero numbers / chapter numerals
        "title": title,
        "subtitle": max(heading, body + 4),
        "section_heading": heading,
        "body": body,
        "caption": max(body - 4, 12),
    }
    components = {
        "card": {"radius_px": 10, "fill_alt": [primary, accent], "text_color": inverse,
                 "padding_px": 18, "shadow": "0 4px 16px rgba(0,0,0,.08)",
                 "note": "圆角卡片，深浅主色交替填充，文字反白"},
        "number_badge": {"shape": "circle", "bg": primary, "text_color": inverse, "size_px": 36,
                         "note": "两位数编号圆形徽标"},
        "divider": {"color": line, "thickness_px": 1, "note": "细分隔线 / 标题两侧横线"},
        "bullet": {"color": accent, "note": "项目符号圆点用强调色"},
        "title_decoration": (cs.get("title") or {}).get("decoration") or "两侧横线",
    }
    spacing = {"canvas_margin_px": 48, "gutter_px": 24, "section_gap_px": 20}
    return {
        "palette": {"primary": primary, "accent": accent, "text": text, "subtext": subtext,
                    "background": bg, "line": line, "inverse": inverse},
        "font_family": cs.get("font_family") or "",
        "type_scale": type_scale,
        "components": components,
        "spacing": spacing,
    }


# The standard roles a complete deck needs. Missing ones are synthesized (derived).
STANDARD_ROLES = ["cover", "abstract", "toc", "chapter_cover", "content", "summary"]


def _derived_template(tpl_id: str, role: str, layout_kind: str, chrome_ref: str,
                      slots: dict[str, Any], vp: str, good: list[str], forbid: list[str]) -> dict[str, Any]:
    return {
        "id": tpl_id, "layout_kind": layout_kind, "role": role, "derived": True,
        "confidence": "synthesized", "representative_page": None,
        "blank_template": {"ref": chrome_ref,
                           "architecture_prompt": "复用内容页底图作为整页底层（与正文同源的角落装饰），不要重绘背景。"},
        "slots": slots, "visual_prompt": vp, "good_for": good, "forbid": forbid,
    }


def derived_templates(existing: list[dict[str, Any]], chrome: dict[str, str]) -> list[dict[str, Any]]:
    """Synthesize derived templates for standard roles the deck lacks, so generation
    always stays inside the template system instead of ad-hoc custom layouts."""
    roles = {t.get("role") for t in existing}
    kinds = {t.get("layout_kind") for t in existing}
    content_ref = chrome.get("content", "")
    out: list[dict[str, Any]] = []
    if "abstract" not in roles and "abstract" not in kinds:
        out.append(_derived_template(
            "abstract", "abstract", "abstract", content_ref,
            {"title": {"present": True, "max_chars": 10}, "subtitle": {"present": True, "max_chars": 40},
             "sections": {"count_min": 2, "count_max": 4,
                          "per_section": {"heading_max_chars": 0, "body_max_chars": 48}}},
            "摘要页：顶部统一标题“摘要”，下方一行引言加 2-4 个并列要点卡片，舒展填满版面、左右均衡。",
            ["全文要点概述"], ["大段正文", "图表", "真实照片"]))
    if "toc" not in roles and "toc" not in kinds:
        out.append(_derived_template(
            "toc", "toc", "toc", content_ref,
            {"title": {"present": True, "max_chars": 4}},
            "目录页：左侧大号“目录”+CONTENTS+蓝色直角框，右侧纵向均匀列出全部章节，每条圆形编号+章节名。",
            ["章节列表"], ["正文", "图表", "真实照片"]))
    if "summary" not in roles and "support" not in kinds:
        out.append(_derived_template(
            "summary", "summary", "support", content_ref,
            {"title": {"present": True, "max_chars": 12}, "subtitle": {"present": True, "max_chars": 40},
             "sections": {"count_min": 2, "count_max": 5,
                          "per_section": {"heading_max_chars": 20, "body_max_chars": 60}}},
            "总结页：标题+2-5个并列结论/要点块，每块小标题+一句话，左右或上下均衡收尾。",
            ["结论要点", "展望"], ["复杂图表", "真实照片"]))
    return out


def distill(styles: dict[str, Any]) -> dict[str, Any]:
    templates: list[dict[str, Any]] = []
    seen: set[str] = set()
    for role, items in (styles.get("roles") or {}).items():
        for it in items:
            if not isinstance(it, dict):
                continue
            contract = it.get("template_contract")
            if not isinstance(contract, dict):
                continue
            layout_kind = str(contract.get("layout_kind") or "other")
            noncontent = contract.get("noncontent_kind") or None
            # One template per distinct archetype (keep the first representative).
            key = str(noncontent or layout_kind)
            if key in seen:
                continue
            seen.add(key)
            templates.append({
                "id": key,
                "layout_kind": layout_kind,
                "role": str(noncontent or "content"),
                "confidence": contract.get("layout_kind_confidence") or "medium",
                "representative_page": it.get("page"),
                "blank_template": {
                    "ref": it.get("blank_template") or "",
                    "architecture_prompt": architecture_prompt(it, contract),
                },
                "slots": distill_slots(contract),
                "visual_prompt": visual_prompt(contract),
                "good_for": (contract.get("content_prerequisites") or {}).get("requires") or [],
                "forbid": contract.get("forbid") or [],
            })
    # Canonical chrome: a content background reused by custom/derived pages, plus the
    # divider (chapter) background — so abstract/toc/summary look like the body pages.
    def _ref_for(pred) -> str:
        for t in templates:
            r = (t.get("blank_template") or {}).get("ref")
            if r and pred(t):
                return str(r)
        return ""
    content_ref = _ref_for(lambda t: t["role"] == "content") or _ref_for(
        lambda t: t["layout_kind"] not in ("cover", "chapter_cover"))
    divider_ref = _ref_for(lambda t: t["role"] == "chapter_cover")
    canonical_chrome = {"content": content_ref, "divider": divider_ref}

    # Item 3: fill standard-role gaps with derived templates (always inside the system).
    templates += derived_templates(templates, canonical_chrome)

    # Order: cover -> abstract -> toc -> chapter -> content archetypes -> summary/ending.
    order = {"cover": 0, "abstract": 1, "toc": 2, "chapter_cover": 3, "summary": 8, "ending": 9}
    templates.sort(key=lambda t: (order.get(t["role"], 5), t["id"]))
    return {
        "schema_version": "template_library.v2",
        "source": styles.get("source", ""),
        "canvas": styles.get("canvas") or {"width": 1280, "height": 720},
        "common_style": styles.get("common_style") or {},
        "design_kit": build_design_kit(styles),       # item 2
        "canonical_chrome": canonical_chrome,
        "templates": templates,
    }


def _slots_summary(slots: dict[str, Any]) -> str:
    """Condense the slots into one human-readable Chinese line."""
    parts: list[str] = []
    title = slots.get("title") or {}
    if title.get("present"):
        parts.append(f"标题(≤{title.get('max_chars')}字)")
    sub = slots.get("subtitle") or {}
    if sub.get("present"):
        parts.append(f"副标题(≤{sub.get('max_chars')}字)")
    sec = slots.get("sections") or {}
    cmin, cmax = sec.get("count_min") or 0, sec.get("count_max") or 0
    if cmax:
        per = sec.get("per_section") or {}
        n = f"{cmin}" if cmin == cmax else f"{cmin}-{cmax}"
        parts.append(f"{n}个内容块(小标题≤{per.get('heading_max_chars')}字/正文≤{per.get('body_max_chars')}字)")
    chart = slots.get("chart") or {}
    if chart.get("present"):
        parts.append("含图表")
    imgs = slots.get("images") or {}
    if imgs.get("count"):
        parts.append(f"{imgs.get('count')}张图片")
    if slots.get("callouts_max"):
        parts.append(f"{slots.get('callouts_max')}个标注")
    return " + ".join(parts) if parts else "无内容块（仅标题）"


def to_markdown(library: dict[str, Any]) -> str:
    cs = library.get("common_style") or {}
    t = cs.get("title") or {}
    fs = cs.get("font_sizes") or {}
    colors = cs.get("colors") or {}
    palette = "、".join(f"{r}{h}" for r, h in list(colors.items())[:5])
    lines = [
        f"# 模板库  ({len(library.get('templates') or [])} 个版式)",
        "",
        f"**画布** {library.get('canvas', {}).get('width', 1280)}×{library.get('canvas', {}).get('height', 720)}　"
        f"**字体** {cs.get('font_family', '')}　**调色板** {palette}",
        f"**统一标题** {t.get('color', '')}、{t.get('size_px', '')}px、{t.get('anchor', '')}/{t.get('align', '')}"
        f"（字号 标题{fs.get('title')}px / 小标题{fs.get('section_heading')}px / 正文{fs.get('body')}px）",
        "",
        "> 所有内容页共用上面的统一标题与配色；每个版式下三项：① 空白模板 ② 内容槽 ③ 视觉描述。",
        "",
    ]
    kit = library.get("design_kit") or {}
    if kit:
        p = kit.get("palette", {})
        ts = kit.get("type_scale", {})
        sp = kit.get("spacing", {})
        lines += [
            "## 设计套件（全篇统一复用）",
            f"- **调色** 主色{p.get('primary')}、强调{p.get('accent')}、文字{p.get('text')}、辅助{p.get('subtext')}、底{p.get('background')}、线{p.get('line')}、反白{p.get('inverse')}",
            f"- **字阶(px)** display{ts.get('display')} / 标题{ts.get('title')} / 副标题{ts.get('subtitle')} / 小标题{ts.get('section_heading')} / 正文{ts.get('body')} / 注释{ts.get('caption')}",
            "- **组件** 圆角卡片(主/强调交替填充、反白字)、圆形编号徽标、细分隔线/标题侧线、强调色项目符号",
            f"- **间距** 页边距{sp.get('canvas_margin_px')}px、栏间距{sp.get('gutter_px')}px、块间距{sp.get('section_gap_px')}px",
            "",
        ]
    for tpl in library.get("templates") or []:
        tag = "　[派生]" if tpl.get("derived") else ""
        lines.append(f"## {tpl['id']}　[{tpl['role']}]{tag}")
        bt = tpl.get("blank_template") or {}
        lines.append(f"**① 空白模板**：`{bt.get('ref', '')}`")
        lines.append(f"> {bt.get('architecture_prompt', '')}")
        lines.append("")
        lines.append(f"**② 内容槽**：{_slots_summary(tpl.get('slots') or {})}")
        if tpl.get("forbid"):
            lines.append(f"> 禁止：{ '、'.join(tpl['forbid']) }")
        lines.append("")
        lines.append("**③ 视觉描述**：")
        lines.append(f"> {tpl.get('visual_prompt', '')}")
        lines.append("")
        lines.append("---")
        lines.append("")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", type=Path, required=True)
    args = ap.parse_args()
    styles = load_json(args.output_dir / "styles.json")
    library = distill(styles)
    out_json = args.output_dir / "template_library.json"
    out_json.write_text(json.dumps(library, ensure_ascii=False, indent=2), encoding="utf-8")
    out_md = args.output_dir / "template_library.md"
    out_md.write_text(to_markdown(library), encoding="utf-8")
    print(f"wrote {out_md} and {out_json} ({len(library['templates'])} templates)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
