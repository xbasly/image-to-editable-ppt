#!/usr/bin/env python
"""Stage 3: render a slide_plan.json into an HTML deck using a template library.

Each planned slide carries a role (cover|abstract|toc|chapter_cover|content|summary),
optionally a template id, and the REAL content. Behaviour:
- Template slides use that template's mounted blank background + visual style as a
  REFERENCE (palette/title/decoration); the model may adapt the layout to best fit
  the content as long as it stays on-brand and inside the canvas.
- Custom slides (template=null) get a shared content background mounted for visual
  consistency and are laid out freely according to their page role + the deck style.
- Chapter numbers come from the plan and are rendered verbatim (never recomputed).

Run:  python render_from_plan.py --deck-dir output_kaiti --plan slide_plan.json
Writes: <deck-dir>/deck/slide_###.html + <deck-dir>/deck/presentation.html
"""
from __future__ import annotations

import argparse
import html as _html
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from generate_preview_html_fast import (
    FOREGROUND_RULES,
    apply_blank_template_frame,
    call_glm,
    deck_style_guide,
    load_json,
)

# Page-role layout vocabulary (mirrors extra_image.txt layout_kind) for custom pages.
LAYOUT_KIND_HINT = {
    "timeline": "时间线：一条水平或斜向时间轴，轴上 4-6 个有序节点，节点上下交错排列说明卡片。",
    "grid_cards": "等宽卡片网格：2-4 张等宽卡片，每张含小标题+正文，可配简洁 CSS 图标。",
    "concept_diagram": "概念结构图：中心辐射或并列要点结构，节点之间用简洁线条/图标体现关系。",
    "support": "支撑说明：标题 + 2-5 个并列论点/要点块，左右或上下均衡排布。",
    "comparison": "对比页：2-4 列并排卡片，逐项对照不同对象的差异。",
    "process_flow": "流程页：有方向的步骤序列，箭头连接，体现先后或因果。",
    "framework": "框架页：象限/分类/画布结构，用分区承载不同维度。",
    "data_highlight": "关键数字页：1-3 个超大数字/KPI 主导版面，辅以极少文字。",
    "big_statement": "观点页：一句核心判断，大字居中，大量留白，气场克制。",
    "table": "表格页：行列对齐的数据表，表头清晰，斑马纹或细分隔线。",
}

ROLE_HINT = {
    "abstract": (
        "这是【摘要】页。顶部用统一标题样式写“摘要”（中文，可配两侧细横线）。下方先一行引言(lead)，"
        "再把 points 排成 2-4 个并列要点块（可用序号圆点/色块/细分隔线点缀）。版面要舒展、纵向填满、"
        "左右留白均衡，不要出现大片空白，也不要把文字堆在角落。"
    ),
    "toc": (
        "这是【目录】页。左侧放大号“目录”标题（可加蓝色直角装饰框 + 英文副标题 CONTENTS）。右侧把 items 纵向"
        "均匀排列：每条左侧是蓝色圆形两位数编号(number)，右侧是章节名(name)。必须列出全部条目并在垂直方向均匀分布、"
        "占满右半区，条目之间间距一致。"
    ),
    "chapter_cover": (
        "这是【章节封面】页。左侧是超大号章节编号(number，约 160-200px，主色)，"
        "编号必须与给定 number 完全一致——禁止自行编号、改动或补零。右侧紧邻深灰色章节标题(title)，"
        "标题下方一行小字副标题(subtitle)。整页只有这组元素，居中偏左、留白克制，"
        "且每一页章节封面的元素位置、字号、样式必须完全一致。"
    ),
}


def _slots_text(slots: dict[str, Any]) -> str:
    bits: list[str] = []
    sec = slots.get("sections") or {}
    if sec.get("count_max"):
        per = sec.get("per_section") or {}
        bits.append(
            f"{sec.get('count_min')}-{sec.get('count_max')}个内容块"
            f"(小标题≤{per.get('heading_max_chars', '')}字/正文≤{per.get('body_max_chars', '')}字)"
        )
    if (slots.get("chart") or {}).get("present"):
        bits.append("一个图表")
    return "、".join(bits) if bits else "标题与少量文字"


def component_kit_guide(kit: dict[str, Any] | None) -> str:
    """Hard, reusable component/type/spacing rules so every slide looks identical."""
    if not kit:
        return ""
    p = kit.get("palette", {})
    ts = kit.get("type_scale", {})
    c = kit.get("components", {})
    sp = kit.get("spacing", {})
    card = c.get("card", {})
    badge = c.get("number_badge", {})
    div = c.get("divider", {})
    return (
        "组件套件（全篇统一，必须复用，不要每页另创风格）：\n"
        f"- 卡片：圆角{card.get('radius_px')}px，背景在 {p.get('primary')} 与 {p.get('accent')} 间交替，"
        f"文字 {card.get('text_color')}，内边距{card.get('padding_px')}px，阴影 {card.get('shadow')}。\n"
        f"- 编号徽标：{badge.get('size_px')}px {p.get('primary')} 圆形、白字。\n"
        f"- 分隔线：{div.get('color')} 粗 {div.get('thickness_px')}px；项目符号用 {p.get('accent')}。\n"
        f"- 字阶(px)：display {ts.get('display')} / 标题 {ts.get('title')} / 副标题 {ts.get('subtitle')} / "
        f"小标题 {ts.get('section_heading')} / 正文 {ts.get('body')} / 注释 {ts.get('caption')}。\n"
        f"- 间距：页边距 {sp.get('canvas_margin_px')}px，栏间距 {sp.get('gutter_px')}px，块间距 {sp.get('section_gap_px')}px。\n\n"
    )


def _palette_line(common_style: dict[str, Any]) -> str:
    cs = common_style or {}
    parts: list[str] = []
    colors = cs.get("colors") or {}
    if colors:
        parts.append("配色（保持与全篇一致）：" + "，".join(f"{r} {h}" for r, h in colors.items()) + "。")
    if cs.get("font_family"):
        parts.append(f"字体：{cs.get('font_family')}。")
    fs = cs.get("font_sizes") or {}
    if any(fs.values()):
        parts.append(f"字号层级：标题 {fs.get('title')}px / 小标题 {fs.get('section_heading')}px / 正文 {fs.get('body')}px。")
    bg = cs.get("background")
    if bg:
        parts.append(f"背景基调：{bg}（已挂载，勿重绘）。")
    return ("全篇风格统一规范 —— " + " ".join(parts) + "\n\n") if parts else ""


def render_slide(
    slide: dict[str, Any],
    templates: dict[str, dict[str, Any]],
    common_style: dict[str, Any],
    default_bg: dict[str, Any],
    deck_dir: Path,
    cfg: dict[str, Any],
    *,
    timeout: int,
    max_tokens: int,
    stream: bool,
    design_kit: dict[str, Any] | None = None,
) -> str:
    role = str(slide.get("role") or "content")
    content = slide.get("content") or {}
    # Resolve to a template: explicit id, else a derived/real template matching the
    # page role's layout_kind (abstract/toc/summary), so custom pages stay in-system.
    tpl = templates.get(str(slide.get("template"))) if slide.get("template") else None
    if tpl is None and slide.get("layout_kind"):
        tpl = templates.get(str(slide.get("layout_kind")))

    # background + style reference
    if tpl:
        bt = tpl.get("blank_template") or {}
        bg_ref = bt.get("ref", "")
        arch = str(bt.get("architecture_prompt", ""))
        look = str(tpl.get("visual_prompt", ""))
        slots_line = _slots_text(tpl.get("slots") or {})
        forbid = tpl.get("forbid") or []
    else:
        bg_ref = default_bg.get("ref", "")
        arch = "页面背景已挂载（与内容页一致的浅蓝角落装饰），请勿重绘背景或装饰。"
        look = LAYOUT_KIND_HINT.get(str(slide.get("layout_kind")), LAYOUT_KIND_HINT["support"])
        slots_line = ""
        forbid = []

    sec = content.get("sections") or []
    n_sections = len(sec) if sec else int(((tpl or {}).get("slots", {}).get("sections", {}) or {}).get("count_max") or 0)
    min_chars = min(4200, max(1700, 1200 + n_sections * 420))

    # style guide: content/summary get the fixed centred top-title band; structural
    # pages (cover/abstract/toc/chapter_cover) keep bespoke titles + palette only.
    style_guide = deck_style_guide(common_style) if role in ("content", "summary") else _palette_line(common_style)

    role_block = ROLE_HINT.get(role, "")
    if tpl:
        look_block = (
            "模板风格仅作【参考】（配色、标题样式、装饰语言、版式倾向）：" + look
            + "\n你可以在保持同一视觉风格、留白均衡、不出血的前提下，自由调整布局以最好地呈现下列内容；"
            + (f"建议容量：{slots_line}。" if slots_line else "")
        )
    else:
        look_block = "请按以下页面角色自由排版，并与全篇风格保持一致：" + look

    forbid_block = ("\n避免：" + "、".join(str(f) for f in forbid) + "。") if forbid else ""

    prompt = (
        "生成一页 1280x720、演示级、好看的 HTML 幻灯片。只输出 HTML，内联 CSS。\n"
        + FOREGROUND_RULES
        + "\n\n" + style_guide
        + component_kit_guide(design_kit)
        + (role_block + "\n\n" if role_block else "")
        + look_block
        + "\n\n背景说明（已作为整页底层挂载，不要重绘）：" + arch
        + forbid_block
        + "\n\n无图片素材：本套幻灯片由文字文档生成，没有照片。若版式本应有图片区，"
        "不要画空的图片占位框/灰色矩形/相框图标；用文字、色块或简洁 CSS/SVG 图标填充，"
        "每个可见区域都要有真实内容，绝不留空槽。"
        "\n\n所有内容必须完整落在 1280x720 画布内，四周留≥40px 边距，任何卡片/文字不得贴边或溢出右/下边缘；"
        "同时版面要充实、均衡，不要出现大片空白。"
        + "\n\n严格按以下内容渲染（逐字保留措辞与语言，不增不删不翻译"
        + ("；其中 number 是章节编号，必须原样显示" if role == "chapter_cover" else "")
        + "）：\n"
        + json.dumps(content, ensure_ascii=False, indent=2)
    )

    best = ""
    for _attempt in range(3):
        candidate = call_glm(prompt, cfg, timeout, max_tokens, stream)
        if len(candidate) > len(best):
            best = candidate
        if "<" in candidate and len(candidate) >= min_chars:
            break
    text = best
    if "<" not in text:
        raise RuntimeError("no HTML returned")
    text = re.sub(r"(?<!\.\./)backgrounds/", "../backgrounds/", text)
    text = re.sub(r"(?is)<img\b[^>]*\bsrc=\"[^\"]*backgrounds/[^\"]*\"[^>]*>", "", text)
    return apply_blank_template_frame(text, {"blank_template": bg_ref, "_output_dir": str(deck_dir)})


def write_presentation(out_dir: Path) -> None:
    files = sorted(out_dir.glob("slide_*.html"))
    frames = "\n".join(
        f'<iframe src="{_html.escape(p.name)}" width="1280" height="720"></iframe>' for p in files
    )
    (out_dir / "presentation.html").write_text(
        '<!doctype html><html><head><meta charset="utf-8"><title>Generated Deck</title>'
        "<style>body{margin:0;background:#111;display:flex;flex-direction:column;align-items:center;gap:16px;padding:16px}"
        "iframe{border:0;background:#fff}</style></head><body>" + frames + "</body></html>\n",
        encoding="utf-8",
    )


def main() -> int:
    try:
        import certifi, os
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument("--deck-dir", type=Path, required=True)
    ap.add_argument("--plan", type=Path, required=True)
    ap.add_argument("--config", type=Path, default=Path("config.json"))
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--max-tokens", type=int, default=4600)
    ap.add_argument("--no-stream", action="store_true")
    args = ap.parse_args()

    library = load_json(args.deck_dir / "template_library.json")
    plan = load_json(args.plan)
    cfg = load_json(args.config)
    templates = {str(t.get("id")): t for t in (library.get("templates") or [])}
    common_style = library.get("common_style") or {}
    design_kit = library.get("design_kit") or {}
    # shared chrome for custom pages = canonical content chrome (fallback: first content bg)
    chrome_ref = (library.get("canonical_chrome") or {}).get("content") or next(
        ((t.get("blank_template") or {}).get("ref", "") for t in (library.get("templates") or [])
         if str(t.get("layout_kind")) not in ("cover", "chapter_cover")), "")
    default_bg = {"ref": chrome_ref}
    out_dir = args.deck_dir / "deck"
    out_dir.mkdir(parents=True, exist_ok=True)
    slides = plan.get("slides") or []

    def one(slide: dict[str, Any]) -> tuple[int, str, str | None]:
        idx = int(slide.get("index") or 0)
        out = out_dir / f"slide_{idx:03d}.html"
        try:
            html = render_slide(
                slide, templates, common_style, default_bg, args.deck_dir, cfg,
                timeout=args.timeout, max_tokens=args.max_tokens, stream=not args.no_stream,
                design_kit=design_kit,
            )
            out.write_text(html, encoding="utf-8")
            return idx, "written", None
        except Exception as exc:  # noqa: BLE001
            return idx, "failed", f"{type(exc).__name__}: {str(exc)[:200]}"

    results = []
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        for fut in as_completed([ex.submit(one, s) for s in slides]):
            r = fut.result()
            results.append(r)
            print(f"slide {r[0]:03d}: {r[1]}" + (f" - {r[2]}" if r[2] else ""), flush=True)
    write_presentation(out_dir)
    ok = sum(1 for r in results if r[1] == "written")
    print(f"done: {ok}/{len(results)} slides -> {out_dir / 'presentation.html'}")
    return 1 if ok < len(results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
