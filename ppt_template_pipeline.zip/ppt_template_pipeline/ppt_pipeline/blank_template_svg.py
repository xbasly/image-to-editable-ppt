#!/usr/bin/env python
"""Build shared blank-template backgrounds by intersecting per-page SVG elements.

The idea: convert each page of a cluster (same structural role, e.g. chapter
covers or one content background family) to SVG, then keep ONLY the drawable
elements (paths / images) that repeat byte-for-byte across most pages of the
cluster. Those repeated elements are the shared chrome: logos, color
decorations, dividers, and shared background art. Everything page-specific
(titles, body text, per-slide graphics, content photos) is dropped, which
leaves the content area empty.

This is fully deterministic: no model redraws the background. The blank
template is reconstructed from ONE representative page's real SVG, so geometry,
clip-path context, and image transforms are preserved exactly.

Text (<text>/<tspan>) is always treated as content and removed.
"""
from __future__ import annotations

import collections
import hashlib
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable


def find_libreoffice() -> str | None:
    for name in ("soffice", "libreoffice"):
        found = shutil.which(name)
        if found:
            return found
    for candidate in (
        Path(r"C:\Program Files\LibreOffice\program\soffice.exe"),
        Path(r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"),
    ):
        if candidate.exists():
            return str(candidate)
    return None


def prepare_source_pdf(source: Path, output_dir: Path) -> Path | None:
    """Return a PDF whose page N matches rendered page N, converting PPTX if needed.

    PDF input is used directly. PPTX input is converted once with LibreOffice
    (the same engine the renderer already relies on) and cached under lo_export/.
    Returns None when no conversion path is available.
    """
    suffix = source.suffix.lower()
    if suffix == ".pdf":
        return source
    lo_dir = output_dir / "lo_export"
    lo_dir.mkdir(parents=True, exist_ok=True)
    cached = lo_dir / f"{source.stem}.pdf"
    if cached.exists():
        return cached
    soffice = find_libreoffice()
    if not soffice:
        return None
    cmd = [soffice, "--headless", "--convert-to", "pdf", "--outdir", str(lo_dir), str(source.resolve())]
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=240)
    except Exception:
        return None
    if result.returncode != 0:
        return None
    produced = sorted(lo_dir.glob("*.pdf"))
    if not produced:
        return None
    pdf = produced[0]
    if pdf.name != cached.name and not cached.exists():
        try:
            pdf.replace(cached)
            return cached
        except Exception:
            return pdf
    return cached if cached.exists() else pdf


def render_pages_to_svg(pdf_path: Path, pages: set[int]) -> dict[int, str]:
    """Convert the requested 1-based pages of a PDF to SVG strings via PyMuPDF."""
    try:
        import fitz
    except ImportError:
        return {}
    out: dict[int, str] = {}
    try:
        with fitz.open(pdf_path) as doc:
            for page in sorted(pages):
                if 1 <= page <= len(doc):
                    out[page] = doc[page - 1].get_svg_image(text_as_path=False)
    except Exception:
        return out
    return out


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _attr(element: str, name: str) -> str:
    match = re.search(rf'\s{name}="([^"]*)"', element, flags=re.I)
    return match.group(1) if match else ""


def _path_key(element: str) -> tuple[str, ...]:
    return (
        "path",
        _norm(_attr(element, "transform")),
        _attr(element, "fill").lower(),
        _attr(element, "stroke").lower(),
        _norm(_attr(element, "d")),
    )


def _image_key(element: str) -> tuple[str, ...]:
    href_match = re.search(r'xlink:href="([^"]*)"', element, flags=re.I) or re.search(r'\shref="([^"]*)"', element, flags=re.I)
    href = href_match.group(1) if href_match else ""
    return (
        "image",
        _attr(element, "width"),
        _attr(element, "height"),
        hashlib.md5(href.encode("utf-8", "ignore")).hexdigest(),
    )


def _viewbox_wh(svg: str) -> tuple[float, float]:
    match = re.search(r'\sviewBox="([^"]+)"', svg, flags=re.I)
    if match:
        parts = match.group(1).replace(",", " ").split()
        if len(parts) == 4:
            try:
                return float(parts[2]), float(parts[3])
            except ValueError:
                pass
    return 960.0, 540.0


def _matrix(transform: str) -> tuple[float, float, float, float, float, float] | None:
    match = re.search(r"matrix\(\s*([^)]+)\)", transform or "", flags=re.I)
    if not match:
        return None
    nums = [float(x) for x in re.findall(r"[-+]?\d*\.?\d+(?:e[-+]?\d+)?", match.group(1), flags=re.I)]
    if len(nums) != 6:
        return None
    return tuple(nums)  # type: ignore[return-value]


def _keep_bbox(x0: float, y0: float, x1: float, y1: float, canvas_w: float, canvas_h: float) -> bool:
    """Keep a blank-template element only when it is perimeter chrome.

    Rule: the element's bbox must touch at least TWO canvas edges. This captures
    the real chrome — corner shapes (two adjacent edges), full-height/width side
    bands (two opposite edges), and full-canvas backgrounds (four edges) — while
    dropping floating content that touches one edge or none (content photos,
    cards, title rules, centred motifs). That keeps the middle empty without
    relying on cross-page intersection, so a page keeps all of its own corners.
    """
    tol_x = 0.04 * canvas_w
    tol_y = 0.04 * canvas_h
    edges = 0
    if x0 <= tol_x:
        edges += 1  # left
    if x1 >= canvas_w - tol_x:
        edges += 1  # right
    if y0 <= tol_y:
        edges += 1  # top
    if y1 >= canvas_h - tol_y:
        edges += 1  # bottom
    return edges >= 2


def _image_bbox(transform: str, image_el: str) -> tuple[float, float, float, float] | None:
    mat = _matrix(transform)
    width = float(_attr(image_el, "width") or 0)
    height = float(_attr(image_el, "height") or 0)
    if not mat or width <= 0 or height <= 0:
        return None
    a, b, c, d, e, f = mat
    corners = [(0.0, 0.0), (width, 0.0), (0.0, height), (width, height)]
    xs = [a * x + c * y + e for x, y in corners]
    ys = [b * x + d * y + f for x, y in corners]
    return min(xs), min(ys), max(xs), max(ys)


def _path_bbox(element: str) -> tuple[float, float, float, float] | None:
    """Approximate a path's canvas bbox from its transform and `d` coordinates.

    The numeric scan treats `d` numbers as alternating x/y pairs. This is rough
    (curve control points and arc params inflate it slightly) but good enough to
    tell a centred motif from edge/corner chrome.
    """
    mat = _matrix(_attr(element, "transform"))
    if not mat:
        return None
    nums = [float(x) for x in re.findall(r"[-+]?\d*\.?\d+(?:e[-+]?\d+)?", _attr(element, "d"), flags=re.I)]
    if len(nums) < 2:
        return None
    # Pair numbers as x/y coordinates; trailing unpaired values (e.g. an H/V
    # endpoint) are ignored but the start point is enough to locate the element.
    pair_count = len(nums) // 2
    xs = nums[0 : pair_count * 2 : 2]
    ys = nums[1 : pair_count * 2 : 2]
    a, b, c, d, e, f = mat
    pts = list(zip(xs, ys))
    px = [a * x + c * y + e for x, y in pts]
    py = [b * x + d * y + f for x, y in pts]
    if not px or not py:
        return None
    return min(px), min(py), max(px), max(py)


def _image_keep_by_position(transform: str, image_el: str, canvas_w: float, canvas_h: float) -> bool:
    bbox = _image_bbox(transform, image_el)
    if bbox is None:
        # Cannot place it reliably -> drop, so a content photo never leaks in.
        return False
    return _keep_bbox(*bbox, canvas_w, canvas_h)


def _path_keep_by_position(element: str, canvas_w: float, canvas_h: float) -> bool:
    bbox = _path_bbox(element)
    if bbox is None:
        # Cannot assess -> keep, to avoid stripping legitimate edge chrome.
        return True
    return _keep_bbox(*bbox, canvas_w, canvas_h)


def _split_defs(svg: str) -> tuple[str, str]:
    """Split the SVG into (head-including-defs, body-after-defs).

    Drawable content lives after </defs>; clip-path geometry inside <defs> must
    be preserved untouched so clip references keep resolving.
    """
    match = re.search(r"(?is)</defs>", svg)
    if not match:
        return "", svg
    return svg[: match.end()], svg[match.end() :]


def page_element_keys(svg: str) -> set[tuple[str, ...]]:
    """Keys of drawable leaf elements (paths/images) in the body. Text excluded."""
    _head, body = _split_defs(svg)
    keys: set[tuple[str, ...]] = set()
    for element in re.findall(r"<path\b[^>]*?/?>", body, flags=re.S):
        keys.add(_path_key(element))
    for element in re.findall(r"<image\b[^>]*?>", body, flags=re.S):
        keys.add(_image_key(element))
    return keys


def shared_element_keys(svgs: list[str], threshold: float = 0.6) -> set[tuple[str, ...]]:
    """Keys present in at least `threshold` of the pages (min 2 pages)."""
    if not svgs:
        return set()
    counts: collections.Counter[tuple[str, ...]] = collections.Counter()
    for svg in svgs:
        for key in page_element_keys(svg):
            counts[key] += 1
    need = max(2, int(round(threshold * len(svgs))))
    if len(svgs) < 2:
        need = 1
    return {key for key, count in counts.items() if count >= need}


def deck_shared_path_keys(svgs: dict[int, str], *, threshold_frac: float = 0.2, min_pages: int = 3) -> set[tuple[str, ...]]:
    """Path keys that recur on many pages of the deck.

    Large decorative vectors (ribbons, sweeping shapes) that span the canvas are
    template chrome but fail the perimeter test. They are reliably identified by
    recurring across many pages, whereas page content does not. Images are
    excluded here on purpose: a content photo reused on a few pages must still be
    dropped, so images stay perimeter-only.
    """
    if not svgs:
        return set()
    counts: collections.Counter[tuple[str, ...]] = collections.Counter()
    for svg in svgs.values():
        _head, body = _split_defs(svg)
        seen: set[tuple[str, ...]] = set()
        for el in re.findall(r"<path\b[^>]*?/?>", body, flags=re.S):
            # Only FILLED shapes count as recurring background art (e.g. ribbons,
            # color sweeps). Stroke-only paths (title side rules, dividers,
            # underlines) are content accents and must not be frozen into the
            # background, even when they repeat on every page — otherwise the
            # foreground also draws them and the two sets misalign.
            fill = _attr(el, "fill").strip().lower()
            if fill in ("", "none"):
                continue
            seen.add(_path_key(el))
        for key in seen:
            counts[key] += 1
    need = max(min_pages, int(round(threshold_frac * len(svgs))))
    return {key for key, count in counts.items() if count >= need}


def prune_to_shared(svg: str, shared: set[tuple[str, ...]], shared_chrome: set[tuple[str, ...]] | None = None) -> str:
    """Keep only shared drawable leaves; drop all text and non-shared leaves.

    Reconstructs from one real page so transforms/clips stay valid. Returns the
    pruned standalone SVG string (root <svg> ... </svg>).

    A path is kept when it is shared on this page AND it is EITHER perimeter
    chrome (touches >=2 edges) OR a deck-wide recurring decoration (in
    `shared_chrome`). The latter rescues large sweeping background graphics that
    cross the centre but are part of the template on every page.
    """
    chrome = shared_chrome or set()
    canvas_w, canvas_h = _viewbox_wh(svg)
    head, body = _split_defs(svg)
    # Text is always content.
    body = re.sub(r"(?is)<text\b.*?</text>", "", body)
    body = re.sub(r"(?is)<tspan\b.*?</tspan>", "", body)

    def _keep_path(match: re.Match[str]) -> str:
        el = match.group(0)
        key = _path_key(el)
        if key not in shared:
            return ""
        if _path_keep_by_position(el, canvas_w, canvas_h) or key in chrome:
            return el
        return ""

    body = re.sub(r"<path\b[^>]*?/?>", _keep_path, body, flags=re.S)

    # Images: fitz wraps each image in <g transform="matrix(...)"><image/></g>.
    # Keep the whole unit only when the image is shared AND sits at the edge /
    # full canvas; drop floating central images so the content area stays empty.
    def _image_unit(match: re.Match[str]) -> str:
        transform = match.group("transform")
        image_el = match.group("image")
        if _image_key(image_el) not in shared:
            return ""
        if _image_keep_by_position(transform, image_el, canvas_w, canvas_h):
            return match.group(0)
        return ""

    body = re.sub(
        r'<g\b[^>]*\stransform="(?P<transform>matrix\([^"]*\))"[^>]*>\s*(?P<image><image\b[^>]*?>)\s*</g>',
        _image_unit,
        body,
        flags=re.S,
    )
    # The unit pass above handles every transform-wrapped image (the fitz norm).
    # This only prunes any leftover non-shared bare image; shared images already
    # kept by the unit pass are left untouched.
    body = re.sub(
        r"<image\b[^>]*?>",
        lambda m: m.group(0) if _image_key(m.group(0)) in shared else "",
        body,
        flags=re.S,
    )
    result = head + body
    # Drop groups that became empty after pruning (repeat for nested groups).
    for _ in range(6):
        pruned = re.sub(r"(?is)<g\b[^>]*>\s*</g>", "", result)
        if pruned == result:
            break
        result = pruned
    return result


def build_blank_template_svg(
    pages: list[int],
    svgs: dict[int, str],
    threshold: float = 0.6,
    shared_chrome: set[tuple[str, ...]] | None = None,
) -> str | None:
    """Build the shared blank-template SVG for a cluster of pages.

    Returns None when no usable SVG is available for the cluster.
    """
    available = [(page, svgs[page]) for page in pages if page in svgs and svgs[page]]
    if not available:
        return None
    shared = shared_element_keys([svg for _page, svg in available], threshold)
    if not shared:
        # Nothing repeats across the cluster; fall back to the lone page's
        # background paths only when there is a single page, else give up.
        if len(available) == 1:
            shared = page_element_keys(available[0][1])
        else:
            return None
    # Representative page = the one covering the most shared elements.
    rep_svg = max(available, key=lambda item: len(page_element_keys(item[1]) & shared))[1]
    return prune_to_shared(rep_svg, shared, shared_chrome)


def template_image_bboxes(svg: str) -> list[tuple[float, float, float, float]]:
    """Bboxes (in viewBox coords) of the images kept in a blank template.

    Used by the renderer to tell the generation model which regions are already
    covered by a background photo, so it does not overlay an image slot there.
    """
    _head, body = _split_defs(svg)
    boxes: list[tuple[float, float, float, float]] = []
    for m in re.finditer(
        r'<g\b[^>]*\stransform="(matrix\([^"]*\))"[^>]*>\s*(<image\b[^>]*?>)\s*</g>',
        body,
        flags=re.S,
    ):
        bbox = _image_bbox(m.group(1), m.group(2))
        if bbox is not None:
            boxes.append(bbox)
    return boxes


def blank_template_html(svg: str, width: int = 1280, height: int = 720) -> str:
    """Wrap a pruned SVG as a standalone fixed-size blank-template HTML document."""
    # Force the embedded SVG to fill the canvas regardless of its native size.
    svg = re.sub(r'(<svg\b[^>]*?)\swidth="[^"]*"', r"\1", svg, count=1, flags=re.I)
    svg = re.sub(r'(<svg\b[^>]*?)\sheight="[^"]*"', r"\1", svg, count=1, flags=re.I)
    return (
        '<!doctype html><html><head><meta charset="utf-8">'
        "<style>html,body{margin:0;padding:0;background:transparent}"
        f"#blank-wrap{{width:{width}px;height:{height}px;overflow:hidden}}"
        f"#blank-wrap>svg{{width:{width}px;height:{height}px;display:block}}</style>"
        f'</head><body><div id="blank-wrap">{svg}</div></body></html>\n'
    )


def write_page_blank_template(
    page: int,
    svgs: dict[int, str],
    blank_dir: Path,
    *,
    shared_chrome: set[tuple[str, ...]] | None = None,
    log: Callable[[str], None] = print,
) -> str | None:
    """Build and persist a single page's own perimeter chrome as a blank template.

    Used for pages (e.g. content slides) whose decorations vary page to page: a
    cluster-wide intersection would drop a corner that this page has but its
    siblings do not. Building from the page's own SVG keeps every corner/edge
    decoration that page actually has, with text and central content removed.
    """
    svg = svgs.get(page)
    if not svg:
        log(f"[blank] page {page}: no SVG available -> skip")
        return None
    built = build_blank_template_svg([page], svgs, threshold=0.6, shared_chrome=shared_chrome)
    if not built:
        log(f"[blank] page {page}: no perimeter chrome -> skip")
        return None
    kept = len(re.findall(r"<path\b", built)) + len(re.findall(r"<image\b", built))
    blank_dir.mkdir(parents=True, exist_ok=True)
    out = blank_dir / f"page_{page:03d}.html"
    out.write_text(blank_template_html(built), encoding="utf-8")
    log(f"[blank] page {page}: kept {kept} perimeter element(s)")
    return f"blank_templates/{out.name}"


def write_blank_template(
    cluster: dict[str, Any],
    svgs: dict[int, str],
    blank_dir: Path,
    *,
    threshold: float = 0.6,
    shared_chrome: set[tuple[str, ...]] | None = None,
    log: Callable[[str], None] = print,
) -> str | None:
    """Build and persist blank_templates/<cluster_id>.html. Returns the relative ref."""
    cluster_id = str(cluster.get("cluster_id") or "")
    pages = [int(p) for p in (cluster.get("pages") or []) if str(p).strip().isdigit()]
    if not cluster_id or not pages:
        return None
    svg = build_blank_template_svg(pages, svgs, threshold, shared_chrome=shared_chrome)
    if not svg:
        log(f"[blank] cluster {cluster_id}: no shared SVG elements across pages {pages} -> skip")
        return None
    shared_count = len(re.findall(r"<path\b", svg)) + len(re.findall(r"<image\b", svg))
    blank_dir.mkdir(parents=True, exist_ok=True)
    out = blank_dir / f"{cluster_id}.html"
    out.write_text(blank_template_html(svg), encoding="utf-8")
    log(f"[blank] cluster {cluster_id}: kept {shared_count} shared element(s) from {len(pages)} page(s)")
    return f"blank_templates/{out.name}"
