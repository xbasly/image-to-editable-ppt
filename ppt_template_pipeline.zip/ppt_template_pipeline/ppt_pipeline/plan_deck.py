#!/usr/bin/env python
"""Stage 2: document -> slide_plan.json for a given template deck.

Pipeline:  doc (.docx)  --plan_deck-->  slide_plan.json  --render_from_plan-->  HTML deck

Design (addresses: wrong chapter numbers, empty/overflow pages, rigid template lock):
- The DECK STRUCTURE is built deterministically in Python so it always reads
  封面 -> 摘要 -> 目录 -> [章节封面 -> 内容] x N -> 总结, and chapter numbers are
  assigned sequentially in code (the LLM never numbers chapters -> never misnumbers).
- The LLM only does two things: condense each chapter's real text into slot-sized
  sections, and pick the best content template per chapter (or "custom" + a page
  role when no template fits well). Pages with no matching template (摘要/目录/某些内容)
  are marked custom; render_from_plan lays them out freely but on-brand.

Output schema (consumed by render_from_plan.py):
  {"slides":[{index, role, template|null, layout_kind, content{...}}]}
  role in: cover|abstract|toc|chapter_cover|content|summary
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from generate_preview_html_fast import call_glm, load_json


# ---------------------------------------------------------------- doc parsing
def parse_docx(path: Path, *, body_chars: int = 900) -> dict[str, Any]:
    import docx

    d = docx.Document(str(path))
    title = path.stem.split("@")[0].strip()
    abstract_parts: list[str] = []
    chapters: list[dict[str, Any]] = []
    cur_ch: dict[str, Any] | None = None
    cur_sub: dict[str, Any] | None = None
    mode = ""

    for p in d.paragraphs:
        t = p.text.strip()
        if not t:
            continue
        style = p.style.name
        if style == "Heading 2":
            if t.startswith("摘要") or t.lower().startswith("abstract"):
                mode = "abstract"
                cur_ch = cur_sub = None
                continue
            mode = "chapter"
            cur_ch = {"title": re.sub(r"^\d+[.\s、]*", "", t).strip(), "raw_title": t, "intro": "", "subs": []}
            cur_sub = None
            chapters.append(cur_ch)
            continue
        if style in ("Heading 3", "Heading 4") and cur_ch is not None:
            cur_sub = {"title": re.sub(r"^[\d.]+\s*", "", t).strip(), "body": ""}
            cur_ch["subs"].append(cur_sub)
            continue
        if mode == "abstract":
            if len("".join(abstract_parts)) < 900:
                abstract_parts.append(t)
        elif cur_sub is not None:
            if len(cur_sub["body"]) < body_chars:
                cur_sub["body"] = (cur_sub["body"] + " " + t).strip()
        elif cur_ch is not None:
            if len(cur_ch["intro"]) < 400:
                cur_ch["intro"] = (cur_ch["intro"] + " " + t).strip()

    return {"title": title, "abstract": " ".join(abstract_parts), "chapters": chapters}


def outline_text(outline: dict[str, Any]) -> str:
    lines = [f"# 文档标题：{outline['title']}", "", f"## 摘要原文\n{outline['abstract']}", "", "## 章节正文"]
    for i, ch in enumerate(outline["chapters"], 1):
        lines.append(f"\n### 第{i}章：{ch['title']}")
        if ch.get("intro"):
            lines.append(f"（导语）{ch['intro'][:260]}")
        for sub in ch.get("subs", []):
            lines.append(f"- {sub['title']}：{sub['body'][:240]}")
    return "\n".join(lines)


# ------------------------------------------------------------- template menu
def template_menu(library: dict[str, Any]) -> str:
    lines: list[str] = []
    for t in library.get("templates", []):
        lk = str(t.get("layout_kind"))
        if lk in ("cover", "chapter_cover"):
            continue  # structural pages are placed by code, not chosen by the LLM
        slots = t.get("slots", {})
        sec = slots.get("sections", {})
        per = sec.get("per_section", {})
        cap: list[str] = []
        if sec.get("count_max"):
            cap.append(
                f"{sec.get('count_min')}-{sec.get('count_max')}个内容块"
                f"(小标题≤{per.get('heading_max_chars', '?')}字/正文≤{per.get('body_max_chars', '?')}字)"
            )
        if (slots.get("chart") or {}).get("present"):
            cap.append("含图表")
        good = t.get("good_for") or []
        good = "、".join(str(g) for g in good) if isinstance(good, list) else str(good)
        lines.append(f'- "{t["id"]}"：{"; ".join(cap) or "标题+少量文字"}。适合：{good}')
    lines.append(
        '- "custom"：以上都不合适时使用。你必须额外给出 layout_kind，'
        "可选：big_statement(单句核心观点/大量留白)、data_highlight(1-3个大数字)、"
        "comparison(2-4列并列对比)、process_flow(有方向的流程步骤)、framework(象限/分类框架)、"
        "table(行列表格)。custom 页会按该角色自由排版，但风格与其它页保持一致。"
    )
    return "\n".join(lines)


# ------------------------------------------------------------- planning call
def build_plan_prompt(outline: dict[str, Any], library: dict[str, Any]) -> str:
    return (
        "你是资深演示文稿策划。把下面这份研究文档编排成一套连贯、专业、好看的幻灯片内容。\n"
        "整套结构固定为：封面 → 摘要 → 目录 → （章节封面 → 该章内容页）逐章 → 总结。"
        "封面/摘要/目录/章节封面/编号由程序生成，你只需提供文字与内容页模板选择。\n\n"
        "## 内容页可选模板（id 必须严格使用；slots 字数是硬上限，超出会被截断或溢出，务必精炼）\n"
        + template_menu(library)
        + "\n\n## 文档内容\n"
        + outline_text(outline)
        + "\n\n## 你的任务（只输出 JSON）\n"
        "1. cover_subtitle：封面副标题，一句话点题（≤30字）。\n"
        "2. abstract：{lead: 一句话总览(≤40字), points: [2-4条要点，每条≤48字]}，全部浓缩自摘要原文。\n"
        "3. body：正文章节数组。把文档的实质内容章节逐个编排（最后一个明显是结语/总结的章节不要放进 body，放到 summary）。每个元素：\n"
        "   {name: 章节名(去掉序号), divider_subtitle: 该章一句话概述(≤40字), "
        "template: 选一个内容页模板 id 或 \"custom\", layout_kind: 当 template=custom 时必填角色否则留空, "
        "content_title: 内容页标题(≤24字), content_subtitle: 副标题(≤40字), "
        "sections: [{heading: 小标题, body: 正文}]}。\n"
        "4. summary：{title: \"总结\"或结语章节名, subtitle: ≤40字, template: 模板id或custom, layout_kind: 同上, sections:[...]}。\n\n"
        "## 硬性要求\n"
        "- 文字必须忠实概括文档，禁止编造文档没有的人名、作品、史实。把长段落压缩成短句。\n"
        "- sections 数量必须落在所选模板的 count_min~count_max 之间；每条 body 控制在该模板正文上限以内，宁短勿长（防止页面溢出）。\n"
        "- 同类型模板不要连续重复太多次，注意节奏变化；内容形态决定模板：时间/年代/演进→timeline；并列维度/要点→grid_cards 或 concept_diagram；列表论点→support；数据对比→quant_chart；都不合适→custom。\n"
        "- 每页内容量要足以填满版面、又不过载；避免大片空白，也避免文字挤爆。\n\n"
        "## 输出格式（极其重要）\n"
        "直接输出 JSON，第一个字符必须是 `{`，最后一个字符必须是 `}`。禁止任何思考过程、前言、解释或 ``` 代码块。\n"
        '{"cover_subtitle":"...","abstract":{"lead":"...","points":["...","..."]},'
        '"body":[{"name":"...","divider_subtitle":"...","template":"timeline","layout_kind":"",'
        '"content_title":"...","content_subtitle":"...","sections":[{"heading":"...","body":"..."}]}],'
        '"summary":{"title":"总结","subtitle":"...","template":"support","layout_kind":"","sections":[{"heading":"...","body":"..."}]}}'
    )


def extract_json(text: str) -> dict[str, Any]:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.IGNORECASE | re.MULTILINE)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start, end = text.find("{"), text.rfind("}")
    if start >= 0 and end > start:
        return json.loads(text[start : end + 1])
    raise ValueError("no JSON object found in planner output")


# --------------------------------------------------------- assemble the deck
def assemble(plan: dict[str, Any], outline: dict[str, Any], valid: set[str]) -> list[dict[str, Any]]:
    def tpl_of(obj: dict[str, Any]) -> tuple[str | None, str]:
        tid = str(obj.get("template") or "").strip()
        lk = str(obj.get("layout_kind") or "").strip()
        if tid and tid != "custom" and tid in valid:
            return tid, ""
        return None, (lk or "support")

    body = plan.get("body") or []
    n = len(body)
    slides: list[dict[str, Any]] = []

    # 1. cover
    slides.append({
        "role": "cover", "template": "cover", "layout_kind": "cover",
        "content": {"title": outline["title"], "subtitle": plan.get("cover_subtitle", "")},
    })
    # 2. abstract (custom)
    ab = plan.get("abstract") or {}
    slides.append({
        "role": "abstract", "template": None, "layout_kind": "abstract",
        "content": {"title": "摘要", "lead": ab.get("lead", ""), "points": ab.get("points", [])},
    })
    # 3. toc (custom) — items numbered in code => always correct
    items = [{"number": f"{i:02d}", "name": ch.get("name", "")} for i, ch in enumerate(body, 1)]
    slides.append({
        "role": "toc", "template": None, "layout_kind": "toc",
        "content": {"title": "目录", "items": items},
    })
    # 4. per-chapter divider + content
    for i, ch in enumerate(body, 1):
        slides.append({
            "role": "chapter_cover", "template": "chapter_cover", "layout_kind": "chapter_cover",
            "content": {
                "number": f"{i:02d}", "total": f"{n:02d}",
                "title": ch.get("name", ""), "subtitle": ch.get("divider_subtitle", ""),
            },
        })
        tid, lk = tpl_of(ch)
        slides.append({
            "role": "content", "template": tid, "layout_kind": lk,
            "content": {
                "title": ch.get("content_title") or ch.get("name", ""),
                "subtitle": ch.get("content_subtitle", ""),
                "sections": ch.get("sections", []),
            },
        })
    # 5. summary
    sm = plan.get("summary") or {}
    tid, lk = tpl_of(sm)
    slides.append({
        "role": "summary", "template": tid, "layout_kind": lk,
        "content": {
            "title": sm.get("title", "总结"), "subtitle": sm.get("subtitle", ""),
            "sections": sm.get("sections", []),
        },
    })

    for idx, s in enumerate(slides, 1):
        s["index"] = idx
    return slides


def main() -> int:
    try:
        import certifi, os
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument("--doc", type=Path, required=True)
    ap.add_argument("--deck-dir", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--config", type=Path, default=Path("config.json"))
    ap.add_argument("--timeout", type=int, default=600)
    ap.add_argument("--max-tokens", type=int, default=20000)
    ap.add_argument("--no-stream", action="store_true")
    args = ap.parse_args()

    library = load_json(args.deck_dir / "template_library.json")
    cfg = load_json(args.config)
    outline = parse_docx(args.doc)
    print(f"parsed: {len(outline['chapters'])} chapters, abstract {len(outline['abstract'])} chars", flush=True)

    valid = {str(t.get("id")) for t in library.get("templates", [])}
    prompt = build_plan_prompt(outline, library)
    raw = call_glm(prompt, cfg, args.timeout, args.max_tokens, not args.no_stream)
    (args.deck_dir / "_plan_raw.txt").write_text(raw, encoding="utf-8")
    plan = extract_json(raw)
    slides = assemble(plan, outline, valid)

    out = args.out or (args.deck_dir / "slide_plan.json")
    out.write_text(json.dumps({"slides": slides}, ensure_ascii=False, indent=2), encoding="utf-8")
    from collections import Counter
    print(f"planned {len(slides)} slides -> {out}", flush=True)
    print("roles:", dict(Counter(s["role"] for s in slides)), flush=True)
    print("content templates:", dict(Counter(s["template"] or f"custom:{s['layout_kind']}"
          for s in slides if s["role"] in ("content", "summary"))), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
