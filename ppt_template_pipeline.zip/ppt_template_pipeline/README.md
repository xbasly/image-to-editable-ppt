# PPT 模板提取 + 文档生成演示文稿 流水线

把一份 **PPT/PDF 模板**解析成「可复用的设计系统」，再用这套系统把任意 **文档（.docx）** 自动排版成一套**风格统一、好看**的 HTML 演示文稿。

设计理念：**内容优先、模板只作美观导向、允许重构**。模板不是被像素级复刻，而是被提炼成一套确定性的设计系统（版式角色 + 设计套件 + 空白底图），生成阶段在这套系统内"填内容"，从而保证一致性与美观。

---

## 1. 目录结构

```
ppt_template_pipeline/
├── main.py                 ← 入口①：模板提取（PPT/PDF → 可复用模板包 zip）
├── generate.py             ← 入口②：内容生成（文档 + 模板 → HTML 演示文稿）
├── config.json             ← 模型端点配置（vision / generation 的 url、key、model）
├── README.md               ← 本文件
├── tmp/                    ← 提取产物的工作目录（tmp/<user_id><template_id>/）
└── ppt_pipeline/           ← 全部实现模块（包）
    ├── llm_client.py                    模型调用唯一出口（VL + Chat）
    ├── build_prompt_template_system.py  提取主流程（PPT/PDF → styles.json）
    ├── image_prepare.py                 PPT/PDF → 页面图片
    ├── blank_template_svg.py            从 SVG 抽取四周公共 chrome → 空白底图
    ├── distill_templates.py             styles.json → template_library.json/.md（含设计套件）
    ├── plan_deck.py                     文档 → slide_plan.json（规划：结构+内容）
    ├── render_from_plan.py              slide_plan.json → 每页 HTML
    ├── generate_preview_html_fast.py    共享渲染工具（call_glm / 底图挂载 / 风格规范）
    ├── rerun_vl_page.py                 调试：单页重跑 VL
    └── prompts/extra_image.txt          VL 提取用的「模板契约」提示词
```

**两个入口完全独立**：提取（main.py）只产出模板包，绝不做生成；生成（generate.py）是单独分支。

---

## 2. 两个入口函数

### 入口① 模板提取 —— `main.py`

```python
from main import extract_template
result = extract_template(sn="S123", user_id="u01", ppt_dir="./decks",
                          template_id="t9", debug=False)
# CLI: python main.py --sn S123 --user-id u01 --ppt-dir ./decks --template-id t9 [--debug]
```

流程：在 `ppt_dir` 里找 `.pptx/.ppt/.pdf` → 固定解析到 `tmp/<user_id><template_id>/` →
跑提取（**不含**验证 HTML 生成那一步）→ 蒸馏出模板库 → 打包 zip。
返回 `{"status":"done","zip":...}`。`debug=False` 会清掉全部中间产物，只留必要文件。

产物（zip 内）：`styles.json` + `template_library.json/.md` + `blank_templates/` + `backgrounds/`。

### 入口② 内容生成 —— `generate.py`

```python
from generate import generate_deck
result = generate_deck(sn="S1", user_id="u01", doc="report.docx",
                       deck_dir="output_kaiti", debug=False)
# CLI: python generate.py --sn S1 --user-id u01 --doc report.docx --deck-dir output_kaiti
```

流程：读取 `deck_dir` 里已提取的 `template_library.json` → 解析文档 → 规划幻灯片
(`slide_plan.json`) → 逐页渲染 → `deck/slide_###.html` + `deck/presentation.html`。

> 两个入口的**核心日志**都通过 `build_prompt_template_system.set_log_context(sn, user_id)`
> 打上 `[sn=..][uid=..]` 前缀（输出到 stdout + `../log/stage_a_*.log`），便于检索。

---

## 3. 端到端数据流

### 提取（Stage A）

```
PPT/PDF
  └─(image_prepare) 渲染每页 → _vl_pages/page_*.jpg
       └─(VL 结构预扫) run_structure_prescan → _structure.json   每页角色：封面/章节封面/内容/结尾…
            └─(按结构采样若干页) 逐页 VL 提取 → template_contract（版式/槽位/标题区/配色/字体…）
                 ├─(VL 背景聚类) cluster_backgrounds_with_vl → 同底图分簇
                 ├─(blank_template_svg) 抽取四周公共 chrome → blank_templates/*.html（中间留白）
                 └─ 抽取图片资产 → backgrounds/*.jpg
  ⇒ styles.json（每页契约 + 全篇 common_style + 背景簇）
       └─(distill_templates) ⇒ template_library.json / .md
              · common_style（统一标题/配色/字体）
              · design_kit（调色板 + 字阶 + 组件 + 间距）        ← 设计套件
              · canonical_chrome（内容底图 / 章节底图）
              · templates[]（每个版式：空白底图 + 槽位 + 视觉描述；缺失角色自动合成"派生模板"）
```

### 生成

```
文档 .docx
  └─(plan_deck.parse_docx) 解析标题/摘要/章节(H2)/小节(H3) → 大纲
       └─(plan_deck.build_plan_prompt → LLM) 仅做：内容浓缩 + 内容页模板选择
            └─(plan_deck.assemble) 用代码确定性地拼装结构与编号 ⇒ slide_plan.json
                 结构固定：封面 → 摘要 → 目录 → [章节封面(编号代码生成) → 内容] ×N → 总结
  └─(render_from_plan.render_slide，逐页并发) 每页：
       挂载空白底图(iframe) + 注入【风格规范+设计套件+角色提示+模板视觉参考】 + 逐字内容 → GLM 出 HTML
  ⇒ deck/slide_###.html + deck/presentation.html
```

---

## 4. 各文件与关键函数

### `ppt_pipeline/llm_client.py` —— 模型调用唯一出口
所有 VL/Chat HTTP 都在这里，便于统一改 url/key/model。
- `LLMConfig(base_url, api_key, model, timeout)`：单个模型端点配置（可直接 new 指向自建服务）。
- `vision_config(cfg)` / `chat_config(cfg)`：从 `config.json` 字典构造上面的配置。
- `vl_complete(image, prompt, *, cfg)`：一次视觉调用（图+提示 → 文本，非流式）。
- `chat_complete(prompt, *, cfg, max_tokens, stream)`：一次文本调用（默认 SSE 流式）。
  内部 `_read_stream/_stream_delta` 会兼容 GLM-5 把答案放在 `reasoning_content` 增量里的情况。

### `ppt_pipeline/build_prompt_template_system.py` —— 提取主流程
- `build_prompt_template_system(source, output_dir, *, verify_render=False, …)`：提取总编排。
- `run(input, output, …)`：简易启动器。
- `set_log_context(sn, user_id)` / `log(msg)`：给日志打 sn/uid 前缀（stdout+文件）。
- `read_config(path)`：读取 `config.json`（vision + generation 端点）。
- `run_structure_prescan(...)`：整册 VL 预扫，判定每页角色 → `_structure.json`，据此按结构采样。
- `request_vl_report(...)` / `request_vl_report_once(...)`：逐页 VL 提取「模板契约」（已委托 `llm_client.vl_complete`，保留重试）。
- `request_text_chat(...)`：文本 LLM 调用（已委托 `llm_client.chat_complete`）。
- `cluster_backgrounds_with_vl(...)`：把内容页按底图分簇，决定哪些页共用一张空白底图。
- `build_styles_json(...)`：把逐页契约 + 角色 + 背景簇 + 空白底图汇总成 `styles.json`，并聚合全篇 `common_style`（统一标题/配色/字号）。

### `ppt_pipeline/image_prepare.py` —— 页面图片
- `render_pdf_pages_for_vl(...)`：PDF 按 1280×720 渲染每页为图（PPTX 先经 LibreOffice 转 PDF）。
- `compress_image_for_vl(...)`：压缩图片以便喂给 VL。

### `ppt_pipeline/blank_template_svg.py` —— 空白底图抽取
把页面转 SVG，**只保留四周的公共 chrome**（logo、角落装饰、背景），中间留白给内容。
- `deck_shared_path_keys(svgs, …)`：找全册反复出现的填充图形（保留章节彩条等）。
- `prune_to_shared(svg, shared, shared_chrome)`：按位置+共享性裁剪，丢掉 `<text>` 与中部元素。
- `write_page_blank_template(...)` / `write_blank_template(...)`：输出 `blank_templates/*.html`。

### `ppt_pipeline/distill_templates.py` —— 蒸馏成模板库（含设计系统）
- `distill(styles)`：`styles.json` → `template_library.json`（schema v2）。每个版式给三件套：
  ① 空白底图 `blank_template{ref, architecture_prompt}` ② 槽位 `slots` ③ 视觉描述 `visual_prompt`。
- `build_design_kit(styles)`【设计套件 / item 2】：从 common_style 聚合
  **调色板 + 字阶(display/title/subtitle/heading/body/caption) + 组件(卡片/编号徽标/分隔线/项目符号) + 间距**。
- `derived_templates(existing, chrome)`【角色补全 / item 3】：当模板册缺少标准角色（摘要/目录/总结）时，
  用统一风格**合成派生模板**（`derived:true`，底图复用 `canonical_chrome`），让生成永远在模板系统内。
- `architecture_prompt(...)` / `visual_prompt(...)`：生成底图与视觉描述的中文提示。
- `to_markdown(library)`：人读版 `template_library.md`。

### `ppt_pipeline/plan_deck.py` —— 规划（文档 → slide_plan.json）
**结构与编号在代码里确定**（不让 LLM 编号 → 不会错），LLM 只做内容浓缩 + 内容页选模板。
- `parse_docx(path)`：解析 docx → `{title, abstract, chapters[{title, intro, subs[{title, body}]}]}`。
- `template_menu(library)`：把可选内容页模板（含 `custom` + layout_kind 角色）列给 LLM。
- `build_plan_prompt(outline, library)`：规划提示词（输出严格 JSON）。
- `extract_json(text)`：从 LLM 回复里稳健抽取 JSON。
- `assemble(plan, outline, valid)`：拼装最终结构
  封面→摘要→目录→[章节封面(`number=NN` 代码生成)→内容]×N→总结，并顺序编号。

### `ppt_pipeline/render_from_plan.py` —— 渲染（slide_plan.json → HTML）
- `render_slide(slide, templates, common_style, default_bg, …, design_kit)`：渲染单页。
  - 把 `custom` 角色解析到派生/真实模板（按 `layout_kind`），保证不脱离系统；
  - 注入：`deck_style_guide`（统一标题带）/`_palette_line` + `component_kit_guide`（设计套件）
    + `ROLE_HINT`（封面/摘要/目录/章节封面专属排版）+ 模板视觉参考 + 逐字内容；
  - 通过 `apply_blank_template_frame` 把空白底图作为 iframe 挂在最底层，前景透明叠加。
- `component_kit_guide(kit)`：把设计套件转成"必须复用"的硬性组件规则。
- `LAYOUT_KIND_HINT` / `ROLE_HINT`：页面角色的版式说明。
- `write_presentation(out_dir)`：把所有页拼成 `presentation.html`。

### `ppt_pipeline/generate_preview_html_fast.py` —— 共享渲染工具
- `call_glm(prompt, cfg, timeout, max_tokens, stream)`：文本生成（已委托 `llm_client.chat_complete`）。
- `apply_blank_template_frame(text, item)`：强制把空白底图挂为整页底层 iframe，前景透明。
- `deck_style_guide(common_style)`：把全篇统一标题/配色/字号转成硬性一致性规范。
- `FOREGROUND_RULES`：前景生成通用规则（透明背景、不重绘底图、不用空图片占位框、图表/连线自主规划等）。
- `summarize(item)` / `load_json(path)` 等工具。

### `ppt_pipeline/rerun_vl_page.py`
调试用：对单页重新跑 VL 提取，便于核对某页契约。

### `ppt_pipeline/prompts/extra_image.txt`
VL 提取的核心提示词，定义 **template_contract.v1**：`layout_kind / slots / title_zone /
typography_tokens / colors / background_strategy / image_asset_policy / visual_report …`。

---

## 5. 关键数据结构

### `styles.json`（提取产物）
```jsonc
{
  "common_style": { "title": {...}, "colors": {...}, "font_family": "...", "font_sizes": {...} },
  "background_clusters": [...],
  "roles": {
    "<role>": [ {
      "page": 5,
      "blank_template": "blank_templates/page_005.html",
      "template_contract": { "layout_kind": "...", "slots": {...}, "title_zone": {...}, "style": {...} }
    } ]
  }
}
```

### `template_library.json`（schema v2，生成阶段唯一依赖）
```jsonc
{
  "common_style": {...},
  "design_kit": { "palette": {...}, "type_scale": {...}, "components": {...}, "spacing": {...} },
  "canonical_chrome": { "content": "blank_templates/xxx.html", "divider": "blank_templates/yyy.html" },
  "templates": [ {
    "id": "timeline", "layout_kind": "timeline", "role": "content", "derived": false,
    "blank_template": { "ref": "...", "architecture_prompt": "..." },
    "slots": { "title": {...}, "sections": {"count_min":4,"count_max":4,"per_section":{...}}, ... },
    "visual_prompt": "...", "good_for": [...], "forbid": [...]
  } ]
}
```

### `slide_plan.json`（规划产物 → 渲染输入）
```jsonc
{ "slides": [
  { "index": 1, "role": "cover",         "template": "cover",         "layout_kind": "cover",
    "content": { "title": "...", "subtitle": "..." } },
  { "index": 4, "role": "chapter_cover", "template": "chapter_cover", "layout_kind": "chapter_cover",
    "content": { "number": "01", "total": "11", "title": "...", "subtitle": "..." } },
  { "index": 5, "role": "content",       "template": "timeline",      "layout_kind": "",
    "content": { "title": "...", "subtitle": "...", "sections": [ {"heading":"...","body":"..."} ] } }
] }
```
`role ∈ cover | abstract | toc | chapter_cover | content | summary`；
`template=null` 时按 `layout_kind` 解析到派生/真实模板或自由排版。

---

## 6. 配置

`config.json`：
```jsonc
{
  "vision":     { "base_url": "https://yunwu.ai", "api_key": "sk-...", "model": "qwen3.5-397b-a17b" },
  "generation": { "base_url": "https://yunwu.ai", "api_key": "sk-...", "model": "glm-5" }
}
```
想换自建端点：改这里，或在代码里直接构造 `llm_client.LLMConfig(base_url=…, api_key=…, model=…)`。

---

## 7. 设计要点（为什么这样做）

- **结构与编号确定性**：`plan_deck.assemble` 用代码固定"封面→摘要→目录→章节封面→内容→总结"
  并顺序生成章节编号，避免 LLM 把章节数搞错或结构飘移。
- **设计套件 design_kit**：把散文式风格沉淀为「调色板+字阶+组件+间距」硬规则，渲染时强制复用，
  解决"每页模型即兴 → 风格不一致/卡片样式乱"的问题。
- **角色补全 derived templates**：模板册缺摘要/目录/总结时自动合成派生模板，
  让生成永远在模板系统内，而不是脱缰的 custom 排版。
- **模板作美观导向、允许重构**：渲染提示把模板视觉当**参考**（配色/标题/装饰/版式倾向），
  允许模型为更好呈现内容而调整布局，同时用 `FOREGROUND_RULES` + 画布约束防止出血/空白/空图框。
- **空白底图挂载**：每页底层挂 `blank_templates/*.html`（iframe），前景透明叠加，
  保证全篇背景/装饰/logo 完全一致，且模型不重绘底图。

---

## 8. 运行示例

```bash
# ① 提取模板（产出 tmp/u01t9/ 与 tmp/u01t9.zip）
python main.py --sn S1 --user-id u01 --ppt-dir ./decks --template-id t9 --debug

# ② 用文档生成演示文稿（deck-dir 为已提取的模板目录）
python generate.py --sn S1 --user-id u01 --doc ./report.docx --deck-dir output_kaiti

# 打开 output_kaiti/deck/presentation.html 预览
```
