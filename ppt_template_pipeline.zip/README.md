# PPT Template Extraction and HTML Preview Pipeline

This project extracts reusable presentation-template structure from PPTX/PDF files and generates HTML preview pages. It is designed around a model-authored contract:

- VL extracts page structure, reusable image policy, and `vector_plan`.
- Local parsers extract concrete image/SVG assets when available.
- A binder matches VL `vector_plan` candidates to parsed SVG assets.
- GLM generates preview HTML and explicitly chooses whether to reuse shared backgrounds or SVG assets through placeholders.

The renderer intentionally keeps only minimal, generic post-processing. It does not auto-inject SVG/background layers unless the model emits the corresponding placeholder.

## Files

- `build_prompt_template_system.py`  
  Main extraction pipeline. Renders source pages, calls VL, builds `styles.json`, clusters reusable blank backgrounds, and binds SVG assets when available.

- `prompts/extra_image.txt`  
  VL extraction prompt and JSON contract schema. This prompt requires `vector_plan` so the model decides which visible vector-like structures should be matched to exact SVG later.

- `extract_pdf_vector_assets.py`  
  Extracts SVG/vector fragments from a LibreOffice-exported PDF and writes `lo_export/slide_###_vector_assets.json`.

- `bind_vector_assets.py`  
  Binds model-authored `vector_plan` candidates in `styles.json` to parsed SVG assets. It does not invent fallback vector plans.

- `generate_preview_html_fast.py`  
  Generates verification HTML previews from `styles.json`. The model can emit:
  - `{{BLANK_TEMPLATE}}` to mount a shared blank background.
  - `{{VECTOR_ASSET:asset_id}}` to reuse a bound exact SVG asset.

- `image_prepare.py`  
  Image/PDF rendering helpers used by the pipeline.

- `rerun_vl_page.py`  
  Utility for rerunning one VL extraction page during debugging.

- `requirements.txt`  
  Python package dependencies.

- `config.example.json`  
  Safe configuration template. Copy it to `config.json` and fill in your own model endpoint/key.

## Requirements

Install Python dependencies:

```powershell
python -m pip install -r requirements.txt
```

For PPTX input, install LibreOffice separately and make sure `soffice` is available on `PATH`. LibreOffice is preferred for PPTX-to-PDF/SVG conversion because it avoids evaluation-watermark text from commercial renderers.

## Configuration

Copy the example config:

```powershell
Copy-Item config.example.json config.json
```

Then edit `config.json`:

- `vision`: VL model endpoint/key/name.
- `generation`: GLM/HTML-generation endpoint/key/name.

Do not commit or package the real `config.json` if it contains API keys.

## Main Workflow

Run template extraction:

```powershell
python build_prompt_template_system.py "input.pptx" --output-dir output_template --config config.json --style-prompt prompts\extra_image.txt --force --no-resume --keep-intermediate
```

Generate preview HTML pages:

```powershell
python generate_preview_html_fast.py --output-dir output_template --config config.json --workers 1 --timeout 900 --max-tokens 4200
```

Open:

```text
output_template/presentation.html
```

## SVG Binding Workflow

For PPTX files, the main pipeline can produce `lo_export/slide_###_vector_assets.json` when LibreOffice/PDF vector extraction is available. To re-bind after editing `styles.json` or vector assets:

```powershell
python bind_vector_assets.py --output-dir output_template
```

For selected pages:

```powershell
python bind_vector_assets.py --output-dir output_template --pages 16,17,18
```

The binder only matches explicit VL `vector_plan` candidates. It does not create `auto_*` vector plans or silently inject SVGs.

## Preview Placeholder Contract

Preview generation uses explicit model choices:

- If GLM emits `{{BLANK_TEMPLATE}}`, the renderer replaces it with the shared blank-template iframe.
- If GLM emits `{{VECTOR_ASSET:asset_id}}`, the renderer replaces it with that exact SVG.
- If GLM does not emit the placeholder, the renderer leaves that asset unused.

This keeps the system multi-template friendly and avoids code rules that only work for one deck.

## Output Directory Shape

A typical output directory contains:

- `styles.json`: extracted template contracts and bindings.
- `_vl_pages/`: rendered page images used for VL.
- `backgrounds/`: extracted image assets.
- `blank_templates/`: model-generated shared blank backgrounds.
- `lo_export/`: LibreOffice/PDF/SVG vector extraction outputs.
- `verify_render/`: generated per-page HTML previews.
- `presentation.html`: iframe index for previewing all generated pages.
- `tmp/`: prompts/responses/images for debugging.

## Notes

- Font extraction intentionally keeps reusable font family/style evidence only; font sizes are estimated visually by VL and expressed in `px`.
- PDF input generally does not provide the same PPTX-level SVG structure, so exact SVG reuse is best-effort.
- `tmp/`, `_resume/`, rendered previews, and source decks can be large and may contain sensitive content. Do not include them in a code-only package.
