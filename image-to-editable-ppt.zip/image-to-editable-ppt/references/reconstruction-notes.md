# Reconstruction Notes

## What "Editable" Means

The generated PPTX should be useful as a template. Prefer editable PowerPoint objects over pixel-perfect but flattened imagery:

- backgrounds: slide background fill or editable rectangles
- cards and panels: editable rectangles
- dividers: editable lines or thin rectangles
- text: editable text boxes with placeholders
- tables: editable grid lines plus text boxes, or a real table when simple
- charts: editable approximate chart shapes, or labeled chart placeholders
- photos, complex illustrations, brand marks, logos, and abstract graphics: labeled placeholder rectangles

## Common Screenshot Patterns

Hero/title slide:
Use a large title placeholder, subtitle placeholder, optional date/footer text, and background color or image placeholder.

Dashboard or report page:
Create top nav/title bands, metric cards, chart placeholders, table/grid placeholders, and small label text boxes.

Consulting-style slide:
Preserve the title area, horizontal rule, body columns, callout boxes, footers, and page number placeholders.

Image-heavy slide:
Create photo placeholders with similar cropping boxes. Do not embed the screenshot as final content.

## Ambiguous Regions

If a region contains many colors, curved brand geometry, or details that cannot be reliably decomposed, represent it as one editable placeholder with an approximate dominant color. Label it according to visual role:

- `Image`
- `Chart`
- `Map`
- `Diagram`
- `Icon`
- `Logo`
- `Graphic`
- `Table`

## Quality Bar

The first pass does not need perfect validation. It should produce a plausible editable template quickly. Improve manually when the source screenshot has obvious elements the script missed, such as a title band, repeated cards, or chart/table structure.
