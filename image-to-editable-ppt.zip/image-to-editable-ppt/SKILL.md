---
name: image-to-editable-ppt
description: "Generate reusable PowerPoint templates from slide screenshots using an SVG-first workflow. Use when the user provides PPT/page images and wants a reusable template for future PPT generation: create slot-annotated SVG previews, parse them into template schema JSON, fill schema slots with new content, and render editable PPTX."
---

# Image To Editable PPT

## Overview

Use an SVG-first pipeline for template extraction:

```text
slide screenshots -> slot-annotated SVG -> template.schema.json -> PPTX
```

This is preferred over asking a vision model to output PPT schema directly. Vision models are better at producing a visual SVG draft than at writing exact PowerPoint geometry.

## Main Workflow

1. Build the final template package:

```bash
python <skill>/scripts/build_template_package.py \
  --output-dir template-package \
  image1.png image2.jpg
```

Final package outputs:

- `visual_templates/slide_*.svg`: the paginated visual template source and long-term template asset
- `template.schema.json`: parsed slot schema for content filling
- `review.pptx`: editable PPTX generated from the SVG/schema for human review and validation

2. Or run the steps manually. Generate slot-annotated SVG templates from screenshots:

```bash
python <skill>/scripts/generate_template_svg.py \
  --output-dir template-svg \
  image1.png image2.jpg
```

3. Inspect the SVG previews. They should visually resemble the source layout. Complex visuals should appear as labeled placeholders, not decomposed fragments.

4. Convert SVG templates to schema:

```bash
python <skill>/scripts/svg_to_template_schema.py \
  --svg-dir template-svg \
  --output template.schema.json
```

5. Render PPTX from schema:

```bash
python <skill>/scripts/render_schema_pptx.py \
  --schema template.schema.json \
  --output template.pptx
```

6. Fill the template with new content:

```bash
python <skill>/scripts/fill_template.py \
  --schema template.schema.json \
  --content content.json \
  --output filled.schema.json

python <skill>/scripts/render_schema_pptx.py \
  --schema filled.schema.json \
  --output filled.pptx
```

## SVG Requirements

Generated SVG must be directly previewable and parseable:

- root has `viewBox`, `width`, and `height`
- every meaningful element has:
  - `data-slot-id`
  - `data-type`: `text`, `image`, `graphic`, `logo`, `shape`, `line`
  - `data-role`: `title`, `subtitle`, `body`, `logo`, `image`, `graphic`, `feature_item`, `caption`, `button`, `footer`, `metric`, `separator`
- text uses SVG `<text>` with placeholder wording
- photos, logos, abstract graphics, charts, maps, screenshots, and decorative watermarks use a single placeholder `<rect>`
- repeated structures are expanded as separate concrete elements, not one abstract repeat block
- no embedded original screenshot

## Schema Contract

`svg_to_template_schema.py` converts SVG elements into reusable slots:

- `text`: editable text slot
- `image`: replaceable photo/screenshot slot
- `graphic`: replaceable abstract visual/watermark/diagram slot
- `logo`: replaceable logo or brand mark slot
- `shape`: editable panel/card/background block
- `line`: editable separator

The schema is used for future content generation. Stable `slot.id` values matter more than exact source text.

## Content Fill Format

`fill_template.py` accepts content JSON keyed by slide ID and slot ID or role:

```json
{
  "slides": {
    "slide_1": {
      "slots": {
        "main_title": "New title",
        "body": "New body copy",
        "hero_image": {"placeholder": "Product image"}
      }
    }
  }
}
```

Prefer stable slot IDs for production. Role-based fills are useful for quick tests but can be ambiguous.

## Model Endpoint

`generate_template_svg.py` uses an OpenAI-compatible vision endpoint:

- config file: `config/model_config.json`
- default base URL: `https://yunwu.ai`
- default model: `qwen3.5-397b-a17b`
- default auth env var: `YUNWU_API_KEY`

Override config with `--config`, or environment variables:

- `PPT_TEMPLATE_BASE_URL`
- `PPT_TEMPLATE_MODEL`
- `PPT_TEMPLATE_API_KEY_ENV`
- `PPT_TEMPLATE_REQUEST_TIMEOUT`

Never commit API keys into skill files.

## Fallbacks

If SVG generation is poor, use the older candidate/schema tools as diagnostic fallbacks:

- `extract_template_schema.py`: code candidates plus optional vision labeling
- `render_schema_svg.py`: schema to SVG preview
- `hybrid_analyze_slide_layout.py`, `image_to_editable_ppt.py`: legacy direct reconstruction experiments

For production template extraction, prefer SVG-first.
