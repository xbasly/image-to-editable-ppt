---
name: image-to-editable-ppt
description: "Generate reusable PowerPoint templates from slide screenshots using an SVG-first workflow. Use when the user provides PPT/page images and wants a reusable template for future PPT generation: create slot-annotated SVG previews, parse them into template schema JSON, fill schema slots with new content, and render editable PPTX."
---

# Image To Editable PPT

## Overview

Use an SVG-first pipeline for template extraction:

```text
PPTX/PDF/screenshots -> SVG -> template.schema.json -> PPTX
```

Treat SVG as the source of truth. PPTX files are derived artifacts: one for visual review of the SVG itself, one for editable slot review.

Prefer source formats in this order:

1. PPTX -> facts + native preview -> model-cleaned SVG when an original deck is available and template quality matters
2. PPTX -> semantic SVG when a fast direct extraction is enough
3. PDF -> visual SVG when a deck-exported PDF is available
4. screenshot images -> vision-generated SVG when only images are available

## Main Workflow

1. Build the final template package:

```bash
python <skill>/scripts/build_template_package.py \
  --output-dir template-package \
  image1.png image2.jpg
```

The same command also accepts one PDF or one PPTX/PPT in auto mode:

```bash
python <skill>/scripts/build_template_package.py \
  --output-dir template-package \
  input.pdf

python <skill>/scripts/build_template_package.py \
  --output-dir template-package \
  input.pptx
```

Final package outputs:

- `visual_templates/slide_*.svg`: the paginated visual template source and long-term template asset
- `template.schema.json`: parsed slot schema for content filling
- `review_visual.pptx`: SVG-backed PPTX for checking the visual result of the SVG template
- `review.pptx`: editable PPTX generated from the SVG/schema for slot geometry review

For higher-quality PPTX template extraction, prefer the fact-guided builder:

```bash
python <skill>/scripts/build_fact_guided_template_package.py \
  --output-dir template-package \
  input.pptx
```

This emits:

- `raw/pptx_facts/manifest.json`: theme, canvas, assets, slide inventory
- `raw/pptx_facts/slides/slide_*.json`: XML-derived per-slide object facts
- `raw/pptx_facts/previews/slide_*.png`: native PowerPoint-rendered previews
- `visual_templates/slide_*.svg`: model-cleaned SVG templates generated from facts + preview
- `template.schema.json`, `review.pptx`, `review_visual.pptx`

2. Or run the steps manually. Generate slot-annotated SVG templates from screenshots:

```bash
python <skill>/scripts/generate_template_svg.py \
  --output-dir template-svg \
  image1.png image2.jpg
```

3. Convert PDF pages to SVG when the input is a PDF:

```bash
python <skill>/scripts/pdf_to_svg.py \
  input.pdf \
  --output-dir template-svg
```

4. Convert PPTX slides to SVG when the input is a PowerPoint deck:

```bash
python <skill>/scripts/pptx_to_svg.py \
  input.pptx \
  --output-dir template-svg
```

This reads PPTX content directly and emits semantic SVG elements for text, shapes, lines, and images. It does not use the PDF conversion path.

5. Inspect the SVG previews. They should visually resemble the source layout. Complex visuals should appear as labeled placeholders, not decomposed fragments.

6. Convert SVG templates to schema:

```bash
python <skill>/scripts/svg_to_template_schema.py \
  --svg-dir template-svg \
  --output template.schema.json
```

7. Render PPTX from schema:

```bash
python <skill>/scripts/render_schema_pptx.py \
  --schema template.schema.json \
  --output template.pptx
```

8. Render a visual PPTX directly from SVG templates:

```bash
python <skill>/scripts/render_svg_pptx.py \
  --svg-dir template-svg \
  --output review_visual.pptx
```

This command renders SVG pages through a local Chromium-based browser when available, then inserts the rendered pages into PowerPoint for stable review.

9. Fill the template with new content:

```bash
python <skill>/scripts/fill_template.py \
  --schema template.schema.json \
  --content content.json \
  --output filled.schema.json

python <skill>/scripts/render_schema_pptx.py \
  --schema filled.schema.json \
  --output filled.pptx
```

## SVG Requirements

Generated SVG must be directly previewable and parseable:

- root has `viewBox`, `width`, and `height`
- every meaningful element has:
  - `data-slot-id`
  - `data-type`: `text`, `image`, `graphic`, `logo`, `shape`, `line`
  - `data-role`: `title`, `subtitle`, `body`, `logo`, `image`, `graphic`, `feature_item`, `caption`, `button`, `footer`, `metric`, `separator`
- text uses SVG `<text>` with placeholder wording
- photos, logos, abstract graphics, charts, maps, screenshots, and decorative watermarks use a single placeholder `<rect>`
- repeated structures are expanded as separate concrete elements, not one abstract repeat block
- no embedded original screenshot

## Source Conversion Notes

- `pdf_to_svg.py` requires `PyMuPDF` (`python -m pip install pymupdf`).
- `pptx_to_svg.py` reads PPTX directly with `python-pptx`; it does not use PDF as an intermediate format.
- PPTX-derived SVG is semantic and slot-annotated, but it may not preserve every PowerPoint effect exactly.
- PDF-derived SVG can be visually faithful but may contain low-level paths without `data-slot-*` annotations. Use it as a visual source, then run slot annotation/cleanup before relying on `template.schema.json` for content filling.
- `extract_pptx_facts.py` extracts structured PPTX facts and native PowerPoint previews. It records text boxes, images, crops, common styles, image/shape transforms such as horizontal/vertical flips and rotation, and effect flags such as shadow/glow/gradient when visible in OOXML.
- `generate_svg_from_pptx_facts.py` gives those facts plus the preview image to the configured vision model so the model cleans and consolidates the SVG instead of guessing geometry from a screenshot alone.
- Use `--skip-existing` with `generate_svg_from_pptx_facts.py` to resume long deck extraction after a timeout or interrupted model run.

## Review Modes

Use two PPTX outputs for different questions:

- `review_visual.pptx`: asks "does the SVG template look right?" It places each SVG page full-slide in PowerPoint and should be closest to the SVG visual.
- `review.pptx`: asks "are the reusable slots editable and positioned correctly?" It converts SVG/schema slots to PowerPoint shapes and text boxes, so some visual fidelity is traded for editability.

When the user's final pipeline is SVG-template-driven, prefer judging `review_visual.pptx` first and only use `review.pptx` to inspect editable slot boundaries.

## Schema Contract

`svg_to_template_schema.py` converts SVG elements into reusable slots:

- `text`: editable text slot
- `image`: replaceable photo/screenshot slot
- `graphic`: replaceable abstract visual/watermark/diagram slot
- `logo`: replaceable logo or brand mark slot
- `shape`: editable panel/card/background block
- `line`: editable separator

The schema is used for future content generation. Stable `slot.id` values matter more than exact source text.

## Content Fill Format

`fill_template.py` accepts content JSON keyed by slide ID and slot ID or role:

```json
{
  "slides": {
    "slide_1": {
      "slots": {
        "main_title": "New title",
        "body": "New body copy",
        "hero_image": {"placeholder": "Product image"}
      }
    }
  }
}
```

Prefer stable slot IDs for production. Role-based fills are useful for quick tests but can be ambiguous.

## Model Endpoint

`generate_template_svg.py` uses an OpenAI-compatible vision endpoint:

- config file: `config/model_config.json`
- default base URL: `https://yunwu.ai`
- default model: `qwen3.5-397b-a17b`
- default auth env var: `YUNWU_API_KEY`

Override config with `--config`, or environment variables:

- `PPT_TEMPLATE_BASE_URL`
- `PPT_TEMPLATE_MODEL`
- `PPT_TEMPLATE_API_KEY_ENV`
- `PPT_TEMPLATE_REQUEST_TIMEOUT`

Never commit API keys into skill files.

## Fallbacks

If SVG generation is poor, use the older candidate/schema tools as diagnostic fallbacks:

- `extract_template_schema.py`: code candidates plus optional vision labeling
- `render_schema_svg.py`: schema to SVG preview
- `hybrid_analyze_slide_layout.py`, `image_to_editable_ppt.py`: legacy direct reconstruction experiments

For production template extraction, prefer SVG-first.
