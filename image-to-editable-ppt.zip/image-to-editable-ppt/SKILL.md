---
name: image-to-editable-ppt
description: "Extract reusable style references from PDF slide decks and generate template-informed editable SVG slide pages from DOCX/JSON content. Use when the user wants to build future PPT content from an SVG template source rather than directly reconstructing PPTX."
---

# PDF Template To SVG Deck

## Purpose

This skill keeps SVG as the long-term template source. It does not try to make a fully editable PPTX clone. The current workflow is:

```text
PDF template -> template_style.md
PDF template -> optional brand/content-binding audit
DOCX or JSON content -> outline.json
template_style.md + outline.json -> generated SVG pages
generated SVG pages -> deterministic text layout repair
```

Use this flow when the goal is to learn the visual language of an existing PDF deck, then generate new SVG slides that can later feed an SVG-to-PPT process.

## Model Config

OpenAI-compatible model settings live in:

```text
config/model_config.json
```

The default config reads the API key from `YUNWU_API_KEY`. Do not hard-code tokens in scripts or docs.

Override config with environment variables when needed:

```powershell
$env:PPT_TEMPLATE_BASE_URL = "https://yunwu.ai"
$env:PPT_TEMPLATE_MODEL = "qwen3.5-397b-a17b"
$env:PPT_TEMPLATE_API_KEY_ENV = "YUNWU_API_KEY"
$env:PPT_TEMPLATE_REQUEST_TIMEOUT = "240"
```

`generate_svg_from_style_glm.py` also accepts explicit `--base-url`, `--model`, and `--api-key-env`.

## Main Workflow

### 1. Extract PDF Style Reference

Use `style-reference` mode to summarize page roles, palette, typography, layout regions, and per-page visual traits into one Markdown file:

```powershell
python .\image-to-editable-ppt\scripts\build_pdf_template.py `
  "D:\template.pdf" `
  --mode style-reference `
  --output-dir "D:\template_style_reference"
```

Output:

```text
D:\template_style_reference\template_style.md
```

The style guide includes page roles such as `cover`, `agenda`, `chapter_divider`, `image_text_mix`, `table`, `chart`, `process_flow`, `code_or_screenshot`, `card_grid`, `quote`, `dense_text`, `text_explainer`, and `closing`. These roles help the outline choose layouts deliberately instead of picking from raw page examples.

### 2. Optional PDF Visual Replica

Use this only when the user wants a close SVG snapshot of the PDF pages themselves:

```powershell
python .\image-to-editable-ppt\scripts\build_pdf_template.py `
  "D:\template.pdf" `
  --mode visual-replica `
  --output-dir "D:\template_visual_svg"
```

Output:

```text
D:\template_visual_svg\slide_*.svg
```

This mode favors visual fidelity and may sacrifice editability. It is separate from the style-reference generation flow.

### 3. Optional Brand And Background Audit

Run this when a PDF template may contain logos, watermarks, product screenshots, company-specific backgrounds, or other content-bound assets:

```powershell
$env:YUNWU_API_KEY = "<your-token>"
python .\image-to-editable-ppt\scripts\audit_pdf_brand_assets.py `
  "D:\template.pdf" `
  --style "D:\template_style_reference\template_style.md" `
  --output-dir "D:\template_brand_audit" `
  --target-brand "TargetBrand" `
  --keep-images
```

Outputs:

```text
D:\template_brand_audit\brand_asset_audit.md
D:\template_brand_audit\brand_asset_audit.json
```

Use the audit result to decide whether to preserve, remove, abstract, or replace brand-bound visuals when the target brand differs from the source template.

### 4. Build A Slide Outline From DOCX

Use a long DOCX report as source content and optionally bind it to a PDF template style:

```powershell
$env:GLM_API_KEY = "<your-token>"
python .\image-to-editable-ppt\scripts\docx_to_ppt_outline.py `
  "D:\report.docx" `
  --output-dir "D:\generated_deck_plan" `
  --slide-count 10 `
  --template-style "D:\template_style_reference\template_style.md" `
  --brand-audit "D:\template_brand_audit\brand_asset_audit.json" `
  --target-brand "TargetBrand" `
  --topic-hint "Topic hint" `
  --base-url "https://yunwu.ai" `
  --model "glm-5" `
  --api-key-env GLM_API_KEY
```

Outputs:

```text
D:\generated_deck_plan\outline.json
D:\generated_deck_plan\content_strategy.md
D:\generated_deck_plan\template_style.md
```

If `--template-style` is provided, `template_style.md` becomes a template-informed generation guide. If not, the script builds a topic-native style guide from the DOCX.

### 5. Generate SVG Pages

Generate SVG slides from a style guide and outline/content JSON:

```powershell
$env:GLM_API_KEY = "<your-token>"
python .\image-to-editable-ppt\scripts\generate_svg_from_style_glm.py `
  --style "D:\generated_deck_plan\template_style.md" `
  --content "D:\generated_deck_plan\outline.json" `
  --output-dir "D:\generated_deck_svg" `
  --base-url "https://yunwu.ai" `
  --model "glm-5" `
  --api-key-env GLM_API_KEY `
  --text-tokens
```

For quick experiments:

```powershell
python .\image-to-editable-ppt\scripts\generate_svg_from_style_glm.py `
  --style "D:\template_style_reference\template_style.md" `
  --content ".\image-to-editable-ppt\examples\web_crawler_10_pages.json" `
  --output-dir "D:\style_test_svg" `
  --limit 3 `
  --text-tokens
```

Use `--skip-existing` to resume without overwriting existing SVG files.

### 6. Repair Text Layout

Always run this after model SVG generation:

```powershell
python .\image-to-editable-ppt\scripts\repair_svg_text_layout.py `
  --svg-dir "D:\generated_deck_svg" `
  --output-dir "D:\generated_deck_svg_repaired" `
  --content "D:\generated_deck_plan\outline.json"
```

This deterministic pass:

- wraps long text with SVG `<tspan>`
- reduces font size when text overflows its safe region
- keeps cover title/subtitle blocks separated
- rebuilds `agenda` pages into a stable numbered list when model output creates scattered overlapping labels

Use the repaired SVG directory as the preferred downstream source.

## Included Scripts

- `build_pdf_template.py`: PDF style-reference and visual-replica entry point.
- `pdf_to_svg.py`: direct PDF page to SVG conversion used by visual-replica mode.
- `audit_pdf_brand_assets.py`: model-assisted brand/background/content-binding audit.
- `docx_to_ppt_outline.py`: DOCX to slide outline and generation style guide.
- `generate_svg_from_style_glm.py`: model-based SVG page generation from style and content JSON.
- `repair_svg_text_layout.py`: deterministic SVG text overflow and agenda-page repair.
- `model_config.py`: shared config loader.
- `model_utils.py`: shared model response, JSON, image, and URL helpers.

## Dependencies

Install or ensure these are available in the active Python environment:

```powershell
python -m pip install pymupdf
```

The scripts otherwise use the Python standard library. Model-backed steps require network access and an API key in the configured environment variable.

## Notes

- Do not embed API tokens in files.
- Do not use this skill for direct PPTX reconstruction; that older path has been removed.
- Prefer PDF `style-reference` plus SVG generation for reusable templates.
- Prefer `visual-replica` only when the user asks for closest PDF-page SVG appearance.
