#!/usr/bin/env python
"""Ask a vision model to repair layout JSON by comparing source and rendered previews."""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from analyze_slide_layout import extract_json, image_to_data_url, normalize_base_url  # noqa: E402


PROMPT = """Compare the original slide screenshot against the rendered PPT preview.

You are repairing editable PPT layout JSON. Return JSON only.

Use the current layout JSON as the starting point, then fix visible differences:
- geometry: x, y, w, h, alignment, spacing, grouping
- typography: font_size, bold, color, text alignment, and font_family
- font style: use "sans" for modern blackbody/grotesque/Hei style, "serif" only when the source visibly uses a serif font
- content role: keep title/subtitle/body/number/caption blocks separate when the source shows separate hierarchy
- media/logo: use media or logo only for photos, complex artwork, icons, and brand marks; do not convert text into media
- image-heavy regions should remain single placeholders, not many fragments
- preserve editability; never ask to use the original screenshot as a background

The renderer supports these element fields:
type: text, rect, line, media, logo
x,y,w,h: normalized 0..1
text, fill, stroke, color, font_size, bold, align, label, font_family

Return:
{
  "slides": [
    {
      "width": original_width,
      "height": original_height,
      "background": "#RRGGBB",
      "notes": "brief repair summary",
      "elements": [...]
    }
  ]
}
"""


def response_text(response: Dict[str, Any]) -> str:
    choices = response.get("choices") or []
    if choices:
        return choices[0].get("message", {}).get("content", "")
    raise ValueError("Could not find chat completion text output.")


def request_repair(
    source_image: Path,
    preview_image: Path,
    slide_layout: Dict[str, Any],
    model: str,
    api_key: str,
    base_url: str,
    timeout: int,
) -> Dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": f"{PROMPT}\n\nCurrent layout JSON:\n{json.dumps({'slides': [slide_layout]}, ensure_ascii=False)}"},
                    {"type": "text", "text": "Original slide screenshot:"},
                    {"type": "image_url", "image_url": {"url": image_to_data_url(source_image)}},
                    {"type": "text", "text": "Rendered PPT preview:"},
                    {"type": "image_url", "image_url": {"url": image_to_data_url(preview_image)}},
                ],
            }
        ],
        "response_format": {"type": "json_object"},
    }
    req = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Vision API error {exc.code}: {detail}") from exc

    parsed = extract_json(response_text(payload))
    repaired = parsed["slides"][0]
    repaired.setdefault("width", slide_layout.get("width"))
    repaired.setdefault("height", slide_layout.get("height"))
    repaired.setdefault("background", slide_layout.get("background", "#FFFFFF"))
    repaired["source_image"] = str(source_image)
    return repaired


def repair_layout(
    layout_path: Path,
    source_images: List[Path],
    preview_images: List[Path],
    output: Path,
    model: str,
    base_url: str,
    timeout: int,
) -> None:
    api_key = os.environ.get("YUNWU_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("YUNWU_API_KEY or OPENAI_API_KEY is required for preview repair.")
    layout = json.loads(layout_path.read_text(encoding="utf-8-sig"))
    slides = layout.get("slides", [])
    if len(source_images) != len(preview_images) or len(slides) != len(source_images):
        raise ValueError("layout slides, source images, and preview images must have the same count.")
    repaired = [
        request_repair(src, prev, slide, model, api_key, base_url, timeout)
        for src, prev, slide in zip(source_images, preview_images, slides)
    ]
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"slides": repaired}, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Repair layout JSON by comparing source images with rendered previews.")
    parser.add_argument("--layout-json", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--source-images", nargs="+", required=True, type=Path)
    parser.add_argument("--preview-images", nargs="+", required=True, type=Path)
    parser.add_argument("--model", default="qwen3.5-397b-a17b")
    parser.add_argument("--request-timeout", type=int, default=240)
    parser.add_argument(
        "--base-url",
        default=os.environ.get("YUNWU_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or "https://yunwu.ai",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    repair_layout(
        args.layout_json,
        args.source_images,
        args.preview_images,
        args.output,
        args.model,
        args.base_url,
        args.request_timeout,
    )


if __name__ == "__main__":
    main()
