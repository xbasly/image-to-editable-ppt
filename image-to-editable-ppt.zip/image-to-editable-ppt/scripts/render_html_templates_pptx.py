#!/usr/bin/env python
"""Render generated HTML role templates into a preview PPTX.

The PPTX is for human review. Each slide contains one rendered PNG of a role
template, so this is not the final editable PPT generation path.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path


ROLE_ORDER = [
    "cover",
    "agenda",
    "chapter_cover",
    "text",
    "image",
    "quote",
    "chart",
    "table",
    "summary",
    "timeline",
    "data_support",
]


def find_browser() -> str:
    candidates = [
        shutil.which("msedge"),
        shutil.which("chrome"),
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    raise RuntimeError("Could not find Edge or Chrome for HTML rendering.")


def render_html_to_pngs(template_dir: Path, preview_dir: Path, width: int, height: int) -> list[Path]:
    browser = find_browser()
    preview_dir.mkdir(parents=True, exist_ok=True)
    pngs: list[Path] = []
    for role in ROLE_ORDER:
        html_path = template_dir / f"{role}.html"
        if not html_path.exists():
            continue
        png_path = preview_dir / f"{role}.png"
        subprocess.run(
            [
                browser,
                "--headless",
                "--disable-gpu",
                f"--window-size={width},{height}",
                f"--screenshot={png_path}",
                str(html_path.resolve()),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        pngs.append(png_path)
    if not pngs:
        raise RuntimeError(f"No role HTML files found under {template_dir}")
    return pngs


def build_pptx(pngs: list[Path], output: Path, width: int, height: int) -> None:
    try:
        from pptx import Presentation
        from pptx.util import Inches
    except ImportError as exc:
        raise RuntimeError("render_html_templates_pptx.py requires python-pptx. Install it with: python -m pip install python-pptx") from exc

    prs = Presentation()
    prs.slide_width = Inches(13.333333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    for png in pngs:
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(str(png), 0, 0, width=prs.slide_width, height=prs.slide_height)
    output.parent.mkdir(parents=True, exist_ok=True)
    prs.save(output)


def render_preview(template_system_dir: Path, output: Path, keep_pngs: bool) -> None:
    template_dir = template_system_dir / "templates"
    if not template_dir.exists():
        raise FileNotFoundError(f"Missing templates directory: {template_dir}")
    preview_dir = template_system_dir / "preview_png"
    if preview_dir.exists():
        shutil.rmtree(preview_dir)
    pngs = render_html_to_pngs(template_dir, preview_dir, width=1920, height=1080)
    build_pptx(pngs, output, width=1920, height=1080)
    if not keep_pngs:
        shutil.rmtree(preview_dir, ignore_errors=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render HTML role templates into a review PPTX.")
    parser.add_argument("template_system_dir", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--keep-pngs", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    render_preview(args.template_system_dir, args.output, args.keep_pngs)


if __name__ == "__main__":
    main()
