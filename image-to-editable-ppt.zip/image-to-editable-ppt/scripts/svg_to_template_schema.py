#!/usr/bin/env python
"""Convert slot-annotated SVG templates into template schema JSON."""

from __future__ import annotations

import argparse
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Tuple


SVG_NS = "{http://www.w3.org/2000/svg}"


def strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1]


def number(value: str | None, fallback: float = 0.0) -> float:
    if value is None:
        return fallback
    match = re.search(r"-?\d+(?:\.\d+)?", str(value))
    return float(match.group(0)) if match else fallback


def parse_style(element: ET.Element) -> Dict[str, str]:
    style: Dict[str, str] = {}
    inline = element.attrib.get("style", "")
    for part in inline.split(";"):
        if ":" in part:
            key, value = part.split(":", 1)
            style[key.strip()] = value.strip()
    for key in ("fill", "stroke", "font-family", "font-size", "font-weight", "text-anchor"):
        if key in element.attrib:
            style[key] = element.attrib[key]
    return style


def get_svg_size(root: ET.Element) -> Tuple[float, float]:
    viewbox = root.attrib.get("viewBox")
    if viewbox:
        parts = [float(p) for p in re.findall(r"-?\d+(?:\.\d+)?", viewbox)]
        if len(parts) == 4:
            return parts[2], parts[3]
    return number(root.attrib.get("width"), 1600), number(root.attrib.get("height"), 900)


def text_content(element: ET.Element) -> str:
    parts: List[str] = []
    if element.text and element.text.strip():
        parts.append(element.text.strip())
    for child in element:
        if child.text and child.text.strip():
            parts.append(child.text.strip())
    return "\n".join(parts).strip()


def sanitize_svg_xml(text: str) -> str:
    return re.sub(r"&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9A-Fa-f]+;)", "&amp;", text)


def font_family_token(value: str | None) -> str:
    value = (value or "").lower()
    if "serif" in value or "simsun" in value or "song" in value:
        return "serif"
    if "mono" in value or "consolas" in value:
        return "mono"
    return "sans"


def placeholder_text(slot_id: str, role: str | None, text: str) -> str:
    slot_id_l = slot_id.lower()
    role_l = (role or "").lower()
    if slot_id_l.startswith("nav_"):
        return "导航"
    if role_l == "title":
        return "标题"
    if role_l == "subtitle":
        return "副标题"
    if role_l in {"caption", "footer"}:
        return "说明"
    if role_l == "metric":
        return "01"
    if "chart" in slot_id_l:
        return "图表"
    if role_l == "body" and len(text) > 24:
        return "正文占位"
    return text


def slot_from_element(element: ET.Element, width: float, height: float, index: int) -> Dict[str, Any] | None:
    slot_id = element.attrib.get("data-slot-id")
    slot_type = element.attrib.get("data-type")
    role = element.attrib.get("data-role")
    if not slot_id or not slot_type:
        return None
    tag = strip_ns(element.tag)
    if tag == "g":
        rect_child = next((child for child in element if strip_ns(child.tag) == "rect"), None)
        if rect_child is not None and slot_type in {"graphic", "image", "logo"}:
            x = number(rect_child.attrib.get("x"))
            y = number(rect_child.attrib.get("y"))
            w = number(rect_child.attrib.get("width"))
            h = number(rect_child.attrib.get("height"))
            style_raw = parse_style(rect_child)
            return {
                "id": f"{slot_id}_visual",
                "type": "image" if role in {"feature_item", "image"} else slot_type,
                "role": "image" if role == "feature_item" else (role or slot_type),
                "x": max(0, x / width),
                "y": max(0, y / height),
                "w": min(1, w / width),
                "h": min(1, h / height),
                "placeholder": element.attrib.get("aria-label") or "Image",
                "style": {
                    "fill": style_raw.get("fill", "#E8E8E8"),
                    "stroke": style_raw.get("stroke", style_raw.get("fill", "#E8E8E8")),
                },
            }
        return None
    style_raw = parse_style(element)
    if tag == "line":
        x1 = number(element.attrib.get("x1"))
        y1 = number(element.attrib.get("y1"))
        x2 = number(element.attrib.get("x2"))
        y2 = number(element.attrib.get("y2"))
        x = min(x1, x2)
        y = min(y1, y2)
        w = max(abs(x2 - x1), number(element.attrib.get("stroke-width"), 1))
        h = max(abs(y2 - y1), number(element.attrib.get("stroke-width"), 1))
        return {
            "id": slot_id,
            "type": "line",
            "role": role or "separator",
            "x": max(0, x / width),
            "y": max(0, y / height),
            "w": min(1, w / width),
            "h": min(1, h / height),
            "placeholder": element.attrib.get("aria-label") or role or "Line",
            "style": {
                "fill": style_raw.get("stroke", style_raw.get("fill", "#999999")),
                "stroke": style_raw.get("stroke", style_raw.get("fill", "#999999")),
            },
        }
    if tag == "text":
        x = number(element.attrib.get("x"))
        y = number(element.attrib.get("y"))
        font_size = number(style_raw.get("font-size"), 12)
        text = text_content(element) or role or "Text"
        anchor = style_raw.get("text-anchor", "start")
        has_box = all(key in element.attrib for key in ("data-box-x", "data-box-y", "data-box-w", "data-box-h"))
        if has_box:
            box_x = number(element.attrib.get("data-box-x"))
            box_y = number(element.attrib.get("data-box-y"))
            box_w = number(element.attrib.get("data-box-w"))
            box_h = number(element.attrib.get("data-box-h"))
            if role == "title" and box_x + box_w < width * 0.85:
                box_w = max(box_w, width - box_x - width * 0.04)
        else:
            approx_w = max(font_size * max(len(line) for line in text.splitlines() or ["Text"]) * 0.62, font_size * 4)
            approx_h = max(font_size * 1.35 * len(text.splitlines() or ["Text"]), font_size * 1.35)
            box_x = x
            if anchor == "middle":
                box_x -= approx_w / 2
            elif anchor == "end":
                box_x -= approx_w
            box_y = y - font_size
            box_w = approx_w
            box_h = approx_h
        style = {
            "font_family": font_family_token(style_raw.get("font-family")),
            "font_size": font_size,
            "bold": style_raw.get("font-weight") in {"bold", "700", "800", "900"},
            "color": style_raw.get("fill", "#111111"),
            "align": {"middle": "center", "end": "right"}.get(anchor, "left"),
        }
        return {
            "id": slot_id,
            "type": "text",
            "role": role or "text",
            "x": max(0, box_x / width),
            "y": max(0, box_y / height),
            "w": min(1, box_w / width),
            "h": min(1, box_h / height),
            "placeholder": placeholder_text(slot_id, role, text),
            "style": style,
        }
    x = number(element.attrib.get("x"))
    y = number(element.attrib.get("y"))
    w = number(element.attrib.get("width"))
    h = number(element.attrib.get("height"))
    if tag in {"circle", "ellipse"}:
        cx = number(element.attrib.get("cx"))
        cy = number(element.attrib.get("cy"))
        rx = number(element.attrib.get("r") or element.attrib.get("rx"), 20)
        ry = number(element.attrib.get("r") or element.attrib.get("ry"), rx)
        x, y, w, h = cx - rx, cy - ry, rx * 2, ry * 2
    if w <= 0 or h <= 0:
        return None
    style = {
        "fill": style_raw.get("fill", "#E8E8E8"),
        "stroke": style_raw.get("stroke", style_raw.get("fill", "#E8E8E8")),
    }
    return {
        "id": slot_id,
        "type": slot_type,
        "role": role or slot_type,
        "x": max(0, x / width),
        "y": max(0, y / height),
        "w": min(1, w / width),
        "h": min(1, h / height),
        "placeholder": element.attrib.get("aria-label") or role or slot_type.title(),
        "style": style,
    }


def structural_slot_from_element(element: ET.Element, width: float, height: float, index: int) -> Dict[str, Any] | None:
    if element.attrib.get("data-slot-id") or strip_ns(element.tag) != "rect":
        return None
    style_raw = parse_style(element)
    fill = style_raw.get("fill", "")
    if fill in {"", "none", "transparent"}:
        return None
    x = number(element.attrib.get("x"))
    y = number(element.attrib.get("y"))
    w = number(element.attrib.get("width"))
    h = number(element.attrib.get("height"))
    if w <= 0 or h <= 0:
        return None
    if x == 0 and y == 0 and w >= width * 0.95 and h >= height * 0.95:
        return None
    area = (w * h) / max(1.0, width * height)
    touches_edge = x <= width * 0.02 or y <= height * 0.02 or x + w >= width * 0.98 or y + h >= height * 0.98
    if area < 0.025 and not (touches_edge and area >= 0.01):
        return None
    return {
        "id": f"structural_rect_{index}",
        "type": "shape",
        "role": "background_block",
        "x": max(0, x / width),
        "y": max(0, y / height),
        "w": min(1, w / width),
        "h": min(1, h / height),
        "placeholder": "Background block",
        "style": {
            "fill": fill,
            "stroke": style_raw.get("stroke", fill),
        },
    }


def infer_theme(root: ET.Element, slots: List[Dict[str, Any]]) -> Dict[str, Any]:
    bg = "#FFFFFF"
    for element in root.iter():
        if strip_ns(element.tag) == "rect" and number(element.attrib.get("x")) == 0 and number(element.attrib.get("y")) == 0:
            w = number(element.attrib.get("width"))
            h = number(element.attrib.get("height"))
            if w > 100 and h > 100:
                bg = parse_style(element).get("fill", bg)
                break
    dark = bg.lower() in {"#000", "#000000", "black"}
    return {
        "background": bg,
        "primary": "#FFFFFF" if dark else "#111111",
        "secondary": "#AAAAAA" if dark else "#666666",
        "muted": "#777777" if dark else "#999999",
        "accent": "#5B8FD6",
        "font_family": "sans",
    }


def parse_svg(svg_path: Path, slide_index: int) -> Dict[str, Any]:
    root = ET.fromstring(sanitize_svg_xml(svg_path.read_text(encoding="utf-8")))
    width, height = get_svg_size(root)
    slots: List[Dict[str, Any]] = []
    for i, element in enumerate(root.iter(), 1):
        slot = slot_from_element(element, width, height, i)
        if not slot:
            slot = structural_slot_from_element(element, width, height, i)
        if slot:
            slots.append(slot)
    return {
        "id": f"slide_{slide_index}",
        "slide_type": "svg_extracted_template",
        "canvas": {"width": width, "height": height, "aspect": round(width / height, 4)},
        "grid": {"columns": 12, "margin_x": 0.08, "margin_y": 0.06, "gutter": 0.016},
        "theme": infer_theme(root, slots),
        "slots": slots,
        "notes": f"Parsed from {svg_path.name}",
        "source_svg": str(svg_path),
    }


def slide_sort_key(path: Path) -> tuple[int, str]:
    match = re.search(r"(\d+)", path.stem)
    return (int(match.group(1)) if match else 10**9, path.name)


def convert(svg_dir: Path, output: Path) -> None:
    svg_paths = sorted(svg_dir.glob("*.svg"), key=slide_sort_key)
    if not svg_paths:
        raise ValueError(f"No SVG files found in {svg_dir}")
    slides = [parse_svg(path, i) for i, path in enumerate(svg_paths, 1)]
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"schema_version": "1.0", "slides": slides}, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert slot-annotated SVG files into template schema JSON.")
    parser.add_argument("--svg-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    convert(args.svg_dir, args.output)


if __name__ == "__main__":
    main()
