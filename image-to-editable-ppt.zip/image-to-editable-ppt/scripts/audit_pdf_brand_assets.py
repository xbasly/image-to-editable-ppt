#!/usr/bin/env python
"""Audit PDF template pages for brand assets and content-bound backgrounds.

The audit is vision-assisted because code extraction cannot reliably tell whether
a background is a reusable decorative texture, a brand logo, or a product-specific
image that should be replaced for a different company/topic.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from model_utils import extract_json, image_to_data_url, normalize_base_url, response_text  # noqa: E402
from model_config import load_model_config, resolve_api_key  # noqa: E402


SPECIAL_ROLES = {"cover", "chapter_divider", "chapter_cover", "agenda", "closing"}


def require_fitz():
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("audit_pdf_brand_assets.py requires PyMuPDF. Install it with: python -m pip install pymupdf") from exc
    return fitz


def parse_style_roles(style_path: Path | None) -> dict[int, str]:
    if not style_path or not style_path.exists():
        return {}
    text = style_path.read_text(encoding="utf-8-sig")
    roles: dict[int, str] = {}
    for match in re.finditer(r"^###\s+slide_(\d+)\s+-\s+([^\n]+)\s*$", text, flags=re.MULTILINE):
        roles[int(match.group(1))] = match.group(2).strip()
    return roles


def selected_pages(page_count: int, roles: dict[int, str], content_sample_count: int) -> list[int]:
    selected: set[int] = {1, page_count}
    selected.update(index for index, role in roles.items() if role in SPECIAL_ROLES)
    content_candidates = [i for i in range(1, page_count + 1) if i not in selected]
    if content_candidates and content_sample_count > 0:
        if len(content_candidates) <= content_sample_count:
            selected.update(content_candidates)
        else:
            for slot in range(content_sample_count):
                pos = round(slot * (len(content_candidates) - 1) / max(1, content_sample_count - 1))
                selected.add(content_candidates[pos])
    return sorted(i for i in selected if 1 <= i <= page_count)


def render_pages(pdf: Path, output_dir: Path, page_numbers: list[int], zoom: float) -> dict[int, Path]:
    fitz = require_fitz()
    output_dir.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(pdf)
    rendered: dict[int, Path] = {}
    try:
        for page_number in page_numbers:
            page = doc[page_number - 1]
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            path = output_dir / f"slide_{page_number}.png"
            pix.save(path)
            rendered[page_number] = path
    finally:
        doc.close()
    return rendered


def audit_prompt(page_number: int, page_count: int, page_role: str, target_brand: str | None) -> str:
    target = target_brand or "not specified"
    return f"""
Analyze this slide screenshot for reusable PPT template extraction.

Page:
- page_number: {page_number}
- page_count: {page_count}
- candidate_page_role: {page_role}
- target_brand_for_future_generation: {target}

Return JSON only.

Goal:
Decide which visual elements are reusable style assets and which are content-bound or brand-bound assets.
This will be used to prevent mistakes such as applying a Mercedes-specific product background to a BMW deck,
or keeping Huawei logos when generating for Xiaomi.

Classify:
- content_bound_background: background contains product/person/place/screenshot/company-specific imagery that should not be reused across different topics/brands.
- brand_bound_asset: logos, company marks, watermarks, brand names, product icons, trademark visuals.
- reusable_background: solid color, gradient, abstract texture, generic geometry, generic pattern.
- decorative_asset: abstract ornaments that may be reused if they match the style.

Return a JSON object:
{{
  "page_number": {page_number},
  "page_role": "{page_role}",
  "background": {{
    "type": "reusable_background|content_bound_background|mixed|unknown",
    "binding_level": "low|medium|high",
    "description": "short description",
    "same_brand_policy": "preserve|replace_with_same_brand_asset|remove|abstract",
    "different_brand_policy": "preserve|replace|remove|abstract"
  }},
  "brand_assets": [
    {{
      "kind": "logo|brand_name|watermark|product_image|company_photo|screenshot|icon|other",
      "text_or_identity": "recognized brand/product if visible, else unknown",
      "location": "top-left|top-right|center|bottom|background|...",
      "binding_level": "low|medium|high",
      "same_brand_policy": "preserve|replace_with_same_brand_asset|remove|abstract",
      "different_brand_policy": "preserve|replace|remove|abstract"
    }}
  ],
  "content_visuals": [
    {{
      "kind": "photo|screenshot|chart|diagram|table|product|person|device|other",
      "description": "short description",
      "template_slot_policy": "convert_to_placeholder|preserve_as_style|remove|keep_if_same_topic"
    }}
  ],
  "global_style_signals": [
    "visual style signals useful across brands, e.g. blue corporate background, red module blocks"
  ],
  "notes": "concise implementation notes for future SVG template generation"
}}
""".strip()


def request_audit(
    image_path: Path,
    page_number: int,
    page_count: int,
    page_role: str,
    target_brand: str | None,
    model: str,
    api_key: str,
    base_url: str,
    timeout: int,
) -> dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": audit_prompt(page_number, page_count, page_role, target_brand)},
                    {"type": "image_url", "image_url": {"url": image_to_data_url(image_path)}},
                ],
            }
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.1,
    }
    request = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Vision API error {exc.code}: {detail}") from exc
    return extract_json(response_text(payload))


def aggregate_findings(page_audits: list[dict[str, Any]]) -> dict[str, Any]:
    brand_assets: dict[str, dict[str, Any]] = {}
    reusable_signals: list[str] = []
    high_binding_pages: list[int] = []
    for audit in page_audits:
        background = audit.get("background") or {}
        if background.get("binding_level") == "high" or background.get("type") == "content_bound_background":
            high_binding_pages.append(int(audit.get("page_number") or 0))
        for asset in audit.get("brand_assets") or []:
            key = f"{asset.get('kind')}:{asset.get('text_or_identity')}:{asset.get('location')}"
            brand_assets.setdefault(key, asset)
        for signal in audit.get("global_style_signals") or []:
            if signal not in reusable_signals:
                reusable_signals.append(signal)
    return {
        "brand_assets": list(brand_assets.values()),
        "reusable_style_signals": reusable_signals,
        "high_binding_pages": [page for page in high_binding_pages if page],
    }


def build_markdown(pdf: Path, page_audits: list[dict[str, Any]], summary: dict[str, Any], target_brand: str | None) -> str:
    lines = [
        "# PDF Brand Asset Audit",
        "",
        f"- Source PDF: {pdf}",
        f"- Target brand: {target_brand or 'not specified'}",
        "",
        "## Global Guidance",
        "",
    ]
    if summary["brand_assets"]:
        lines.append("- Brand-bound assets found. Preserve only for same-brand generation; replace/remove for different-brand generation.")
    else:
        lines.append("- No obvious repeated brand-bound assets were detected in sampled pages.")
    if summary["high_binding_pages"]:
        lines.append(f"- High content-binding pages: {', '.join('slide_' + str(p) for p in summary['high_binding_pages'])}.")
    if summary["reusable_style_signals"]:
        lines.append("- Reusable style signals: " + "; ".join(summary["reusable_style_signals"][:8]))

    lines.extend(["", "## Brand Assets", ""])
    if not summary["brand_assets"]:
        lines.append("- None detected in sampled pages.")
    for asset in summary["brand_assets"]:
        lines.append(
            f"- {asset.get('kind', 'asset')} `{asset.get('text_or_identity', 'unknown')}` at {asset.get('location', 'unknown')}: "
            f"same-brand `{asset.get('same_brand_policy')}`, different-brand `{asset.get('different_brand_policy')}`."
        )

    lines.extend(["", "## Page Findings", ""])
    for audit in page_audits:
        bg = audit.get("background") or {}
        lines.extend(
            [
                f"### slide_{audit.get('page_number')} - {audit.get('page_role')}",
                f"- Background: `{bg.get('type', 'unknown')}`, binding `{bg.get('binding_level', 'unknown')}`.",
                f"- Background policy: same-brand `{bg.get('same_brand_policy', 'unknown')}`, different-brand `{bg.get('different_brand_policy', 'unknown')}`.",
                f"- Description: {bg.get('description', '')}",
            ]
        )
        visuals = audit.get("content_visuals") or []
        if visuals:
            lines.append("- Content visuals: " + "; ".join(f"{v.get('kind')}: {v.get('template_slot_policy')}" for v in visuals[:5]))
        if audit.get("notes"):
            lines.append(f"- Notes: {audit['notes']}")
        lines.append("")
    return "\n".join(lines)


def audit_pdf(
    pdf: Path,
    output_dir: Path,
    style_path: Path | None,
    target_brand: str | None,
    content_sample_count: int,
    model: str,
    base_url: str,
    api_key_env: str,
    timeout: int,
    keep_images: bool,
) -> None:
    api_key = resolve_api_key({"api_key_env": api_key_env})
    if not api_key:
        raise RuntimeError(f"{api_key_env} or OPENAI_API_KEY is required.")
    fitz = require_fitz()
    roles = parse_style_roles(style_path)
    doc = fitz.open(pdf)
    try:
        page_count = len(doc)
    finally:
        doc.close()
    pages = selected_pages(page_count, roles, content_sample_count)
    output_dir.mkdir(parents=True, exist_ok=True)
    image_dir = output_dir / "audit_images"

    with tempfile.TemporaryDirectory() as tmp:
        render_dir = image_dir if keep_images else Path(tmp)
        rendered = render_pages(pdf, render_dir, pages, zoom=1.0)
        page_audits = []
        for page_number in pages:
            page_role = roles.get(page_number) or ("cover" if page_number == 1 else "closing" if page_number == page_count else "content")
            audit = request_audit(
                rendered[page_number],
                page_number,
                page_count,
                page_role,
                target_brand,
                model,
                api_key,
                base_url,
                timeout,
            )
            audit.setdefault("page_number", page_number)
            audit.setdefault("page_role", page_role)
            page_audits.append(audit)

    summary = aggregate_findings(page_audits)
    payload = {
        "schema_version": "1.0",
        "source_pdf": str(pdf),
        "target_brand": target_brand,
        "sampled_pages": pages,
        "summary": summary,
        "pages": page_audits,
    }
    (output_dir / "brand_asset_audit.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "brand_asset_audit.md").write_text(build_markdown(pdf, page_audits, summary, target_brand), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    config = load_model_config()
    parser = argparse.ArgumentParser(description="Vision-audit PDF template brand assets and content-bound backgrounds.")
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--style", type=Path, help="Optional template_style.md for page role selection.")
    parser.add_argument("--target-brand", help="Future deck target brand, e.g. Huawei or Xiaomi.")
    parser.add_argument("--content-sample-count", type=int, default=4)
    parser.add_argument("--model", default=config["model"])
    parser.add_argument("--base-url", default=config["base_url"])
    parser.add_argument("--api-key-env", default=config["api_key_env"])
    parser.add_argument("--request-timeout", type=int, default=int(config["request_timeout"]))
    parser.add_argument("--keep-images", action="store_true", help="Keep rendered sampled page images for inspection.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    audit_pdf(
        args.pdf,
        args.output_dir,
        args.style,
        args.target_brand,
        args.content_sample_count,
        args.model,
        args.base_url,
        args.api_key_env,
        args.request_timeout,
        args.keep_images,
    )


if __name__ == "__main__":
    main()
