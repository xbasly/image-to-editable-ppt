#!/usr/bin/env python
"""Repair common SVG text layout failures after model generation.

This pass is intentionally deterministic. It fixes problems that LLM-produced
SVGs frequently leave behind: long single-line Chinese titles, text extending
past its intended column, and agenda pages rendered as unstable node diagrams.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any


SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)


def qname(name: str) -> str:
    return f"{{{SVG_NS}}}{name}"


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_num(value: str | None, default: float = 0) -> float:
    if value is None:
        return default
    match = re.search(r"-?\d+(?:\.\d+)?", str(value))
    return float(match.group(0)) if match else default


def text_width(text: str, font_size: float) -> float:
    width = 0.0
    for char in text:
        if char.isspace():
            width += font_size * 0.32
        elif "\u4e00" <= char <= "\u9fff" or "\u3000" <= char <= "\u303f":
            width += font_size * 0.98
        elif char.isupper() or char.isdigit():
            width += font_size * 0.62
        else:
            width += font_size * 0.52
    return width


def split_cjk_text(text: str, font_size: float, max_width: float) -> list[str]:
    chunks = re.split(r"(\s+|[，。；：、,.!?！？；:])", text)
    units: list[str] = []
    for chunk in chunks:
        if not chunk:
            continue
        if re.fullmatch(r"\s+", chunk):
            units.append(chunk)
        elif text_width(chunk, font_size) > max_width and re.search(r"[\u4e00-\u9fff]", chunk):
            units.extend(list(chunk))
        else:
            units.append(chunk)

    lines: list[str] = []
    current = ""
    for unit in units:
        candidate = current + unit
        if current and text_width(candidate, font_size) > max_width:
            lines.append(current.strip())
            current = unit.lstrip()
        else:
            current = candidate
    if current.strip():
        lines.append(current.strip())
    return lines or [text]


def nearest_rect_width(root: ET.Element, text_el: ET.Element, x: float, y: float, width: float, height: float) -> float | None:
    candidates: list[tuple[float, float]] = []
    for rect in root.iter(qname("rect")):
        rx = parse_num(rect.get("x"))
        ry = parse_num(rect.get("y"))
        rw = parse_num(rect.get("width"))
        rh = parse_num(rect.get("height"))
        if rw < 80 or rh < 30:
            continue
        if rx - 12 <= x <= rx + rw + 12 and ry - 30 <= y <= ry + rh + 60:
            candidates.append((abs((rx + rw / 2) - x) + abs((ry + rh / 2) - y), max(80, rw - 44)))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def first_visual_x(root: ET.Element) -> float | None:
    xs: list[float] = []
    for el in root.iter():
        role = (el.get("data-role") or "").lower()
        if role in {"visual", "image", "media", "chart", "code"}:
            for child in el.iter():
                if local_name(child.tag) in {"rect", "image"}:
                    x = parse_num(child.get("x"))
                    w = parse_num(child.get("width"))
                    if w > 120:
                        xs.append(x)
    return min(xs) if xs else None


def parent_map(root: ET.Element) -> dict[ET.Element, ET.Element]:
    return {child: parent for parent in root.iter() for child in parent}


def ancestor_roles(text_el: ET.Element, parents: dict[ET.Element, ET.Element]) -> set[str]:
    roles: set[str] = set()
    cur: ET.Element | None = text_el
    while cur is not None:
        role = cur.get("data-role")
        if role:
            roles.add(role.lower())
        cur = parents.get(cur)
    return roles


def safe_width(root: ET.Element, text_el: ET.Element, roles: set[str], x: float, y: float, canvas_w: float, canvas_h: float) -> float:
    anchor = (text_el.get("text-anchor") or "start").lower()
    if anchor == "middle":
        return max(120, 2 * min(x - 64, canvas_w - x - 64))
    if "title" in roles or "cover" in roles:
        visual_x = first_visual_x(root)
        if visual_x and visual_x > x + 240:
            return max(180, visual_x - x - 72)
        return max(240, canvas_w - x - 96)
    rect_width = nearest_rect_width(root, text_el, x, y, canvas_w, canvas_h)
    if rect_width:
        return rect_width
    return max(180, canvas_w - x - 96)


def replace_text_with_lines(text_el: ET.Element, lines: list[str], x: float, font_size: float, line_height: float) -> None:
    for child in list(text_el):
        text_el.remove(child)
    text_el.text = None
    for idx, line in enumerate(lines):
        tspan = ET.SubElement(text_el, qname("tspan"))
        tspan.set("x", fmt(x))
        tspan.set("dy", "0" if idx == 0 else fmt(line_height))
        tspan.text = line


def fmt(value: float) -> str:
    if math.isclose(value, round(value)):
        return str(int(round(value)))
    return f"{value:.2f}".rstrip("0").rstrip(".")


def repair_text_elements(root: ET.Element, width: float, height: float) -> int:
    changed = 0
    parents = parent_map(root)
    for text_el in list(root.iter(qname("text"))):
        raw_text = "".join(text_el.itertext()).strip()
        if not raw_text:
            continue
        x = parse_num(text_el.get("x"), width / 2)
        y = parse_num(text_el.get("y"), height / 2)
        font_size = parse_num(text_el.get("font-size"), 36)
        roles = ancestor_roles(text_el, parents)
        max_width = safe_width(root, text_el, roles, x, y, width, height)
        max_lines = 3 if "title" in roles or "cover" in roles else 5
        min_font = 42 if "title" in roles or "cover" in roles else 20

        current_size = font_size
        is_cover_title = ("title" in roles or "cover" in roles) and re.search(r"[\u4e00-\u9fff]", raw_text)
        if is_cover_title and len(raw_text) >= 16 and current_size > 82:
            current_size = 82
        lines = split_cjk_text(raw_text, current_size, max_width)
        while (len(lines) > max_lines or any(text_width(line, current_size) > max_width for line in lines)) and current_size > min_font:
            current_size -= 4
            lines = split_cjk_text(raw_text, current_size, max_width)
        if is_cover_title and len(lines) >= 3 and current_size > 76:
            current_size = 76
            lines = split_cjk_text(raw_text, current_size, max_width)
        if is_cover_title and len(lines) > 1 and y > 350:
            y = 330
            text_el.set("y", fmt(y))
        if len(lines) > max_lines:
            merged: list[str] = lines[: max_lines - 1]
            merged.append("".join(lines[max_lines - 1 :]))
            lines = split_cjk_text("".join(merged), current_size, max_width)
            lines = lines[:max_lines]

        needs_repair = len(lines) > 1 or current_size != font_size or text_width(raw_text, font_size) > max_width
        if not needs_repair:
            continue

        text_el.set("font-size", fmt(current_size))
        replace_text_with_lines(text_el, lines, x, current_size, current_size * 1.16)
        changed += 1
    return changed


def slide_number(path: Path) -> int | None:
    match = re.search(r"(\d+)", path.stem)
    return int(match.group(1)) if match else None


def slide_content(content: dict[str, Any], index: int) -> dict[str, Any]:
    slides = content.get("slides") or []
    if 1 <= index <= len(slides):
        return slides[index - 1]
    return {}


def collect_points(slide: dict[str, Any]) -> list[str]:
    points: list[str] = []
    for key in ("agenda", "sections", "bullets", "key_points", "takeaways"):
        value = slide.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, str):
                    points.append(item)
                elif isinstance(item, dict):
                    text = item.get("title") or item.get("label") or item.get("text")
                    if text:
                        points.append(str(text))
        elif isinstance(value, str):
            points.extend([part.strip() for part in re.split(r"[;\n]", value) if part.strip()])
    if not points:
        title = slide.get("title")
        if title:
            points = ["历史分期", "核心观念", "权力结构", "视觉演进"]
    return points[:6]


def rebuild_dark_agenda(root: ET.Element, slide: dict[str, Any], width: float, height: float) -> bool:
    if str(slide.get("page_role") or "").lower() != "agenda":
        return False
    title = str(slide.get("title") or "目录")
    points = collect_points(slide)
    root.clear()
    root.set("width", fmt(width))
    root.set("height", fmt(height))
    root.set("viewBox", f"0 0 {fmt(width)} {fmt(height)}")
    root.set("xmlns", SVG_NS)

    ET.SubElement(root, qname("rect"), {"width": fmt(width), "height": fmt(height), "fill": "#000000"})
    defs = ET.SubElement(root, qname("defs"))
    grad = ET.SubElement(defs, qname("linearGradient"), {"id": "agendaGrad", "x1": "0%", "y1": "0%", "x2": "100%", "y2": "100%"})
    ET.SubElement(grad, qname("stop"), {"offset": "0%", "stop-color": "#6000F0"})
    ET.SubElement(grad, qname("stop"), {"offset": "100%", "stop-color": "#0090FF"})
    ET.SubElement(root, qname("rect"), {"x": "0", "y": "0", "width": fmt(width), "height": "12", "fill": "url(#agendaGrad)"})
    ET.SubElement(root, qname("rect"), {"x": "96", "y": "168", "width": "18", "height": "112", "fill": "#6000F0"})

    title_el = ET.SubElement(root, qname("text"), {
        "x": "142", "y": "250", "font-size": "76", "font-family": "Arial, Helvetica, sans-serif",
        "font-weight": "700", "fill": "#FFFFFF", "data-role": "title",
    })
    title_el.text = title

    subtitle = str(slide.get("subtitle") or "核心脉络")
    sub_el = ET.SubElement(root, qname("text"), {
        "x": "146", "y": "318", "font-size": "30", "font-family": "Arial, Helvetica, sans-serif",
        "fill": "#B8B8C8", "data-role": "subtitle",
    })
    sub_el.text = subtitle

    body = ET.SubElement(root, qname("g"), {"data-role": "body"})
    y0 = 415
    row_h = 105 if len(points) <= 5 else 88
    for idx, point in enumerate(points, 1):
        y = y0 + (idx - 1) * row_h
        ET.SubElement(body, qname("circle"), {"cx": "160", "cy": fmt(y - 14), "r": "34", "fill": "#6000F0"})
        num = ET.SubElement(body, qname("text"), {
            "x": "160", "y": fmt(y - 3), "font-size": "28", "font-family": "Arial, Helvetica, sans-serif",
            "font-weight": "700", "fill": "#FFFFFF", "text-anchor": "middle",
        })
        num.text = f"{idx:02d}"
        ET.SubElement(body, qname("rect"), {"x": "224", "y": fmt(y - 48), "width": "1180", "height": "2", "fill": "#303040"})
        txt = ET.SubElement(body, qname("text"), {
            "x": "245", "y": fmt(y), "font-size": "44", "font-family": "Arial, Helvetica, sans-serif",
            "font-weight": "600", "fill": "#FFFFFF",
        })
        txt.text = point

    ET.SubElement(root, qname("rect"), {"x": "1510", "y": "188", "width": "300", "height": "620", "rx": "18", "fill": "#101018", "stroke": "#6000F0", "stroke-width": "4"})
    ET.SubElement(root, qname("circle"), {"cx": "1660", "cy": "378", "r": "96", "fill": "none", "stroke": "#6000F0", "stroke-width": "18", "opacity": "0.75"})
    ET.SubElement(root, qname("circle"), {"cx": "1660", "cy": "578", "r": "132", "fill": "none", "stroke": "#0090FF", "stroke-width": "10", "opacity": "0.55"})
    label = ET.SubElement(root, qname("text"), {
        "x": "1660", "y": "840", "font-size": "28", "font-family": "Arial, Helvetica, sans-serif",
        "fill": "#B8B8C8", "text-anchor": "middle",
    })
    label.text = "STRUCTURE"
    repair_text_elements(root, width, height)
    return True


def repair_file(svg_path: Path, out_path: Path, content: dict[str, Any] | None) -> tuple[bool, int]:
    tree = ET.parse(svg_path)
    root = tree.getroot()
    width = parse_num(root.get("width"), 1920)
    height = parse_num(root.get("height"), 1080)
    idx = slide_number(svg_path) or 0
    slide = slide_content(content or {}, idx)
    rebuilt = rebuild_dark_agenda(root, slide, width, height)
    changed = repair_text_elements(root, width, height)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tree.write(out_path, encoding="utf-8", xml_declaration=False)
    return rebuilt, changed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Repair SVG text overflow/overlap after model generation.")
    parser.add_argument("--svg-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--content", type=Path, help="Optional outline/content JSON for page-role aware repairs.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    content = json.loads(args.content.read_text(encoding="utf-8-sig")) if args.content else None
    svg_paths = sorted(args.svg_dir.glob("slide_*.svg"), key=lambda p: slide_number(p) or 0)
    if not svg_paths:
        raise FileNotFoundError(f"No slide_*.svg files found in {args.svg_dir}")
    for svg_path in svg_paths:
        rebuilt, changed = repair_file(svg_path, args.output_dir / svg_path.name, content)
        status = "rebuilt agenda" if rebuilt else f"repaired {changed} text nodes"
        print(f"{svg_path.name}: {status}")


if __name__ == "__main__":
    main()
