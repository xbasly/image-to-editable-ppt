#!/usr/bin/env python
"""Build final SVG-first template package from screenshots.

Outputs:
- visual_templates/slide_*.svg
- template.schema.json
- review.pptx
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def build_package(images: list[Path], output_dir: Path, config: Path | None) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    svg_dir = output_dir / "visual_templates"
    schema_path = output_dir / "template.schema.json"
    pptx_path = output_dir / "review.pptx"

    generate_cmd = [
        sys.executable,
        str(SCRIPT_DIR / "generate_template_svg.py"),
        "--output-dir",
        str(svg_dir),
    ]
    if config:
        generate_cmd.extend(["--config", str(config)])
    generate_cmd.extend(str(path) for path in images)

    run(generate_cmd)
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "svg_to_template_schema.py"),
            "--svg-dir",
            str(svg_dir),
            "--output",
            str(schema_path),
        ]
    )
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "render_schema_pptx.py"),
            "--schema",
            str(schema_path),
            "--output",
            str(pptx_path),
        ]
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build SVG template package and review PPTX from screenshots.")
    parser.add_argument("images", nargs="+", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--config", type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    build_package(args.images, args.output_dir, args.config)


if __name__ == "__main__":
    main()
