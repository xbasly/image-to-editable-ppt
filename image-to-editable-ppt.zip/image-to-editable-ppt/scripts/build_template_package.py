#!/usr/bin/env python
"""Build final SVG-first template package from screenshots, PDFs, or PPTX files.

Outputs:
- visual_templates/slide_*.svg
- template.schema.json
- review.pptx
- review_visual.pptx
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}


def source_mode(paths: list[Path], requested: str) -> str:
    if requested != "auto":
        return requested
    suffixes = {path.suffix.lower() for path in paths}
    if suffixes <= IMAGE_EXTS:
        return "image"
    if len(paths) == 1 and paths[0].suffix.lower() == ".pdf":
        return "pdf"
    if len(paths) == 1 and paths[0].suffix.lower() in {".pptx", ".ppt"}:
        return "pptx"
    raise ValueError("Auto mode supports either all images, one PDF, or one PPTX/PPT file.")


def build_svg_sources(sources: list[Path], svg_dir: Path, config: Path | None, mode: str) -> None:
    if mode == "image":
        generate_cmd = [
            sys.executable,
            str(SCRIPT_DIR / "generate_template_svg.py"),
            "--output-dir",
            str(svg_dir),
        ]
        if config:
            generate_cmd.extend(["--config", str(config)])
        generate_cmd.extend(str(path) for path in sources)
        run(generate_cmd)
        return
    if mode == "pdf":
        if len(sources) != 1:
            raise ValueError("PDF mode expects exactly one PDF input.")
        run(
            [
                sys.executable,
                str(SCRIPT_DIR / "pdf_to_svg.py"),
                str(sources[0]),
                "--output-dir",
                str(svg_dir),
            ]
        )
        return
    if mode == "pptx":
        if len(sources) != 1:
            raise ValueError("PPTX mode expects exactly one PPTX/PPT input.")
        run(
            [
                sys.executable,
                str(SCRIPT_DIR / "pptx_to_svg.py"),
                str(sources[0]),
                "--output-dir",
                str(svg_dir),
            ]
        )
        return
    raise ValueError(f"Unsupported input mode: {mode}")


def build_package(sources: list[Path], output_dir: Path, config: Path | None, input_mode: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    svg_dir = output_dir / "visual_templates"
    schema_path = output_dir / "template.schema.json"
    pptx_path = output_dir / "review.pptx"
    visual_pptx_path = output_dir / "review_visual.pptx"

    mode = source_mode(sources, input_mode)
    build_svg_sources(sources, svg_dir, config, mode)
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "svg_to_template_schema.py"),
            "--svg-dir",
            str(svg_dir),
            "--output",
            str(schema_path),
        ]
    )
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "render_schema_pptx.py"),
            "--schema",
            str(schema_path),
            "--output",
            str(pptx_path),
        ]
    )
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "render_svg_pptx.py"),
            "--svg-dir",
            str(svg_dir),
            "--output",
            str(visual_pptx_path),
        ]
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build SVG template package and review PPTX from images, PDF, or PPTX.")
    parser.add_argument("sources", nargs="+", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--input-mode", choices=["auto", "image", "pdf", "pptx"], default="auto")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    build_package(args.sources, args.output_dir, args.config, args.input_mode)


if __name__ == "__main__":
    main()
