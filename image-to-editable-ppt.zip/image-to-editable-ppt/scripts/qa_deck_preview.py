#!/usr/bin/env python
"""Quality audit for generated HTML/PPT preview PNGs.

The score is heuristic, but intentionally strict enough to catch the common
failures in this workflow: empty pages, weak chapter/agenda identity, and
thin layouts that do not read at thumbnail size.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


ROLE_MIN_EDGE = {
    "cover": 0.010,
    "agenda": 0.018,
    "chapter_cover": 0.015,
    "timeline": 0.016,
    "image": 0.014,
    "text": 0.018,
    "table": 0.018,
    "quote": 0.012,
    "chart": 0.018,
    "data_support": 0.016,
    "summary": 0.017,
}

ROLE_MIN_ACTIVE = {
    "cover": 0.18,
    "agenda": 0.10,
    "chapter_cover": 0.09,
    "timeline": 0.09,
    "image": 0.12,
    "text": 0.10,
    "table": 0.08,
    "quote": 0.08,
    "chart": 0.10,
    "data_support": 0.09,
    "summary": 0.10,
}


def require_pil():
    try:
        from PIL import Image, ImageFilter, ImageStat
    except ImportError as exc:
        raise RuntimeError("Install pillow to run QA: python -m pip install pillow") from exc
    return Image, ImageFilter, ImageStat


def role_from_name(path: Path) -> str:
    match = re.search(r"slide_\d+_(.+)$", path.stem)
    return match.group(1) if match else "text"


def image_metrics(path: Path) -> dict[str, float]:
    Image, ImageFilter, ImageStat = require_pil()
    img = Image.open(path).convert("RGB")
    small = img.resize((320, 180))
    gray = small.convert("L")
    edges = gray.filter(ImageFilter.FIND_EDGES)
    edge_mean = ImageStat.Stat(edges).mean[0] / 255

    # Estimate active visual area by comparing each sampled pixel to the
    # dominant calm background from the four corners.
    corners = [
        small.crop((0, 0, 36, 36)),
        small.crop((284, 0, 320, 36)),
        small.crop((0, 144, 36, 180)),
        small.crop((284, 144, 320, 180)),
    ]
    corner_pixels = []
    for corner in corners:
        corner_pixels.extend(corner.getdata())
    bg = tuple(int(sum(px[i] for px in corner_pixels) / len(corner_pixels)) for i in range(3))
    pixels = list(small.getdata())
    active = 0
    dark_or_accent = 0
    xs: list[int] = []
    ys: list[int] = []
    for idx, px in enumerate(pixels):
        dist = sum(abs(px[i] - bg[i]) for i in range(3))
        if dist > 34:
            active += 1
            x = idx % 320
            y = idx // 320
            xs.append(x)
            ys.append(y)
        if px[0] < 95 or (px[0] > 180 and 70 < px[1] < 170 and px[2] < 80):
            dark_or_accent += 1
    active_ratio = active / len(pixels)
    dark_accent_ratio = dark_or_accent / len(pixels)
    bbox_area = 0.0
    if xs and ys:
        bbox_area = ((max(xs) - min(xs) + 1) * (max(ys) - min(ys) + 1)) / (320 * 180)
    return {
        "edge_density": round(edge_mean, 4),
        "active_ratio": round(active_ratio, 4),
        "dark_accent_ratio": round(dark_accent_ratio, 4),
        "active_bbox_area": round(bbox_area, 4),
    }


def html_checks(html_path: Path | None, role: str) -> list[str]:
    if not html_path or not html_path.exists():
        return []
    text = html_path.read_text(encoding="utf-8", errors="ignore")
    issues: list[str] = []
    if role == "agenda" and ("CONTENTS" not in text and "目录" not in text):
        issues.append("agenda_missing_contents_marker")
    if role == "chapter_cover" and ("CHAPTER" not in text or ("chapter-big" not in text and "arch-rail" not in text and "arch-wordmark" not in text)):
        issues.append("chapter_marker_not_clear")
    if role == "timeline" and (text.count("master-step") + text.count("arch-step") + text.count("arch-agenda-row")) < 4:
        issues.append("timeline_less_than_4_steps")
    content_card_count = text.count("master-card") + text.count("arch-column") + text.count("arch-agenda-row") + text.count("arch-copy-block")
    if role in {"text", "summary", "agenda"} and content_card_count < 3:
        issues.append("not_enough_content_cards")
    return issues


def score_slide(png_path: Path, html_dir: Path | None) -> dict[str, Any]:
    role = role_from_name(png_path)
    metrics = image_metrics(png_path)
    html_path = html_dir / f"{png_path.stem}.html" if html_dir else None
    issues = html_checks(html_path, role)
    min_edge = ROLE_MIN_EDGE.get(role, 0.015)
    min_active = ROLE_MIN_ACTIVE.get(role, 0.09)
    if metrics["edge_density"] < min_edge:
        issues.append("too_sparse_at_thumbnail")
    structure_visible = metrics["edge_density"] >= min_edge * 1.75 and metrics["active_bbox_area"] >= 0.45
    if metrics["active_ratio"] < min_active and not structure_visible:
        issues.append("too_much_empty_space")
    if metrics["active_bbox_area"] < 0.42 and role not in {"cover", "quote"}:
        issues.append("content_region_too_small")
    if metrics["dark_accent_ratio"] < 0.018 and role not in {"cover"}:
        issues.append("weak_text_or_accent_presence")
    score = 100
    for issue in issues:
        score -= {
            "agenda_missing_contents_marker": 22,
            "chapter_marker_not_clear": 24,
            "timeline_less_than_4_steps": 20,
            "not_enough_content_cards": 14,
            "too_sparse_at_thumbnail": 18,
            "too_much_empty_space": 20,
            "content_region_too_small": 16,
            "weak_text_or_accent_presence": 4,
        }.get(issue, 10)
    return {
        "file": str(png_path),
        "role": role,
        "score": max(0, score),
        "issues": issues,
        "metrics": metrics,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit rendered deck preview PNGs.")
    parser.add_argument("preview_png_dir", type=Path)
    parser.add_argument("--html-dir", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--min-average", type=float, default=90)
    parser.add_argument("--min-slide", type=float, default=82)
    args = parser.parse_args()

    pngs = sorted(args.preview_png_dir.glob("slide_*.png"))
    if not pngs:
        raise RuntimeError(f"No slide_*.png files found in {args.preview_png_dir}")
    results = [score_slide(path, args.html_dir) for path in pngs]
    average = round(sum(item["score"] for item in results) / len(results), 2)
    critical_issues = {
        "agenda_missing_contents_marker",
        "chapter_marker_not_clear",
        "timeline_less_than_4_steps",
        "too_sparse_at_thumbnail",
        "too_much_empty_space",
        "content_region_too_small",
    }
    failed = [
        item
        for item in results
        if item["score"] < args.min_slide or any(issue in critical_issues for issue in item["issues"])
    ]
    report = {
        "average_score": average,
        "min_average": args.min_average,
        "min_slide": args.min_slide,
        "passed": average >= args.min_average and not failed,
        "slides": results,
    }
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text)
    if not report["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
