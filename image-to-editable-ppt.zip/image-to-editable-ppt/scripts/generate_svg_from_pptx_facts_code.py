#!/usr/bin/env python
"""Generate deterministic SVG templates from extracted PPTX facts.

This is the default PPTX template path when repeatability matters: no vision
model, no guessing, only XML-derived boxes/assets/styles with conservative SVG.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import shutil
from pathlib import Path
from typing import Any


def esc(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def clean_font_family(value: Any) -> str:
    text = str(value or "").strip()
    if not text or "?" in text or "\ufffd" in text:
        return "Microsoft YaHei"
    return re.sub(r"[\"'<>]", "", text) or "Microsoft YaHei"


def num(value: Any, fallback: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return fallback


def box_values(obj: dict[str, Any]) -> tuple[float, float, float, float]:
    box = obj.get("box") or {}
    return num(box.get("x")), num(box.get("y")), num(box.get("w")), num(box.get("h"))


def slot_id(obj: dict[str, Any], index: int) -> str:
    raw = obj.get("id") or obj.get("name") or f"slot_{index}"
    value = re.sub(r"[^a-zA-Z0-9_\u4e00-\u9fff]+", "_", str(raw)).strip("_").lower()
    return value or f"slot_{index}"


def is_near_full_slide(obj: dict[str, Any], canvas: dict[str, Any]) -> bool:
    _, _, w, h = box_values(obj)
    area = w * h
    canvas_area = num(canvas.get("width")) * num(canvas.get("height"))
    return bool(canvas_area and area / canvas_area > 0.85)


def role_for(obj: dict[str, Any], canvas: dict[str, Any]) -> str:
    typ = obj.get("type")
    x, y, w, h = box_values(obj)
    if typ == "image" and is_near_full_slide(obj, canvas):
        return "background"
    if typ == "image":
        return "image"
    if typ == "line":
        return "separator"
    if typ == "shape":
        return "graphic" if w < 80 or h < 80 else "shape"
    if typ == "text":
        size = 0.0
        runs = obj.get("runs") or []
        if runs:
            size = max(num(run.get("size")) for run in runs)
        if y < num(canvas.get("height")) * 0.22 or size >= 36:
            return "title"
        if size >= 22:
            return "subtitle"
        if y > num(canvas.get("height")) * 0.82:
            return "footer"
        return "body"
    return "graphic"


def text_style(obj: dict[str, Any], fallback_size: float) -> dict[str, Any]:
    runs = obj.get("runs") or []
    run = runs[0] if runs else {}
    family = clean_font_family(run.get("font"))
    size = num(run.get("size"), fallback_size)
    color = run.get("color") or "#111111"
    return {
        "family": family,
        "size": max(6.0, size),
        "color": color,
        "weight": "700" if run.get("bold") else "400",
        "italic": "italic" if run.get("italic") else "normal",
    }


def text_lines(obj: dict[str, Any]) -> list[str]:
    text = str(obj.get("text") or "").strip()
    if text:
        return [line.strip() for line in text.splitlines() if line.strip()] or [text]
    runs = obj.get("runs") or []
    merged = "".join(str(run.get("text") or "") for run in runs).strip()
    return [merged] if merged else ["文本"]


def char_width(char: str, size: float) -> float:
    return size * (0.95 if "\u2e80" <= char <= "\uffff" else 0.56)


def wrap_line(line: str, max_width: float, size: float) -> list[str]:
    if max_width <= size * 2:
        return [line]
    lines: list[str] = []
    current = ""
    width = 0.0
    for char in line:
        cw = char_width(char, size)
        if current and width + cw > max_width:
            lines.append(current.rstrip())
            current = char
            width = cw
        else:
            current += char
            width += cw
    if current:
        lines.append(current.rstrip())
    return lines or [line]


def wrapped_text_lines(obj: dict[str, Any], box_width: float, size: float) -> list[str]:
    wrapped: list[str] = []
    for line in text_lines(obj):
        wrapped.extend(wrap_line(line, box_width, size))
    return wrapped


def is_dark(color: str | None) -> bool:
    if not color or not color.startswith("#") or len(color) != 7:
        return False
    r = int(color[1:3], 16)
    g = int(color[3:5], 16)
    b = int(color[5:7], 16)
    return (0.299 * r + 0.587 * g + 0.114 * b) < 110


def effect_attrs(obj: dict[str, Any], defs: list[str], prefix: str) -> tuple[str, str]:
    effects = obj.get("effects") or {}
    fill = ""
    filt = ""
    if effects.get("gradient"):
        gradient_id = f"{prefix}_gradient"
        defs.append(
            f'<linearGradient id="{gradient_id}" x1="0%" y1="0%" x2="100%" y2="0%">'
            '<stop offset="0%" stop-color="#8A7449"/>'
            '<stop offset="55%" stop-color="#D8BD6D"/>'
            '<stop offset="100%" stop-color="#8A7449"/>'
            '</linearGradient>'
        )
        fill = f' fill="url(#{gradient_id})"'
    if effects.get("shadow"):
        filter_id = f"{prefix}_shadow"
        defs.append(
            f'<filter id="{filter_id}" x="-25%" y="-25%" width="150%" height="150%">'
            '<feDropShadow dx="2" dy="3" stdDeviation="3" flood-color="#000000" flood-opacity="0.35"/>'
            '</filter>'
        )
        filt = f' filter="url(#{filter_id})"'
    return fill, filt


def transform_attr(obj: dict[str, Any], x: float, y: float, w: float, h: float) -> str:
    transform = obj.get("transform") or {}
    parts: list[str] = []
    cx = x + w / 2
    cy = y + h / 2
    if transform.get("flip_h"):
        parts.append(f"translate({cx:.3f} {cy:.3f}) scale(-1 1) translate({-cx:.3f} {-cy:.3f})")
    if transform.get("flip_v"):
        parts.append(f"translate({cx:.3f} {cy:.3f}) scale(1 -1) translate({-cx:.3f} {-cy:.3f})")
    rotation = transform.get("rotation")
    if rotation:
        parts.append(f"rotate({num(rotation):.3f} {cx:.3f} {cy:.3f})")
    return f' transform="{" ".join(parts)}"' if parts else ""


def render_image(obj: dict[str, Any], index: int, canvas: dict[str, Any]) -> str:
    x, y, w, h = box_values(obj)
    sid = slot_id(obj, index)
    role = role_for(obj, canvas)
    asset = obj.get("asset")
    data = (
        f'data-slot-id="{esc(sid)}" data-type="image" data-role="{role}" '
        f'data-box-x="{x:.3f}" data-box-y="{y:.3f}" data-box-w="{w:.3f}" data-box-h="{h:.3f}"'
    )
    transform = transform_attr(obj, x, y, w, h)
    if asset:
        return (
            f'<image x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" '
            f'{data} href="{esc(asset)}" preserveAspectRatio="none"{transform}/>'
        )
    return (
        f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" '
        f'{data} fill="#E8E8E8" stroke="#CCCCCC"{transform}/>'
    )


def render_text(obj: dict[str, Any], index: int, canvas: dict[str, Any], defs: list[str]) -> str:
    x, y, w, h = box_values(obj)
    sid = slot_id(obj, index)
    role = role_for(obj, canvas)
    fallback_size = max(8.0, min(28.0, h * 0.45))
    style = text_style(obj, fallback_size)
    lines = wrapped_text_lines(obj, max(1.0, w), style["size"])
    fill_override, filter_attr = effect_attrs(obj, defs, sid)
    transform = ""
    background = ""
    shape_fill = obj.get("fill")
    geometry = str(obj.get("geometry") or "").lower()
    if shape_fill and shape_fill != "none":
        data = (
            f'data-slot-id="{esc(sid)}_background" data-type="shape" data-role="{role}_background" '
            f'data-box-x="{x:.3f}" data-box-y="{y:.3f}" data-box-w="{w:.3f}" data-box-h="{h:.3f}" '
            f'fill="{esc(shape_fill)}" stroke="{esc(obj.get("stroke") or "none")}" stroke-width="1"'
        )
        if geometry in {"ellipse", "oval"}:
            background = (
                f'<ellipse cx="{x + w / 2:.3f}" cy="{y + h / 2:.3f}" rx="{w / 2:.3f}" ry="{h / 2:.3f}" {data}/>'
            )
        else:
            background = f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" {data}/>'
    text_color = style["color"]
    if shape_fill and is_dark(shape_fill) and text_color in {"#111111", "#000000"}:
        text_color = "#FFFFFF"
    fill = fill_override or f' fill="{esc(text_color)}"'
    text_x = x
    text_y = y + style["size"]
    anchor = ""
    if background:
        text_x = x + w / 2
        text_y = y + h / 2 + style["size"] * 0.35
        anchor = ' text-anchor="middle"'
    tspans = []
    for line_index, line in enumerate(lines):
        dy = 0 if line_index == 0 else style["size"] * 1.25
        tspans.append(f'<tspan x="{text_x:.3f}" dy="{dy:.3f}">{esc(line)}</tspan>')
    return (
        f'{background}<text x="{text_x:.3f}" y="{text_y:.3f}" '
        f'data-slot-id="{esc(sid)}" data-type="text" data-role="{role}" '
        f'data-box-x="{x:.3f}" data-box-y="{y:.3f}" data-box-w="{w:.3f}" data-box-h="{h:.3f}" '
        f'font-family="{esc(style["family"])}" font-size="{style["size"]:.3f}" '
        f'font-weight="{style["weight"]}" font-style="{style["italic"]}"{fill}{filter_attr}{anchor}{transform}>'
        f'{"".join(tspans)}</text>'
    )


def render_line(obj: dict[str, Any], index: int, canvas: dict[str, Any]) -> str:
    x, y, w, h = box_values(obj)
    sid = slot_id(obj, index)
    stroke = obj.get("stroke") or "#333333"
    transform = transform_attr(obj, x, y, w, h)
    return (
        f'<line x1="{x:.3f}" y1="{y:.3f}" x2="{x + w:.3f}" y2="{y + h:.3f}" '
        f'data-slot-id="{esc(sid)}" data-type="line" data-role="{role_for(obj, canvas)}" '
        f'data-box-x="{x:.3f}" data-box-y="{y:.3f}" data-box-w="{w:.3f}" data-box-h="{h:.3f}" '
        f'stroke="{esc(stroke)}" stroke-width="1"{transform}/>'
    )


def render_shape(obj: dict[str, Any], index: int, canvas: dict[str, Any]) -> str:
    x, y, w, h = box_values(obj)
    sid = slot_id(obj, index)
    fill = obj.get("fill") or "none"
    stroke = obj.get("stroke") or "none"
    transform = transform_attr(obj, x, y, w, h)
    geometry = str(obj.get("geometry") or "").lower()
    data = (
        f'data-slot-id="{esc(sid)}" data-type="shape" data-role="{role_for(obj, canvas)}" '
        f'data-box-x="{x:.3f}" data-box-y="{y:.3f}" data-box-w="{w:.3f}" data-box-h="{h:.3f}" '
        f'fill="{esc(fill)}" stroke="{esc(stroke)}" stroke-width="1"{transform}'
    )
    if geometry in {"ellipse", "oval"}:
        return (
            f'<ellipse cx="{x + w / 2:.3f}" cy="{y + h / 2:.3f}" rx="{w / 2:.3f}" ry="{h / 2:.3f}" '
            f'{data}/>'
        )
    if geometry == "diamond":
        points = f"{x + w / 2:.3f},{y:.3f} {x + w:.3f},{y + h / 2:.3f} {x + w / 2:.3f},{y + h:.3f} {x:.3f},{y + h / 2:.3f}"
        return f'<polygon points="{points}" {data}/>'
    if geometry == "rttriangle":
        points = f"{x:.3f},{y + h:.3f} {x + w:.3f},{y:.3f} {x + w:.3f},{y + h:.3f}"
        return f'<polygon points="{points}" {data}/>'
    return (
        f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" '
        f'{data}/>'
    )


def slide_to_svg(slide: dict[str, Any]) -> str:
    canvas = slide.get("canvas") or {}
    width = num(canvas.get("width"), 960.0)
    height = num(canvas.get("height"), 540.0)
    defs: list[str] = []
    body: list[str] = [f'<rect x="0" y="0" width="{width:.3f}" height="{height:.3f}" fill="#FFFFFF"/>']
    for index, obj in enumerate(slide.get("objects") or [], 1):
        typ = obj.get("type")
        try:
            if typ == "image":
                body.append(render_image(obj, index, canvas))
            elif typ == "text":
                body.append(render_text(obj, index, canvas, defs))
            elif typ == "line":
                body.append(render_line(obj, index, canvas))
            else:
                body.append(render_shape(obj, index, canvas))
        except Exception as exc:
            x, y, w, h = box_values(obj)
            sid = slot_id(obj, index)
            body.append(
                f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" '
                f'data-slot-id="{esc(sid)}" data-type="graphic" data-role="graphic" '
                f'fill="#F2F2F2" stroke="#CCCCCC"><title>{esc(exc)}</title></rect>'
            )
    defs_block = f'<defs>{"".join(defs)}</defs>' if defs else ""
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.3f}" height="{height:.3f}" '
        f'viewBox="0 0 {width:.3f} {height:.3f}" data-slide-id="{esc(slide.get("id", "slide"))}">'
        f'{defs_block}<g id="editable_layer">{"".join(body)}</g></svg>\n'
    )


def generate(facts_dir: Path, output_dir: Path, max_slides: int | None = None) -> None:
    slides_dir = facts_dir / "slides"
    assets_dir = facts_dir / "assets"
    output_dir.mkdir(parents=True, exist_ok=True)
    if assets_dir.exists():
        target_assets = output_dir / "assets"
        if target_assets.exists():
            shutil.rmtree(target_assets)
        shutil.copytree(assets_dir, target_assets)
    slide_paths = sorted(slides_dir.glob("slide_*.json"), key=lambda p: int(re.search(r"(\d+)", p.stem).group(1)))
    if max_slides:
        slide_paths = slide_paths[:max_slides]
    for path in slide_paths:
        slide = json.loads(path.read_text(encoding="utf-8-sig"))
        match = re.search(r"(\d+)", path.stem)
        number = int(match.group(1)) if match else len(list(output_dir.glob("slide_*.svg"))) + 1
        (output_dir / f"slide_{number}.svg").write_text(slide_to_svg(slide), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate deterministic SVG from extracted PPTX facts.")
    parser.add_argument("--facts-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--max-slides", type=int)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    generate(args.facts_dir, args.output_dir, args.max_slides)


if __name__ == "__main__":
    main()
