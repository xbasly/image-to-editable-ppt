#!/usr/bin/env python
"""Hybrid slide layout extraction.

Use deterministic image processing for candidate positions, then ask a vision
model to merge/classify the candidates into a concise editable PPT layout.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

from PIL import Image

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from analyze_slide_layout import extract_json, image_to_data_url, normalize_base_url  # noqa: E402
from image_to_editable_ppt import (  # noqa: E402
    Box,
    detect_flat_regions,
    detect_media_regions,
    detect_text_regions,
    dominant_color,
)


PROMPT = """You are converting a slide screenshot into an editable PPT template.

You will receive:
1. the screenshot image
2. deterministic candidate boxes extracted by code

Important:
- Prefer the candidate box positions from code. Do not replace them with a broad visual summary.
- Use vision mainly to classify, merge, and remove candidates.
- Preserve text block positions from candidate boxes; text content may be placeholder text.
- Do not turn candidate text groups into media. Numbered feature blocks, labels, titles, and body copy must remain text.
- Only output media when the candidate list contains media boxes, or when the screenshot clearly contains a photo/chart/complex raster area.
- Merge complex photo/icon/chart areas into one media/logo placeholder. Do not split photo internals.
- Keep repeated card/image grids as repeated media placeholders plus text placeholders.
- Keep the output concise, but do not omit major layout regions.
- Coordinates must be normalized floats from 0 to 1.

Element types:
- text: editable text box
- rect: editable filled rectangle/panel/card/button
- line: editable separator/rule
- media: editable placeholder for photo/chart/map/screenshot/complex visual
- logo: editable approximate logo/brand mark placeholder

Return JSON only:
{
  "slides": [
    {
      "width": image_pixel_width,
      "height": image_pixel_height,
      "background": "#RRGGBB",
      "notes": "short notes about how candidates were merged/classified",
      "elements": [
        {
          "type": "text|rect|line|media|logo",
          "x": 0.0,
          "y": 0.0,
          "w": 0.1,
          "h": 0.1,
          "text": "placeholder or recognized text",
          "fill": "#RRGGBB",
          "stroke": "#RRGGBB",
          "color": "#RRGGBB",
          "font_size": 12,
          "bold": false,
          "align": "left|center|right",
          "label": "Image|Chart|Logo|..."
        }
      ]
    }
  ]
}
"""


def rgb_to_hex(color: tuple[int, int, int]) -> str:
    return f"#{color[0]:02X}{color[1]:02X}{color[2]:02X}"


def norm_box(box: Box, width: int, height: int, kind: str) -> Dict[str, Any]:
    return {
        "type": kind,
        "x": round(box.x / width, 4),
        "y": round(box.y / height, 4),
        "w": round(box.w / width, 4),
        "h": round(box.h / height, 4),
        "color": rgb_to_hex(box.color),
    }


def classify_rect_candidate(box: Box, width: int, height: int) -> str:
    if box.h <= height * 0.018 and box.w >= width * 0.08:
        return "line"
    if box.w <= width * 0.018 and box.h >= height * 0.08:
        return "line"
    return "rect"


def build_candidates(image_path: Path) -> Dict[str, Any]:
    img = Image.open(image_path).convert("RGB")
    bg = dominant_color(img)
    media = detect_media_regions(img, bg)
    rects = detect_flat_regions(img, bg, suppress=media)
    texts = detect_text_regions(img, bg, suppress=media)

    candidates: List[Dict[str, Any]] = []
    for idx, box in enumerate(media):
        item = norm_box(box, img.width, img.height, "media")
        item["id"] = f"m{idx + 1}"
        item["label"] = "Image"
        candidates.append(item)
    for idx, box in enumerate(rects):
        kind = classify_rect_candidate(box, img.width, img.height)
        item = norm_box(box, img.width, img.height, kind)
        item["id"] = f"r{idx + 1}"
        item["fill"] = item["color"]
        candidates.append(item)
    for idx, box in enumerate(texts):
        item = norm_box(box, img.width, img.height, "text")
        item["id"] = f"t{idx + 1}"
        item["text"] = "Text"
        item["font_size"] = max(7, min(34, round(box.h * 0.12, 1)))
        candidates.append(item)

    return {
        "width": img.width,
        "height": img.height,
        "background": rgb_to_hex(bg),
        "candidates": candidates,
    }


def request_hybrid_layout(
    image_path: Path,
    candidates: Dict[str, Any],
    model: str,
    api_key: str,
    base_url: str,
) -> Dict[str, Any]:
    content = [
        {
            "type": "text",
            "text": (
                f"{PROMPT}\n\n"
                "Deterministic candidate boxes JSON:\n"
                f"{json.dumps(candidates, ensure_ascii=False)}"
            ),
        },
        {"type": "image_url", "image_url": {"url": image_to_data_url(image_path)}},
    ]
    body = {
        "model": model,
        "messages": [{"role": "user", "content": content}],
        "response_format": {"type": "json_object"},
    }
    endpoint = f"{normalize_base_url(base_url)}/chat/completions"
    req = urllib.request.Request(
        endpoint,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Vision API error {exc.code}: {detail}") from exc

    text = payload["choices"][0]["message"]["content"]
    parsed = extract_json(text)
    slide = parsed["slides"][0]
    slide.setdefault("width", candidates["width"])
    slide.setdefault("height", candidates["height"])
    slide.setdefault("background", candidates["background"])
    slide["source_image"] = str(image_path)
    return slide


def analyze_images(image_paths: List[Path], output: Path, model: str, base_url: str, candidates_output: Path | None) -> None:
    api_key = os.environ.get("YUNWU_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("YUNWU_API_KEY or OPENAI_API_KEY is required for hybrid vision layout analysis.")

    all_candidates = []
    slides = []
    for image_path in image_paths:
        candidates = build_candidates(image_path)
        all_candidates.append({"source_image": str(image_path), **candidates})
        slides.append(request_hybrid_layout(image_path, candidates, model, api_key, base_url))

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"slides": slides}, ensure_ascii=False, indent=2), encoding="utf-8")
    if candidates_output:
        candidates_output.parent.mkdir(parents=True, exist_ok=True)
        candidates_output.write_text(
            json.dumps({"slides": all_candidates}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create layout JSON by combining code candidates with vision validation.")
    parser.add_argument("images", nargs="+", type=Path, help="Input slide screenshots/images.")
    parser.add_argument("-o", "--output", required=True, type=Path, help="Output hybrid layout JSON path.")
    parser.add_argument("--candidates-output", type=Path, help="Optional debug JSON for deterministic candidates.")
    parser.add_argument("--model", default="qwen3.5-397b-a17b", help="Vision-capable model.")
    parser.add_argument(
        "--base-url",
        default=os.environ.get("YUNWU_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or "https://yunwu.ai",
        help="OpenAI-compatible API base URL. /v1 is appended if omitted.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    analyze_images(args.images, args.output, args.model, args.base_url, args.candidates_output)


if __name__ == "__main__":
    main()
