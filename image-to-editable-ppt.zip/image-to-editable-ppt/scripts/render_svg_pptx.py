#!/usr/bin/env python
"""Render SVG template pages into a visual-review PPTX.

This PPTX is intentionally visual-template-backed: each slide contains a
full-slide render of the SVG template so reviewers can judge the SVG itself.
"""

from __future__ import annotations

import argparse
import json
import shutil
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Tuple

from pptx import Presentation
from pptx.util import Emu


EMU_PER_INCH = 914400


def sanitize_svg_xml(text: str) -> str:
    return re.sub(r"&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9A-Fa-f]+;)", "&amp;", text)


def number(value: str | None, fallback: float = 0.0) -> float:
    if value is None:
        return fallback
    match = re.search(r"-?\d+(?:\.\d+)?", str(value))
    return float(match.group(0)) if match else fallback


def svg_size(svg_path: Path) -> Tuple[float, float]:
    root = ET.fromstring(sanitize_svg_xml(svg_path.read_text(encoding="utf-8")))
    viewbox = root.attrib.get("viewBox")
    if viewbox:
        parts = [float(p) for p in re.findall(r"-?\d+(?:\.\d+)?", viewbox)]
        if len(parts) == 4:
            return parts[2], parts[3]
    return number(root.attrib.get("width"), 1600), number(root.attrib.get("height"), 900)


def render_svg_pptx(svg_dir: Path, output: Path) -> None:
    svg_paths = sorted(svg_dir.glob("*.svg"))
    if not svg_paths:
        raise ValueError(f"No SVG files found in {svg_dir}")

    width, height = svg_size(svg_paths[0])
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        render_with_browser(svg_paths, output, width / height)
    except Exception:
        try:
            render_with_cairosvg(svg_paths, output, width / height)
        except Exception:
            render_with_powerpoint(svg_paths, output, width / height)


def find_browser() -> str | None:
    candidates = [
        shutil.which("msedge"),
        shutil.which("chrome"),
        shutil.which("chromium"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    return None


def render_with_browser(svg_paths: list[Path], output: Path, aspect: float) -> None:
    browser = find_browser()
    if not browser:
        raise RuntimeError("No Chromium-based browser found for SVG rendering.")
    pixel_width = 1920
    pixel_height = round(pixel_width / aspect)
    prs = Presentation()
    prs.slide_width = Emu(10 * EMU_PER_INCH)
    prs.slide_height = Emu(round(prs.slide_width / aspect))
    blank = prs.slide_layouts[6]
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        for index, svg_path in enumerate(svg_paths, 1):
            png_path = tmp_path / f"slide_{index}.png"
            html_path = tmp_path / f"slide_{index}.html"
            svg_text = sanitize_svg_xml(svg_path.read_text(encoding="utf-8"))
            base_href = svg_path.parent.resolve().as_uri() + "/"
            html_path.write_text(
                "<!doctype html><html><head><meta charset=\"utf-8\">"
                f"<base href=\"{base_href}\">"
                "<style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:white;}"
                "svg{display:block;width:100vw;height:100vh;}</style></head><body>"
                f"{svg_text}</body></html>",
                encoding="utf-8",
            )
            subprocess.run(
                [
                    browser,
                    "--headless",
                    "--disable-gpu",
                    f"--window-size={pixel_width},{pixel_height}",
                    f"--screenshot={png_path}",
                    html_path.resolve().as_uri(),
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            slide = prs.slides.add_slide(blank)
            slide.shapes.add_picture(str(png_path), 0, 0, width=prs.slide_width, height=prs.slide_height)
    prs.save(output)


def render_with_cairosvg(svg_paths: list[Path], output: Path, aspect: float) -> None:
    import cairosvg

    prs = Presentation()
    prs.slide_width = Emu(10 * EMU_PER_INCH)
    prs.slide_height = Emu(round(prs.slide_width / aspect))
    blank = prs.slide_layouts[6]
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        for index, svg_path in enumerate(svg_paths, 1):
            png_path = tmp_path / f"slide_{index}.png"
            cairosvg.svg2png(url=str(svg_path), write_to=str(png_path), output_width=1920)
            slide = prs.slides.add_slide(blank)
            slide.shapes.add_picture(str(png_path), 0, 0, width=prs.slide_width, height=prs.slide_height)
    prs.save(output)


def render_with_powerpoint(svg_paths: list[Path], output: Path, aspect: float) -> None:
    slide_width = 720.0
    slide_height = slide_width / aspect
    payload = {
        "output": str(output.resolve()),
        "slide_width": slide_width,
        "slide_height": slide_height,
        "svgs": [str(path.resolve()) for path in svg_paths],
    }
    script = r"""
param([string]$PayloadPath)
$payload = Get-Content -LiteralPath $PayloadPath -Raw | ConvertFrom-Json
$pp = New-Object -ComObject PowerPoint.Application
$pres = $pp.Presentations.Add()
$pres.PageSetup.SlideWidth = [double]$payload.slide_width
$pres.PageSetup.SlideHeight = [double]$payload.slide_height
foreach ($svg in $payload.svgs) {
  $slide = $pres.Slides.Add($pres.Slides.Count + 1, 12)
  $null = $slide.Shapes.AddPicture2($svg, $false, $true, 0, 0, $pres.PageSetup.SlideWidth, $pres.PageSetup.SlideHeight)
}
if (Test-Path -LiteralPath $payload.output) {
  Remove-Item -LiteralPath $payload.output -Force
}
$pres.SaveAs($payload.output)
$pres.Close()
$pp.Quit()
"""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        payload_path = tmp_path / "payload.json"
        script_path = tmp_path / "render_svg_pptx.ps1"
        payload_path.write_text(json.dumps(payload), encoding="utf-8")
        script_path.write_text(script, encoding="utf-8")
        subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
                str(payload_path),
            ],
            check=True,
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render SVG pages into a visual-review PPTX.")
    parser.add_argument("--svg-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    try:
        render_svg_pptx(args.svg_dir, args.output)
    except Exception as exc:
        print(f"Failed to render SVG-backed PPTX: {exc}", file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
