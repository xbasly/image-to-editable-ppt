#!/usr/bin/env python
"""Generate clean SVG templates from PPTX facts plus native slide previews."""

from __future__ import annotations

import argparse
import http.client
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from analyze_slide_layout import image_to_data_url, normalize_base_url  # noqa: E402
from model_config import load_model_config, resolve_api_key  # noqa: E402


PROMPT = """Create a clean reusable SVG template from this PowerPoint slide.

Return SVG only. Do not wrap it in Markdown. Do not explain.

You are given two inputs:
1. A native PowerPoint-rendered preview image. Use it for visual fidelity.
2. A JSON fact extraction from the PPTX XML. Use it as the source of truth for coordinates, text boxes, fonts, colors, images, crops, and effect flags.

Goal:
- Produce a maintainable SVG template for future PPT generation.
- Preserve layout, hierarchy, colors, typography style, and major decorative motifs.
- Prefer facts from JSON over guessing from the image.
- Use the preview image only to resolve ambiguity and check visual appearance.
- For image objects, preserve exact fact x/y/w/h and transform flags. If transform.flip_h or transform.flip_v exists, apply the equivalent SVG transform around the object's own box center.
- Do not move, mirror, crop, or resize fact images based only on the preview. The preview is only a visual check.
- If text in the JSON is mojibake or incomplete, use the preview to infer a short readable placeholder with the same role and style.

Required SVG structure:
- Root <svg> must use the fact canvas viewBox and width/height.
- Include <g id="editable_layer"> containing editable SVG text/shapes/placeholders.
- Every meaningful editable element must have:
  data-slot-id="stable_snake_case_id"
  data-type="text|image|graphic|logo|shape|line"
  data-role="title|subtitle|body|logo|image|graphic|caption|footer|metric|separator|background"
- Text must be real <text> elements, not paths. Keep text short if exact content is not needed.
- For each text element, include data-box-x/y/w/h from the fact box.
- Complex images/charts/artwork should be a single <rect> or <image> placeholder, not decomposed fragments.
- If a PPTX object has shadow/glow/gradient effect flags, approximate them with SVG filter/gradient only when simple; otherwise preserve the object's visual role without overcomplicating the SVG.
- Use image hrefs from the fact JSON when they are important reusable assets.
- Near-full-slide image objects are usually reusable backgrounds. Keep them as a single image background and layer editable text/placeholders above them only when the text exists as separate PPTX fact objects.
- Do not embed the preview screenshot as the only content. The output must be editable-layer driven.

Optional visual reference layer:
- If the slide has highly complex artwork that cannot be reconstructed cleanly, include a hidden reference layer:
  <g id="visual_reference_layer" style="display:none">...</g>
  Do not let it replace editable elements.

SVG quality target:
- A designer should recognize the template when compared with the preview.
- Coordinates should follow the PPTX facts.
- The SVG should be useful as a template, not a raw PPTX dump.
"""


def extract_svg(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:svg|xml)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
    start = text.find("<svg")
    end = text.rfind("</svg>")
    if start == -1 or end == -1:
        raise ValueError(f"Model did not return SVG: {text[:500]}")
    return text[start : end + len("</svg>")]


def repair_svg(svg: str) -> str:
    svg = re.sub(r">([^<]{1,80})/text>", r">\1</text>", svg)
    svg = re.sub(r"&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9A-Fa-f]+;)", "&amp;", svg)
    return svg


def shorten(value: Any, limit: int = 240) -> Any:
    if not isinstance(value, str):
        return value
    return value if len(value) <= limit else value[:limit] + "..."


def compact_slide_facts(slide: Dict[str, Any], max_objects: int) -> Dict[str, Any]:
    objects = []
    canvas = slide.get("canvas", {})
    canvas_area = float(canvas.get("width") or 0) * float(canvas.get("height") or 0)
    for obj in slide.get("objects", [])[:max_objects]:
        box = obj.get("box") or {}
        obj_area = float(box.get("w") or 0) * float(box.get("h") or 0)
        item = {
            "id": obj.get("id"),
            "type": obj.get("type"),
            "name": obj.get("name"),
            "box": box,
            "near_full_slide": bool(canvas_area and obj_area / canvas_area > 0.85),
            "text": shorten(obj.get("text")),
            "runs": [{**run, "text": shorten(run.get("text"), 120)} for run in obj.get("runs", [])[:3]],
            "asset": obj.get("asset"),
            "crop": obj.get("crop"),
            "transform": obj.get("transform"),
            "fill": obj.get("fill"),
            "stroke": obj.get("stroke"),
            "effects": obj.get("effects"),
        }
        objects.append({key: value for key, value in item.items() if value not in (None, "", [], {})})
    return {**slide, "objects": objects}


def request_svg(
    slide_json: Path,
    preview_path: Path,
    model: str,
    api_key: str,
    base_url: str,
    timeout: int,
    max_objects: int,
) -> str:
    slide = json.loads(slide_json.read_text(encoding="utf-8-sig"))
    compact = compact_slide_facts(slide, max_objects)
    body: Dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": f"{PROMPT}\n\nPPTX facts JSON:\n{json.dumps(compact, ensure_ascii=False)}"},
                    {"type": "image_url", "image_url": {"url": image_to_data_url(preview_path)}},
                ],
            }
        ],
    }
    req = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    for attempt in range(1, 4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Vision API error {exc.code}: {detail}") from exc
        except (urllib.error.URLError, http.client.RemoteDisconnected, TimeoutError) as exc:
            if attempt == 3:
                raise RuntimeError(f"Vision API connection failed after retries: {exc}") from exc
            time.sleep(2 * attempt)
    return extract_svg(payload["choices"][0]["message"]["content"])


def generate_from_facts(
    facts_dir: Path,
    output_dir: Path,
    model: str,
    base_url: str,
    timeout: int,
    api_key_env: str,
    max_slides: int | None,
    max_objects: int,
    skip_existing: bool = False,
) -> None:
    api_key = resolve_api_key({"api_key_env": api_key_env})
    if not api_key:
        raise RuntimeError(f"{api_key_env} or OPENAI_API_KEY is required.")
    slides_dir = facts_dir / "slides"
    previews_dir = facts_dir / "previews"
    output_dir.mkdir(parents=True, exist_ok=True)
    slide_jsons = sorted(slides_dir.glob("slide_*.json"), key=lambda p: int(re.search(r"(\d+)", p.stem).group(1)))
    if max_slides:
        slide_jsons = slide_jsons[:max_slides]
    for slide_json in slide_jsons:
        match = re.search(r"(\d+)", slide_json.stem)
        slide_no = int(match.group(1)) if match else len(list(output_dir.glob("*.svg"))) + 1
        preview = previews_dir / f"slide_{slide_no}.png"
        if not preview.exists():
            raise FileNotFoundError(f"Missing preview for {slide_json.name}: {preview}")
        output_path = output_dir / f"slide_{slide_no}.svg"
        if skip_existing and output_path.exists():
            continue
        svg = repair_svg(request_svg(slide_json, preview, model, api_key, base_url, timeout, max_objects))
        output_path.write_text(svg, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate SVG templates from extracted PPTX facts.")
    parser.add_argument("--facts-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--model")
    parser.add_argument("--base-url")
    parser.add_argument("--api-key-env")
    parser.add_argument("--request-timeout", type=int)
    parser.add_argument("--max-slides", type=int)
    parser.add_argument("--max-objects", type=int, default=40)
    parser.add_argument("--skip-existing", action="store_true", help="Do not regenerate SVG files that already exist.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_model_config(args.config)
    generate_from_facts(
        args.facts_dir,
        args.output_dir,
        args.model or config["model"],
        args.base_url or config["base_url"],
        int(args.request_timeout or config["request_timeout"]),
        args.api_key_env or config["api_key_env"],
        args.max_slides,
        args.max_objects,
        args.skip_existing,
    )


if __name__ == "__main__":
    main()
