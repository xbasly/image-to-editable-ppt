#!/usr/bin/env python
"""Build a reusable HTML template system from a PDF or PPTX deck.

Output:
- layout.md: role selector, style summary, and usage guidance.
- templates/common.css: shared theme, typography, spacing, density, and modules.
- templates/*.html: one HTML template per page role.
"""

from __future__ import annotations

import argparse
import base64
import html
import io
import json
import os
import re
import shutil
import sys
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


PAGE_ROLES = [
    "cover",
    "agenda",
    "chapter_cover",
    "text",
    "image",
    "quote",
    "chart",
    "table",
    "summary",
    "timeline",
    "data_support",
]

HTML_SLIDE_WIDTH = 1920
HTML_SLIDE_HEIGHT = 1080

ROLE_LABELS = {
    "cover": "cover",
    "agenda": "agenda",
    "chapter_cover": "chapter cover",
    "text": "text",
    "image": "large image",
    "quote": "quote",
    "chart": "chart",
    "table": "table",
    "summary": "summary",
    "timeline": "timeline",
    "data_support": "data support",
}

ROLE_USE_CASES = {
    "cover": "Opening page for title, subtitle, author, date, and brand.",
    "agenda": "Contents, outline, navigation, or meeting agenda.",
    "chapter_cover": "Section divider with a strong title and short context.",
    "text": "Explanation-heavy content, bullets, background, or methodology.",
    "image": "Large image, screenshot, product/case visual, or image-text mixed page.",
    "quote": "One strong statement, principle, conclusion, or quotation.",
    "chart": "Trend, share, comparison, funnel, distribution, or chart-led analysis.",
    "table": "Matrix, comparison, schedule, checklist, or structured data.",
    "summary": "Key findings, action items, conclusion, or next steps.",
    "timeline": "Milestones, stages, roadmap, historical evolution, or project plan.",
    "data_support": "KPI cards, metrics, evidence, quantitative support, or experiment result.",
}

ALLOWED_MODEL_PLACEHOLDERS = {
    "brand_or_series", "deck_title", "subtitle", "presenter", "date", "cover_visual",
    "section_label", "agenda_title", "chapter_index", "chapter_title", "chapter_summary",
    "page_title", "paragraph_or_bullets_left", "paragraph_or_bullets_right", "image_context",
    "image_or_screenshot", "quote_context", "quote_text", "quote_source_or_interpretation",
    "chart_title", "chart_area", "table_title", "summary_title", "next_step", "timeline_title",
    "data_title", "supporting_chart_or_evidence",
    *[f"agenda_item_{i}" for i in range(1, 7)],
    *[f"phase_{i}" for i in range(1, 5)],
    *[f"metric_{i}" for i in range(1, 5)],
    *[f"insight_{i}" for i in range(1, 5)],
    *[f"kpi_{i}" for i in range(1, 5)],
    *[f"kpi_label_{i}" for i in range(1, 5)],
    *[f"takeaway_{i}" for i in range(1, 5)],
    *[f"col_{i}" for i in range(1, 5)],
    *[f"row_{r}_col_{c}" for r in range(1, 4) for c in range(1, 5)],
}


def require_fitz():
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("This script requires PyMuPDF. Install it with: python -m pip install pymupdf") from exc
    return fitz


def clean_output_dir(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for child in output_dir.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def rgb_from_int(value: int | None) -> str | None:
    if value is None:
        return None
    return f"#{(value >> 16) & 255:02X}{(value >> 8) & 255:02X}{value & 255:02X}"


def normalize_color(color: Any) -> str | None:
    if color is None:
        return None
    if isinstance(color, int):
        return rgb_from_int(color)
    if isinstance(color, (list, tuple)) and len(color) >= 3:
        vals = [int(clamp(float(v), 0, 1) * 255) if float(v) <= 1 else int(clamp(float(v), 0, 255)) for v in color[:3]]
        return f"#{vals[0]:02X}{vals[1]:02X}{vals[2]:02X}"
    return None


def hex_to_rgb(color: str) -> tuple[int, int, int]:
    raw = color.strip().lstrip("#")
    if len(raw) != 6:
        return (0, 0, 0)
    return (int(raw[0:2], 16), int(raw[2:4], 16), int(raw[4:6], 16))


def luminance(color: str) -> float:
    r, g, b = hex_to_rgb(color)
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255


def contrast_text(bg: str) -> str:
    return "#FFFFFF" if luminance(bg) < 0.48 else "#111111"


def color_distance(a: str, b: str) -> float:
    ar, ag, ab = hex_to_rgb(a)
    br, bg, bb = hex_to_rgb(b)
    return ((ar - br) ** 2 + (ag - bg) ** 2 + (ab - bb) ** 2) ** 0.5


@dataclass
class AssetBindingConfig:
    enabled: bool = False
    base_url: str = "https://yunwu.ai"
    model: str = "qwen3.5-397b-a17b"
    api_key: str = ""
    max_calls: int = 6
    timeout: int = 45
    calls: int = 0
    cache: dict[str, dict[str, Any]] = field(default_factory=dict)


@dataclass
class ModelVariantConfig:
    enabled: bool = False
    base_url: str = "https://yunwu.ai"
    model: str = "glm-5"
    api_key: str = ""
    timeout: int = 180
    variants_per_role: int = 2
    roles: set[str] = field(default_factory=set)
    max_tokens: int = 2500


def normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/").removesuffix("/v1").rstrip("/") + "/v1"


def response_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") or []
    if not choices:
        return ""
    message = choices[0].get("message") or {}
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict):
                parts.append(str(item.get("text") or ""))
        return "\n".join(parts)
    return ""


def extract_json_object(text: str) -> dict[str, Any]:
    try:
        return json.loads(text)
    except Exception:
        pass
    match = re.search(r"\{.*\}", text, flags=re.S)
    if not match:
        return {}
    try:
        return json.loads(match.group(0))
    except Exception:
        return {}


def request_chat_jsonish(payload: dict[str, Any], base_url: str, api_key: str, timeout: int) -> str:
    req = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"Model request failed: HTTP {exc.code} {body[:800]}") from exc
    return response_text(data)


def image_asset_stats(blob: bytes) -> dict[str, Any]:
    try:
        from PIL import Image
    except ImportError:
        return {"kind_hint": "unknown", "vision_candidate": False}
    try:
        image = Image.open(io.BytesIO(blob))
        mode = image.mode
        has_alpha = mode in {"RGBA", "LA"} or ("transparency" in image.info)
        rgb = image.convert("RGBA" if has_alpha else "RGB")
        sample = rgb.copy()
        sample.thumbnail((96, 96))
        pixels = list(sample.getdata())
        if has_alpha:
            opaque = [p[:3] for p in pixels if p[3] > 12]
            alpha_ratio = 1 - (len(opaque) / max(1, len(pixels)))
        else:
            opaque = [p[:3] for p in pixels]
            alpha_ratio = 0.0
        unique_ratio = len(set(opaque)) / max(1, len(opaque))
        avg_sat = 0.0
        if opaque:
            avg_sat = sum((max(p) - min(p)) / max(1, max(p)) for p in opaque) / len(opaque)
        looks_icon = has_alpha or unique_ratio < 0.18 or (avg_sat > 0.38 and unique_ratio < 0.32)
        return {
            "mode": mode,
            "has_alpha": has_alpha,
            "alpha_ratio": round(alpha_ratio, 3),
            "unique_ratio": round(unique_ratio, 3),
            "avg_saturation": round(avg_sat, 3),
            "kind_hint": "icon_or_illustration" if looks_icon else "photo_or_texture",
            "vision_candidate": looks_icon,
        }
    except Exception:
        return {"kind_hint": "unknown", "vision_candidate": False}


def classify_asset_with_vision(asset_name: str, blob: bytes, stats: dict[str, Any], config: AssetBindingConfig) -> dict[str, Any]:
    if not config.enabled or not config.api_key or config.calls >= config.max_calls:
        return {}
    config.calls += 1
    mime = "image/png" if asset_name.lower().endswith(".png") else "image/jpeg"
    data_url = f"data:{mime};base64,{base64.b64encode(blob).decode('ascii')}"
    prompt = (
        "判断这张 PPT 模板资产是否与原模板主题强绑定。只输出 JSON，不要解释。"
        "字段：category 取 generic_decorative/background_texture/photo_context/topic_bound_icon/logo_or_brand；"
        "reusable_for_unrelated_topic 为 true/false；"
        "reason 用不超过 20 个中文字符。"
        f"启发式信息：{json.dumps(stats, ensure_ascii=False)}"
    )
    payload = {
        "model": config.model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": data_url}},
                ],
            }
        ],
        "temperature": 0,
        "max_tokens": 220,
    }
    req = urllib.request.Request(
        f"{normalize_base_url(config.base_url)}/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=config.timeout) as resp:
            result = extract_json_object(response_text(json.loads(resp.read().decode("utf-8"))))
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        return {"vision_error": str(exc)[:180]}
    category = str(result.get("category") or "").strip() or "unknown"
    reusable = bool(result.get("reusable_for_unrelated_topic"))
    return {"category": category, "reusable_for_unrelated_topic": reusable, "reason": str(result.get("reason") or "")[:60], "vision": True}


def asset_binding(asset_name: str, blob: bytes, box: dict[str, float], config: AssetBindingConfig | None) -> dict[str, Any]:
    if config and asset_name in config.cache:
        return config.cache[asset_name]
    area_ratio = (box["width"] * box["height"]) / (HTML_SLIDE_WIDTH * HTML_SLIDE_HEIGHT)
    stats = image_asset_stats(blob)
    binding = {
        "asset": asset_name,
        "area_ratio": round(area_ratio, 3),
        **stats,
        "category": "photo_context" if stats.get("kind_hint") == "photo_or_texture" else "generic_decorative",
        "reusable_for_unrelated_topic": stats.get("kind_hint") == "photo_or_texture",
        "source": "heuristic",
    }
    should_call = bool(config and config.enabled and area_ratio >= 0.08 and stats.get("vision_candidate"))
    if should_call:
        vision = classify_asset_with_vision(asset_name, blob, stats, config)
        if vision and "vision_error" not in vision:
            binding.update(vision)
            binding["source"] = "vision"
        elif vision:
            binding.update(vision)
    if binding["category"] in {"topic_bound_icon", "logo_or_brand"}:
        binding["reusable_for_unrelated_topic"] = False
    if config:
        config.cache[asset_name] = binding
    return binding


def saturation(color: str) -> float:
    r, g, b = hex_to_rgb(color)
    hi = max(r, g, b)
    lo = min(r, g, b)
    return 0.0 if hi == 0 else (hi - lo) / hi


def hue_degrees(color: str) -> float:
    r, g, b = [v / 255 for v in hex_to_rgb(color)]
    hi = max(r, g, b)
    lo = min(r, g, b)
    if hi == lo:
        return 0.0
    if hi == r:
        return (60 * ((g - b) / (hi - lo)) + 360) % 360
    if hi == g:
        return 60 * ((b - r) / (hi - lo)) + 120
    return 60 * ((r - g) / (hi - lo)) + 240


def choose_theme_colors_weighted(colors: Counter, background: str, primary_text: str) -> tuple[str, str]:
    excluded = {background.upper(), primary_text.upper(), "#FFFFFF", "#000000"}
    total = max(1, sum(colors.values()))
    candidates: list[tuple[str, float]] = []
    for color, weight in colors.items():
        color = color.upper()
        if color in excluded or color_distance(color, background) <= 18 or saturation(color) <= 0.22:
            continue
        hue = hue_degrees(color)
        red_penalty = 2.8 if (hue < 16 or hue > 345) and weight < total * 0.035 else 0.0
        orange_bonus = 1.35 if 18 <= hue <= 45 else 0.0
        blue_bonus = 0.85 if 185 <= hue <= 225 else 0.0
        score = (weight / total) * 18 + saturation(color) * 2.4 + orange_bonus + blue_bonus - red_penalty
        candidates.append((color, score))
    if not candidates:
        return choose_theme_colors([color for color, _ in colors.most_common()], background, primary_text)
    accent = sorted(candidates, key=lambda item: item[1], reverse=True)[0][0]
    secondary_candidates: list[tuple[str, float]] = []
    for color, score in candidates:
        if color == accent or color_distance(color, accent) < 70:
            continue
        hue = hue_degrees(color)
        blue_bonus = 2.4 if 185 <= hue <= 225 else 0.0
        secondary_candidates.append((color, score + color_distance(color, accent) / 95 + blue_bonus))
    secondary = sorted(secondary_candidates, key=lambda item: item[1], reverse=True)[0][0] if secondary_candidates else nearest_palette_support([c for c, _ in candidates], accent, background)
    return accent, secondary


def choose_theme_colors(palette: list[str], background: str, primary_text: str) -> tuple[str, str]:
    excluded = {background.upper(), primary_text.upper(), "#FFFFFF", "#000000"}
    usable = [c.upper() for c in palette if c.upper() not in excluded and color_distance(c, background) > 18]
    chromatic = [c for c in usable if saturation(c) > 0.25 and color_distance(c, background) > 70]
    if chromatic:
        accent = sorted(chromatic, key=lambda c: (saturation(c), color_distance(c, background)), reverse=True)[0]
        remaining = [c for c in chromatic if c != accent]
        secondary = remaining[0] if remaining else nearest_palette_support(usable, accent, background)
        return accent, secondary

    # Neutral decks, especially architecture/art PDFs, often have no true
    # chromatic accent. Preserve that restraint instead of inventing blue/purple.
    if luminance(background) >= 0.5:
        dark_neutrals = sorted(usable, key=lambda c: (luminance(c), -color_distance(c, background)))
        accent = dark_neutrals[0] if dark_neutrals else primary_text
        mid_candidates = [c for c in usable if c != accent and 0.35 <= luminance(c) <= 0.82]
        secondary = sorted(mid_candidates, key=lambda c: abs(luminance(c) - 0.62))[0] if mid_candidates else accent
        return accent, secondary

    light_neutrals = sorted(usable, key=lambda c: (-luminance(c), -color_distance(c, background)))
    accent = light_neutrals[0] if light_neutrals else primary_text
    mid_candidates = [c for c in usable if c != accent and 0.18 <= luminance(c) <= 0.72]
    secondary = sorted(mid_candidates, key=lambda c: abs(luminance(c) - 0.45))[0] if mid_candidates else accent
    return accent, secondary


def nearest_palette_support(colors: list[str], accent: str, background: str) -> str:
    candidates = [c for c in colors if c != accent]
    if not candidates:
        return accent
    return sorted(candidates, key=lambda c: color_distance(c, accent), reverse=True)[0]


def quantize_hex(hex_color: str, step: int = 24) -> str:
    raw = hex_color.lstrip("#")
    if len(raw) != 6:
        return hex_color
    vals = [int(raw[i : i + 2], 16) for i in (0, 2, 4)]
    vals = [int(round(v / step) * step) for v in vals]
    vals = [int(clamp(v, 0, 255)) for v in vals]
    return f"#{vals[0]:02X}{vals[1]:02X}{vals[2]:02X}"


def font_category(font_name: str) -> str:
    name = font_name.lower()
    if any(token in name for token in ("song", "serif", "times", "ming", "simsun", "kaiti", "kai")):
        return "serif"
    if any(token in name for token in ("mono", "consolas", "courier")):
        return "monospace"
    if any(token in name for token in ("hei", "sans", "arial", "yahei", "pingfang", "noto", "source han sans")):
        return "sans"
    return "unknown"


def rect_to_dict(rect, width: float, height: float) -> dict[str, float]:
    return {
        "x": round(rect.x0, 2),
        "y": round(rect.y0, 2),
        "w": round(max(0.0, rect.x1 - rect.x0), 2),
        "h": round(max(0.0, rect.y1 - rect.y0), 2),
        "x_pct": round(rect.x0 / width, 4) if width else 0,
        "y_pct": round(rect.y0 / height, 4) if height else 0,
        "w_pct": round(max(0.0, rect.x1 - rect.x0) / width, 4) if width else 0,
        "h_pct": round(max(0.0, rect.y1 - rect.y0) / height, 4) if height else 0,
    }


def top_pixmap_colors(page, max_colors: int = 10) -> list[dict[str, Any]]:
    fitz = require_fitz()
    pix = page.get_pixmap(matrix=fitz.Matrix(0.16, 0.16), alpha=False)
    data = pix.samples
    counts: Counter[str] = Counter()
    stride = max(1, pix.n)
    for i in range(0, len(data), stride * 5):
        if i + 2 >= len(data):
            continue
        counts[quantize_hex(f"#{data[i]:02X}{data[i + 1]:02X}{data[i + 2]:02X}")] += 1
    total = sum(counts.values()) or 1
    return [{"color": color, "ratio": round(count / total, 4)} for color, count in counts.most_common(max_colors)]


def extract_text_blocks(page, width: float, height: float) -> tuple[list[dict[str, Any]], Counter[str], Counter[str], Counter[float], Counter[str]]:
    text_dict = page.get_text("dict")
    blocks: list[dict[str, Any]] = []
    fonts: Counter[str] = Counter()
    categories: Counter[str] = Counter()
    sizes: Counter[float] = Counter()
    colors: Counter[str] = Counter()
    for block in text_dict.get("blocks", []):
        if block.get("type") != 0:
            continue
        spans: list[dict[str, Any]] = []
        parts: list[str] = []
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span.get("text", "")
                if not text.strip():
                    continue
                font = str(span.get("font") or "")
                size = round(float(span.get("size") or 0), 1)
                color = rgb_from_int(span.get("color"))
                fonts[font] += len(text)
                categories[font_category(font)] += len(text)
                sizes[size] += len(text)
                if color:
                    colors[color] += len(text)
                parts.append(text)
                spans.append({"font": font, "font_category": font_category(font), "size": size, "color": color})
        full_text = "".join(parts).strip()
        if not full_text:
            continue
        rect = require_fitz().Rect(block.get("bbox", [0, 0, 0, 0]))
        main = spans[0] if spans else {}
        blocks.append(
            {
                "text_sample": full_text[:160],
                "char_count": len(full_text),
                "bbox": rect_to_dict(rect, width, height),
                "font": main.get("font"),
                "font_category": main.get("font_category"),
                "font_size": main.get("size"),
                "color": main.get("color"),
                "span_count": len(spans),
            }
        )
    return blocks, fonts, categories, sizes, colors


def image_blocks_from_page(page, width: float, height: float) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type") != 1:
            continue
        rect = require_fitz().Rect(block.get("bbox", [0, 0, 0, 0]))
        bbox = rect_to_dict(rect, width, height)
        if bbox["w_pct"] * bbox["h_pct"] > 0.01:
            blocks.append({"bbox": bbox, "kind": "image"})
    return blocks


def extract_shapes(page, width: float, height: float) -> tuple[list[dict[str, Any]], Counter[str]]:
    shapes: list[dict[str, Any]] = []
    colors: Counter[str] = Counter()
    for drawing in page.get_drawings():
        rect = drawing.get("rect")
        if not rect:
            continue
        bbox = rect_to_dict(rect, width, height)
        area = bbox["w_pct"] * bbox["h_pct"]
        fill = normalize_color(drawing.get("fill"))
        stroke = normalize_color(drawing.get("color"))
        if fill:
            colors[fill] += 1
        if stroke:
            colors[stroke] += 1
        if area < 0.001:
            continue
        shapes.append({"bbox": bbox, "fill": fill, "stroke": stroke, "kind": drawing.get("type") or "drawing"})
    return shapes[:100], colors


def coarse_region(rect: dict[str, float]) -> str:
    cx = rect["x_pct"] + rect["w_pct"] / 2
    cy = rect["y_pct"] + rect["h_pct"] / 2
    horizontal = "left" if cx < 0.36 else "right" if cx > 0.64 else "center"
    vertical = "top" if cy < 0.28 else "bottom" if cy > 0.72 else "middle"
    return f"{vertical}_{horizontal}"


def is_table_like(text_blocks: list[dict[str, Any]]) -> bool:
    if len(text_blocks) < 8:
        return False
    xs = [round(b["bbox"]["x_pct"] / 0.08) for b in text_blocks if b["bbox"]["w_pct"] < 0.5]
    ys = [round(b["bbox"]["y_pct"] / 0.06) for b in text_blocks]
    return len(set(xs)) >= 3 and len(set(ys)) >= 3


def layout_signature(text_blocks: list[dict[str, Any]], image_blocks: list[dict[str, Any]], shapes: list[dict[str, Any]]) -> dict[str, Any]:
    all_regions = Counter(coarse_region(item["bbox"]) for item in text_blocks + image_blocks + shapes)
    text_regions = Counter(coarse_region(item["bbox"]) for item in text_blocks)
    image_regions = Counter(coarse_region(item["bbox"]) for item in image_blocks)
    total_chars = sum(int(b.get("char_count") or 0) for b in text_blocks)
    has_large_visual = any(b["bbox"]["w_pct"] * b["bbox"]["h_pct"] > 0.22 for b in image_blocks + shapes)
    has_left_text = any(b["bbox"]["x_pct"] < 0.42 and b["char_count"] > 12 for b in text_blocks)
    has_right_visual = any(b["bbox"]["x_pct"] > 0.42 and b["bbox"]["w_pct"] > 0.25 for b in image_blocks + shapes)
    compact_blocks = [b for b in text_blocks + shapes if b["bbox"]["w_pct"] < 0.3 and b["bbox"]["h_pct"] < 0.25]
    chart_like = len(shapes) >= 10 and len(text_blocks) <= 18
    flow_like = len(shapes) >= 6 and len({round(s["bbox"]["y_pct"], 1) for s in shapes}) <= 3
    table_like = is_table_like(text_blocks)
    if has_left_text and has_right_visual:
        pattern = "left_text_right_visual"
    elif has_large_visual:
        pattern = "visual_dominant"
    elif table_like:
        pattern = "table_matrix"
    elif chart_like:
        pattern = "chart_or_diagram"
    elif flow_like:
        pattern = "timeline_or_process"
    elif len(compact_blocks) >= 4:
        pattern = "card_grid"
    elif len(text_blocks) <= 3 and total_chars <= 140:
        pattern = "statement"
    elif len(text_blocks) >= 8:
        pattern = "dense_text"
    else:
        pattern = "standard_text"
    return {
        "pattern": pattern,
        "occupied_regions": [region for region, _ in all_regions.most_common()],
        "text_regions": [region for region, _ in text_regions.most_common()],
        "image_regions": [region for region, _ in image_regions.most_common()],
        "text_block_count": len(text_blocks),
        "image_block_count": len(image_blocks),
        "shape_block_count": len(shapes),
        "char_count": total_chars,
        "table_like": table_like,
        "chart_like": chart_like,
        "flow_like": flow_like,
    }


def joined_text(text_blocks: list[dict[str, Any]]) -> str:
    return " ".join(str(b.get("text_sample") or "") for b in text_blocks).lower()


def classify_role(index: int, total: int, text_blocks: list[dict[str, Any]], image_blocks: list[dict[str, Any]], layout: dict[str, Any]) -> str:
    text = joined_text(text_blocks)
    text_count = len(text_blocks)
    image_count = len(image_blocks)
    char_count = layout["char_count"]
    max_size = max((float(b.get("font_size") or 0) for b in text_blocks), default=0)
    large_title = max_size >= 24 or (text_blocks and max_size >= max(18, sum(float(b.get("font_size") or 0) for b in text_blocks) / len(text_blocks) * 1.55))
    keyword = lambda words: any(word in text for word in words)

    if index == 1 and large_title:
        return "cover"
    if index == total and (keyword(["thanks", "thank you", "谢谢", "感谢"]) or char_count <= 180):
        return "summary"
    if keyword(["目录", "agenda", "contents", "outline", "大纲"]) and text_count >= 3:
        return "agenda"
    if keyword(["timeline", "roadmap", "milestone", "里程碑", "时间线", "阶段"]) or layout["flow_like"]:
        return "timeline"
    if layout["table_like"]:
        return "table"
    if keyword(["kpi", "roi", "gmv", "maU".lower(), "数据", "指标", "%", "同比", "环比"]) and (layout["chart_like"] or text_count <= 8):
        return "data_support"
    if layout["chart_like"]:
        return "chart"
    if large_title and text_count <= 5 and char_count <= 240 and image_count <= 2:
        return "chapter_cover"
    if layout["pattern"] == "visual_dominant" or image_count >= max(1, text_count):
        return "image"
    if layout["pattern"] == "statement" or (large_title and text_count <= 3 and char_count <= 160):
        return "quote"
    if text_count >= 8 and image_count == 0:
        return "text"
    return "text"


def summarize_page(page, index: int, total: int) -> dict[str, Any]:
    width = float(page.rect.width)
    height = float(page.rect.height)
    text_blocks, fonts, font_categories, sizes, text_colors = extract_text_blocks(page, width, height)
    image_blocks = image_blocks_from_page(page, width, height)
    shapes, shape_colors = extract_shapes(page, width, height)
    palette = Counter()
    for item in top_pixmap_colors(page):
        palette[item["color"]] += int(item["ratio"] * 10000)
    palette.update(text_colors)
    palette.update(shape_colors)
    layout = layout_signature(text_blocks, image_blocks, shapes)
    role = classify_role(index, total, text_blocks, image_blocks, layout)
    return {
        "id": f"slide_{index}",
        "page_index": index,
        "page_role": role,
        "canvas": {"width": round(width, 2), "height": round(height, 2), "aspect_ratio": round(width / height, 4) if height else 1.7778},
        "layout": layout,
        "palette": [{"color": color, "weight": weight} for color, weight in palette.most_common(12)],
        "typography": {
            "font_families": [{"font": font, "weight": weight} for font, weight in fonts.most_common(8)],
            "font_categories": [{"category": cat, "weight": weight} for cat, weight in font_categories.most_common()],
            "font_sizes": [{"size": size, "weight": weight} for size, weight in sizes.most_common(10)],
            "text_colors": [{"color": color, "weight": weight} for color, weight in text_colors.most_common(8)],
        },
        "text_blocks": sorted(text_blocks, key=lambda b: (b["bbox"]["y"], b["bbox"]["x"]))[:40],
        "image_blocks": image_blocks[:30],
        "shape_blocks": shapes[:50],
    }


def emu_rect_to_dict(left: int, top: int, width: int, height: int, canvas_w: int, canvas_h: int) -> dict[str, float]:
    return {
        "x": round(float(left), 2),
        "y": round(float(top), 2),
        "w": round(float(max(0, width)), 2),
        "h": round(float(max(0, height)), 2),
        "x_pct": round(left / canvas_w, 4) if canvas_w else 0,
        "y_pct": round(top / canvas_h, 4) if canvas_h else 0,
        "w_pct": round(max(0, width) / canvas_w, 4) if canvas_w else 0,
        "h_pct": round(max(0, height) / canvas_h, 4) if canvas_h else 0,
    }


def pptx_rgb(value: Any) -> str | None:
    if value is None:
        return None
    try:
        return f"#{value[0]:02X}{value[1]:02X}{value[2]:02X}"
    except Exception:
        return None


def pptx_color_from_format(color_format: Any) -> str | None:
    try:
        if color_format is None:
            return None
        if getattr(color_format, "rgb", None) is not None:
            return pptx_rgb(color_format.rgb)
    except Exception:
        return None
    return None


def pptx_shape_fill(shape: Any) -> str | None:
    try:
        fill = shape.fill
        if fill is None:
            return None
        return pptx_color_from_format(fill.fore_color)
    except Exception:
        return None


def pptx_shape_line(shape: Any) -> str | None:
    try:
        line = shape.line
        if line is None:
            return None
        return pptx_color_from_format(line.color)
    except Exception:
        return None


def pptx_slide_background(slide: Any) -> str | None:
    try:
        return pptx_color_from_format(slide.background.fill.fore_color)
    except Exception:
        return None


def iter_pptx_shapes(shapes: Any):
    for shape in shapes:
        yield shape
        try:
            if getattr(shape, "shapes", None):
                yield from iter_pptx_shapes(shape.shapes)
        except Exception:
            continue


def extract_pptx_text_blocks(slide: Any, canvas_w: int, canvas_h: int) -> tuple[list[dict[str, Any]], Counter[str], Counter[str], Counter[float], Counter[str]]:
    blocks: list[dict[str, Any]] = []
    fonts: Counter[str] = Counter()
    categories: Counter[str] = Counter()
    sizes: Counter[float] = Counter()
    colors: Counter[str] = Counter()
    for shape in iter_pptx_shapes(slide.shapes):
        if not getattr(shape, "has_text_frame", False):
            continue
        text = (getattr(shape, "text", "") or "").strip()
        if not text:
            continue
        span_count = 0
        main_font = None
        main_size = None
        main_color = None
        for paragraph in shape.text_frame.paragraphs:
            for run in paragraph.runs:
                run_text = run.text or ""
                if not run_text.strip():
                    continue
                span_count += 1
                font_name = run.font.name or ""
                font_size = round(run.font.size.pt, 1) if run.font.size else None
                color = pptx_color_from_format(run.font.color)
                if font_name:
                    fonts[font_name] += len(run_text)
                    categories[font_category(font_name)] += len(run_text)
                if font_size:
                    sizes[font_size] += len(run_text)
                if color:
                    colors[color] += len(run_text)
                main_font = main_font or font_name
                main_size = main_size or font_size
                main_color = main_color or color
        if not main_font:
            try:
                main_font = shape.text_frame.paragraphs[0].font.name
            except Exception:
                main_font = ""
        if not main_size:
            try:
                font_size = shape.text_frame.paragraphs[0].font.size
                main_size = round(font_size.pt, 1) if font_size else None
            except Exception:
                main_size = None
        bbox = emu_rect_to_dict(int(shape.left), int(shape.top), int(shape.width), int(shape.height), canvas_w, canvas_h)
        blocks.append(
            {
                "text_sample": text[:160],
                "char_count": len(text),
                "bbox": bbox,
                "font": main_font,
                "font_category": font_category(main_font or ""),
                "font_size": main_size,
                "color": main_color,
                "span_count": span_count,
            }
        )
    return blocks, fonts, categories, sizes, colors


def extract_pptx_visual_blocks(slide: Any, canvas_w: int, canvas_h: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]], Counter[str]]:
    try:
        from pptx.enum.shapes import MSO_SHAPE_TYPE
    except ImportError as exc:
        raise RuntimeError("PPTX input requires python-pptx. Install it with: python -m pip install python-pptx") from exc

    image_blocks: list[dict[str, Any]] = []
    shape_blocks: list[dict[str, Any]] = []
    colors: Counter[str] = Counter()
    for shape in iter_pptx_shapes(slide.shapes):
        bbox = emu_rect_to_dict(int(shape.left), int(shape.top), int(shape.width), int(shape.height), canvas_w, canvas_h)
        if bbox["w_pct"] * bbox["h_pct"] < 0.001:
            continue
        fill = pptx_shape_fill(shape)
        stroke = pptx_shape_line(shape)
        if fill:
            colors[fill] += 1
        if stroke:
            colors[stroke] += 1
        if getattr(shape, "shape_type", None) == MSO_SHAPE_TYPE.PICTURE:
            for color, weight in pptx_picture_palette(shape, bbox).items():
                colors[color] += weight
            image_blocks.append({"bbox": bbox, "kind": "image"})
            continue
        if getattr(shape, "has_text_frame", False) and (getattr(shape, "text", "") or "").strip():
            continue
        shape_blocks.append({"bbox": bbox, "fill": fill, "stroke": stroke, "kind": str(getattr(shape, "shape_type", "shape"))})
    return image_blocks[:30], shape_blocks[:100], colors


def pptx_picture_palette(shape: Any, bbox: dict[str, float]) -> Counter[str]:
    colors: Counter[str] = Counter()
    try:
        from PIL import Image
        image = Image.open(io.BytesIO(shape.image.blob)).convert("RGB")
    except Exception:
        return colors
    image.thumbnail((96, 96))
    pixels = list(image.getdata())
    if not pixels:
        return colors
    sample_step = max(1, len(pixels) // 5000)
    counts: Counter[str] = Counter()
    for r, g, b in pixels[::sample_step]:
        counts[quantize_hex(f"#{r:02X}{g:02X}{b:02X}")] += 1
    area_weight = max(1, int(bbox["w_pct"] * bbox["h_pct"] * 12000))
    total = sum(counts.values()) or 1
    for color, count in counts.most_common(8):
        colors[color] += max(1, int(count / total * area_weight))
    return colors


def summarize_pptx_slide(slide: Any, index: int, total: int, canvas_w: int, canvas_h: int) -> dict[str, Any]:
    text_blocks, fonts, font_categories, sizes, text_colors = extract_pptx_text_blocks(slide, canvas_w, canvas_h)
    image_blocks, shapes, shape_colors = extract_pptx_visual_blocks(slide, canvas_w, canvas_h)
    palette = Counter()
    bg = pptx_slide_background(slide)
    if bg:
        palette[bg] += 10000
    palette.update(text_colors)
    palette.update(shape_colors)
    layout = layout_signature(text_blocks, image_blocks, shapes)
    role = classify_role(index, total, text_blocks, image_blocks, layout)
    return {
        "id": f"slide_{index}",
        "page_index": index,
        "page_role": role,
        "canvas": {"width": canvas_w, "height": canvas_h, "aspect_ratio": round(canvas_w / canvas_h, 4) if canvas_h else 1.7778},
        "layout": layout,
        "palette": [{"color": color, "weight": weight} for color, weight in palette.most_common(12)],
        "typography": {
            "font_families": [{"font": font, "weight": weight} for font, weight in fonts.most_common(8)],
            "font_categories": [{"category": cat, "weight": weight} for cat, weight in font_categories.most_common()],
            "font_sizes": [{"size": size, "weight": weight} for size, weight in sizes.most_common(10)],
            "text_colors": [{"color": color, "weight": weight} for color, weight in text_colors.most_common(8)],
        },
        "text_blocks": sorted(text_blocks, key=lambda b: (b["bbox"]["y"], b["bbox"]["x"]))[:40],
        "image_blocks": image_blocks[:30],
        "shape_blocks": shapes[:50],
    }


def analyze_pdf(source: Path) -> list[dict[str, Any]]:
    fitz = require_fitz()
    doc = fitz.open(source)
    try:
        return [summarize_page(page, index, len(doc)) for index, page in enumerate(doc, 1)]
    finally:
        doc.close()


def analyze_pptx(source: Path) -> list[dict[str, Any]]:
    try:
        from pptx import Presentation
    except ImportError as exc:
        raise RuntimeError("PPTX input requires python-pptx. Install it with: python -m pip install python-pptx") from exc
    prs = Presentation(str(source))
    canvas_w = int(prs.slide_width)
    canvas_h = int(prs.slide_height)
    return [summarize_pptx_slide(slide, index, len(prs.slides), canvas_w, canvas_h) for index, slide in enumerate(prs.slides, 1)]


def analyze_source(source: Path) -> tuple[list[dict[str, Any]], str]:
    suffix = source.suffix.lower()
    if suffix == ".pdf":
        return analyze_pdf(source), "pdf"
    if suffix in {".pptx", ".ppt"}:
        return analyze_pptx(source), "pptx-direct"
    raise ValueError("Input must be a PDF, PPTX, or PPT file.")


def aggregate_theme(slides: list[dict[str, Any]]) -> dict[str, Any]:
    colors = Counter()
    bg_colors = Counter()
    text_colors = Counter()
    fonts = Counter()
    categories = Counter()
    sizes = Counter()
    patterns = Counter()
    role_counts = Counter(slide["page_role"] for slide in slides)
    for slide in slides:
        patterns[slide["layout"]["pattern"]] += 1
        if slide["palette"]:
            bg_colors[slide["palette"][0]["color"]] += slide["palette"][0]["weight"]
        for item in slide["palette"]:
            colors[item["color"]] += item["weight"]
        for item in slide["typography"]["text_colors"]:
            text_colors[item["color"]] += item["weight"]
        for item in slide["typography"]["font_families"]:
            fonts[item["font"]] += item["weight"]
        for item in slide["typography"]["font_categories"]:
            categories[item["category"]] += item["weight"]
        for item in slide["typography"]["font_sizes"]:
            sizes[str(item["size"])] += item["weight"]

    background = (bg_colors.most_common(1)[0][0] if bg_colors else "#FFFFFF").upper()
    primary_text = (text_colors.most_common(1)[0][0] if text_colors else contrast_text(background)).upper()
    palette = [color.upper() for color, _ in colors.most_common(10)]
    accent, secondary = choose_theme_colors_weighted(colors, background, primary_text)
    size_values = [float(size) for size, _ in sizes.most_common(8)]
    base_size = round(sorted(size_values)[len(size_values) // 2], 1) if size_values else 28
    title_size = round(max(size_values), 1) if size_values else 64
    density_score = sum(slide["layout"]["text_block_count"] + slide["layout"]["shape_block_count"] * 0.35 for slide in slides) / max(1, len(slides))
    if density_score >= 16:
        density = "dense"
    elif density_score >= 8:
        density = "medium"
    else:
        density = "low"
    dna = infer_template_dna(slides)
    if dna["background_image_ratio"] >= 0.65 and density == "dense":
        density = "medium"
    visual_pages = sum(1 for slide in slides if slide["layout"]["image_block_count"] > 0 or slide["layout"]["pattern"] == "visual_dominant")
    data_pages = sum(1 for slide in slides if slide["page_role"] in {"chart", "table", "data_support"})
    if dna["background_image_ratio"] >= 0.65 and dna["title_band_confidence"] >= 0.55:
        style_focus = "visual-story"
    elif data_pages >= max(2, len(slides) * 0.28):
        style_focus = "data-first"
    elif visual_pages >= max(2, len(slides) * 0.35):
        style_focus = "visual-first"
    else:
        style_focus = "content-first"
    font_family = fonts.most_common(1)[0][0] if fonts else "Arial"
    font_category = categories.most_common(1)[0][0] if categories else "sans"
    template_family = determine_template_family(accent, secondary, background, font_family, density, role_counts, dna)
    return {
        "background": background,
        "text": primary_text,
        "muted_text": "#B8BCC8" if luminance(background) < 0.48 else "#5F6673",
        "surface": "#111827" if luminance(background) < 0.48 else "#FFFFFF",
        "surface_alt": "#1F2937" if luminance(background) < 0.48 else "#F3F5F8",
        "accent": accent.upper(),
        "secondary": secondary.upper(),
        "palette": palette,
        "font_family": font_family,
        "font_category": font_category,
        "base_font_size": base_size,
        "title_font_size": max(title_size, base_size * 1.8),
        "content_density": density,
        "style_focus": style_focus,
        "template_family": template_family,
        "template_dna": dna,
        "dominant_patterns": [{"pattern": p, "count": c} for p, c in patterns.most_common(6)],
        "role_counts": [{"role": r, "count": c} for r, c in role_counts.most_common()],
    }


def median(values: list[float], default: float) -> float:
    if not values:
        return default
    ordered = sorted(values)
    return ordered[len(ordered) // 2]


def percentile(values: list[float], pct: float, default: float) -> float:
    if not values:
        return default
    ordered = sorted(values)
    index = int(clamp(round((len(ordered) - 1) * pct), 0, len(ordered) - 1))
    return ordered[index]


def infer_template_dna(slides: list[dict[str, Any]]) -> dict[str, Any]:
    """Infer the generator-like master rhythm behind a template deck."""
    title_boxes: list[dict[str, float]] = []
    left_boxes: list[dict[str, float]] = []
    right_boxes: list[dict[str, float]] = []
    center_boxes: list[dict[str, float]] = []
    quote_boxes: list[dict[str, float]] = []
    full_bg_images = 0
    content_slide_count = 0
    for slide in slides:
        images = slide.get("image_blocks") or []
        if any(
            img.get("bbox", {}).get("x_pct", 1) <= 0.02
            and img.get("bbox", {}).get("y_pct", 1) <= 0.02
            and img.get("bbox", {}).get("w_pct", 0) >= 0.92
            and img.get("bbox", {}).get("h_pct", 0) >= 0.92
            for img in images
        ):
            full_bg_images += 1
        texts = [t for t in slide.get("text_blocks", []) if t.get("char_count", 0) > 0]
        if not texts:
            continue
        content_slide_count += 1
        title = max(texts, key=lambda t: (float(t.get("font_size") or 0), t["bbox"].get("w_pct", 0)))
        if title["bbox"].get("y_pct", 1) <= 0.18:
            title_boxes.append(title["bbox"])
        for item in texts:
            box = item["bbox"]
            y = float(box.get("y_pct", 0))
            x = float(box.get("x_pct", 0))
            w = float(box.get("w_pct", 0))
            if y < 0.20:
                continue
            if x < 0.18 and w <= 0.52:
                left_boxes.append(box)
            elif x >= 0.48:
                right_boxes.append(box)
            elif 0.18 <= x < 0.48:
                center_boxes.append(box)
            if y >= 0.74 and w >= 0.45:
                quote_boxes.append(box)

    title_x = median([b.get("x_pct", 0.0625) for b in title_boxes], 0.0625)
    title_y = median([b.get("y_pct", 0.0833) for b in title_boxes], 0.0833)
    title_w = median([b.get("w_pct", 0.875) for b in title_boxes], 0.875)
    left_x = median([b.get("x_pct", 0.0625) for b in left_boxes], 0.0625)
    left_w = median([b.get("w_pct", 0.43) for b in left_boxes], 0.43)
    right_x = median([b.get("x_pct", 0.52) for b in right_boxes], 0.52)
    right_w = median([b.get("w_pct", 0.38) for b in right_boxes], 0.38)
    content_y = percentile([b.get("y_pct", 0.25) for b in left_boxes + right_boxes + center_boxes], 0.18, 0.25)
    quote_y = median([b.get("y_pct", 0.78) for b in quote_boxes], 0.78)
    has_two_col = bool(left_boxes and right_boxes)
    return {
        "master_pattern": "title_band_two_column_story" if has_two_col else "title_band_single_flow",
        "background_image_ratio": round(full_bg_images / max(1, len(slides)), 3),
        "title_band_confidence": round(len(title_boxes) / max(1, content_slide_count), 3),
        "title_band": {
            "x_pct": round(title_x, 4),
            "y_pct": round(title_y, 4),
            "w_pct": round(title_w, 4),
        },
        "content_start_y_pct": round(content_y, 4),
        "left_column": {"x_pct": round(left_x, 4), "w_pct": round(left_w, 4)},
        "right_column": {"x_pct": round(right_x, 4), "w_pct": round(right_w, 4)},
        "quote_band_y_pct": round(quote_y, 4),
        "layout_rules": [
            "Use a stable top title band across content pages.",
            "Prefer paired content regions instead of unrelated decorative blocks.",
            "Keep the right side as a content region, visual placeholder, table, or evidence panel depending on role.",
            "Reserve bottom-wide centered text for closing claims or quote pages.",
        ],
    }


def determine_template_family(
    accent: str,
    secondary: str,
    background: str,
    font_family: str,
    density: str,
    role_counts: Counter,
    dna: dict[str, Any],
) -> str:
    accent_hue = hue_degrees(accent)
    secondary_hue = hue_degrees(secondary)
    cool_accent = 185 <= accent_hue <= 250 or 185 <= secondary_hue <= 250
    light_neutral_bg = luminance(background) > 0.78 and color_distance(background, "#FFFFFF") < 80
    light_font = "light" in font_family.lower()
    table_heavy = role_counts.get("table", 0) >= 3
    weak_title_band = dna.get("title_band_confidence", 1) < 0.35
    if cool_accent and light_neutral_bg and (light_font or table_heavy or weak_title_band):
        return "architectural_minimal"
    if "serif" in font_family.lower():
        return "editorial"
    if density == "dense" or table_heavy:
        return "analytical"
    return "visual_story"


def role_examples(slides: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for slide in slides:
        grouped[slide["page_role"]].append(slide)
    examples: dict[str, dict[str, Any]] = {}
    for role in PAGE_ROLES:
        if grouped.get(role):
            examples[role] = grouped[role][0]
        else:
            examples[role] = synthesize_role_example(role, slides)
            examples[role]["synthetic"] = True
    return examples


def synthesize_role_example(role: str, slides: list[dict[str, Any]]) -> dict[str, Any]:
    base = slides[0] if slides else {}
    canvas = base.get("canvas") or {"width": HTML_SLIDE_WIDTH, "height": HTML_SLIDE_HEIGHT, "aspect_ratio": 1.7778}
    return {
        "id": f"synthetic_{role}",
        "page_index": None,
        "page_role": role,
        "canvas": canvas,
        "layout": {"pattern": default_pattern_for_role(role), "occupied_regions": ["top_left", "middle_center"], "text_block_count": 0, "image_block_count": 0, "shape_block_count": 0},
        "palette": base.get("palette", []),
        "typography": base.get("typography", {}),
        "text_blocks": [],
        "image_blocks": [],
        "shape_blocks": [],
    }


def default_pattern_for_role(role: str) -> str:
    return {
        "cover": "hero_title",
        "agenda": "numbered_list",
        "chapter_cover": "section_divider",
        "text": "standard_text",
        "image": "left_text_right_visual",
        "quote": "statement",
        "chart": "chart_or_diagram",
        "table": "table_matrix",
        "summary": "card_grid",
        "timeline": "timeline_or_process",
        "data_support": "metric_cards",
    }[role]


def css_from_theme(theme: dict[str, Any]) -> str:
    density = theme["content_density"]
    gap = {"low": "36px", "medium": "28px", "dense": "20px"}[density]
    pad = {"low": "84px", "medium": "72px", "dense": "56px"}[density]
    body = max(24, float(theme["base_font_size"]) * 1.25)
    title = max(54, float(theme["title_font_size"]) * 1.55)
    return f"""/* Shared CSS extracted from source deck. */
:root {{
  --slide-width: {HTML_SLIDE_WIDTH}px;
  --slide-height: {HTML_SLIDE_HEIGHT}px;
  --bg: {theme['background']};
  --text: {theme['text']};
  --muted: {theme['muted_text']};
  --surface: {theme['surface']};
  --surface-alt: {theme['surface_alt']};
  --accent: {theme['accent']};
  --secondary: {theme['secondary']};
  --font-main: "{css_escape(str(theme['font_family']))}", "Microsoft YaHei", Arial, sans-serif;
  --title-size: {title:.0f}px;
  --subtitle-size: {max(30, body * 1.15):.0f}px;
  --body-size: {body:.0f}px;
  --caption-size: {max(18, body * 0.7):.0f}px;
  --page-padding: {pad};
  --gap: {gap};
  --radius: 8px;
}}

* {{ box-sizing: border-box; }}
html, body {{ margin: 0; width: 100%; min-height: 100%; background: #222; }}
body {{ font-family: var(--font-main); color: var(--text); }}
.slide {{
  position: relative;
  width: var(--slide-width);
  height: var(--slide-height);
  overflow: hidden;
  background: var(--bg);
  color: var(--text);
  padding: var(--page-padding);
}}
.slide::before {{
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
  background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 18%, transparent), transparent 42%);
  opacity: 0.35;
}}
.slide > * {{ position: relative; z-index: 1; }}
.source-slide {{ padding: 0; }}
.source-slide::before {{ display: none; }}
.source-slide.architectural_minimal::after {{ display: none; }}
.pptx-picture {{ position: absolute; z-index: 0; display: block; }}
.pptx-shape {{ position: absolute; z-index: 1; }}
.pptx-text {{ position: absolute; z-index: 2; overflow: hidden; white-space: pre-wrap; word-break: break-word; }}
.pptx-text ul {{ margin: 0; padding-left: 1.1em; }}
.pptx-text li {{ margin: 0 0 0.32em; }}
.pptx-picture-placeholder {{ position: absolute; z-index: 1; display: grid; place-items: center; color: color-mix(in srgb, var(--accent) 70%, var(--text)); background: color-mix(in srgb, var(--accent) 8%, var(--bg)); border: 1px solid color-mix(in srgb, var(--accent) 30%, transparent); font-size: 18px; font-weight: 400; }}
.pptx-picture-placeholder::after {{ content: "IMAGE"; }}
.redesign-bg {{ position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; z-index: 0; }}
.redesign-wash {{ position: absolute; inset: 0; z-index: 1; background: linear-gradient(90deg, color-mix(in srgb, var(--bg) 94%, white) 0%, color-mix(in srgb, var(--bg) 86%, white) 48%, color-mix(in srgb, var(--bg) 26%, transparent) 100%); }}
.redesign-mark {{ position: absolute; right: 90px; top: 72px; z-index: 3; color: var(--secondary); font: 700 32px/1 var(--font-main); }}
.redesign-panel {{ position: absolute; z-index: 3; left: 90px; top: 148px; width: 780px; }}
.redesign-index {{ color: var(--accent); font-size: 54px; line-height: 1; font-weight: 800; margin-bottom: 34px; }}
.redesign-title {{ color: var(--text); font-size: 54px; line-height: 1.16; font-weight: 800; margin: 0 0 28px; }}
.redesign-summary {{ color: var(--secondary); font-size: 30px; line-height: 1.3; font-weight: 700; margin: 0 0 28px; }}
.redesign-body {{ color: var(--muted); font-size: 26px; line-height: 1.42; max-width: 720px; }}
.redesign-body ul {{ margin: 0; padding-left: 1.1em; }}
.redesign-list {{ margin: 44px 0 0; padding: 0; list-style: none; display: grid; gap: 22px; }}
.redesign-list li {{ color: var(--text); font-size: 26px; line-height: 1.28; border-left: 4px solid var(--accent); padding-left: 20px; }}
.agenda-grid {{ position: absolute; z-index: 3; left: 90px; right: 90px; bottom: 106px; display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 30px; }}
.agenda-card {{ min-height: 292px; border-top: 7px solid var(--accent); background: color-mix(in srgb, var(--bg) 70%, white); padding: 34px 30px; display: grid; align-content: start; }}
.agenda-num {{ color: var(--accent); font-size: 50px; font-weight: 800; line-height: 1; margin-bottom: 42px; }}
.agenda-text {{ color: var(--text); font-size: 29px; line-height: 1.32; }}
.full-panel {{ position: absolute; z-index: 3; left: 90px; right: 90px; top: 145px; }}
.full-title {{ color: var(--text); font-size: 56px; line-height: 1.14; font-weight: 800; margin: 0 0 24px; max-width: 1180px; }}
.full-subtitle {{ color: var(--secondary); font-size: 30px; line-height: 1.3; font-weight: 700; margin: 0; max-width: 980px; }}
.text-block-grid {{ position: absolute; z-index: 3; left: 90px; right: 90px; bottom: 112px; display: grid; grid-template-columns: 1.28fr .86fr .86fr; gap: 30px; align-items: stretch; }}
.text-feature {{ border-top: 6px solid var(--accent); background: color-mix(in srgb, var(--bg) 70%, white); padding: 34px; font-size: 26px; line-height: 1.42; color: var(--text); min-height: 292px; }}
.text-feature:first-child {{ font-size: 31px; line-height: 1.35; font-weight: 700; }}
.text-feature ul {{ margin: 0; padding-left: 1.1em; }}
.redesign-visual {{ position: absolute; z-index: 2; right: 90px; top: 190px; width: 720px; height: 620px; object-fit: cover; border-radius: 8px; }}
.redesign-visual.wide {{ right: 90px; top: 170px; width: 680px; height: 720px; }}
.redesign-visual.small-stack-top {{ top: 170px; height: 330px; }}
.redesign-visual.small-stack-bottom {{ top: 540px; height: 330px; }}
.redesign-visual-blank {{ position: absolute; z-index: 2; right: 90px; top: 170px; width: 680px; height: 720px; border-radius: 8px; background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 16%, white), color-mix(in srgb, var(--bg) 84%, white)); border: 1px solid color-mix(in srgb, var(--accent) 24%, transparent); }}
.redesign-visual-blank::after {{ content: ""; position: absolute; left: 64px; right: 64px; bottom: 86px; height: 4px; background: var(--accent); opacity: .62; }}
.image-placeholder {{ position: absolute; z-index: 3; right: 90px; top: 210px; width: 720px; height: 580px; border: 2px dashed color-mix(in srgb, var(--secondary) 55%, transparent); background: color-mix(in srgb, var(--secondary) 10%, var(--bg)); display: grid; place-items: center; color: var(--secondary); font-size: 32px; font-weight: 800; }}
.image-placeholder::after {{ content: "IMAGE"; letter-spacing: 0; }}
.kpi-grid {{ position: absolute; z-index: 3; left: 90px; bottom: 116px; width: 890px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 24px; }}
.kpi-card {{ min-height: 144px; border-top: 5px solid var(--accent); background: color-mix(in srgb, var(--bg) 72%, white); padding: 26px 28px; }}
.kpi-value {{ color: var(--accent); font-size: 44px; line-height: 1; font-weight: 800; margin-bottom: 14px; }}
.kpi-label {{ color: var(--text); font-size: 22px; line-height: 1.28; }}
.redesign-table {{ position: absolute; z-index: 3; left: 90px; top: 438px; width: 980px; border-collapse: collapse; font-size: 22px; }}
.redesign-table th {{ color: var(--accent); font-size: 22px; font-weight: 800; border-bottom: 4px solid var(--accent); padding: 18px 16px; }}
.redesign-table td {{ color: var(--text); border-bottom: 1px solid color-mix(in srgb, var(--muted) 28%, transparent); padding: 18px 16px; line-height: 1.3; }}
.timeline-board {{ position: absolute; z-index: 3; left: 90px; right: 90px; bottom: 110px; height: 390px; }}
.timeline-board::before {{ content: ""; position: absolute; left: 64px; right: 64px; top: 190px; height: 5px; background: color-mix(in srgb, var(--accent) 72%, transparent); }}
.timeline-item {{ position: absolute; width: 360px; min-height: 168px; background: color-mix(in srgb, var(--bg) 72%, white); border: 1px solid color-mix(in srgb, var(--secondary) 22%, transparent); border-top: 6px solid var(--accent); padding: 28px 28px 24px; color: var(--text); font-size: 27px; line-height: 1.28; }}
.timeline-item::before {{ content: attr(data-step); display: block; color: var(--accent); font-size: 42px; line-height: 1; font-weight: 800; margin-bottom: 20px; }}
.timeline-item::after {{ content: ""; position: absolute; width: 22px; height: 22px; border-radius: 50%; background: var(--accent); left: 28px; }}
.timeline-item:nth-child(1) {{ left: 0; top: 0; }}
.timeline-item:nth-child(2) {{ left: 430px; top: 118px; }}
.timeline-item:nth-child(3) {{ left: 860px; top: 0; }}
.timeline-item:nth-child(4) {{ right: 0; top: 118px; }}
.timeline-item:nth-child(1)::after, .timeline-item:nth-child(3)::after {{ bottom: -51px; }}
.timeline-item:nth-child(2)::after, .timeline-item:nth-child(4)::after {{ top: -51px; }}
.quote-center {{ position: absolute; z-index: 3; inset: 0; display: grid; place-items: center; padding: 120px 220px; text-align: center; }}
.quote-text {{ color: var(--text); font-size: 62px; line-height: 1.18; font-weight: 800; max-width: 1220px; margin: 28px auto; }}
.quote-caption {{ color: var(--muted); font-size: 25px; line-height: 1.42; max-width: 980px; margin: 0 auto; }}
.chart-dashboard {{ position: absolute; z-index: 3; left: 90px; right: 90px; bottom: 104px; height: 430px; display: grid; grid-template-columns: 1.36fr .64fr; gap: 34px; }}
.chart-canvas {{ background: color-mix(in srgb, var(--bg) 72%, white); border: 1px solid color-mix(in srgb, var(--accent) 22%, transparent); padding: 34px 38px; display: grid; align-content: center; gap: 34px; }}
.chart-line {{ display: grid; grid-template-columns: 180px 1fr 170px; gap: 22px; align-items: center; color: var(--text); font-size: 24px; }}
.chart-line-label {{ font-weight: 800; color: var(--accent); font-size: 30px; }}
.chart-bar {{ height: 20px; background: color-mix(in srgb, var(--accent) 18%, transparent); position: relative; }}
.chart-bar::after {{ content: ""; position: absolute; left: 0; top: 0; bottom: 0; background: var(--accent); }}
.chart-line:nth-child(1) .chart-bar::after {{ width: 82%; }}
.chart-line:nth-child(2) .chart-bar::after {{ width: 64%; }}
.chart-line:nth-child(3) .chart-bar::after {{ width: 48%; }}
.chart-note {{ color: var(--muted); line-height: 1.3; }}
.chart-side {{ display: grid; gap: 22px; align-content: stretch; }}
.chart-card {{ border-top: 5px solid var(--secondary); background: color-mix(in srgb, var(--bg) 72%, white); padding: 28px; min-height: 126px; }}
.chart-card .kpi-value {{ font-size: 36px; }}
.chart-card.emphasis {{ display: grid; align-content: center; min-height: 100%; }}
.summary-grid {{ position: absolute; z-index: 3; left: 90px; right: 90px; bottom: 116px; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 28px; }}
.summary-card {{ min-height: 270px; border-top: 6px solid var(--accent); background: color-mix(in srgb, var(--bg) 72%, white); padding: 34px; color: var(--text); font-size: 28px; line-height: 1.36; }}
.chapter-hero {{ position: absolute; z-index: 3; inset: 0; padding: 135px 120px; display: grid; grid-template-columns: 520px 1fr; gap: 72px; align-items: center; }}
.chapter-number {{ color: var(--accent); font-size: 220px; line-height: .86; font-weight: 800; letter-spacing: 0; }}
.chapter-rule {{ width: 260px; height: 8px; background: var(--secondary); margin-top: 44px; }}
.chapter-copy h1 {{ color: var(--text); font-size: 64px; line-height: 1.12; margin: 0 0 32px; font-weight: 800; }}
.chapter-copy .redesign-summary {{ font-size: 34px; }}
.chapter-copy .redesign-body {{ max-width: 820px; font-size: 27px; }}
.data-viz {{ position: absolute; z-index: 2; right: 90px; top: 286px; width: 650px; height: 500px; background: color-mix(in srgb, var(--secondary) 10%, var(--bg)); border: 1px solid color-mix(in srgb, var(--secondary) 28%, transparent); padding: 52px; display: grid; align-content: center; gap: 30px; }}
.data-viz-line {{ height: 18px; background: color-mix(in srgb, var(--secondary) 18%, transparent); position: relative; }}
.data-viz-line::after {{ content: ""; position: absolute; left: 0; top: 0; bottom: 0; background: var(--secondary); }}
.data-viz-line:nth-child(1)::after {{ width: 74%; }}
.data-viz-line:nth-child(2)::after {{ width: 56%; }}
.data-viz-line:nth-child(3)::after {{ width: 86%; }}
.data-viz-line:nth-child(4)::after {{ width: 42%; }}
.master-title {{ position: absolute; z-index: 3; left: 120px; top: 82px; right: 120px; }}
.master-title h1 {{ margin: 0; color: var(--text); font-size: 56px; line-height: 1.1; font-weight: 800; }}
.master-title .lead {{ margin: 24px 0 0; max-width: 1520px; color: var(--text); font-size: 28px; line-height: 1.36; }}
.master-kicker {{ color: var(--accent); font-size: 26px; font-weight: 800; margin-bottom: 14px; }}
.master-section {{ position: absolute; z-index: 3; left: 120px; top: 250px; width: 820px; }}
.master-section.wide {{ right: 120px; width: auto; }}
.master-section.right {{ left: auto; right: 120px; }}
.master-eyebrow {{ color: var(--accent); font-size: 28px; line-height: 1.2; font-weight: 800; margin-bottom: 18px; }}
.master-heading {{ color: var(--text); font-size: 34px; line-height: 1.22; font-weight: 800; margin: 0 0 24px; }}
.master-copy {{ color: var(--text); font-size: 23px; line-height: 1.42; }}
.master-copy ul {{ margin: 0; padding-left: 1.08em; }}
.master-copy li {{ margin: 0 0 14px; }}
.master-grid-2 {{ position: absolute; z-index: 3; left: 120px; right: 120px; top: 360px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 46px 86px; }}
.master-grid-4 {{ position: absolute; z-index: 3; left: 120px; right: 120px; top: 372px; display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 34px; }}
.master-card {{ min-height: 210px; padding: 30px 34px 30px 44px; border-left: 8px solid var(--accent); background: color-mix(in srgb, var(--bg) 54%, white); color: var(--text); font-size: 27px; line-height: 1.36; font-weight: 600; box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--secondary) 12%, transparent); }}
.master-card h3 {{ margin: 0 0 18px; color: var(--text); font-size: 36px; line-height: 1.18; font-weight: 800; }}
.master-card.compact {{ min-height: 128px; padding-left: 34px; }}
.master-card.compact h3 {{ font-size: 26px; }}
.master-number {{ display: inline-grid; place-items: center; width: 42px; height: 42px; margin-right: 18px; color: #fff; background: var(--accent); border-radius: 50%; font-size: 24px; font-weight: 800; vertical-align: middle; }}
.master-visual {{ position: absolute; z-index: 3; right: 136px; top: 275px; width: 690px; height: 610px; background: color-mix(in srgb, var(--secondary) 28%, var(--bg)); border: 3px solid color-mix(in srgb, var(--secondary) 62%, transparent); display: grid; place-items: center; color: color-mix(in srgb, var(--secondary) 70%, var(--text)); font-size: 36px; font-weight: 800; box-shadow: inset 0 0 0 18px color-mix(in srgb, white 20%, transparent); }}
.master-visual::after {{ content: "IMAGE"; }}
.master-table-wrap {{ position: absolute; z-index: 3; left: 120px; right: 120px; top: 382px; }}
.master-table {{ width: 100%; border-collapse: collapse; color: var(--text); font-size: 25px; font-weight: 600; }}
.master-table th {{ color: var(--text); background: color-mix(in srgb, var(--accent) 20%, var(--bg)); border-bottom: 3px solid var(--accent); padding: 20px 22px; }}
.master-table td {{ padding: 20px 22px; border-bottom: 1px solid color-mix(in srgb, var(--muted) 24%, transparent); line-height: 1.32; }}
.master-callout {{ position: absolute; z-index: 3; left: 240px; right: 240px; bottom: 116px; text-align: center; color: var(--text); font-size: 36px; line-height: 1.28; font-weight: 800; }}
.master-timeline {{ position: absolute; z-index: 3; left: 120px; right: 120px; top: 370px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 30px; }}
.master-step {{ min-height: 330px; border-top: 8px solid var(--accent); padding: 30px 26px 28px; background: color-mix(in srgb, var(--bg) 54%, white); color: var(--text); font-size: 26px; line-height: 1.36; font-weight: 600; box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--secondary) 12%, transparent); }}
.master-step strong {{ display: block; color: var(--accent); font-size: 44px; line-height: 1; margin-bottom: 24px; }}
.master-step b {{ display: block; color: var(--text); font-size: 30px; line-height: 1.2; margin-bottom: 18px; }}
.master-dashboard {{ position: absolute; z-index: 3; left: 120px; right: 120px; top: 350px; display: grid; grid-template-columns: .92fr 1.08fr; gap: 70px; align-items: start; }}
.master-metrics {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 26px; }}
.master-metric {{ min-height: 156px; border-left: 7px solid var(--accent); padding: 26px 24px 20px 30px; background: color-mix(in srgb, var(--bg) 58%, white); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--secondary) 12%, transparent); }}
.master-metric .value {{ color: var(--accent); font-size: 42px; line-height: 1; font-weight: 800; margin-bottom: 16px; }}
.master-metric .label {{ color: var(--text); font-size: 22px; line-height: 1.32; }}
.master-bars {{ display: grid; gap: 30px; padding-top: 8px; }}
.master-bar {{ display: grid; grid-template-columns: 170px 1fr; gap: 20px; align-items: center; color: var(--text); font-size: 24px; font-weight: 800; }}
.master-bar span:last-child {{ height: 18px; background: color-mix(in srgb, var(--accent) 18%, transparent); position: relative; }}
.master-bar span:last-child::after {{ content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 68%; background: var(--accent); }}
.master-summary {{ position: absolute; z-index: 3; left: 120px; right: 120px; top: 360px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 42px; }}
.master-summary .master-card {{ min-height: 300px; }}
.master-bottom-note {{ position: absolute; z-index: 3; left: 120px; right: 120px; bottom: 78px; border-left: 8px solid var(--accent); background: color-mix(in srgb, var(--bg) 54%, white); color: var(--text); padding: 26px 34px; font-size: 29px; line-height: 1.32; font-weight: 700; box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--secondary) 12%, transparent); }}
.image-info-stack {{ position: absolute; z-index: 3; left: 120px; top: 286px; width: 760px; bottom: 116px; display: grid; grid-template-rows: auto 1fr auto; gap: 28px; }}
.image-intro {{ border-left: 8px solid var(--accent); background: color-mix(in srgb, var(--bg) 54%, white); padding: 30px 34px 30px 42px; color: var(--text); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--secondary) 12%, transparent); }}
.image-intro h2 {{ margin: 0 0 18px; color: var(--text); font-size: 36px; line-height: 1.18; font-weight: 800; }}
.image-intro .master-copy {{ font-size: 26px; line-height: 1.38; font-weight: 600; }}
.image-insight-grid {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 24px; align-content: stretch; }}
.image-mini-card {{ min-height: 178px; background: color-mix(in srgb, var(--bg) 58%, white); border-top: 7px solid var(--accent); padding: 28px 26px; color: var(--text); font-size: 24px; line-height: 1.34; font-weight: 600; box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--secondary) 12%, transparent); }}
.image-mini-card h3 {{ margin: 0 0 14px; color: var(--accent); font-size: 30px; line-height: 1.18; font-weight: 800; }}
.image-note {{ border-left: 8px solid var(--secondary); background: color-mix(in srgb, var(--secondary) 12%, var(--bg)); padding: 26px 32px; color: var(--text); font-size: 26px; line-height: 1.32; font-weight: 700; }}
.agenda-label {{ position: absolute; z-index: 3; right: 120px; top: 86px; color: color-mix(in srgb, var(--secondary) 65%, transparent); font-size: 74px; line-height: 1; font-weight: 800; }}
.agenda-label small {{ display: block; color: var(--accent); font-size: 26px; margin-top: 14px; text-align: right; }}
.chapter-layout {{ position: absolute; z-index: 3; left: 120px; right: 120px; top: 128px; bottom: 106px; display: grid; grid-template-columns: 440px 1fr; gap: 86px; align-items: center; }}
.chapter-layout > div:first-child {{ background: color-mix(in srgb, var(--accent) 16%, var(--bg)); padding: 56px 52px 62px; box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 24%, transparent); }}
.chapter-badge {{ color: var(--accent); font-size: 34px; font-weight: 800; margin-bottom: 32px; }}
.chapter-big {{ color: var(--accent); font-size: 214px; line-height: .84; font-weight: 800; }}
.chapter-line {{ width: 260px; height: 8px; background: var(--secondary); margin-top: 46px; }}
.chapter-main {{ background: color-mix(in srgb, var(--bg) 64%, white); padding: 50px 56px 48px; box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--secondary) 12%, transparent); }}
.chapter-main h1 {{ margin: 0 0 30px; color: var(--text); font-size: 68px; line-height: 1.12; font-weight: 800; }}
.chapter-main .lead {{ color: var(--text); font-size: 30px; line-height: 1.36; max-width: 980px; margin: 0 0 44px; }}
.chapter-points {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 34px; }}
.chapter-point {{ border-left: 7px solid var(--accent); padding: 22px 20px 20px 28px; background: color-mix(in srgb, var(--bg) 54%, white); color: var(--text); font-size: 24px; line-height: 1.36; min-height: 160px; }}
.chapter-point h3 {{ margin: 0 0 14px; color: var(--text); font-size: 31px; line-height: 1.2; }}
.architectural_minimal {{ background: color-mix(in srgb, var(--bg) 92%, white); }}
.architectural_minimal::after {{ content: ""; position: absolute; inset: 0; z-index: 1; pointer-events: none; background:
  linear-gradient(90deg, color-mix(in srgb, var(--accent) 10%, transparent) 1px, transparent 1px),
  linear-gradient(0deg, color-mix(in srgb, var(--accent) 8%, transparent) 1px, transparent 1px),
  radial-gradient(circle at 78% 18%, color-mix(in srgb, var(--accent) 12%, transparent), transparent 28%),
  linear-gradient(135deg, transparent 0 58%, color-mix(in srgb, var(--accent) 7%, transparent) 58% 60%, transparent 60%);
  background-size: 96px 96px, 96px 96px, auto, auto;
  opacity: .62;
}}
.arch-title {{ position: absolute; z-index: 3; left: 90px; top: 84px; right: 90px; display: grid; grid-template-columns: 170px 1fr 260px; gap: 34px; align-items: start; }}
.arch-no {{ color: var(--accent); font-size: 30px; line-height: 1; font-weight: 800; border-top: 4px solid var(--accent); padding-top: 18px; }}
.arch-title h1 {{ margin: 0; color: color-mix(in srgb, var(--text) 82%, black); font-size: 56px; line-height: 1.1; font-weight: 800; }}
.arch-title .lead {{ margin: 20px 0 0; color: color-mix(in srgb, var(--text) 76%, black); font-size: 25px; line-height: 1.36; max-width: 1180px; }}
.arch-wordmark {{ color: color-mix(in srgb, var(--accent) 72%, transparent); text-align: right; font-size: 26px; font-weight: 800; letter-spacing: 0; }}
.arch-wordmark::before {{ content: ""; display: block; height: 3px; background: color-mix(in srgb, var(--accent) 58%, transparent); margin: 0 0 18px auto; width: 150px; }}
.arch-rail {{ position: absolute; z-index: 3; left: 90px; top: 254px; bottom: 92px; width: 170px; border-right: 4px solid color-mix(in srgb, var(--accent) 58%, transparent); color: var(--accent); background: linear-gradient(180deg, color-mix(in srgb, var(--accent) 8%, transparent), transparent 45%); }}
.arch-rail strong {{ display: block; font-size: 82px; line-height: .9; margin-bottom: 18px; }}
.arch-rail span {{ display: block; font-size: 22px; font-weight: 800; writing-mode: vertical-rl; letter-spacing: 0; }}
.arch-agenda {{ position: absolute; z-index: 3; left: 310px; right: 120px; top: 312px; display: grid; gap: 22px; }}
.arch-agenda-row {{ display: grid; grid-template-columns: 92px 300px 1fr; gap: 28px; align-items: center; min-height: 132px; border-top: 4px solid color-mix(in srgb, var(--accent) 66%, transparent); background: color-mix(in srgb, var(--bg) 50%, white); padding: 25px 30px; box-shadow: 0 18px 42px color-mix(in srgb, var(--secondary) 8%, transparent); }}
.arch-agenda-row .num {{ color: var(--accent); font-size: 42px; font-weight: 800; }}
.arch-agenda-row h3 {{ margin: 0; color: var(--text); font-size: 32px; line-height: 1.18; }}
.arch-agenda-row p {{ margin: 0; color: var(--text); font-size: 26px; line-height: 1.32; }}
.arch-columns {{ position: absolute; z-index: 3; left: 300px; right: 120px; top: 310px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 28px; }}
.arch-column {{ min-height: 500px; border-top: 5px solid var(--accent); background: linear-gradient(180deg, color-mix(in srgb, var(--bg) 44%, white), color-mix(in srgb, var(--bg) 68%, white)); padding: 34px 32px; color: color-mix(in srgb, var(--text) 88%, black); font-size: 28px; line-height: 1.34; font-weight: 600; box-shadow: 0 18px 46px color-mix(in srgb, var(--secondary) 8%, transparent), inset 0 0 0 1px color-mix(in srgb, var(--accent) 10%, transparent); }}
.arch-column h3 {{ margin: 0 0 22px; color: color-mix(in srgb, var(--text) 84%, black); font-size: 36px; line-height: 1.18; }}
.arch-image-layout {{ position: absolute; z-index: 3; left: 90px; right: 90px; top: 284px; bottom: 96px; display: grid; grid-template-columns: 520px 1fr; gap: 48px; }}
.arch-image-copy {{ display: grid; grid-template-rows: auto 1fr auto; gap: 22px; }}
.arch-copy-block {{ border-top: 5px solid var(--accent); background: linear-gradient(180deg, color-mix(in srgb, var(--bg) 44%, white), color-mix(in srgb, var(--bg) 68%, white)); padding: 32px 34px; color: color-mix(in srgb, var(--text) 88%, black); font-size: 28px; line-height: 1.34; font-weight: 600; box-shadow: 0 18px 46px color-mix(in srgb, var(--secondary) 8%, transparent), inset 0 0 0 1px color-mix(in srgb, var(--accent) 10%, transparent); }}
.arch-copy-block h2 {{ margin: 0 0 20px; color: var(--text); font-size: 36px; line-height: 1.16; }}
.arch-mini-row {{ display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }}
.arch-mini {{ border-left: 5px solid var(--accent); background: color-mix(in srgb, var(--bg) 52%, white); padding: 25px; color: color-mix(in srgb, var(--text) 88%, black); font-size: 26px; line-height: 1.32; font-weight: 600; box-shadow: 0 12px 30px color-mix(in srgb, var(--secondary) 7%, transparent); }}
.arch-visual {{ position: relative; background:
  linear-gradient(90deg, color-mix(in srgb, var(--accent) 18%, transparent) 1px, transparent 1px),
  linear-gradient(0deg, color-mix(in srgb, var(--accent) 14%, transparent) 1px, transparent 1px),
  linear-gradient(135deg, color-mix(in srgb, var(--accent) 22%, var(--bg)), color-mix(in srgb, var(--bg) 62%, white));
  background-size: 72px 72px, 72px 72px, auto;
  border: 4px solid color-mix(in srgb, var(--accent) 52%, transparent); display: grid; place-items: center; color: var(--accent); font-size: 44px; font-weight: 800; box-shadow: 0 24px 60px color-mix(in srgb, var(--secondary) 10%, transparent), inset 0 0 0 22px color-mix(in srgb, white 22%, transparent); }}
.arch-visual::before {{ content: ""; position: absolute; inset: 42px; border: 2px solid color-mix(in srgb, var(--accent) 44%, transparent); }}
.arch-visual::after {{ content: "IMAGE / PLAN"; }}
.arch-timeline {{ position: absolute; z-index: 3; left: 300px; right: 120px; top: 360px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; border-top: 4px solid var(--accent); }}
.arch-step {{ min-height: 380px; border-right: 1px solid color-mix(in srgb, var(--accent) 44%, transparent); background: linear-gradient(180deg, color-mix(in srgb, var(--bg) 46%, white), color-mix(in srgb, var(--bg) 68%, white)); padding: 36px 28px; color: color-mix(in srgb, var(--text) 88%, black); font-size: 25px; line-height: 1.34; font-weight: 600; box-shadow: 0 18px 42px color-mix(in srgb, var(--secondary) 6%, transparent); }}
.arch-step strong {{ display: block; color: var(--accent); font-size: 44px; line-height: 1; margin-bottom: 34px; }}
.arch-step b {{ display: block; color: var(--text); font-size: 30px; line-height: 1.18; margin-bottom: 18px; }}
.arch-bottom {{ position: absolute; z-index: 3; left: 300px; right: 120px; bottom: 64px; border-top: 3px solid var(--accent); color: var(--text); font-size: 26px; line-height: 1.32; font-weight: 700; padding-top: 18px; }}
.arch-table-wrap {{ position: absolute; z-index: 3; left: 150px; right: 150px; top: 334px; }}
.arch-table {{ width: 100%; border-collapse: collapse; color: var(--text); font-size: 24px; }}
.arch-table th {{ color: var(--text); background: color-mix(in srgb, var(--accent) 18%, var(--bg)); border-top: 3px solid var(--accent); border-bottom: 1px solid color-mix(in srgb, var(--accent) 40%, transparent); padding: 20px 24px; }}
.arch-table td {{ padding: 20px 24px; border-bottom: 1px solid color-mix(in srgb, var(--accent) 28%, transparent); }}
.arch-quote {{ position: absolute; z-index: 3; left: 190px; right: 190px; top: 300px; border-left: 8px solid var(--accent); padding: 36px 0 36px 50px; color: var(--text); }}
.arch-quote h1 {{ margin: 0; font-size: 58px; line-height: 1.18; }}
.arch-quote p {{ margin: 30px 0 0; font-size: 26px; line-height: 1.38; color: var(--muted); }}
.variant-numbered_grid .arch-column,
.variant-three_columns .arch-column,
.variant-two_column_deep .arch-copy-block,
.variant-visual_grid .arch-copy-block,
.variant-visual_grid .arch-mini,
.variant-metric_dashboard .arch-mini,
.variant-metric_dashboard .arch-copy-block,
.variant-closing_band .arch-agenda-row,
.variant-stacked_process .arch-agenda-row {{
  background: color-mix(in srgb, var(--bg) 74%, white);
  box-shadow: none;
  border-top-width: 3px;
  border-color: color-mix(in srgb, var(--accent) 54%, transparent);
}}
.variant-three_columns .arch-column,
.variant-numbered_grid .arch-column {{
  min-height: 440px;
  padding: 30px 30px 32px;
}}
.variant-two_column_deep .arch-copy-block {{
  min-height: 460px;
  padding: 38px 42px;
}}
.variant-stacked_process .arch-agenda-row,
.variant-closing_band .arch-agenda-row {{
  min-height: 118px;
  grid-template-columns: 86px 300px 1fr;
  padding: 22px 28px;
}}
.variant-stacked_process .arch-agenda-row .num,
.variant-closing_band .arch-agenda-row .num {{
  font-size: 36px;
}}
.variant-stacked_process .arch-agenda-row h3,
.variant-closing_band .arch-agenda-row h3 {{
  font-size: 29px;
}}
.variant-stacked_process .arch-agenda-row p,
.variant-closing_band .arch-agenda-row p {{
  color: color-mix(in srgb, var(--text) 76%, white);
  font-size: 23px;
}}
.variant-visual_grid .arch-image-layout,
.variant-split_statement .arch-image-layout,
.variant-metric_dashboard .arch-image-layout {{
  gap: 38px;
}}
.variant-visual_grid .arch-visual,
.variant-split_statement .arch-visual,
.variant-metric_dashboard .arch-visual,
.variant-wide_visual_bottom_notes .arch-visual {{
  background:
    linear-gradient(90deg, color-mix(in srgb, var(--accent) 10%, transparent) 1px, transparent 1px),
    linear-gradient(0deg, color-mix(in srgb, var(--accent) 8%, transparent) 1px, transparent 1px),
    color-mix(in srgb, var(--accent) 7%, white);
  background-size: 64px 64px;
  border: 2px solid color-mix(in srgb, var(--accent) 40%, transparent);
  box-shadow: inset 0 0 0 16px color-mix(in srgb, white 34%, transparent);
  color: color-mix(in srgb, var(--accent) 70%, white);
  font-size: 34px;
}}
.variant-visual_grid .arch-visual::before,
.variant-split_statement .arch-visual::before,
.variant-metric_dashboard .arch-visual::before,
.variant-wide_visual_bottom_notes .arch-visual::before {{
  inset: 30px;
  border-color: color-mix(in srgb, var(--accent) 28%, transparent);
}}
.variant-split_statement .arch-copy-block {{
  border-left: 5px solid color-mix(in srgb, var(--accent) 70%, transparent);
  border-top: 0;
  box-shadow: none;
}}
.variant-large_quote .arch-quote,
.variant-center_statement .arch-quote {{
  border-color: color-mix(in srgb, var(--accent) 72%, transparent);
}}
.kicker {{ color: var(--accent); font-size: var(--caption-size); font-weight: 700; text-transform: uppercase; letter-spacing: 0; }}
.title {{ margin: 0; font-size: var(--title-size); line-height: 1.04; font-weight: 800; color: var(--text); max-width: 1180px; }}
.subtitle {{ margin: 22px 0 0; font-size: var(--subtitle-size); line-height: 1.28; color: var(--muted); max-width: 980px; }}
.body-text {{ font-size: var(--body-size); line-height: 1.45; color: var(--text); }}
.muted {{ color: var(--muted); }}
.accent {{ color: var(--accent); }}
.rule {{ width: 190px; height: 8px; background: var(--accent); margin: 28px 0; }}
.grid {{ display: grid; gap: var(--gap); }}
.two-col {{ display: grid; grid-template-columns: 0.95fr 1.05fr; gap: calc(var(--gap) * 1.6); align-items: center; height: 100%; }}
.card {{ background: color-mix(in srgb, var(--surface) 86%, transparent); border: 1px solid color-mix(in srgb, var(--accent) 34%, transparent); border-radius: var(--radius); padding: 30px; }}
.visual-placeholder {{ min-height: 520px; border-radius: var(--radius); background: color-mix(in srgb, var(--surface-alt) 84%, transparent); border: 2px solid color-mix(in srgb, var(--accent) 55%, transparent); display: grid; place-items: center; color: var(--muted); font-size: var(--body-size); }}
.number {{ display: inline-grid; place-items: center; width: 58px; height: 58px; border-radius: 50%; background: var(--accent); color: #fff; font-weight: 800; }}
.metric {{ font-size: calc(var(--title-size) * 0.72); line-height: 1; font-weight: 900; color: var(--accent); }}
.footer {{ position: absolute; left: var(--page-padding); right: var(--page-padding); bottom: 34px; color: var(--muted); font-size: var(--caption-size); display: flex; justify-content: space-between; }}
table {{ width: 100%; border-collapse: collapse; font-size: calc(var(--body-size) * 0.86); }}
th, td {{ padding: 20px 22px; border-bottom: 1px solid color-mix(in srgb, var(--muted) 28%, transparent); text-align: left; }}
th {{ color: var(--accent); font-weight: 800; }}
"""


def css_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def role_html(role: str, theme: dict[str, Any], example: dict[str, Any], body: str | None = None, variant: str = "default") -> str:
    title = ROLE_LABELS[role]
    pattern = example.get("layout", {}).get("pattern", default_pattern_for_role(role))
    source_note = "synthetic fallback" if example.get("synthetic") else f"derived from {example.get('id')}"
    body = body if body is not None else role_body_html(role)
    section_classes = f"slide {role}"
    if variant != "default":
        section_classes += f" variant-{variant}"
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <link rel="stylesheet" href="common.css">
</head>
<body>
  <section class="{section_classes}" data-page-role="{role}" data-layout-variant="{html.escape(variant)}" data-source="{html.escape(source_note)}" data-pattern="{html.escape(pattern)}">
{body}
  </section>
</body>
</html>
"""


def role_placeholder_sequence(role: str) -> list[str]:
    common = ["section_label", "page_title", "subtitle", "paragraph_or_bullets_left", "paragraph_or_bullets_right"]
    return {
        "cover": ["deck_title", "subtitle", "paragraph_or_bullets_left", "date"],
        "agenda": ["section_label", "agenda_title", "subtitle", "agenda_item_1", "agenda_item_2", "agenda_item_3", "agenda_item_4", "agenda_item_5", "agenda_item_6"],
        "chapter_cover": ["chapter_index", "chapter_title", "chapter_summary", "paragraph_or_bullets_left"],
        "text": common + ["agenda_item_1", "agenda_item_2", "agenda_item_3", "agenda_item_4"],
        "image": ["section_label", "page_title", "subtitle", "image_context", "paragraph_or_bullets_left", "image_or_screenshot"],
        "quote": ["quote_context", "quote_text", "quote_source_or_interpretation"],
        "chart": ["section_label", "chart_title", "subtitle", "chart_area", "metric_1", "insight_1", "metric_2", "insight_2", "metric_3", "insight_3"],
        "table": ["section_label", "table_title", "col_1", "col_2", "col_3", "col_4", "row_1_col_1", "row_1_col_2", "row_1_col_3", "row_1_col_4", "row_2_col_1", "row_2_col_2", "row_2_col_3", "row_2_col_4", "row_3_col_1", "row_3_col_2", "row_3_col_3", "row_3_col_4"],
        "summary": ["section_label", "summary_title", "takeaway_1", "takeaway_2", "takeaway_3", "next_step"],
        "timeline": ["section_label", "timeline_title", "phase_1", "phase_2", "phase_3", "phase_4", "paragraph_or_bullets_left"],
        "data_support": ["section_label", "data_title", "kpi_1", "kpi_label_1", "kpi_2", "kpi_label_2", "kpi_3", "kpi_label_3", "kpi_4", "kpi_label_4", "supporting_chart_or_evidence"],
    }[role]


def source_skeleton_placeholder_sequence(role: str) -> list[str]:
    """Map generated content into source PPT text boxes without treating page numbers as titles."""
    return {
        "cover": ["deck_title", "subtitle", "paragraph_or_bullets_left", "date"],
        "agenda": ["agenda_title", "subtitle", "paragraph_or_bullets_left", "agenda_item_1", "agenda_item_2", "agenda_item_3", "agenda_item_4", "agenda_item_5", "agenda_item_6"],
        "chapter_cover": ["chapter_title", "chapter_summary", "paragraph_or_bullets_left", "agenda_item_1", "agenda_item_2"],
        "text": ["page_title", "subtitle", "paragraph_or_bullets_left", "paragraph_or_bullets_right", "agenda_item_1", "agenda_item_2", "agenda_item_3", "agenda_item_4"],
        "image": ["page_title", "subtitle", "image_context", "paragraph_or_bullets_left", "paragraph_or_bullets_right", "image_or_screenshot"],
        "quote": ["quote_text", "quote_context", "quote_source_or_interpretation"],
        "chart": ["chart_title", "subtitle", "chart_area", "metric_1", "insight_1", "metric_2", "insight_2", "metric_3", "insight_3"],
        "table": ["table_title", "subtitle", "col_1", "col_2", "col_3", "col_4", "row_1_col_1", "row_1_col_2", "row_1_col_3", "row_1_col_4", "row_2_col_1", "row_2_col_2", "row_2_col_3", "row_2_col_4"],
        "summary": ["summary_title", "subtitle", "takeaway_1", "takeaway_2", "takeaway_3", "takeaway_4", "next_step"],
        "timeline": ["timeline_title", "subtitle", "phase_1", "phase_2", "phase_3", "phase_4", "paragraph_or_bullets_left"],
        "data_support": ["data_title", "subtitle", "kpi_1", "kpi_label_1", "kpi_2", "kpi_label_2", "kpi_3", "kpi_label_3", "supporting_chart_or_evidence"],
    }[role]


def text_shape_font(shape: Any) -> tuple[str, float, str, bool]:
    font_name = "Arial"
    font_size = 28.0
    color = "#555555"
    bold = False
    try:
        runs = [run for para in shape.text_frame.paragraphs for run in para.runs if run.text]
        if runs:
            run = runs[0]
            font_name = run.font.name or font_name
            if run.font.size:
                font_size = float(run.font.size.pt) * 96 / 72
            color = pptx_color_from_format(run.font.color) or color
            bold = bool(run.font.bold)
        else:
            para_font = shape.text_frame.paragraphs[0].font
            font_name = para_font.name or font_name
            if para_font.size:
                font_size = float(para_font.size.pt) * 96 / 72
            color = pptx_color_from_format(para_font.color) or color
            bold = bool(para_font.bold)
    except Exception:
        pass
    return font_name, font_size, color, bold


def px_box(shape: Any, canvas_w: int, canvas_h: int) -> dict[str, float]:
    return {
        "left": int(shape.left) / canvas_w * HTML_SLIDE_WIDTH,
        "top": int(shape.top) / canvas_h * HTML_SLIDE_HEIGHT,
        "width": int(shape.width) / canvas_w * HTML_SLIDE_WIDTH,
        "height": int(shape.height) / canvas_h * HTML_SLIDE_HEIGHT,
    }


def css_box(box: dict[str, float]) -> str:
    return f"left:{box['left']:.1f}px;top:{box['top']:.1f}px;width:{box['width']:.1f}px;height:{box['height']:.1f}px;"


def is_decorative_source_text(text: str, role: str, box: dict[str, float], font_size: float) -> bool:
    stripped = text.strip()
    if stripped == "E":
        return True
    latin = re.sub(r"[^A-Za-z]", "", stripped)
    has_cjk = bool(re.search(r"[\u4e00-\u9fff]", stripped))
    if role == "cover" and latin and not has_cjk and stripped.upper() == stripped and font_size >= 64:
        return True
    if len(stripped) <= 2 and not has_cjk and font_size >= 28:
        return True
    if re.fullmatch(r"\d{1,2}", stripped) and font_size <= 34:
        return True
    if box["top"] > 820 and font_size <= 12:
        return True
    if box["width"] <= 80 and font_size <= 16:
        return True
    if box["width"] > 1200 and font_size >= 86 and not has_cjk:
        return True
    return False


def readable_placeholder_font_size(key: str, role: str, source_size: float) -> float:
    if key in {"section_label", "chapter_index"}:
        return max(source_size, 36.0)
    if key in {"deck_title", "page_title", "chapter_title", "agenda_title", "summary_title", "timeline_title", "data_title", "table_title", "chart_title"}:
        return max(source_size, 34.0)
    if key in {"subtitle", "chapter_summary", "quote_context"}:
        return max(source_size, 24.0)
    if key.startswith(("paragraph_or_bullets", "agenda_item", "phase_", "takeaway_", "kpi_label", "insight_", "row_", "col_")):
        return max(source_size, 22.0)
    if key in {"quote_text"}:
        return max(source_size, 38.0)
    if key.startswith(("metric_", "kpi_")):
        return max(source_size, 36.0)
    if role in {"text", "image", "summary", "table"}:
        return max(source_size, 20.0)
    return source_size


def write_pptx_skeleton_templates(
    source: Path,
    examples: dict[str, dict[str, Any]],
    templates_dir: Path,
    theme: dict[str, Any],
    asset_config: AssetBindingConfig | None = None,
    model_config: ModelVariantConfig | None = None,
    design_constraints: str = "",
) -> None:
    try:
        from pptx import Presentation
        from pptx.enum.shapes import MSO_SHAPE_TYPE
    except ImportError as exc:
        raise RuntimeError("PPTX skeleton templates require python-pptx.") from exc

    prs = Presentation(str(source))
    canvas_w = int(prs.slide_width)
    canvas_h = int(prs.slide_height)
    assets_dir = templates_dir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    variants_dir = templates_dir / "variants"
    variants_dir.mkdir(parents=True, exist_ok=True)
    for role in PAGE_ROLES:
        example = examples[role]
        slide_no = None
        if str(example.get("id", "")).startswith("slide_"):
            try:
                slide_no = int(str(example["id"]).split("_")[1])
            except Exception:
                slide_no = None
        if slide_no is None or slide_no < 1 or slide_no > len(prs.slides):
            slide_no = fallback_slide_for_role(role, len(prs.slides))
        slide = prs.slides[slide_no - 1]
        body = pptx_slide_to_html_body(slide, role, slide_no, canvas_w, canvas_h, assets_dir, asset_config, theme)
        html_doc = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(role)}</title>
  <link rel="stylesheet" href="common.css">
</head>
<body>
  <section class="slide source-slide {role} {theme.get('template_family', 'visual_story')}" data-page-role="{role}" data-template-family="{theme.get('template_family', 'visual_story')}" data-source-slide="{slide_no}">
{body}
  </section>
</body>
</html>
"""
        (templates_dir / f"{role}.html").write_text(html_doc, encoding="utf-8")
        if theme.get("template_family") == "architectural_minimal" and role != "cover":
            pictures = source_picture_assets(slide, slide_no, canvas_w, canvas_h, assets_dir, None)
            bg_img = ""
            if pictures:
                bg = max(pictures, key=lambda item: item["area"])
                bg_img = f'    <img class="redesign-bg" src="assets/{bg["name"]}" alt="">'
            mark = '    <div class="redesign-mark">E</div>'
            variant_bodies = architectural_role_variant_bodies(role, bg_img, mark)
            if model_config and model_config.enabled and (not model_config.roles or role in model_config.roles):
                variant_bodies.update(request_model_role_variants(role, theme, design_constraints, model_config))
            for variant, variant_body in variant_bodies.items():
                variant_doc = role_html(role, theme, example, variant_body, variant)
                (variants_dir / f"{role}_{variant}.html").write_text(variant_doc, encoding="utf-8")


def fallback_slide_for_role(role: str, slide_count: int) -> int:
    preferred = {
        "cover": 1,
        "agenda": 2,
        "chapter_cover": 3,
        "text": 4,
        "image": 5,
        "quote": 6,
        "chart": 8,
        "table": 2,
        "summary": slide_count,
        "timeline": 4,
        "data_support": 9,
    }
    return max(1, min(slide_count, preferred.get(role, 2)))


def source_picture_assets(slide: Any, slide_no: int, canvas_w: int, canvas_h: int, assets_dir: Path, asset_config: AssetBindingConfig | None = None) -> list[dict[str, Any]]:
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    pictures: list[dict[str, Any]] = []
    for shape_index, shape in enumerate(slide.shapes, 1):
        if getattr(shape, "shape_type", None) != MSO_SHAPE_TYPE.PICTURE:
            continue
        ext = getattr(shape.image, "ext", "png") or "png"
        asset_name = f"slide{slide_no:02d}_shape{shape_index:02d}.{ext}"
        blob = shape.image.blob
        (assets_dir / asset_name).write_bytes(blob)
        box = px_box(shape, canvas_w, canvas_h)
        binding = asset_binding(asset_name, blob, box, asset_config)
        pictures.append({"name": asset_name, "box": box, "area": box["width"] * box["height"], "binding": binding})
    return pictures


def visual_markup(visual: dict[str, Any] | None = None, classes: str = "redesign-visual wide", *, allow_source_visual: bool = False) -> str:
    blank_classes = classes.replace("redesign-visual", "redesign-visual-blank", 1)
    if not allow_source_visual:
        return f'    <div class="{blank_classes}"></div>'
    if not visual:
        return f'    <div class="{blank_classes}"></div>'
    if not visual.get("binding", {}).get("reusable_for_unrelated_topic", True):
        return f'    <div class="{blank_classes}"></div>'
    return f'    <img class="{classes}" src="assets/{visual["name"]}" alt="">'


def arch_title(role_title: str, title_key: str, subtitle_key: str = "subtitle") -> str:
    return f"""    <div class="arch-title">
      <div class="arch-no">{{{{section_label}}}}</div>
      <div>
        <h1>{{{{{title_key}}}}}</h1>
        <p class="lead">{{{{{subtitle_key}}}}}</p>
      </div>
      <div class="arch-wordmark">{role_title}</div>
    </div>
"""


def architectural_role_body(role: str, bg_img: str, mark: str) -> str:
    common_bg = f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
"""
    if role == "agenda":
        return common_bg + arch_title("CONTENTS", "agenda_title") + """    <div class="arch-rail"><strong>00</strong><span>CONTENTS</span></div>
    <div class="arch-agenda">
      <div class="arch-agenda-row"><div class="num">01</div><h3>{{agenda_item_1}}</h3><p>{{insight_1}}</p></div>
      <div class="arch-agenda-row"><div class="num">02</div><h3>{{agenda_item_2}}</h3><p>{{insight_2}}</p></div>
      <div class="arch-agenda-row"><div class="num">03</div><h3>{{agenda_item_3}}</h3><p>{{insight_3}}</p></div>
      <div class="arch-agenda-row"><div class="num">04</div><h3>{{agenda_item_4}}</h3><p>{{next_step}}</p></div>
    </div>
"""
    if role == "chapter_cover":
        return common_bg + """    <div class="arch-rail"><strong>{{chapter_index}}</strong><span>CHAPTER</span></div>
    <div class="arch-quote" style="top:250px; left:360px; right:150px;">
      <h1>{{chapter_title}}</h1>
      <p>{{chapter_summary}}</p>
    </div>
    <div class="arch-columns" style="top:560px; grid-template-columns: repeat(2, 1fr);">
      <div class="arch-column"><h3>{{agenda_item_1}}</h3>{{takeaway_1}}</div>
      <div class="arch-column"><h3>{{agenda_item_2}}</h3>{{takeaway_2}}</div>
    </div>
"""
    if role == "image":
        return common_bg + arch_title("VISUAL", "page_title") + """    <div class="arch-image-layout">
      <div class="arch-image-copy">
        <div class="arch-copy-block"><h2>{{agenda_item_1}}</h2>{{paragraph_or_bullets_left}}</div>
        <div class="arch-mini-row">
          <div class="arch-mini">{{takeaway_2}}</div>
          <div class="arch-mini">{{takeaway_3}}</div>
        </div>
        <div class="arch-copy-block">{{next_step}}</div>
      </div>
      <div class="arch-visual"></div>
    </div>
"""
    if role == "text":
        return common_bg + arch_title("ANALYSIS", "page_title") + """    <div class="arch-columns">
      <div class="arch-column"><h3>{{agenda_item_1}}</h3>{{paragraph_or_bullets_left}}</div>
      <div class="arch-column"><h3>{{agenda_item_2}}</h3>{{paragraph_or_bullets_right}}</div>
      <div class="arch-column"><h3>{{agenda_item_3}}</h3>{{insight_1}}<br><br>{{insight_2}}</div>
    </div>
"""
    if role == "timeline":
        return common_bg + arch_title("TIMELINE", "timeline_title") + """    <div class="arch-rail"><strong>{{section_label}}</strong><span>SEQUENCE</span></div>
    <div class="arch-timeline">
      <div class="arch-step"><strong>01</strong><b>{{phase_1}}</b>{{takeaway_1}}</div>
      <div class="arch-step"><strong>02</strong><b>{{phase_2}}</b>{{takeaway_2}}</div>
      <div class="arch-step"><strong>03</strong><b>{{phase_3}}</b>{{takeaway_3}}</div>
      <div class="arch-step"><strong>04</strong><b>{{phase_4}}</b>{{takeaway_4}}</div>
    </div>
    <div class="arch-bottom">{{next_step}}</div>
"""
    if role == "table":
        return common_bg + arch_title("MATRIX", "table_title") + """    <div class="arch-table-wrap">
      <table class="arch-table">
        <thead><tr><th>{{col_1}}</th><th>{{col_2}}</th><th>{{col_3}}</th><th>{{col_4}}</th></tr></thead>
        <tbody>
          <tr><td>{{row_1_col_1}}</td><td>{{row_1_col_2}}</td><td>{{row_1_col_3}}</td><td>{{row_1_col_4}}</td></tr>
          <tr><td>{{row_2_col_1}}</td><td>{{row_2_col_2}}</td><td>{{row_2_col_3}}</td><td>{{row_2_col_4}}</td></tr>
          <tr><td>{{row_3_col_1}}</td><td>{{row_3_col_2}}</td><td>{{row_3_col_3}}</td><td>{{row_3_col_4}}</td></tr>
        </tbody>
      </table>
    </div>
"""
    if role == "quote":
        return common_bg + """    <div class="arch-title">
      <div class="arch-no">Q</div>
      <div><h1>{{quote_context}}</h1><p class="lead">{{quote_source_or_interpretation}}</p></div>
      <div class="arch-wordmark">QUOTE</div>
    </div>
    <div class="arch-quote"><h1>{{quote_text}}</h1><p>{{next_step}}</p></div>
"""
    if role == "chart":
        return common_bg + arch_title("DIAGRAM", "chart_title") + """    <div class="arch-image-layout" style="grid-template-columns: 1fr 560px;">
      <div class="arch-visual" style="min-height:520px;"></div>
      <div class="arch-image-copy">
        <div class="arch-copy-block"><h2>{{metric_1}}</h2>{{insight_1}}</div>
        <div class="arch-copy-block"><h2>{{metric_2}}</h2>{{insight_2}}</div>
        <div class="arch-copy-block"><h2>{{metric_3}}</h2>{{insight_3}}</div>
      </div>
    </div>
"""
    if role == "data_support":
        return common_bg + arch_title("EVIDENCE", "data_title", "supporting_chart_or_evidence") + """    <div class="arch-columns" style="grid-template-columns: repeat(4, 1fr);">
      <div class="arch-column"><h3>{{kpi_1}}</h3>{{kpi_label_1}}</div>
      <div class="arch-column"><h3>{{kpi_2}}</h3>{{kpi_label_2}}</div>
      <div class="arch-column"><h3>{{kpi_3}}</h3>{{kpi_label_3}}</div>
      <div class="arch-column"><h3>{{kpi_4}}</h3>{{kpi_label_4}}</div>
    </div>
    <div class="arch-bottom">{{next_step}}</div>
"""
    if role == "summary":
        return common_bg + arch_title("SUMMARY", "summary_title", "next_step") + """    <div class="arch-columns">
      <div class="arch-column"><h3>{{agenda_item_1}}</h3>{{takeaway_1}}</div>
      <div class="arch-column"><h3>{{agenda_item_2}}</h3>{{takeaway_2}}</div>
      <div class="arch-column"><h3>{{agenda_item_3}}</h3>{{takeaway_3}}</div>
    </div>
    <div class="arch-bottom">{{takeaway_4}}</div>
"""
    return ""


def architectural_role_variant_bodies(role: str, bg_img: str, mark: str) -> dict[str, str]:
    common_bg = f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
"""
    variants: dict[str, str] = {}
    if role == "agenda":
        variants["rail_rows"] = architectural_role_body(role, bg_img, mark)
        variants["numbered_grid"] = common_bg + arch_title("CONTENTS", "agenda_title") + """    <div class="arch-columns" style="top:330px; grid-template-columns: repeat(2, 1fr); gap:32px;">
      <div class="arch-column"><h3>01 {{agenda_item_1}}</h3>{{insight_1}}</div>
      <div class="arch-column"><h3>02 {{agenda_item_2}}</h3>{{insight_2}}</div>
      <div class="arch-column"><h3>03 {{agenda_item_3}}</h3>{{insight_3}}</div>
      <div class="arch-column"><h3>04 {{agenda_item_4}}</h3>{{next_step}}</div>
    </div>
"""
        return variants
    if role == "chapter_cover":
        variants["quote_band"] = architectural_role_body(role, bg_img, mark)
        variants["split_statement"] = common_bg + """    <div class="arch-title">
      <div class="arch-no">{{chapter_index}}</div>
      <div><h1>{{chapter_title}}</h1><p class="lead">{{chapter_summary}}</p></div>
      <div class="arch-wordmark">CHAPTER</div>
    </div>
    <div class="arch-image-layout" style="top:340px; grid-template-columns: 620px 1fr;">
      <div class="arch-copy-block"><h2>{{agenda_item_1}}</h2>{{takeaway_1}}<br><br>{{takeaway_2}}</div>
      <div class="arch-visual"></div>
    </div>
"""
        return variants
    if role == "text":
        variants["three_columns"] = architectural_role_body(role, bg_img, mark)
        variants["two_column_deep"] = common_bg + arch_title("ANALYSIS", "page_title") + """    <div class="arch-image-layout" style="grid-template-columns: 1fr 1fr; top:330px;">
      <div class="arch-copy-block"><h2>{{agenda_item_1}}</h2>{{paragraph_or_bullets_left}}<br><br>{{takeaway_3}}</div>
      <div class="arch-copy-block"><h2>{{agenda_item_2}}</h2>{{paragraph_or_bullets_right}}<br><br>{{next_step}}</div>
    </div>
"""
        variants["statement_notes"] = common_bg + arch_title("ANALYSIS", "page_title") + """    <div class="arch-quote" style="top:300px; left:260px; right:260px;">
      <h1>{{subtitle}}</h1>
      <p>{{paragraph_or_bullets_left}}</p>
    </div>
    <div class="arch-bottom">{{next_step}}</div>
"""
        return variants
    if role == "image":
        variants["left_notes_right_visual"] = architectural_role_body(role, bg_img, mark)
        variants["wide_visual_bottom_notes"] = common_bg + arch_title("VISUAL", "page_title") + """    <div class="arch-visual" style="position:absolute; z-index:3; left:220px; right:220px; top:300px; height:430px;"></div>
    <div class="arch-bottom">{{paragraph_or_bullets_left}}</div>
"""
        variants["visual_grid"] = common_bg + arch_title("VISUAL", "page_title") + """    <div class="arch-image-layout" style="top:310px; grid-template-columns: 1fr 1fr; gap:32px;">
      <div class="arch-visual"></div>
      <div class="arch-image-copy">
        <div class="arch-copy-block"><h2>{{agenda_item_1}}</h2>{{takeaway_1}}</div>
        <div class="arch-mini-row"><div class="arch-mini">{{takeaway_2}}</div><div class="arch-mini">{{takeaway_3}}</div></div>
      </div>
    </div>
"""
        return variants
    if role == "timeline":
        variants["horizontal_steps"] = architectural_role_body(role, bg_img, mark)
        variants["stacked_process"] = common_bg + arch_title("TIMELINE", "timeline_title") + """    <div class="arch-agenda" style="top:330px;">
      <div class="arch-agenda-row"><div class="num">01</div><h3>{{phase_1}}</h3><p>{{takeaway_1}}</p></div>
      <div class="arch-agenda-row"><div class="num">02</div><h3>{{phase_2}}</h3><p>{{takeaway_2}}</p></div>
      <div class="arch-agenda-row"><div class="num">03</div><h3>{{phase_3}}</h3><p>{{takeaway_3}}</p></div>
      <div class="arch-agenda-row"><div class="num">04</div><h3>{{phase_4}}</h3><p>{{takeaway_4}}</p></div>
    </div>
"""
        return variants
    if role == "table":
        variants["matrix"] = architectural_role_body(role, bg_img, mark)
        variants["comparison_cards"] = common_bg + arch_title("MATRIX", "table_title") + """    <div class="arch-columns" style="top:330px; grid-template-columns: repeat(4, 1fr);">
      <div class="arch-column"><h3>{{col_1}}</h3>{{row_1_col_1}}<br>{{row_2_col_1}}<br>{{row_3_col_1}}</div>
      <div class="arch-column"><h3>{{col_2}}</h3>{{row_1_col_2}}<br>{{row_2_col_2}}<br>{{row_3_col_2}}</div>
      <div class="arch-column"><h3>{{col_3}}</h3>{{row_1_col_3}}<br>{{row_2_col_3}}<br>{{row_3_col_3}}</div>
      <div class="arch-column"><h3>{{col_4}}</h3>{{row_1_col_4}}<br>{{row_2_col_4}}<br>{{row_3_col_4}}</div>
    </div>
"""
        return variants
    if role == "chart":
        variants["visual_with_insights"] = architectural_role_body(role, bg_img, mark)
        variants["evidence_panels"] = common_bg + arch_title("DIAGRAM", "chart_title") + """    <div class="arch-columns" style="top:330px; grid-template-columns: repeat(3, 1fr);">
      <div class="arch-column"><h3>{{metric_1}}</h3>{{insight_1}}<br><br>{{takeaway_1}}</div>
      <div class="arch-column"><h3>{{metric_2}}</h3>{{insight_2}}<br><br>{{takeaway_2}}</div>
      <div class="arch-column"><h3>{{metric_3}}</h3>{{insight_3}}<br><br>{{takeaway_3}}</div>
    </div>
    <div class="arch-bottom">{{next_step}}</div>
"""
        return variants
    if role == "data_support":
        variants["kpi_columns"] = architectural_role_body(role, bg_img, mark)
        variants["metric_dashboard"] = common_bg + arch_title("EVIDENCE", "data_title", "supporting_chart_or_evidence") + """    <div class="arch-image-layout" style="grid-template-columns: 640px 1fr; top:330px;">
      <div class="arch-visual"></div>
      <div class="arch-image-copy">
        <div class="arch-mini-row"><div class="arch-mini"><b>{{kpi_1}}</b><br>{{kpi_label_1}}</div><div class="arch-mini"><b>{{kpi_2}}</b><br>{{kpi_label_2}}</div></div>
        <div class="arch-mini-row"><div class="arch-mini"><b>{{kpi_3}}</b><br>{{kpi_label_3}}</div><div class="arch-mini"><b>{{kpi_4}}</b><br>{{kpi_label_4}}</div></div>
        <div class="arch-copy-block">{{next_step}}</div>
      </div>
    </div>
"""
        return variants
    if role == "quote":
        variants["large_quote"] = architectural_role_body(role, bg_img, mark)
        variants["center_statement"] = common_bg + """    <div class="arch-title">
      <div class="arch-no">Q</div>
      <div><h1>{{quote_context}}</h1><p class="lead">{{quote_source_or_interpretation}}</p></div>
      <div class="arch-wordmark">QUOTE</div>
    </div>
    <div class="arch-quote" style="left:300px; right:300px; top:360px; text-align:center; border-left:0; border-top:6px solid var(--accent); padding:40px 0 0;">
      <h1>{{quote_text}}</h1>
    </div>
"""
        return variants
    if role == "summary":
        variants["takeaway_columns"] = architectural_role_body(role, bg_img, mark)
        variants["closing_band"] = common_bg + arch_title("SUMMARY", "summary_title", "next_step") + """    <div class="arch-agenda" style="top:330px;">
      <div class="arch-agenda-row"><div class="num">01</div><h3>{{agenda_item_1}}</h3><p>{{takeaway_1}}</p></div>
      <div class="arch-agenda-row"><div class="num">02</div><h3>{{agenda_item_2}}</h3><p>{{takeaway_2}}</p></div>
      <div class="arch-agenda-row"><div class="num">03</div><h3>{{agenda_item_3}}</h3><p>{{takeaway_3}}</p></div>
    </div>
    <div class="arch-bottom">{{takeaway_4}}</div>
"""
        return variants
    return variants


def sanitize_model_variant_body(body: str) -> str | None:
    body = body.strip()
    if not body or len(body) > 12000:
        return None
    if re.search(r"<\s*(script|iframe|link|style|html|head|body)\b", body, flags=re.I):
        return None
    placeholders = set(re.findall(r"\{\{\s*([^}]+?)\s*\}\}", body))
    if any(name not in ALLOWED_MODEL_PLACEHOLDERS for name in placeholders):
        return None
    return body


def model_variant_prompt(role: str, theme: dict[str, Any], design_constraints: str, count: int) -> str:
    return f"""
You are generating high-quality reusable HTML BODY snippets for a PowerPoint template system.

Source design language:
- Template family: {theme.get('template_family', 'visual_story')}
- Background: {theme.get('background')}
- Text: {theme.get('text')}
- Accent: {theme.get('accent')}
- Secondary: {theme.get('secondary')}
- Font: {theme.get('font_family')} / {theme.get('font_category')}
- Style focus: {theme.get('style_focus')}

Design constraints:
{design_constraints[:1500]}

Role to design: {role}
Need {count} layout variants.

Return JSON only:
{{
  "variants": [
    {{
      "name": "short_snake_case",
      "html": "HTML body snippet only"
    }}
  ]
}}

Rules:
- HTML snippet must be only the content inside <section>; do not include section/html/head/body/style/script/link.
- Use only existing CSS classes: redesign-bg, redesign-wash, redesign-mark, arch-title, arch-no, arch-wordmark, arch-rail, arch-agenda, arch-agenda-row, arch-columns, arch-column, arch-image-layout, arch-image-copy, arch-copy-block, arch-mini-row, arch-mini, arch-visual, arch-timeline, arch-step, arch-bottom, arch-table-wrap, arch-table, arch-quote.
- You may use inline style only for layout positioning/grid columns/top/left/right/bottom/height.
- Use placeholders exactly like {{{{page_title}}}}, {{{{subtitle}}}}, {{{{agenda_item_1}}}}, {{{{takeaway_1}}}}, {{{{paragraph_or_bullets_left}}}}.
- Keep the design elegant, restrained, museum/editorial, not dashboard-like.
- Make variants genuinely different in composition.
- Avoid over-heavy cards, large shadows, dense borders, and generic landing-page hero layouts.
- Text must have enough room and should not overlap.
""".strip()


def request_model_role_variants(role: str, theme: dict[str, Any], design_constraints: str, config: ModelVariantConfig) -> dict[str, str]:
    if not config.enabled or not config.api_key:
        return {}
    payload = {
        "model": config.model,
        "messages": [
            {"role": "system", "content": "You generate concise JSON for editable HTML slide templates. Return JSON only."},
            {"role": "user", "content": model_variant_prompt(role, theme, design_constraints, config.variants_per_role)},
        ],
        "temperature": 0.55,
        "response_format": {"type": "json_object"},
        "max_tokens": config.max_tokens,
    }
    try:
        data = extract_json_object(request_chat_jsonish(payload, config.base_url, config.api_key, config.timeout))
    except Exception as exc:
        print(f"[WARN] model variants failed for {role}: {exc}", file=sys.stderr)
        return {}
    variants: dict[str, str] = {}
    for item in data.get("variants") or []:
        if not isinstance(item, dict):
            continue
        name = re.sub(r"[^a-z0-9_]+", "_", str(item.get("name") or "model_variant").lower()).strip("_")[:48]
        body = sanitize_model_variant_body(str(item.get("html") or ""))
        if name and body:
            variants[f"model_{name}"] = body
    return variants


def is_full_slide_picture(box: dict[str, float]) -> bool:
    if {"x_pct", "y_pct", "w_pct", "h_pct"}.issubset(box):
        return box.get("x_pct", 1) <= 0.02 and box.get("y_pct", 1) <= 0.02 and box.get("w_pct", 0) >= 0.92 and box.get("h_pct", 0) >= 0.92
    return box.get("left", 9999) <= 28 and box.get("top", 9999) <= 28 and box.get("width", 0) >= 1170 and box.get("height", 0) >= 660


def pptx_source_skeleton_body(slide: Any, role: str, slide_no: int, canvas_w: int, canvas_h: int, assets_dir: Path, asset_config: AssetBindingConfig | None = None) -> str:
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    parts: list[str] = []
    placeholders = source_skeleton_placeholder_sequence(role)
    text_counter = 0

    for shape_index, shape in enumerate(slide.shapes, 1):
        box = px_box(shape, canvas_w, canvas_h)
        if getattr(shape, "shape_type", None) == MSO_SHAPE_TYPE.PICTURE:
            ext = getattr(shape.image, "ext", "png") or "png"
            asset_name = f"slide{slide_no:02d}_shape{shape_index:02d}.{ext}"
            blob = shape.image.blob
            (assets_dir / asset_name).write_bytes(blob)
            asset_binding(asset_name, blob, box, asset_config)
            if is_full_slide_picture(box):
                parts.append(f'    <img class="pptx-picture" src="assets/{asset_name}" style="{css_box(box)} object-fit:cover;" alt="">')
            else:
                parts.append(f'    <div class="pptx-picture-placeholder" style="{css_box(box)}"></div>')
            continue
        if getattr(shape, "has_text_frame", False) and (getattr(shape, "text", "") or "").strip():
            original_text = (getattr(shape, "text", "") or "").strip()
            font_name, font_size, color, bold = text_shape_font(shape)
            if is_decorative_source_text(original_text, role, box, font_size):
                parts.append(
                    f'    <div class="pptx-text decorative" '
                    f'style="{css_box(box)}font-family:{html.escape(font_name)}, var(--font-main);font-size:{font_size:.1f}px;line-height:1.08;font-weight:700;color:{color};">'
                    f'{html.escape(original_text)}</div>'
                )
                continue
            idx = text_counter
            text_counter += 1
            key = placeholders[idx] if idx < len(placeholders) else f"paragraph_or_bullets_{idx}"
            weight = "700" if bold else "400"
            line_height = 1.12 if font_size >= 34 else 1.22
            parts.append(
                f'    <div class="pptx-text fit-text" data-placeholder="{key}" '
                f'style="{css_box(box)}font-family:{html.escape(font_name)}, var(--font-main);font-size:{font_size:.1f}px;line-height:{line_height};font-weight:{weight};color:{color};">'
                f'{{{{{key}}}}}</div>'
            )
            continue
        fill = pptx_shape_fill(shape)
        stroke = pptx_shape_line(shape)
        if fill or stroke:
            fill_css = fill or "transparent"
            stroke_css = stroke or "transparent"
            parts.append(f'    <div class="pptx-shape" style="{css_box(box)}background:{fill_css};border:1px solid {stroke_css};"></div>')
    return "\n".join(parts)


def redesigned_source_role_body(slide: Any, role: str, slide_no: int, canvas_w: int, canvas_h: int, assets_dir: Path, asset_config: AssetBindingConfig | None = None, theme: dict[str, Any] | None = None) -> str:
    pictures = source_picture_assets(slide, slide_no, canvas_w, canvas_h, assets_dir, asset_config)
    if not pictures:
        return ""
    bg = max(pictures, key=lambda item: item["area"])
    non_bg = [p for p in pictures if p is not bg]
    reusable = [p for p in non_bg if p.get("binding", {}).get("reusable_for_unrelated_topic", True)]
    visual = max(reusable, key=lambda item: item["area"]) if reusable else (max(non_bg, key=lambda item: item["area"]) if non_bg else bg)
    bg_img = f'    <img class="redesign-bg" src="assets/{bg["name"]}" alt="">'
    mark = '    <div class="redesign-mark">E</div>'
    if (theme or {}).get("template_family") == "architectural_minimal":
        return architectural_role_body(role, bg_img, mark)
    if role == "chapter_cover":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="chapter-layout">
      <div>
        <div class="chapter-badge">CHAPTER</div>
        <div class="chapter-big">{{{{chapter_index}}}}</div>
        <div class="chapter-line"></div>
      </div>
      <div class="chapter-main">
        <h1>{{{{chapter_title}}}}</h1>
        <p class="lead">{{{{chapter_summary}}}}</p>
        <div class="chapter-points">
          <div class="chapter-point"><h3>{{{{agenda_item_1}}}}</h3>{{{{takeaway_1}}}}</div>
          <div class="chapter-point"><h3>{{{{agenda_item_2}}}}</h3>{{{{takeaway_2}}}}</div>
        </div>
      </div>
    </div>
"""
    if role == "data_support":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{data_title}}}}</h1>
      <p class="lead">{{{{supporting_chart_or_evidence}}}}</p>
    </div>
    <div class="master-dashboard">
      <div class="master-metrics">
        <div class="master-metric"><div class="value">{{{{kpi_1}}}}</div><div class="label">{{{{kpi_label_1}}}}</div></div>
        <div class="master-metric"><div class="value">{{{{kpi_2}}}}</div><div class="label">{{{{kpi_label_2}}}}</div></div>
        <div class="master-metric"><div class="value">{{{{kpi_3}}}}</div><div class="label">{{{{kpi_label_3}}}}</div></div>
        <div class="master-metric"><div class="value">{{{{kpi_4}}}}</div><div class="label">{{{{kpi_label_4}}}}</div></div>
      </div>
      <div class="master-bars">
        <div class="master-bar"><span>{{{{metric_1}}}}</span><span></span></div>
        <div class="master-bar"><span>{{{{metric_2}}}}</span><span></span></div>
        <div class="master-bar"><span>{{{{metric_3}}}}</span><span></span></div>
      </div>
    </div>
    <div class="master-bottom-note">{{{{next_step}}}}</div>
"""
    if role == "agenda":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="agenda-label">CONTENTS<small>目录</small></div>
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{agenda_title}}}}</h1>
      <p class="lead">{{{{subtitle}}}}</p>
    </div>
    <div class="master-grid-2">
      <div class="master-card"><h3><span class="master-number">1</span>{{{{agenda_item_1}}}}</h3>{{{{insight_1}}}}</div>
      <div class="master-card"><h3><span class="master-number">2</span>{{{{agenda_item_2}}}}</h3>{{{{insight_2}}}}</div>
      <div class="master-card"><h3><span class="master-number">3</span>{{{{agenda_item_3}}}}</h3>{{{{insight_3}}}}</div>
      <div class="master-card"><h3><span class="master-number">4</span>{{{{agenda_item_4}}}}</h3>{{{{next_step}}}}</div>
    </div>
"""
    if role in {"text", "image"}:
        title_key = "page_title"
        if role == "image":
            return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{{title_key}}}}}</h1>
      <p class="lead">{{{{subtitle}}}}</p>
    </div>
    <div class="image-info-stack">
      <div class="image-intro">
        <h2>{{{{agenda_item_1}}}}</h2>
        <div class="master-copy">{{{{paragraph_or_bullets_left}}}}</div>
      </div>
      <div class="image-insight-grid">
        <div class="image-mini-card"><h3>{{{{agenda_item_2}}}}</h3>{{{{takeaway_2}}}}</div>
        <div class="image-mini-card"><h3>{{{{agenda_item_3}}}}</h3>{{{{takeaway_3}}}}</div>
      </div>
      <div class="image-note">{{{{next_step}}}}</div>
    </div>
    <div class="master-visual"></div>
"""
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{{title_key}}}}}</h1>
      <p class="lead">{{{{subtitle}}}}</p>
    </div>
    <div class="master-grid-2">
      <div class="master-card"><h3>{{{{agenda_item_1}}}}</h3>{{{{paragraph_or_bullets_left}}}}</div>
      <div class="master-card"><h3>{{{{agenda_item_2}}}}</h3>{{{{paragraph_or_bullets_right}}}}</div>
      <div class="master-card"><h3>{{{{agenda_item_3}}}}</h3>{{{{insight_1}}}}</div>
      <div class="master-card"><h3>{{{{agenda_item_4}}}}</h3>{{{{insight_2}}}}</div>
    </div>
"""
    if role == "timeline":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{timeline_title}}}}</h1>
      <p class="lead">{{{{paragraph_or_bullets_left}}}}</p>
    </div>
    <div class="master-timeline">
      <div class="master-step"><strong>01</strong><b>{{{{phase_1}}}}</b>{{{{takeaway_1}}}}</div>
      <div class="master-step"><strong>02</strong><b>{{{{phase_2}}}}</b>{{{{takeaway_2}}}}</div>
      <div class="master-step"><strong>03</strong><b>{{{{phase_3}}}}</b>{{{{takeaway_3}}}}</div>
      <div class="master-step"><strong>04</strong><b>{{{{phase_4}}}}</b>{{{{takeaway_4}}}}</div>
    </div>
    <div class="master-bottom-note">{{{{next_step}}}}</div>
"""
    if role == "table":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{table_title}}}}</h1>
    </div>
    <div class="master-table-wrap">
      <table class="master-table">
        <thead><tr><th>{{{{col_1}}}}</th><th>{{{{col_2}}}}</th><th>{{{{col_3}}}}</th><th>{{{{col_4}}}}</th></tr></thead>
        <tbody>
          <tr><td>{{{{row_1_col_1}}}}</td><td>{{{{row_1_col_2}}}}</td><td>{{{{row_1_col_3}}}}</td><td>{{{{row_1_col_4}}}}</td></tr>
          <tr><td>{{{{row_2_col_1}}}}</td><td>{{{{row_2_col_2}}}}</td><td>{{{{row_2_col_3}}}}</td><td>{{{{row_2_col_4}}}}</td></tr>
          <tr><td>{{{{row_3_col_1}}}}</td><td>{{{{row_3_col_2}}}}</td><td>{{{{row_3_col_3}}}}</td><td>{{{{row_3_col_4}}}}</td></tr>
        </tbody>
      </table>
    </div>
"""
    if role == "quote":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{quote_context}}}}</div>
      <h1>{{{{quote_text}}}}</h1>
      <p class="lead">{{{{quote_source_or_interpretation}}}}</p>
    </div>
    <div class="master-callout">{{{{next_step}}}}</div>
"""
    if role == "chart":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{chart_title}}}}</h1>
      <p class="lead">{{{{subtitle}}}}</p>
    </div>
    <div class="master-dashboard">
      <div class="master-bars">
        <div class="master-bar"><span>{{{{metric_1}}}}</span><span></span></div>
        <div class="master-bar"><span>{{{{metric_2}}}}</span><span></span></div>
        <div class="master-bar"><span>{{{{metric_3}}}}</span><span></span></div>
      </div>
      <div class="master-grid-2" style="position:static; display:grid; grid-template-columns:1fr; gap:26px;">
        <div class="master-card compact"><h3>{{{{insight_1}}}}</h3>{{{{paragraph_or_bullets_left}}}}</div>
        <div class="master-card compact"><h3>{{{{insight_2}}}}</h3>{{{{paragraph_or_bullets_right}}}}</div>
        <div class="master-card compact"><h3>{{{{insight_3}}}}</h3>{{{{next_step}}}}</div>
      </div>
    </div>
"""
    if role == "summary":
        return f"""{bg_img}
    <div class="redesign-wash"></div>
{mark}
    <div class="master-title">
      <div class="master-kicker">{{{{section_label}}}}</div>
      <h1>{{{{summary_title}}}}</h1>
      <p class="lead">{{{{next_step}}}}</p>
    </div>
    <div class="master-summary">
      <div class="master-card"><h3>{{{{agenda_item_1}}}}</h3>{{{{takeaway_1}}}}</div>
      <div class="master-card"><h3>{{{{agenda_item_2}}}}</h3>{{{{takeaway_2}}}}</div>
      <div class="master-card"><h3>{{{{agenda_item_3}}}}</h3>{{{{takeaway_3}}}}</div>
    </div>
    <div class="master-bottom-note">{{{{takeaway_4}}}}</div>
"""
    return ""


def pptx_slide_to_html_body(slide: Any, role: str, slide_no: int, canvas_w: int, canvas_h: int, assets_dir: Path, asset_config: AssetBindingConfig | None = None, theme: dict[str, Any] | None = None) -> str:
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    if role in {"agenda", "chapter_cover", "text", "image", "timeline", "table", "quote", "chart", "data_support", "summary"}:
        redesigned = redesigned_source_role_body(slide, role, slide_no, canvas_w, canvas_h, assets_dir, asset_config, theme)
        if redesigned:
            return redesigned

    parts: list[str] = []
    placeholders = role_placeholder_sequence(role)
    text_counter = 0

    for shape_index, shape in enumerate(slide.shapes, 1):
        box = px_box(shape, canvas_w, canvas_h)
        if getattr(shape, "shape_type", None) == MSO_SHAPE_TYPE.PICTURE:
            ext = getattr(shape.image, "ext", "png") or "png"
            asset_name = f"slide{slide_no:02d}_shape{shape_index:02d}.{ext}"
            blob = shape.image.blob
            (assets_dir / asset_name).write_bytes(blob)
            asset_binding(asset_name, blob, box, asset_config)
            parts.append(f'    <img class="pptx-picture" src="assets/{asset_name}" style="{css_box(box)} object-fit:cover;" alt="">')
            continue
        if getattr(shape, "has_text_frame", False) and (getattr(shape, "text", "") or "").strip():
            original_text = (getattr(shape, "text", "") or "").strip()
            font_name, font_size, color, bold = text_shape_font(shape)
            if is_decorative_source_text(original_text, role, box, font_size):
                parts.append(
                    f'    <div class="pptx-text decorative" '
                    f'style="{css_box(box)}font-family:{html.escape(font_name)}, var(--font-main);font-size:{font_size:.1f}px;line-height:1.1;font-weight:700;color:{color};">'
                    f'{html.escape(original_text)}</div>'
                )
                continue
            idx = text_counter
            text_counter += 1
            key = placeholders[idx] if idx < len(placeholders) else f"paragraph_or_bullets_{idx}"
            font_size = readable_placeholder_font_size(key, role, font_size)
            weight = "700" if bold or font_size >= 46 else "400"
            line_height = 1.16 if font_size >= 42 else 1.28
            parts.append(
                f'    <div class="pptx-text fit-text" data-placeholder="{key}" '
                f'style="{css_box(box)}font-family:{html.escape(font_name)}, var(--font-main);font-size:{font_size:.1f}px;line-height:{line_height};font-weight:{weight};color:{color};">'
                f'{{{{{key}}}}}</div>'
            )
            continue
        fill = pptx_shape_fill(shape)
        stroke = pptx_shape_line(shape)
        if fill or stroke:
            fill_css = fill or "transparent"
            stroke_css = stroke or "transparent"
            parts.append(f'    <div class="pptx-shape" style="{css_box(box)}background:{fill_css};border:1px solid {stroke_css};"></div>')
    return "\n".join(parts)


def role_body_html(role: str) -> str:
    bodies = {
        "cover": """    <div class="two-col">
      <div>
        <div class="kicker">{{brand_or_series}}</div>
        <h1 class="title">{{deck_title}}</h1>
        <div class="rule"></div>
        <p class="subtitle">{{subtitle}}</p>
      </div>
      <div class="visual-placeholder">{{cover_visual}}</div>
    </div>
    <div class="footer"><span>{{presenter}}</span><span>{{date}}</span></div>""",
        "agenda": """    <div class="kicker">{{section_label}}</div>
    <h1 class="title">{{agenda_title}}</h1>
    <div class="rule"></div>
    <div class="grid" style="grid-template-columns: 1fr 1fr; margin-top: 54px;">
      <div class="card"><span class="number">01</span><p class="body-text">{{agenda_item_1}}</p></div>
      <div class="card"><span class="number">02</span><p class="body-text">{{agenda_item_2}}</p></div>
      <div class="card"><span class="number">03</span><p class="body-text">{{agenda_item_3}}</p></div>
      <div class="card"><span class="number">04</span><p class="body-text">{{agenda_item_4}}</p></div>
    </div>""",
        "chapter_cover": """    <div style="height:100%; display:grid; align-content:center;">
      <div class="kicker">{{chapter_index}}</div>
      <h1 class="title">{{chapter_title}}</h1>
      <div class="rule"></div>
      <p class="subtitle">{{chapter_summary}}</p>
    </div>""",
        "text": """    <div class="kicker">{{section_label}}</div>
    <h1 class="title" style="font-size: calc(var(--title-size) * .72);">{{page_title}}</h1>
    <div class="rule"></div>
    <div class="grid" style="grid-template-columns: 1fr 1fr; margin-top: 36px;">
      <div class="body-text">{{paragraph_or_bullets_left}}</div>
      <div class="body-text muted">{{paragraph_or_bullets_right}}</div>
    </div>""",
        "image": """    <div class="two-col">
      <div>
        <div class="kicker">{{section_label}}</div>
        <h1 class="title" style="font-size: calc(var(--title-size) * .68);">{{page_title}}</h1>
        <p class="subtitle">{{image_context}}</p>
      </div>
      <div class="visual-placeholder">{{image_or_screenshot}}</div>
    </div>""",
        "quote": """    <div style="height:100%; display:grid; align-content:center;">
      <div class="kicker">{{quote_context}}</div>
      <h1 class="title" style="max-width: 1380px;">{{quote_text}}</h1>
      <div class="rule"></div>
      <p class="subtitle">{{quote_source_or_interpretation}}</p>
    </div>""",
        "chart": """    <div class="kicker">{{section_label}}</div>
    <h1 class="title" style="font-size: calc(var(--title-size) * .66);">{{chart_title}}</h1>
    <div class="two-col" style="height: 760px;">
      <div class="visual-placeholder">{{chart_area}}</div>
      <div class="grid">
        <div class="card"><div class="metric">{{metric_1}}</div><p class="body-text">{{insight_1}}</p></div>
        <div class="card"><div class="metric">{{metric_2}}</div><p class="body-text">{{insight_2}}</p></div>
      </div>
    </div>""",
        "table": """    <div class="kicker">{{section_label}}</div>
    <h1 class="title" style="font-size: calc(var(--title-size) * .64);">{{table_title}}</h1>
    <div class="card" style="margin-top: 42px;">
      <table>
        <thead><tr><th>{{col_1}}</th><th>{{col_2}}</th><th>{{col_3}}</th><th>{{col_4}}</th></tr></thead>
        <tbody>
          <tr><td>{{row_1_col_1}}</td><td>{{row_1_col_2}}</td><td>{{row_1_col_3}}</td><td>{{row_1_col_4}}</td></tr>
          <tr><td>{{row_2_col_1}}</td><td>{{row_2_col_2}}</td><td>{{row_2_col_3}}</td><td>{{row_2_col_4}}</td></tr>
          <tr><td>{{row_3_col_1}}</td><td>{{row_3_col_2}}</td><td>{{row_3_col_3}}</td><td>{{row_3_col_4}}</td></tr>
        </tbody>
      </table>
    </div>""",
        "summary": """    <div class="kicker">{{section_label}}</div>
    <h1 class="title" style="font-size: calc(var(--title-size) * .68);">{{summary_title}}</h1>
    <div class="grid" style="grid-template-columns: repeat(3, 1fr); margin-top: 58px;">
      <div class="card"><span class="number">1</span><p class="body-text">{{takeaway_1}}</p></div>
      <div class="card"><span class="number">2</span><p class="body-text">{{takeaway_2}}</p></div>
      <div class="card"><span class="number">3</span><p class="body-text">{{takeaway_3}}</p></div>
    </div>
    <p class="subtitle" style="margin-top: 48px;">{{next_step}}</p>""",
        "timeline": """    <div class="kicker">{{section_label}}</div>
    <h1 class="title" style="font-size: calc(var(--title-size) * .66);">{{timeline_title}}</h1>
    <div style="margin-top: 120px; display:grid; grid-template-columns: repeat(4, 1fr); gap: 0; align-items:start;">
      <div class="card"><span class="number">01</span><p class="body-text">{{phase_1}}</p></div>
      <div class="card"><span class="number">02</span><p class="body-text">{{phase_2}}</p></div>
      <div class="card"><span class="number">03</span><p class="body-text">{{phase_3}}</p></div>
      <div class="card"><span class="number">04</span><p class="body-text">{{phase_4}}</p></div>
    </div>""",
        "data_support": """    <div class="kicker">{{section_label}}</div>
    <h1 class="title" style="font-size: calc(var(--title-size) * .66);">{{data_title}}</h1>
    <div class="grid" style="grid-template-columns: repeat(4, 1fr); margin-top: 56px;">
      <div class="card"><div class="metric">{{kpi_1}}</div><p class="body-text">{{kpi_label_1}}</p></div>
      <div class="card"><div class="metric">{{kpi_2}}</div><p class="body-text">{{kpi_label_2}}</p></div>
      <div class="card"><div class="metric">{{kpi_3}}</div><p class="body-text">{{kpi_label_3}}</p></div>
      <div class="card"><div class="metric">{{kpi_4}}</div><p class="body-text">{{kpi_label_4}}</p></div>
    </div>
    <div class="visual-placeholder" style="margin-top: 38px; min-height: 360px;">{{supporting_chart_or_evidence}}</div>""",
    }
    return bodies[role]


def role_detail_markdown(role: str, example: dict[str, Any], theme: dict[str, Any]) -> list[str]:
    layout = example.get("layout", {})
    source = "synthetic fallback" if example.get("synthetic") else f"source slide: {example.get('id')}"
    regions = ", ".join(layout.get("occupied_regions", [])[:6]) or "not detected"
    return [
        f"### {role} - {ROLE_LABELS[role]}",
        f"- Template: `templates/{role}.html`",
        f"- Variants: see `templates/variants/{role}_*.html` when available",
        f"- Source: {source}",
        f"- Use case: {ROLE_USE_CASES[role]}",
        f"- Layout pattern: {layout.get('pattern', default_pattern_for_role(role))}",
        f"- Major regions: {regions}",
        f"- Style focus: {theme['style_focus']}; content density: {theme['content_density']}",
        "",
    ]


def build_layout_md(source: Path, input_kind: str, slides: list[dict[str, Any]], examples: dict[str, dict[str, Any]], theme: dict[str, Any]) -> str:
    dna = theme.get("template_dna", {})
    title_band = dna.get("title_band", {})
    left_col = dna.get("left_column", {})
    right_col = dna.get("right_column", {})
    lines = [
        "# Layout Template Selector",
        "",
        f"- Source: `{source}`",
        f"- Input type: `{input_kind}`",
        f"- Page count analyzed: {len(slides)}",
        f"- Theme palette: {', '.join(theme['palette'][:8])}",
        f"- Background: `{theme['background']}`",
        f"- Text color: `{theme['text']}`",
        f"- Accent colors: `{theme['accent']}`, `{theme['secondary']}`",
        f"- Font: `{theme['font_family']}` ({theme['font_category']})",
        f"- Font scale: title `{theme['title_font_size']}`, body `{theme['base_font_size']}`",
        f"- Content density: `{theme['content_density']}`",
        f"- Style focus: `{theme['style_focus']}`",
        f"- Template family: `{theme.get('template_family', 'visual_story')}`",
        "",
        "## Reverse-Engineered Template DNA",
        "",
        f"- Master pattern: `{dna.get('master_pattern', 'unknown')}`",
        f"- Background-image ratio: `{dna.get('background_image_ratio', 0)}`",
        f"- Title band: x `{title_band.get('x_pct', 0.0625)}`, y `{title_band.get('y_pct', 0.0833)}`, width `{title_band.get('w_pct', 0.875)}`",
        f"- Content starts around y `{dna.get('content_start_y_pct', 0.25)}`",
        f"- Left column: x `{left_col.get('x_pct', 0.0625)}`, width `{left_col.get('w_pct', 0.43)}`",
        f"- Right column: x `{right_col.get('x_pct', 0.52)}`, width `{right_col.get('w_pct', 0.38)}`",
        f"- Quote/closing band starts around y `{dna.get('quote_band_y_pct', 0.78)}`",
        "- Treat these as the source generator's master-page rhythm. Synthetic role templates should extend this rhythm, not invent an unrelated business-dashboard style.",
        "- Layout variants are source-family aware. `architectural_minimal` uses rails, horizontal datum lines, blueprint-like visual zones, and restrained columns; `visual_story` uses stronger cards and story/image balance.",
        "",
        "## Template Selection Rules",
        "",
        "- Prefer `templates/variants/{role}_*.html` for generated content when available.",
        "- Use the base `templates/{role}.html` as a compatibility fallback.",
        "- Select variants by content shape: dense text -> deeper text variants; visual content -> visual variants; metrics -> evidence/dashboard variants; long decks should rotate variants to reduce repetition.",
        "",
        "- `cover`: deck opening, title, author, date, brand.",
        "- `agenda`: contents, outline, navigation.",
        "- `chapter_cover`: section transition.",
        "- `text`: explanation-heavy or bullet-heavy content.",
        "- `image`: large image, screenshot, product/case visual, or image-text mixed content.",
        "- `quote`: one strong statement, principle, or conclusion.",
        "- `chart`: chart-led analytical page.",
        "- `table`: structured matrix, comparison, schedule, checklist.",
        "- `summary`: final conclusion, takeaways, next steps.",
        "- `timeline`: milestones, stages, roadmap, history.",
        "- `data_support`: KPI cards, metrics, evidence, quantitative support.",
        "",
        "## Common Style Contract",
        "",
        "- All templates import `templates/common.css`.",
        "- Keep source background color, text color, typography scale, theme palette, auxiliary palette, spacing density, and layout rhythm through CSS variables.",
        "- Replace placeholders like `{{page_title}}` with generated content while preserving class names and page role.",
        "- Prefer existing role templates detected from the source. Use synthetic fallback templates only when the source deck lacks that role.",
        "",
        "## Page Role Templates",
        "",
    ]
    for role in PAGE_ROLES:
        lines.extend(role_detail_markdown(role, examples[role], theme))
    lines.extend(
        [
            "## Source Page Classification",
            "",
        ]
    )
    for slide in slides:
        lines.append(
            f"- `{slide['id']}` -> `{slide['page_role']}`; pattern `{slide['layout']['pattern']}`; "
            f"text blocks {slide['layout']['text_block_count']}; images {slide['layout']['image_block_count']}; shapes {slide['layout']['shape_block_count']}"
        )
    lines.append("")
    return "\n".join(lines)


def build_design_constraints_md(theme: dict[str, Any]) -> str:
    dna = theme.get("template_dna", {})
    title_band = dna.get("title_band", {})
    left_col = dna.get("left_column", {})
    right_col = dna.get("right_column", {})
    return f"""# Design Constraints

This file is for downstream deck generation. Treat it as a quality gate, not as optional style advice.

## Global Rules

- Keep the extracted palette, background mood, typography mood, and accent color.
- Do not blindly reuse original content images from the source PPTX. Reuse only background-like texture, color fields, abstract decoration, and safe brand-neutral assets.
- The source deck appears to be generated from a master template. Preserve its master rhythm before adding role-specific variation.
- Use a stable top title band on most pages, then place content below it. Do not float content randomly near the top.
- If a source layout is weak, fragmented, or topic-bound, use the reverse-engineered master layout instead of copying original element positions.
- Avoid unrelated business-dashboard styling unless the role is explicitly `chart` or `data_support`.
- A generated slide must look like a designed page at thumbnail size: clear hierarchy, enough whitespace, and one primary focal area.

## Reverse-Engineered Master Rhythm

- Master pattern: `{dna.get('master_pattern', 'unknown')}`.
- Keep title band around x `{title_band.get('x_pct', 0.0625)}`, y `{title_band.get('y_pct', 0.0833)}`, width `{title_band.get('w_pct', 0.875)}`.
- Start the main content around y `{dna.get('content_start_y_pct', 0.25)}`.
- Left column rhythm: x `{left_col.get('x_pct', 0.0625)}`, width `{left_col.get('w_pct', 0.43)}`.
- Right column rhythm: x `{right_col.get('x_pct', 0.52)}`, width `{right_col.get('w_pct', 0.38)}`.
- Reserve the lower centered band around y `{dna.get('quote_band_y_pct', 0.78)}` for quotes, closing claims, or summary sentences.
- When adding missing roles, make them feel like sibling pages produced by this same generator: same title band, same column gutters, same accent-line language, same calm background.

## Role Layout Policy

- `cover`: may preserve the strongest source visual and decorative background treatment.
- `agenda`: use four balanced numbered items under the common title band; keep the card language quiet and aligned.
- `chapter_cover`: use the common title band plus one short explanatory block or lower callout; avoid giant decorative numbers unless the source uses them.
- `text`: use a 2x2 content grid or paired columns under the title band; each block should have a short heading plus concise explanation.
- `image`: use the left text column and a right-side subject-relevant placeholder; do not reuse source content images.
- `timeline`: use four horizontal stages aligned to the same gutters as the source content columns.
- `table`: use a full-width matrix below the title band, matching the source's wide title and calm grid style.
- `quote`: make the title/quote text dominant and use the lower centered band for interpretation or source.
- `chart`: use bars or compact evidence panels that still follow the two-column master rhythm.
- `data_support`: use KPI/evidence cards that align to the source left/right columns, not scattered dashboards.
- `summary`: use three or four takeaway blocks below the title band; keep the final statement in the lower centered band if present.

## Text Budgets

- Title: 12-24 Chinese characters when possible.
- Subtitle or claim: one concise sentence, 18-38 Chinese characters.
- Card or timeline item: 12-28 Chinese characters.
- Body block: at most 2 bullets, each 24-48 Chinese characters.
- Table cell: 8-24 Chinese characters.

## Theme Signals

- Background: `{theme['background']}`
- Text: `{theme['text']}`
- Accent: `{theme['accent']}`
- Secondary: `{theme['secondary']}`
- Font mood: `{theme['font_category']}`
- Density: `{theme['content_density']}`
- Style focus: `{theme['style_focus']}`
- Template family: `{theme.get('template_family', 'visual_story')}`

## Layout Variant Policy

- `architectural_minimal`: use rails, horizontal section lines, restrained columns, blueprint/plan placeholders, and cool low-contrast surfaces. Avoid large warm card blocks and avoid making it look like the visual-story template with different colors.
- `visual_story`: use stronger content cards, clear image/content balance, visible chapter and contents markers, and fuller warm information blocks.
- `analytical`: prioritize matrix, evidence panels, tables, and metric cards while preserving the source title rhythm.
- `editorial`: prioritize quote-led, text-led, and serif-aware compositions.
"""


def template_variants_for_role(templates_dir: Path, role: str) -> list[str]:
    variants_dir = templates_dir / "variants"
    if not variants_dir.exists():
        return []
    return [f"templates/variants/{path.name}" for path in sorted(variants_dir.glob(f"{role}_*.html"))]


def build_template_system(source: Path, output_dir: Path, asset_config: AssetBindingConfig | None = None, model_config: ModelVariantConfig | None = None) -> None:
    clean_output_dir(output_dir)
    templates_dir = output_dir / "templates"
    templates_dir.mkdir(parents=True, exist_ok=True)
    slides, input_kind = analyze_source(source)

    if not slides:
        raise RuntimeError("No pages were analyzed from the input deck.")
    theme = aggregate_theme(slides)
    examples = role_examples(slides)
    design_constraints = build_design_constraints_md(theme)
    (templates_dir / "common.css").write_text(css_from_theme(theme), encoding="utf-8")
    if input_kind == "pptx-direct":
        write_pptx_skeleton_templates(source, examples, templates_dir, theme, asset_config, model_config, design_constraints)
    else:
        for role in PAGE_ROLES:
            (templates_dir / f"{role}.html").write_text(role_html(role, theme, examples[role]), encoding="utf-8")
    analysis = {
        "schema_version": "1.0",
        "source": str(source),
        "input_kind": input_kind,
        "theme": theme,
        "asset_bindings": asset_config.cache if asset_config else {},
        "vision_asset_binding": {
            "enabled": bool(asset_config and asset_config.enabled),
            "model": asset_config.model if asset_config else "",
            "max_calls": asset_config.max_calls if asset_config else 0,
            "calls": asset_config.calls if asset_config else 0,
        },
        "slides": slides,
        "roles": {
            role: {
                "template": f"templates/{role}.html",
                "variants": template_variants_for_role(templates_dir, role),
                "synthetic": bool(examples[role].get("synthetic")),
                "source_slide": examples[role].get("id"),
            }
            for role in PAGE_ROLES
        },
    }
    (output_dir / "analysis.json").write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "layout.md").write_text(build_layout_md(source, input_kind, slides, examples, theme), encoding="utf-8")
    (output_dir / "design_constraints.md").write_text(design_constraints, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract PDF/PPTX style and build a role-based HTML template system.")
    parser.add_argument("input", type=Path, help="PDF, PPTX, or PPT source deck.")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--vision-bind-assets", action="store_true", help="Use a vision model on a small set of likely topic-bound assets.")
    parser.add_argument("--vision-base-url", default=os.environ.get("VISION_BASE_URL") or "https://yunwu.ai")
    parser.add_argument("--vision-model", default=os.environ.get("VISION_MODEL") or "qwen3.5-397b-a17b")
    parser.add_argument("--vision-api-key-env", default=os.environ.get("VISION_API_KEY_ENV") or "VISION_API_KEY")
    parser.add_argument("--max-vision-assets", type=int, default=int(os.environ.get("MAX_VISION_ASSETS") or "6"))
    parser.add_argument("--vision-timeout", type=int, default=int(os.environ.get("VISION_TIMEOUT") or "45"))
    parser.add_argument("--model-generate-variants", action="store_true", help="Use a GLM/OpenAI-compatible model to generate extra HTML layout variants.")
    parser.add_argument("--model-base-url", default=os.environ.get("GLM_BASE_URL") or "https://yunwu.ai")
    parser.add_argument("--model-name", default=os.environ.get("GLM_MODEL") or "glm-5")
    parser.add_argument("--model-api-key-env", default=os.environ.get("GLM_API_KEY_ENV") or "GLM_API_KEY")
    parser.add_argument("--model-variants-per-role", type=int, default=int(os.environ.get("MODEL_VARIANTS_PER_ROLE") or "2"))
    parser.add_argument("--model-variant-roles", default=os.environ.get("MODEL_VARIANT_ROLES") or "", help="Comma-separated roles to ask the model to generate. Empty means all roles.")
    parser.add_argument("--model-timeout", type=int, default=int(os.environ.get("MODEL_TIMEOUT") or "180"))
    parser.add_argument("--model-max-tokens", type=int, default=int(os.environ.get("MODEL_MAX_TOKENS") or "2500"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    api_key = os.environ.get(args.vision_api_key_env) or os.environ.get("OPENAI_API_KEY") or ""
    asset_config = AssetBindingConfig(
        enabled=bool(args.vision_bind_assets),
        base_url=args.vision_base_url,
        model=args.vision_model,
        api_key=api_key,
        max_calls=max(0, args.max_vision_assets),
        timeout=args.vision_timeout,
    )
    if args.vision_bind_assets and not api_key:
        print(f"[WARN] {args.vision_api_key_env} or OPENAI_API_KEY is not set; falling back to heuristic asset binding.", file=sys.stderr)
    model_api_key = os.environ.get(args.model_api_key_env) or os.environ.get("OPENAI_API_KEY") or ""
    if args.model_generate_variants and not model_api_key:
        print(f"[WARN] {args.model_api_key_env} or OPENAI_API_KEY is not set; skipping model-generated variants.", file=sys.stderr)
    model_config = ModelVariantConfig(
        enabled=bool(args.model_generate_variants and model_api_key),
        base_url=args.model_base_url,
        model=args.model_name,
        api_key=model_api_key,
        timeout=args.model_timeout,
        variants_per_role=max(1, args.model_variants_per_role),
        roles={role.strip() for role in args.model_variant_roles.split(",") if role.strip()},
        max_tokens=max(800, args.model_max_tokens),
    )
    build_template_system(args.input, args.output_dir, asset_config, model_config)


if __name__ == "__main__":
    main()
