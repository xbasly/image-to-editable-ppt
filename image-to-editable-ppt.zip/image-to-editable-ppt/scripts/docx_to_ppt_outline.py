#!/usr/bin/env python
"""Convert a DOCX report into a PPT-oriented outline and generation style.

Outputs:
- outline.json: slide content with page_role values
- content_strategy.md: human-readable content/page-role plan
- template_style.md: topic style or template-informed style guide for SVG generation
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from model_utils import extract_json, normalize_base_url, response_text  # noqa: E402


NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
}


def para_text(paragraph: ET.Element) -> str:
    parts = [node.text or "" for node in paragraph.findall(".//w:t", NS)]
    return "".join(parts).strip()


def paragraph_style(paragraph: ET.Element) -> str:
    style = paragraph.find("./w:pPr/w:pStyle", NS)
    if style is None:
        return ""
    return style.attrib.get(f"{{{NS['w']}}}val", "")


def read_docx_blocks(docx: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(docx) as archive:
        xml = archive.read("word/document.xml")
    root = ET.fromstring(xml)
    body = root.find("w:body", NS)
    if body is None:
        return []
    blocks: list[dict[str, str]] = []
    for child in body:
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            text = para_text(child)
            if not text:
                continue
            style = paragraph_style(child)
            kind = "heading" if "Heading" in style or style.startswith(("1", "2", "3")) else "paragraph"
            blocks.append({"type": kind, "style": style, "text": text})
        elif tag == "tbl":
            rows: list[str] = []
            for row in child.findall(".//w:tr", NS):
                cells = [para_text(cell) for cell in row.findall("./w:tc", NS)]
                cells = [cell for cell in cells if cell]
                if cells:
                    rows.append(" | ".join(cells))
            if rows:
                blocks.append({"type": "table", "style": "table", "text": "\n".join(rows[:12])})
    return blocks


def compact_report_text(blocks: list[dict[str, str]], max_chars: int) -> str:
    lines: list[str] = []
    used = 0
    for block in blocks:
        prefix = {"heading": "## ", "table": "[TABLE] "}.get(block["type"], "")
        text = prefix + block["text"]
        if used + len(text) > max_chars:
            remaining = max_chars - used
            if remaining > 200:
                lines.append(text[:remaining])
            break
        lines.append(text)
        used += len(text) + 1
    return "\n".join(lines)


def infer_title(docx: Path, blocks: list[dict[str, str]]) -> str:
    for block in blocks[:20]:
        text = block["text"].strip()
        if 8 <= len(text) <= 80 and block["type"] == "heading":
            return text
    for block in blocks[:10]:
        text = block["text"].strip()
        if 8 <= len(text) <= 80:
            return text
    return docx.stem[:60]


def fallback_outline(docx: Path, blocks: list[dict[str, str]], slide_count: int) -> dict[str, Any]:
    title = infer_title(docx, blocks)
    headings = [b["text"] for b in blocks if b["type"] == "heading"]
    paragraphs = [b["text"] for b in blocks if b["type"] == "paragraph"]
    chapters = headings[: max(3, min(6, slide_count - 4))] or ["历史脉络", "观念转向", "权力图像"]

    slides: list[dict[str, Any]] = [
        {
            "page_role": "cover",
            "title": title,
            "subtitle": "人性、观念与权力的视觉演进",
            "visual_hint": "使用古典绘画局部、博物馆墙面或画布纹理作为抽象背景",
        },
        {"page_role": "agenda", "title": "研究路径", "items": chapters[:5]},
    ]
    role_cycle = ["timeline", "image_text_mix", "comparison", "artwork_analysis", "quote", "dense_text"]
    para_index = 0
    for i, chapter in enumerate(chapters, 1):
        if len(slides) >= slide_count - 1:
            break
        slides.append({"page_role": "chapter_divider", "title": chapter, "subtitle": f"第 {i} 部分"})
        if len(slides) >= slide_count - 1:
            break
        bullets = []
        while para_index < len(paragraphs) and len(bullets) < 4:
            text = re.sub(r"\s+", "", paragraphs[para_index])
            para_index += 1
            if 20 <= len(text) <= 160:
                bullets.append(text[:70])
        slides.append(
            {
                "page_role": role_cycle[(i - 1) % len(role_cycle)],
                "title": chapter,
                "bullets": bullets or ["提炼核心观点", "关联代表图像", "解释历史语境"],
                "visual_hint": "使用画作占位图、时间轴或对比图形表达这一节内容",
            }
        )
    slides.append({"page_role": "closing", "title": "结论", "subtitle": "视觉史也是一部人性、观念与权力的变迁史"})
    return {"title": title, "subtitle": "西方绘画史研究报告", "slides": slides[:slide_count]}


def outline_prompt(report_text: str, doc_title: str, slide_count: int) -> str:
    return f"""
Convert this long DOCX research report into a concise PPT outline.

Document title:
{doc_title}

Report text excerpt:
{report_text}

Return JSON only. Use Chinese.

Required shape:
{{
  "title": "deck title",
  "subtitle": "short deck subtitle",
  "slides": [
    {{
      "page_role": "cover|agenda|chapter_divider|timeline|image_text_mix|artwork_analysis|comparison|quote|dense_text|closing",
      "title": "slide title",
      "subtitle": "optional subtitle",
      "bullets": ["short point 1", "short point 2"],
      "items": ["agenda item"],
      "quote": "optional quote",
      "visual_hint": "what kind of image/diagram placeholder should appear"
    }}
  ]
}}

Rules:
- Create exactly {slide_count} slides.
- This is an art-history research deck, not a technical training deck.
- Use page roles that fit the content: timeline for historical evolution, artwork_analysis for paintings, comparison for periods/ideas, quote for a strong thesis, dense_text only when needed.
- Do not invent exact artwork images; use visual_hint placeholders such as "Renaissance portrait placeholder".
- Keep each slide concise enough for PPT.
""".strip()


def request_outline(report_text: str, doc_title: str, slide_count: int, model: str, api_key: str, base_url: str, timeout: int) -> dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You transform long reports into concise presentation outlines. Return valid JSON only."},
            {"role": "user", "content": outline_prompt(report_text, doc_title, slide_count)},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.25,
    }
    request = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    for attempt in range(1, 4):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Outline API error {exc.code}: {detail}") from exc
        except Exception:
            if attempt == 3:
                raise
            time.sleep(attempt * 3)
    else:
        raise RuntimeError("Outline API request failed.")
    return extract_json(response_text(payload))


def build_art_history_style(source_title: str) -> str:
    return f"""# Topic Template Style

- Source content: {source_title}
- Intended deck: art-history research presentation
- Page count target: 10-14

## Brand / Topic Policy

- This is not a company-branded deck. Do not preserve logos, product photos, or source-template brand marks.
- Treat images as content slots: artwork image placeholder, museum wall placeholder, archive/document placeholder.
- Use a refined museum/research visual style rather than corporate tech styling.
- Replace any brand-bound background with neutral art-history backgrounds.

## Deck-Level Visual DNA

- Overall tone: museum, archive, humanities research, restrained academic elegance.
- Palette: #F3EFE5 warm paper, #1E2528 charcoal ink, #8B1E2D burgundy, #B08D57 muted gold, #D8C7A1 parchment, #2F4F4F deep green-gray.
- Typography: high-contrast serif feeling for titles, clean sans-serif for notes. Use large readable Chinese text.
- Backgrounds: warm paper, subtle canvas texture made with SVG noise/opacity, muted gallery walls, simple frames.
- Do not use company logos, neon tech gradients, dashboard cards, or mobile-app icon metaphors.
- Visual placeholders should be framed like paintings or archival reproductions.

## Page Role Library

### cover
- Use case: report title, subtitle, author/date.
- Layout: large serif-style title over warm paper or muted gallery wall, one framed artwork placeholder on right or faint background.
- Palette: warm paper, charcoal, burgundy/gold accents.

### agenda
- Use case: research path and chapter overview.
- Layout: numbered vertical list with thin gold rules and small artwork thumbnails.

### chapter_divider
- Use case: section opening by historical period or idea.
- Layout: sparse page with huge chapter title, roman numeral or period label, one faint frame/texture.

### timeline
- Use case: historical evolution across periods.
- Layout: horizontal or vertical timeline with era nodes, muted gold line, short labels.

### image_text_mix
- Use case: one idea plus one representative visual.
- Layout: 40% text, 55% framed artwork placeholder; captions below image.

### artwork_analysis
- Use case: close reading of a painting or visual motif.
- Layout: large framed artwork placeholder with 2-4 callout annotations.

### comparison
- Use case: compare periods, ideas, patrons, power structures, or visual languages.
- Layout: two-column comparison with framed panels and concise bullets.

### quote
- Use case: strong thesis or interpretive sentence.
- Layout: centered quote, oversized punctuation, warm paper background.

### dense_text
- Use case: compact argument page.
- Layout: title top-left, 3-5 short argument blocks, thin dividers.

### closing
- Use case: conclusion and final synthesis.
- Layout: large final statement, subtle framed image placeholder, minimal footer.
"""


def read_optional_text(path: Path | None) -> str:
    if not path:
        return ""
    if not path.exists():
        raise FileNotFoundError(path)
    return path.read_text(encoding="utf-8-sig")


def summarize_template_style(template_style: str) -> str:
    """Keep reusable template facts without copying corrupted source text."""
    lines: list[str] = []
    keep_prefixes = (
        "#",
        "- Page count:",
        "- Palette:",
        "- Common patterns:",
        "- Font sizes:",
        "- Use case:",
        "- Pattern:",
        "- Regions:",
        "- Usage:",
    )
    for line in template_style.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("- Source") or stripped.startswith("- Fonts:"):
            continue
        if any(stripped.startswith(prefix) for prefix in keep_prefixes):
            lines.append(line)
    return "\n".join(lines[:180])


def summarize_brand_audit(brand_audit_path: Path | None) -> str:
    if not brand_audit_path:
        return "No brand audit was provided."
    if not brand_audit_path.exists():
        raise FileNotFoundError(brand_audit_path)
    if brand_audit_path.suffix.lower() == ".json":
        data = json.loads(brand_audit_path.read_text(encoding="utf-8-sig"))
        summary = data.get("summary", {})
        assets = summary.get("brand_assets", [])
        signals = summary.get("reusable_style_signals", [])
        high_binding = summary.get("high_binding_pages", [])
        lines = [
            f"- High content-binding pages: {', '.join('slide_' + str(x) for x in high_binding) if high_binding else 'none in sampled pages'}",
            "- Reusable style signals: " + ("; ".join(map(str, signals[:10])) if signals else "none listed"),
            "- Brand-bound assets:",
        ]
        if assets:
            for asset in assets[:12]:
                lines.append(
                    f"  - {asset.get('kind', 'asset')} `{asset.get('text_or_identity', 'unknown')}` at {asset.get('location', 'unknown')}: "
                    f"same-brand={asset.get('same_brand_policy')}, different-brand={asset.get('different_brand_policy')}"
                )
        else:
            lines.append("  - none detected")
        return "\n".join(lines)
    text = brand_audit_path.read_text(encoding="utf-8-sig")
    return "\n".join(text.splitlines()[:120])


def build_template_informed_style(
    source_title: str,
    template_style_path: Path,
    brand_audit_path: Path | None,
    target_brand: str | None,
    topic_hint: str | None,
) -> str:
    template_summary = summarize_template_style(read_optional_text(template_style_path))
    audit_summary = summarize_brand_audit(brand_audit_path)
    target = target_brand or "not specified"
    topic = topic_hint or "DOCX report topic"
    return f"""# Template-Informed Generation Style

- Source content: {source_title}
- Target brand: {target}
- Topic: {topic}
- Source template style file: {template_style_path}
- Brand audit file: {brand_audit_path or 'not provided'}

## Generation Policy

- This deck must reference the source PDF template's reusable visual system instead of inventing a new independent style.
- Preserve reusable template DNA: dominant palette, title placement, page density, margins, diagram rhythm, table treatment, recurring separators, and layout archetypes.
- Do not preserve content-bound imagery from the template unless it matches the new content.
- Do not preserve source-template logos, watermarks, brand names, product screenshots, or product photos when target brand differs from the source brand.
- If the target brand matches the source brand, preserve brand-bound assets only when the brand audit says same-brand `preserve`.
- If the target brand differs, replace brand colors with target brand colors only when requested; otherwise keep structural style while abstracting brand-bound visuals.
- For missing page roles, synthesize new layouts using the source template's visual language.
- Visible text must come from outline content tokens during SVG generation.

## Source Template Summary

{template_summary}

## Brand / Content Binding Audit

{audit_summary}

## Topic Adaptation Rules

- The content is: {topic}.
- Use the source template as the layout and visual-language reference.
- Use topic-appropriate visual placeholders instead of source-template business/product images.
- For art/history content, visual placeholders may be framed artwork, timeline nodes, archive cards, or comparison panels.
- For technical/business content, visual placeholders may be diagrams, screenshots, tables, metrics, or process modules.

## Page Role Library

### cover
- Use the source template's cover composition, background treatment, and title scale.
- Replace content-bound cover images with topic-appropriate visual placeholders.

### agenda
- Use the source template's list rhythm, numbering, section spacing, and accent rules.

### chapter_divider
- Use the source template's section-opening style. If missing, synthesize from cover/title pages.

### timeline
- If absent in the source template, synthesize using the template's line weight, accent color, and spacing.

### image_text_mix
- Use the template's text/visual balance; replace all source images with content slots.

### artwork_analysis
- Synthesized role: adapt image_text_mix or chart/diagram pages into one large framed visual plus callouts.

### comparison
- Use template table/comparison/card patterns if available.

### table
- Use the source template's table/module style.

### chart
- Use the source template's chart/diagram palette and spacing.

### process_flow
- Use the source template's flow arrows, module blocks, and left-to-right rhythm.

### quote
- Synthesized role: use the template's title typography and whitespace, with one strong centered statement.

### dense_text
- Use the source template's text page density and divider rules.

### closing
- Use the source template's closing/thanks composition.
"""


def build_strategy_md(outline: dict[str, Any]) -> str:
    lines = [
        "# PPT Content Strategy",
        "",
        f"- Title: {outline.get('title', '')}",
        f"- Subtitle: {outline.get('subtitle', '')}",
        "",
        "## Slide Plan",
        "",
    ]
    for index, slide in enumerate(outline.get("slides", []), 1):
        lines.append(f"### {index}. {slide.get('title', '')}")
        lines.append(f"- page_role: `{slide.get('page_role', 'text_explainer')}`")
        if slide.get("subtitle"):
            lines.append(f"- subtitle: {slide['subtitle']}")
        if slide.get("visual_hint"):
            lines.append(f"- visual: {slide['visual_hint']}")
        bullets = slide.get("bullets") or slide.get("items") or []
        if bullets:
            lines.append("- content: " + "; ".join(map(str, bullets[:5])))
        if slide.get("quote"):
            lines.append(f"- quote: {slide['quote']}")
        lines.append("")
    return "\n".join(lines)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert DOCX report to PPT outline, strategy, and topic template style.")
    parser.add_argument("docx", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--slide-count", type=int, default=10)
    parser.add_argument("--max-chars", type=int, default=24000)
    parser.add_argument("--model", default=os.environ.get("GLM_MODEL") or "glm-5")
    parser.add_argument("--base-url", default=os.environ.get("GLM_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or "https://yunwu.ai")
    parser.add_argument("--api-key-env", default=os.environ.get("GLM_API_KEY_ENV") or "GLM_API_KEY")
    parser.add_argument("--request-timeout", type=int, default=int(os.environ.get("GLM_REQUEST_TIMEOUT") or "240"))
    parser.add_argument("--no-model", action="store_true")
    parser.add_argument("--template-style", type=Path, help="Optional PDF-derived template_style.md to reference when generating the deck style.")
    parser.add_argument("--brand-audit", type=Path, help="Optional brand_asset_audit.json/md for source-template brand/content binding policy.")
    parser.add_argument("--target-brand", help="Target brand for the new deck, used with --brand-audit.")
    parser.add_argument("--topic-hint", help="Short topic/usage hint for adapting the template to the DOCX content.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    blocks = read_docx_blocks(args.docx)
    if not blocks:
        raise RuntimeError(f"No readable text found in {args.docx}")
    title = infer_title(args.docx, blocks)
    report_text = compact_report_text(blocks, args.max_chars)
    api_key = os.environ.get(args.api_key_env) or os.environ.get("OPENAI_API_KEY")
    if args.no_model or not api_key:
        outline = fallback_outline(args.docx, blocks, args.slide_count)
    else:
        outline = request_outline(report_text, title, args.slide_count, args.model, api_key, args.base_url, args.request_timeout)
    outline.setdefault("title", title)
    outline.setdefault("subtitle", "西方绘画史研究报告")
    outline["slides"] = (outline.get("slides") or [])[: args.slide_count]

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "outline.json").write_text(json.dumps(outline, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output_dir / "content_strategy.md").write_text(build_strategy_md(outline), encoding="utf-8")
    if args.template_style:
        style = build_template_informed_style(
            outline.get("title") or title,
            args.template_style,
            args.brand_audit,
            args.target_brand,
            args.topic_hint,
        )
    else:
        style = build_art_history_style(outline.get("title") or title)
    (args.output_dir / "template_style.md").write_text(style, encoding="utf-8")


if __name__ == "__main__":
    main()
