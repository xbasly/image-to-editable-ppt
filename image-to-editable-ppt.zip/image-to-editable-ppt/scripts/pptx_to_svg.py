#!/usr/bin/env python
"""Convert PPTX slides directly to semantic, slot-annotated SVG files."""

from __future__ import annotations

import argparse
import base64
import html
import re
from pathlib import Path
from dataclasses import dataclass
from typing import Any, Iterable, Tuple

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE


EMU_PER_POINT = 12700


def pt(value: int | float | None) -> float:
    return round(float(value or 0) / EMU_PER_POINT, 3)


def slot_id(text: str, index: int) -> str:
    value = re.sub(r"[^a-zA-Z0-9\u4e00-\u9fff]+", "_", text.strip().lower()).strip("_")
    if not value:
        value = "slot"
    return f"{value}_{index}"


def color_value(color: Any, fallback: str = "none") -> str:
    if color is None:
        return fallback
    try:
        rgb = color.rgb
        if rgb:
            return f"#{rgb}"
    except Exception:
        pass
    return fallback


def fill_color(shape: Any) -> str:
    try:
        if not shape.fill or shape.fill.type is None:
            return "none"
        return color_value(shape.fill.fore_color, "none")
    except Exception:
        return "none"


def stroke_color(shape: Any) -> str:
    try:
        if not shape.line or shape.line.fill.type is None:
            return "none"
        return color_value(shape.line.color, "none")
    except Exception:
        return "none"


def stroke_width(shape: Any) -> float:
    try:
        return max(0.5, pt(shape.line.width))
    except Exception:
        return 0.5


def font_color(run: Any) -> str:
    try:
        value = color_value(run.font.color, "")
        if value:
            return value
    except Exception:
        pass
    return "#111111"


def font_size(run: Any, fallback: float = 18.0) -> float:
    try:
        if run.font.size:
            return pt(run.font.size)
    except Exception:
        pass
    return fallback


def font_family(run: Any) -> str:
    try:
        if run.font.name:
            return run.font.name
    except Exception:
        pass
    return "Microsoft YaHei"


def shape_text(shape: Any) -> str:
    try:
        return shape.text.strip()
    except Exception:
        return ""


@dataclass(frozen=True)
class Transform:
    sx: float = 1.0
    sy: float = 1.0
    tx: float = 0.0
    ty: float = 0.0

    def x(self, value: int | float | None) -> float:
        return self.sx * float(value or 0) + self.tx

    def y(self, value: int | float | None) -> float:
        return self.sy * float(value or 0) + self.ty

    def w(self, value: int | float | None) -> float:
        return self.sx * float(value or 0)

    def h(self, value: int | float | None) -> float:
        return self.sy * float(value or 0)


ShapeItem = Tuple[Any, Transform]


def xfrm_value(xfrm: Any, name: str, attr: str, fallback: int) -> int:
    node = getattr(xfrm, name, None)
    if node is not None and getattr(node, attr, None) is not None:
        return int(getattr(node, attr))
    match = re.search(fr"<a:{name}[^>]*\s{attr}=\"(-?\d+)\"", xfrm.xml)
    return int(match.group(1)) if match else fallback


def child_transform(group: Any, parent: Transform) -> Transform:
    xfrm = group._element.grpSpPr.xfrm
    ch_off_x = xfrm_value(xfrm, "chOff", "x", 0)
    ch_off_y = xfrm_value(xfrm, "chOff", "y", 0)
    ch_ext_x = max(1, xfrm_value(xfrm, "chExt", "cx", int(group.width or 1)))
    ch_ext_y = max(1, xfrm_value(xfrm, "chExt", "cy", int(group.height or 1)))
    group_x = parent.x(group.left)
    group_y = parent.y(group.top)
    sx = parent.w(group.width) / ch_ext_x
    sy = parent.h(group.height) / ch_ext_y
    return Transform(sx=sx, sy=sy, tx=group_x - sx * ch_off_x, ty=group_y - sy * ch_off_y)


def iter_shapes(shapes: Iterable[Any], transform: Transform = Transform()) -> Iterable[ShapeItem]:
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(shape.shapes, child_transform(shape, transform))
        else:
            yield shape, transform


def bounds(shape: Any, transform: Transform) -> tuple[float, float, float, float]:
    return (
        pt(transform.x(shape.left)),
        pt(transform.y(shape.top)),
        pt(transform.w(shape.width)),
        pt(transform.h(shape.height)),
    )


def render_text(shape: Any, index: int, transform: Transform) -> str:
    x, y, w, h = bounds(shape, transform)
    paragraphs = list(shape.text_frame.paragraphs)
    lines: list[str] = []
    first_run = None
    for paragraph in paragraphs:
        line = "".join(run.text for run in paragraph.runs).strip()
        if line:
            lines.append(line)
            if first_run is None and paragraph.runs:
                first_run = paragraph.runs[0]
    if not lines:
        lines = ["文本"]
    sid = slot_id("text", index)
    size = font_size(first_run, max(8.0, min(24.0, h * 0.45))) if first_run else max(8.0, min(24.0, h * 0.45))
    family = font_family(first_run) if first_run else "Microsoft YaHei"
    fill = font_color(first_run) if first_run else "#111111"
    bold = "700" if first_run is not None and bool(first_run.font.bold) else "400"
    tspans = []
    for line_index, line in enumerate(lines):
        dy = 0 if line_index == 0 else size * 1.25
        tspans.append(f'<tspan x="{x:.3f}" dy="{dy:.3f}">{html.escape(line)}</tspan>')
    return (
        f'<text x="{x:.3f}" y="{y + size:.3f}" data-slot-id="{sid}" data-type="text" data-role="body" '
        f'data-box-x="{x:.3f}" data-box-y="{y:.3f}" data-box-w="{w:.3f}" data-box-h="{h:.3f}" '
        f'font-family="{html.escape(family)}" font-size="{size:.3f}" font-weight="{bold}" fill="{fill}">'
        f'{"".join(tspans)}</text>'
    )


def render_picture(shape: Any, index: int, embed_images: bool, transform: Transform) -> str:
    x, y, w, h = bounds(shape, transform)
    sid = slot_id("image", index)
    if embed_images:
        try:
            image = shape.image
            ext = image.ext.lower()
            mime = "jpeg" if ext in {"jpg", "jpeg"} else ext
            data = base64.b64encode(image.blob).decode("ascii")
            return (
                f'<image x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" '
                f'data-slot-id="{sid}" data-type="image" data-role="image" '
                f'href="data:image/{mime};base64,{data}" />'
            )
        except Exception:
            pass
    return (
        f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" '
        f'data-slot-id="{sid}" data-type="image" data-role="image" fill="#E8E8E8" stroke="#CCCCCC" />'
    )


def render_line(shape: Any, index: int, transform: Transform) -> str:
    x, y, w, h = bounds(shape, transform)
    sid = slot_id("line", index)
    return (
        f'<line x1="{x:.3f}" y1="{y:.3f}" x2="{x + w:.3f}" y2="{y + h:.3f}" '
        f'data-slot-id="{sid}" data-type="line" data-role="separator" '
        f'stroke="{stroke_color(shape)}" stroke-width="{stroke_width(shape):.3f}" />'
    )


def render_shape(shape: Any, index: int, transform: Transform) -> str:
    if getattr(shape, "has_text_frame", False) and shape_text(shape):
        return render_text(shape, index, transform)
    if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
        return render_picture(shape, index, embed_images=True, transform=transform)
    if shape.shape_type in {MSO_SHAPE_TYPE.LINE, MSO_SHAPE_TYPE.FREEFORM}:
        return render_line(shape, index, transform)
    x, y, w, h = bounds(shape, transform)
    sid = slot_id("shape", index)
    fill = fill_color(shape)
    stroke = stroke_color(shape)
    common = (
        f'data-slot-id="{sid}" data-type="shape" data-role="graphic" '
        f'fill="{fill}" stroke="{stroke}" stroke-width="{stroke_width(shape):.3f}"'
    )
    try:
        name = str(shape.auto_shape_type).lower()
    except Exception:
        name = ""
    if "oval" in name or "ellipse" in name:
        return (
            f'<ellipse cx="{x + w / 2:.3f}" cy="{y + h / 2:.3f}" rx="{w / 2:.3f}" ry="{h / 2:.3f}" '
            f'{common} />'
        )
    return f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" {common} />'


def slide_to_svg(slide: Any, width: float, height: float, prefix: str, slide_index: int) -> str:
    body = [f'<rect x="0" y="0" width="{width:.3f}" height="{height:.3f}" fill="#FFFFFF" />']
    for index, (shape, transform) in enumerate(iter_shapes(slide.shapes), 1):
        try:
            body.append(render_shape(shape, index, transform))
        except Exception as exc:
            x, y, w, h = bounds(shape, transform)
            sid = slot_id("unsupported", index)
            body.append(
                f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" '
                f'data-slot-id="{sid}" data-type="graphic" data-role="graphic" '
                f'fill="#F2F2F2" stroke="#CCCCCC"><title>{html.escape(str(exc))}</title></rect>'
            )
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
        f'width="{width:.3f}" height="{height:.3f}" viewBox="0 0 {width:.3f} {height:.3f}" '
        f'data-slide-id="{prefix}_{slide_index}">\n'
        + "\n".join(body)
        + "\n</svg>\n"
    )


def convert_pptx_to_svg(pptx_path: Path, output_dir: Path, prefix: str = "slide") -> None:
    prs = Presentation(str(pptx_path))
    width = pt(prs.slide_width)
    height = pt(prs.slide_height)
    output_dir.mkdir(parents=True, exist_ok=True)
    for index, slide in enumerate(prs.slides, 1):
        svg = slide_to_svg(slide, width, height, prefix, index)
        (output_dir / f"{prefix}_{index}.svg").write_text(svg, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert PPTX slides directly to semantic SVG files.")
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--prefix", default="slide")
    parser.add_argument("--keep-pdf", type=Path, help="Deprecated compatibility option; PPTX is no longer converted through PDF.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    convert_pptx_to_svg(args.pptx, args.output_dir, args.prefix)


if __name__ == "__main__":
    main()
