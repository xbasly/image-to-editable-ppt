#!/usr/bin/env python
"""Extract reusable PPT template schema from slide screenshots.

The schema is intentionally higher-level than PPTX shapes. It describes reusable
slots (title, body, image, logo, feature item, etc.) so later content can fill
the same layout without re-analyzing the screenshot.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

from PIL import Image

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from analyze_slide_layout import extract_json, image_to_data_url, normalize_base_url  # noqa: E402
from hybrid_analyze_slide_layout import build_candidates  # noqa: E402


PROMPT = """Label deterministic slide template slots from this screenshot.

You will receive deterministic candidate boxes from image processing. You are a
semantic labeler, not a layout generator.

Important:
- Do NOT change x, y, w, h.
- Do NOT invent new slots.
- Exception: you may add a small number of missing_slots only for logos, large graphics, photos, charts, or decorative image placeholders that code failed to detect.
- Do not add missing text slots.
- Do NOT omit candidates unless they are clearly noise.
- Use candidate IDs exactly.
- Label each candidate with slot type, role, placeholder, and style patch.
- Complex logos, brand marks, abstract graphics, photos, screenshots, charts, and maps should be image/graphic/logo slots.
- Numbered feature blocks, city labels, titles, captions, and body text should remain text slots.
- If a repeated structure exists, add repeat_group metadata to each item, but keep each item slot separate.
- Capture typography as style tokens: sans, serif, mono; weight; approximate font size; color.

Return JSON only in this shape:
{
  "slide_type": "intro_with_feature_grid",
  "theme_patch": {
    "background": "#FFFFFF",
    "primary": "#111111",
    "secondary": "#666666",
    "muted": "#999999",
    "accent": "#5B8FD6",
    "font_family": "sans"
  },
  "slot_patches": [
    {
      "candidate_id": "c1",
      "keep": true,
      "id": "main_title",
      "type": "text|image|graphic|logo|shape|line",
      "role": "title",
      "placeholder": "Title",
      "style": {
        "font_family": "sans",
        "font_size": 18,
        "bold": true,
        "color": "#111111",
        "align": "left",
        "fill": "#EEEEEE",
        "stroke": "#EEEEEE"
      },
      "repeat_group": {"id": "feature_grid", "index": 1, "count": 4, "role": "feature_item"}
    }
  ],
  "missing_slots": [
    {
      "id": "brand_logo",
      "type": "logo|graphic|image",
      "role": "logo",
      "x": 0.04,
      "y": 0.05,
      "w": 0.05,
      "h": 0.08,
      "placeholder": "Logo",
      "style": {"fill": "#E8E8E8", "stroke": "#E8E8E8"}
    }
  ],
  "notes": "brief labeling notes"
}
"""


def rgb_to_hex(color: str | tuple[int, int, int]) -> str:
    if isinstance(color, str):
        return color
    return f"#{color[0]:02X}{color[1]:02X}{color[2]:02X}"


def candidate_to_slot(candidate: Dict[str, Any], index: int) -> Dict[str, Any]:
    kind = candidate.get("type", "shape")
    role = {
        "media": "image",
        "logo": "logo",
        "rect": "panel",
        "line": "separator",
        "text": "body",
    }.get(kind, "content")
    slot_type = {
        "media": "image",
        "rect": "shape",
        "line": "line",
        "text": "text",
    }.get(kind, kind)
    style: Dict[str, Any] = {}
    color = candidate.get("color")
    if slot_type == "text":
        style.update(
            {
                "font_family": "sans",
                "font_size": candidate.get("font_size", 10),
                "bold": False,
                "color": color or "#111111",
                "align": "left",
            }
        )
    else:
        style.update({"fill": candidate.get("fill") or color or "#E6E6E6", "stroke": candidate.get("stroke") or color or "#E6E6E6"})
    return {
        "id": candidate.get("id") or f"c{index}",
        "candidate_id": candidate.get("id") or f"c{index}",
        "type": slot_type,
        "role": role,
        "x": candidate.get("x", 0),
        "y": candidate.get("y", 0),
        "w": candidate.get("w", 0.1),
        "h": candidate.get("h", 0.1),
        "placeholder": candidate.get("label") or candidate.get("text") or role.title(),
        "style": style,
    }


def candidates_to_base_slide(candidates: Dict[str, Any], slide_index: int, image_path: Path) -> Dict[str, Any]:
    width = candidates["width"]
    height = candidates["height"]
    slots = [
        candidate_to_slot(candidate, i)
        for i, candidate in enumerate(candidates.get("candidates", []), 1)
    ]
    bg = candidates.get("background", "#FFFFFF")
    theme = {
        "background": bg,
        "primary": "#FFFFFF" if bg.lower() in {"#000000", "#000"} else "#111111",
        "secondary": "#AAAAAA" if bg.lower() in {"#000000", "#000"} else "#666666",
        "muted": "#777777" if bg.lower() in {"#000000", "#000"} else "#999999",
        "accent": "#5B8FD6",
        "font_family": "sans",
    }
    return {
        "id": f"slide_{slide_index}",
        "slide_type": "extracted_layout",
        "canvas": {"width": width, "height": height, "aspect": round(width / height, 4)},
        "grid": {"columns": 12, "margin_x": 0.08, "margin_y": 0.06, "gutter": 0.016},
        "theme": theme,
        "slots": slots,
        "notes": "Base schema from deterministic image-processing candidates.",
        "source_image": str(image_path),
    }


def deterministic_schema(image_paths: List[Path]) -> Dict[str, Any]:
    slides: List[Dict[str, Any]] = []
    for slide_index, image_path in enumerate(image_paths, 1):
        candidates = build_candidates(image_path)
        slides.append(candidates_to_base_slide(candidates, slide_index, image_path))
    return {"schema_version": "1.0", "slides": slides}


def compact_candidates(base_slide: Dict[str, Any]) -> List[Dict[str, Any]]:
    compact = []
    for slot in base_slide.get("slots", []):
        compact.append(
            {
                "candidate_id": slot.get("candidate_id"),
                "type": slot.get("type"),
                "role": slot.get("role"),
                "x": slot.get("x"),
                "y": slot.get("y"),
                "w": slot.get("w"),
                "h": slot.get("h"),
                "placeholder": slot.get("placeholder"),
                "style": slot.get("style", {}),
            }
        )
    return compact


def apply_patch_to_base_slide(base_slide: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
    base_slide["slide_type"] = patch.get("slide_type") or base_slide.get("slide_type")
    base_slide["theme"].update(patch.get("theme_patch") or {})
    patches = {
        item.get("candidate_id"): item
        for item in patch.get("slot_patches", [])
        if item.get("candidate_id")
    }
    updated_slots = []
    seen_ids: set[str] = set()
    for slot in base_slide.get("slots", []):
        item = patches.get(slot.get("candidate_id"))
        if item and item.get("keep") is False:
            continue
        if item:
            old_geometry = {k: slot.get(k) for k in ("x", "y", "w", "h")}
            for key in ("id", "type", "role", "placeholder", "repeat_group"):
                if key in item and item[key] is not None:
                    slot[key] = item[key]
            slot.setdefault("style", {}).update(item.get("style") or {})
            slot.update(old_geometry)
        normalize_slot_style(slot, base_slide["theme"])
        slot["id"] = unique_id(str(slot.get("id") or slot.get("candidate_id") or "slot"), seen_ids)
        updated_slots.append(slot)
    for missing in patch.get("missing_slots", []) or []:
        if missing.get("type") not in {"logo", "graphic", "image"}:
            continue
        slot = {
            "id": missing.get("id") or missing.get("role") or "missing_visual",
            "type": missing.get("type"),
            "role": missing.get("role") or missing.get("type"),
            "x": clamp01(missing.get("x"), 0),
            "y": clamp01(missing.get("y"), 0),
            "w": clamp01(missing.get("w"), 0.1),
            "h": clamp01(missing.get("h"), 0.1),
            "placeholder": missing.get("placeholder") or missing.get("role") or missing.get("type"),
            "style": missing.get("style") or {},
        }
        normalize_slot_style(slot, base_slide["theme"])
        slot["id"] = unique_id(str(slot["id"]), seen_ids)
        updated_slots.append(slot)
    base_slide["slots"] = updated_slots
    if patch.get("notes"):
        base_slide["notes"] = patch["notes"]
    return base_slide


def clamp01(value: Any, fallback: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = fallback
    return max(0.0, min(1.0, number))


def parse_hex(value: str | None, fallback: tuple[int, int, int]) -> tuple[int, int, int]:
    if not value:
        return fallback
    value = str(value).strip()
    if value.startswith("#"):
        value = value[1:]
    if len(value) != 6:
        return fallback
    try:
        return (int(value[:2], 16), int(value[2:4], 16), int(value[4:], 16))
    except ValueError:
        return fallback


def luminance(color: tuple[int, int, int]) -> float:
    return 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2]


def contrast(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    return abs(luminance(a) - luminance(b))


def normalize_slot_style(slot: Dict[str, Any], theme: Dict[str, Any]) -> None:
    style = slot.setdefault("style", {})
    bg = parse_hex(theme.get("background"), (255, 255, 255))
    bg_luma = luminance(bg)
    if slot.get("type") == "text":
        color = parse_hex(style.get("color"), (255, 255, 255) if bg_luma < 80 else (17, 17, 17))
        if contrast(color, bg) < 70:
            if bg_luma < 80:
                color = (245, 245, 245) if slot.get("role") in {"title", "body", "label"} else (170, 170, 170)
            else:
                color = (20, 20, 20) if slot.get("role") in {"title", "body", "label"} else (120, 120, 120)
        style["color"] = rgb_to_hex(color)
        style.setdefault("font_family", theme.get("font_family", "sans"))
        if not style.get("font_size"):
            style["font_size"] = 10
    elif slot.get("type") in {"image", "graphic", "logo"}:
        style.setdefault("fill", "#E8E8E8")
        style.setdefault("stroke", style.get("fill", "#E8E8E8"))


def unique_id(base: str, seen: set[str]) -> str:
    clean = "".join(ch if ch.isalnum() or ch in {"_", "-"} else "_" for ch in base).strip("_") or "slot"
    candidate = clean
    index = 2
    while candidate in seen:
        candidate = f"{clean}_{index}"
        index += 1
    seen.add(candidate)
    return candidate


def request_schema_patch(image_path: Path, base_slide: Dict[str, Any], model: str, api_key: str, base_url: str, timeout: int) -> Dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"{PROMPT}\n\nCandidate slots:\n{json.dumps(compact_candidates(base_slide), ensure_ascii=False)}",
                    },
                    {"type": "image_url", "image_url": {"url": image_to_data_url(image_path)}},
                ],
            }
        ],
        "response_format": {"type": "json_object"},
    }
    req = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Vision API error {exc.code}: {detail}") from exc

    return extract_json(payload["choices"][0]["message"]["content"])


def extract_schema(image_paths: List[Path], output: Path, model: str, base_url: str, timeout: int, no_vision: bool) -> None:
    api_key = os.environ.get("YUNWU_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if no_vision or not api_key:
        schema = deterministic_schema(image_paths)
    else:
        slides = []
        for i, image_path in enumerate(image_paths, 1):
            candidates = build_candidates(image_path)
            base_slide = candidates_to_base_slide(candidates, i, image_path)
            patch = request_schema_patch(image_path, base_slide, model, api_key, base_url, timeout)
            slides.append(apply_patch_to_base_slide(base_slide, patch))
        schema = {"schema_version": "1.0", "slides": slides}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(schema, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract reusable PPT template schema from slide screenshots.")
    parser.add_argument("images", nargs="+", type=Path)
    parser.add_argument("-o", "--output", required=True, type=Path)
    parser.add_argument("--model", default="qwen3.5-397b-a17b")
    parser.add_argument("--base-url", default=os.environ.get("YUNWU_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or "https://yunwu.ai")
    parser.add_argument("--request-timeout", type=int, default=240)
    parser.add_argument("--no-vision", action="store_true", help="Use deterministic image-processing candidates only.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    extract_schema(args.images, args.output, args.model, args.base_url, args.request_timeout, args.no_vision)


if __name__ == "__main__":
    main()
