#!/usr/bin/env python
"""Fill a template schema with new content data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict


def apply_content(schema: Dict[str, Any], content: Dict[str, Any]) -> Dict[str, Any]:
    slides_content = content.get("slides", {})
    global_slots = content.get("slots", {})
    for slide_index, slide in enumerate(schema.get("slides", []), 1):
        slide_id = slide.get("id") or f"slide_{slide_index}"
        slide_content = slides_content.get(slide_id, {}) if isinstance(slides_content, dict) else {}
        slot_content = {**global_slots, **slide_content.get("slots", {})}
        for slot in slide.get("slots", []):
            slot_id = slot.get("id")
            role = slot.get("role")
            value = None
            if slot_id in slot_content:
                value = slot_content[slot_id]
            elif role in slot_content:
                value = slot_content[role]
            if value is None:
                continue
            if isinstance(value, dict):
                if "content" in value:
                    slot["content"] = value["content"]
                if "placeholder" in value:
                    slot["placeholder"] = value["placeholder"]
                if "style" in value:
                    slot.setdefault("style", {}).update(value["style"])
                if "asset" in value:
                    slot["asset"] = value["asset"]
            else:
                slot["content"] = str(value)
    return schema


def fill_template(schema_path: Path, content_path: Path, output: Path) -> None:
    schema = json.loads(schema_path.read_text(encoding="utf-8-sig"))
    content = json.loads(content_path.read_text(encoding="utf-8-sig"))
    filled = apply_content(schema, content)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(filled, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fill template schema slots with content JSON.")
    parser.add_argument("--schema", required=True, type=Path)
    parser.add_argument("--content", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    fill_template(args.schema, args.content, args.output)


if __name__ == "__main__":
    main()
