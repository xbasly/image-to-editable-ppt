#!/usr/bin/env python
"""Extract PPTX facts, reusable assets, and native PowerPoint slide previews."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Tuple
from xml.etree import ElementTree as ET

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE


EMU_PER_POINT = 12700
NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
}


@dataclass(frozen=True)
class Transform:
    sx: float = 1.0
    sy: float = 1.0
    tx: float = 0.0
    ty: float = 0.0

    def x(self, value: int | float | None) -> float:
        return self.sx * float(value or 0) + self.tx

    def y(self, value: int | float | None) -> float:
        return self.sy * float(value or 0) + self.ty

    def w(self, value: int | float | None) -> float:
        return self.sx * float(value or 0)

    def h(self, value: int | float | None) -> float:
        return self.sy * float(value or 0)


ShapeItem = Tuple[Any, Transform]


def pt(value: int | float | None) -> float:
    return round(float(value or 0) / EMU_PER_POINT, 3)


def xml_attr_int(xml: str, name: str, attr: str, fallback: int) -> int:
    match = re.search(fr"<a:{name}[^>]*\s{attr}=\"(-?\d+)\"", xml)
    return int(match.group(1)) if match else fallback


def child_transform(group: Any, parent: Transform) -> Transform:
    xfrm = group._element.grpSpPr.xfrm
    xml = xfrm.xml
    ch_off_x = xml_attr_int(xml, "chOff", "x", 0)
    ch_off_y = xml_attr_int(xml, "chOff", "y", 0)
    ch_ext_x = max(1, xml_attr_int(xml, "chExt", "cx", int(group.width or 1)))
    ch_ext_y = max(1, xml_attr_int(xml, "chExt", "cy", int(group.height or 1)))
    group_x = parent.x(group.left)
    group_y = parent.y(group.top)
    sx = parent.w(group.width) / ch_ext_x
    sy = parent.h(group.height) / ch_ext_y
    return Transform(sx=sx, sy=sy, tx=group_x - sx * ch_off_x, ty=group_y - sy * ch_off_y)


def iter_shapes(shapes: Iterable[Any], transform: Transform = Transform()) -> Iterable[ShapeItem]:
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(shape.shapes, child_transform(shape, transform))
        else:
            yield shape, transform


def bounds(shape: Any, transform: Transform) -> dict[str, float]:
    return {
        "x": pt(transform.x(shape.left)),
        "y": pt(transform.y(shape.top)),
        "w": pt(transform.w(shape.width)),
        "h": pt(transform.h(shape.height)),
    }


def color_value(color: Any, fallback: str | None = None) -> str | None:
    try:
        rgb = color.rgb
        if rgb:
            return f"#{rgb}"
    except Exception:
        pass
    return fallback


def fill_color(shape: Any) -> str | None:
    try:
        if shape.fill and shape.fill.type is not None:
            return color_value(shape.fill.fore_color)
    except Exception:
        pass
    return None


def stroke_color(shape: Any) -> str | None:
    try:
        if shape.line and shape.line.fill.type is not None:
            return color_value(shape.line.color)
    except Exception:
        pass
    return None


def font_name(run: Any) -> str | None:
    try:
        return run.font.name
    except Exception:
        return None


def font_size(run: Any) -> float | None:
    try:
        if run.font.size:
            return pt(run.font.size)
    except Exception:
        pass
    return None


def effect_flags(shape: Any) -> dict[str, Any]:
    xml = shape._element.xml
    flags: dict[str, Any] = {}
    if "outerShdw" in xml or "innerShdw" in xml:
        flags["shadow"] = True
    if "glow" in xml:
        flags["glow"] = True
    if "gradFill" in xml:
        flags["gradient"] = True
    if "alphaModFix" in xml or "alpha" in xml:
        flags["alpha"] = True
    return flags


def transform_flags(shape: Any) -> dict[str, Any]:
    xml = shape._element.xml
    match = re.search(r"<a:xfrm([^>]*)>", xml)
    if not match:
        return {}
    attrs = match.group(1)
    flags: dict[str, Any] = {}
    if re.search(r'flipH="1"|flipH="true"', attrs):
        flags["flip_h"] = True
    if re.search(r'flipV="1"|flipV="true"', attrs):
        flags["flip_v"] = True
    rot_match = re.search(r'rot="(-?\d+)"', attrs)
    if rot_match:
        flags["rotation"] = round(int(rot_match.group(1)) / 60000.0, 3)
    return flags


def crop_values(shape: Any) -> dict[str, float] | None:
    try:
        xml = shape._element.xml
        match = re.search(r"<a:srcRect([^>]*)/>", xml)
        if not match:
            return None
        values = {}
        for key in ("l", "t", "r", "b"):
            item = re.search(fr'{key}="(-?\d+)"', match.group(1))
            if item:
                values[key] = int(item.group(1)) / 100000.0
        return values or None
    except Exception:
        return None


def save_picture(shape: Any, assets_dir: Path, cache: dict[str, str]) -> str | None:
    try:
        image = shape.image
        blob = image.blob
        digest = hashlib.sha1(blob).hexdigest()[:12]
        ext = image.ext or "png"
        name = cache.get(digest) or f"image_{len(cache) + 1:03d}.{ext}"
        cache[digest] = name
        path = assets_dir / name
        if not path.exists():
            path.write_bytes(blob)
        return f"assets/{name}"
    except Exception:
        return None


def text_runs(shape: Any) -> list[dict[str, Any]]:
    runs = []
    if not getattr(shape, "has_text_frame", False):
        return runs
    for p_index, paragraph in enumerate(shape.text_frame.paragraphs):
        for run in paragraph.runs:
            if not run.text:
                continue
            runs.append(
                {
                    "paragraph": p_index,
                    "text": run.text,
                    "font": font_name(run),
                    "size": font_size(run),
                    "bold": bool(run.font.bold),
                    "italic": bool(run.font.italic),
                    "color": color_value(run.font.color, "#111111"),
                }
            )
    return runs


def shape_record(shape: Any, index: int, transform: Transform, assets_dir: Path, image_cache: dict[str, str]) -> dict[str, Any]:
    record: dict[str, Any] = {
        "id": f"shape_{index}",
        "name": getattr(shape, "name", ""),
        "shape_type": str(shape.shape_type),
        "box": bounds(shape, transform),
        "effects": effect_flags(shape),
    }
    transform_flags_value = transform_flags(shape)
    if transform_flags_value:
        record["transform"] = transform_flags_value
    if getattr(shape, "has_text_frame", False) and shape.text.strip():
        record.update(
            {
                "type": "text",
                "text": shape.text,
                "runs": text_runs(shape),
                "fill": fill_color(shape),
                "stroke": stroke_color(shape),
            }
        )
    elif shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
        record.update(
            {
                "type": "image",
                "asset": save_picture(shape, assets_dir, image_cache),
                "crop": crop_values(shape),
            }
        )
    elif shape.shape_type in {MSO_SHAPE_TYPE.LINE, MSO_SHAPE_TYPE.FREEFORM}:
        record.update({"type": "line", "stroke": stroke_color(shape)})
    else:
        record.update({"type": "shape", "fill": fill_color(shape), "stroke": stroke_color(shape)})
    return record


def theme_info(pptx_path: Path) -> dict[str, Any]:
    info: dict[str, Any] = {"colors": {}, "fonts": {}}
    with zipfile.ZipFile(pptx_path) as zf:
        theme_names = [name for name in zf.namelist() if name.startswith("ppt/theme/theme") and name.endswith(".xml")]
        if not theme_names:
            return info
        root = ET.fromstring(zf.read(theme_names[0]))
    for color in root.findall(".//a:clrScheme/*", NS):
        srgb = color.find(".//a:srgbClr", NS)
        if srgb is not None and "val" in srgb.attrib:
            info["colors"][color.tag.split("}", 1)[-1]] = f"#{srgb.attrib['val']}"
    for tag in ("majorFont", "minorFont"):
        latin = root.find(f".//a:{tag}/a:latin", NS)
        east = root.find(f".//a:{tag}/a:ea", NS)
        info["fonts"][tag] = {
            "latin": latin.attrib.get("typeface") if latin is not None else None,
            "eastAsia": east.attrib.get("typeface") if east is not None else None,
        }
    return info


def export_previews(pptx_path: Path, preview_dir: Path, width: int = 1500, height: int = 844) -> None:
    preview_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "pptx": str(pptx_path.resolve()),
        "out": str(preview_dir.resolve()),
        "width": width,
        "height": height,
    }
    script = r"""
param([string]$PayloadPath)
$payload = Get-Content -LiteralPath $PayloadPath -Raw | ConvertFrom-Json
$pp = New-Object -ComObject PowerPoint.Application
$pres = $null
try {
  $pres = $pp.Presentations.Open($payload.pptx, $false, $false, $false)
  for ($i=1; $i -le $pres.Slides.Count; $i++) {
    $target = Join-Path $payload.out ("slide_{0}.png" -f $i)
    $pres.Slides.Item($i).Export($target, "PNG", [int]$payload.width, [int]$payload.height)
  }
}
finally {
  if ($pres -ne $null) { $pres.Close() }
  $pp.Quit()
}
"""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        payload_path = tmp_path / "payload.json"
        script_path = tmp_path / "export_previews.ps1"
        payload_path.write_text(json.dumps(payload), encoding="utf-8")
        script_path.write_text(script, encoding="utf-8")
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path), str(payload_path)],
            check=True,
        )


def extract_pptx_facts(pptx_path: Path, output_dir: Path, export_preview_images: bool = True) -> None:
    assets_dir = output_dir / "assets"
    slides_dir = output_dir / "slides"
    preview_dir = output_dir / "previews"
    assets_dir.mkdir(parents=True, exist_ok=True)
    slides_dir.mkdir(parents=True, exist_ok=True)

    prs = Presentation(str(pptx_path))
    canvas = {"width": pt(prs.slide_width), "height": pt(prs.slide_height), "unit": "pt"}
    image_cache: dict[str, str] = {}
    slides = []
    for slide_index, slide in enumerate(prs.slides, 1):
        records = [
            shape_record(shape, index, transform, assets_dir, image_cache)
            for index, (shape, transform) in enumerate(iter_shapes(slide.shapes), 1)
        ]
        slide_data = {
            "id": f"slide_{slide_index}",
            "index": slide_index,
            "canvas": canvas,
            "preview": f"previews/slide_{slide_index}.png",
            "objects": records,
        }
        (slides_dir / f"slide_{slide_index}.json").write_text(
            json.dumps(slide_data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        slides.append(slide_data)

    manifest = {
        "source": str(pptx_path),
        "canvas": canvas,
        "theme": theme_info(pptx_path),
        "slides": [
            {"id": slide["id"], "index": slide["index"], "object_count": len(slide["objects"]), "preview": slide["preview"]}
            for slide in slides
        ],
        "assets": sorted(path.name for path in assets_dir.glob("*")),
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    if export_preview_images:
        export_previews(pptx_path, preview_dir)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract PPTX facts and native slide previews.")
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--skip-previews", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    extract_pptx_facts(args.pptx, args.output_dir, not args.skip_previews)


if __name__ == "__main__":
    main()
