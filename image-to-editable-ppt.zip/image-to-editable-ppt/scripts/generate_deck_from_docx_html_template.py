#!/usr/bin/env python
"""Generate a PPTX preview deck from DOCX content and an HTML template system."""

from __future__ import annotations

import argparse
import html
import json
import os
import re
import shutil
import subprocess
import urllib.error
import urllib.request
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any


NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}


ROLE_SEQUENCE = [
    "cover",
    "agenda",
    "chapter_cover",
    "timeline",
    "image",
    "text",
    "table",
    "chapter_cover",
    "image",
    "text",
    "quote",
    "chart",
    "data_support",
    "summary",
]


def read_docx_text(docx: Path, max_chars: int) -> str:
    with zipfile.ZipFile(docx) as zf:
        xml = zf.read("word/document.xml")
    root = ET.fromstring(xml)
    parts: list[str] = []
    for para in root.findall(".//w:p", NS):
        text = "".join(node.text or "" for node in para.findall(".//w:t", NS)).strip()
        if text:
            parts.append(text)
    text = "\n".join(parts)
    return text[:max_chars]


def normalize_base_url(base_url: str) -> str:
    base_url = base_url.rstrip("/")
    return base_url if base_url.endswith("/v1") else f"{base_url}/v1"


def extract_json(text: str) -> dict[str, Any]:
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        raise ValueError(f"Model did not return JSON: {text[:500]}")
    return json.loads(text[start : end + 1])


def response_text(payload: dict[str, Any]) -> str:
    choices = payload.get("choices") or []
    if choices:
        content = choices[0].get("message", {}).get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return "\n".join(part.get("text", "") for part in content if isinstance(part, dict))
    raise ValueError("Could not find text in model response.")


def outline_prompt(doc_text: str, layout_md: str, design_constraints: str, slide_count: int) -> str:
    return f"""
You are designing a PowerPoint outline from a long Chinese research report.

Use this HTML template system and page-role selector:
{layout_md[:6000]}

Follow these design constraints strictly:
{design_constraints[:5000]}

Use exactly {slide_count} slides with this page_role sequence:
{", ".join(ROLE_SEQUENCE[:slide_count])}

Return JSON only:
{{
  "deck_title": "...",
  "subtitle": "...",
  "slides": [
    {{
      "page_role": "cover|agenda|chapter_cover|timeline|image|text|quote|chart|table|summary|data_support",
      "title": "...",
      "subtitle": "...",
      "claim": "one-sentence analytical claim, not a generic topic label",
      "bullets": ["3-6 substantial points with concrete periods, artists, works, techniques, or institutions"],
      "evidence": ["2-4 source-specific evidence notes from the report"],
      "examples": ["named examples such as Lascaux, Giotto, Leonardo, Caravaggio, Monet, Pollock, Warhol"],
      "visual": "specific visual placeholder that should be shown on this slide",
      "quote": "...",
      "metrics": [{{"value": "...", "label": "...", "insight": "..."}}],
      "table": {{"columns": ["...", "..."], "rows": [["...", "..."]]}},
      "phases": ["...", "..."]
    }}
  ]
}}

Rules:
- Do not make empty slides. Every content slide must include a claim, 3-6 bullets, and at least 2 evidence/examples unless the role is cover.
- Design fit is mandatory. Do not generate content that exceeds the text budgets in the design constraints.
- Use the role for its intended layout, not as a label. For example, timeline pages need four short phase labels; quote pages need one dominant statement; table pages need compact cells.
- If the template source is weak or topic-bound, generate for the standardized role layout described in design constraints rather than imitating the source page.
- Avoid page-role monotony and avoid making most slides feel like left-text-right-image pages.
- Compress, but do not oversimplify. This is a long research report; preserve named periods, artists, works, techniques, institutions, and causal logic.
- Avoid generic bullets like "history" or "development". Use specific evidence.
- Use Chinese content.
- Preserve the source report's historical logic: periods, human nature, ideas, power, and visual evolution.
- Do not mention the HTML template system visibly.
- For chart/data_support pages, create qualitative metrics from the report structure if numeric data is absent.

Report excerpt:
{doc_text}
""".strip()


def request_outline(doc_text: str, layout_md: str, design_constraints: str, slide_count: int, model: str, base_url: str, api_key: str, timeout: int) -> dict[str, Any]:
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You create concise Chinese PPT outlines and return valid JSON only."},
            {"role": "user", "content": outline_prompt(doc_text, layout_md, design_constraints, slide_count)},
        ],
        "temperature": 0.35,
        "response_format": {"type": "json_object"},
    }
    content = request_chat_jsonish(payload, base_url, api_key, timeout)
    try:
        return extract_json(content)
    except Exception:
        repair_payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "Repair invalid JSON. Return only one valid JSON object, no markdown."},
                {"role": "user", "content": content},
            ],
            "temperature": 0,
            "response_format": {"type": "json_object"},
        }
        return extract_json(request_chat_jsonish(repair_payload, base_url, api_key, timeout))


def request_chat_jsonish(payload: dict[str, Any], base_url: str, api_key: str, timeout: int) -> str:
    req = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GLM request failed HTTP {exc.code}: {detail[:1000]}") from exc
    return response_text(data)


def fallback_outline(doc_text: str, slide_count: int) -> dict[str, Any]:
    slides = [
        {"page_role": "cover", "title": "西方绘画史：人性、观念与权力的视觉演进", "subtitle": "从史前图像到2026年的视觉观念史", "visual": "艺术史时间轴"},
        {"page_role": "agenda", "title": "研究路径", "bullets": ["人性的图像表达", "观念如何改变绘画", "权力与观看制度", "当代视觉转向"]},
        {"page_role": "chapter_cover", "title": "从生存本能到理想秩序", "subtitle": "史前、古希腊与古罗马的图像基础"},
        {"page_role": "timeline", "title": "关键历史阶段", "phases": ["史前图像", "古典理性", "中世纪神性", "现代主体"]},
        {"page_role": "image", "title": "图像如何承载时代精神", "subtitle": "以代表性作品作为观看制度的切片", "visual": "作品对比图"},
        {"page_role": "text", "title": "人性：从身体到内心", "bullets": ["身体比例体现理性秩序", "肖像与叙事记录个体经验", "现代艺术转向心理与潜意识"]},
        {"page_role": "quote", "title": "绘画不是再现世界，而是重建观看世界的方式", "quote": "每一次风格转向，都是一次观念与权力关系的重排。"},
        {"page_role": "chart", "title": "三条主线的历史权重", "metrics": [{"value": "人性", "label": "身体、情感、主体"}, {"value": "观念", "label": "透视、形式、媒介"}, {"value": "权力", "label": "宗教、宫廷、市场"}]},
        {"page_role": "data_support", "title": "研究支撑", "metrics": [{"value": "4", "label": "历史阶段"}, {"value": "3", "label": "分析主线"}, {"value": "2026", "label": "延伸至当代"}]},
        {"page_role": "summary", "title": "核心结论", "bullets": ["西方绘画史是一部观看制度变化史", "艺术风格背后是人、观念与权力的协商", "当代图像进入媒介和算法共同塑形的新阶段"]},
    ]
    return {"deck_title": "西方绘画史：人性、观念与权力的视觉演进", "subtitle": "小艺深度研究报告", "slides": slides[:slide_count]}


def esc(value: Any) -> str:
    return html.escape(str(value or ""), quote=False)


def compact_text(value: Any, max_chars: int = 78) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(text) <= max_chars:
        return text
    cut = text[:max_chars].rstrip("，。；、,. ")
    return f"{cut}..."


def bullet_html(items: list[Any], max_items: int = 3, max_chars: int = 72) -> str:
    if not items:
        return ""
    return "<ul>" + "".join(f"<li>{esc(compact_text(item, max_chars))}</li>" for item in items[:max_items]) + "</ul>"


def combine_points(slide: dict[str, Any]) -> list[str]:
    points: list[str] = []
    for key in ("claim", "bullets", "evidence", "examples"):
        value = slide.get(key)
        if isinstance(value, str) and value.strip():
            points.append(value.strip())
        elif isinstance(value, list):
            points.extend(str(item).strip() for item in value if str(item).strip())
    seen: set[str] = set()
    result: list[str] = []
    for point in points:
        if point not in seen:
            seen.add(point)
            result.append(point)
    return result


def list_points(slide: dict[str, Any], keys: tuple[str, ...] = ("bullets", "evidence", "examples")) -> list[str]:
    points: list[str] = []
    for key in keys:
        value = slide.get(key)
        if isinstance(value, str) and value.strip():
            points.append(value.strip())
        elif isinstance(value, list):
            points.extend(str(item).strip() for item in value if str(item).strip())
    seen: set[str] = set()
    result: list[str] = []
    for point in points:
        if point not in seen:
            seen.add(point)
            result.append(point)
    return result


def heading_text(value: Any, max_chars: int = 18) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if not text:
        return ""
    for sep in ("：", ":", "，", ",", "。", ".", "；", ";", "-", "—"):
        if sep in text:
            left = text.split(sep, 1)[0].strip()
            if 2 <= len(left) <= max_chars:
                return left
    return compact_text(text, max_chars)


def slide_mapping(deck: dict[str, Any], slide: dict[str, Any], index: int) -> dict[str, str]:
    bullets = combine_points(slide)
    content_points = list_points(slide) or bullets
    headings = [heading_text(item, 18) for item in content_points]
    details = [compact_text(item, 64) for item in content_points]
    while len(headings) < 4:
        fallback = compact_text(slide.get("title") or deck.get("deck_title") or "Key Point", 18)
        headings.append(f"{fallback} {len(headings) + 1}")
    while len(details) < 4:
        details.append(compact_text(slide.get("claim") or slide.get("subtitle") or deck.get("subtitle") or "Reusable content block", 64))
    metrics = slide.get("metrics") or []
    phases = [compact_text(str(x), 36) for x in slide.get("phases") or content_points or bullets]
    table = slide.get("table") or {}
    columns = table.get("columns") or ["维度", "内容", "意义", "模板"]
    rows = table.get("rows") or [[f"阶段{i}", item, "视觉观念变化", "可替换"] for i, item in enumerate(bullets[:3], 1)]
    while len(rows) < 3:
        rows.append(["", "", "", ""])
    while len(metrics) < 4:
        metrics.append({"value": f"{len(metrics)+1}", "label": bullets[len(metrics)] if len(metrics) < len(bullets) else "关键点", "insight": slide.get("subtitle", "")})

    raw_mapping = {
        "brand_or_series": "XIAOYI RESEARCH",
        "deck_title": deck.get("deck_title") or slide.get("title"),
        "subtitle": compact_text(slide.get("subtitle") or slide.get("claim") or deck.get("subtitle") or "", 44),
        "presenter": "小艺深度研究",
        "date": "2026",
        "cover_visual": slide.get("visual") or "Art History Visual",
        "section_label": f"{index:02d}",
        "agenda_title": slide.get("title") or "目录",
        "chapter_index": f"{index:02d}",
        "chapter_title": slide.get("title"),
        "chapter_summary": compact_text(slide.get("subtitle") or (bullets[0] if bullets else ""), 64),
        "page_title": slide.get("title"),
        "paragraph_or_bullets_left": bullet_html(bullets[:1], 1, 58) or esc(compact_text(slide.get("subtitle"), 70)),
        "paragraph_or_bullets_right": bullet_html(bullets[1:2], 1, 58) or esc(compact_text(slide.get("visual"), 70)),
        "image_context": compact_text(slide.get("subtitle"), 64) or bullet_html(bullets[:1], 1, 52),
        "image_or_screenshot": slide.get("visual") or "Artwork / Reference Image",
        "quote_context": slide.get("subtitle") or "Core Insight",
        "quote_text": slide.get("quote") or slide.get("title"),
        "quote_source_or_interpretation": bullet_html(bullets[:2], 2, 64) if bullets else compact_text(slide.get("subtitle", ""), 90),
        "chart_title": slide.get("title"),
        "chart_area": slide.get("visual") or "Conceptual Chart",
        "table_title": slide.get("title"),
        "summary_title": slide.get("title"),
        "next_step": slide.get("claim") or slide.get("subtitle") or "用于后续内容生成与版式复用",
        "timeline_title": slide.get("title"),
        "data_title": slide.get("title"),
        "supporting_chart_or_evidence": slide.get("visual") or "Evidence Area",
    }
    for i in range(1, 5):
        raw_mapping[f"agenda_item_{i}"] = bullets[i - 1] if i - 1 < len(bullets) else f"章节 {i}"
        raw_mapping[f"phase_{i}"] = phases[i - 1] if i - 1 < len(phases) else f"阶段 {i}"
        metric = metrics[i - 1]
        raw_mapping[f"metric_{i}"] = metric.get("value", "")
        raw_mapping[f"insight_{i}"] = metric.get("insight") or metric.get("label", "")
        raw_mapping[f"kpi_{i}"] = metric.get("value", "")
        raw_mapping[f"kpi_label_{i}"] = metric.get("label") or metric.get("insight", "")
        raw_mapping[f"takeaway_{i}"] = bullets[i - 1] if i - 1 < len(bullets) else metric.get("label", "")
        raw_mapping[f"col_{i}"] = columns[i - 1] if i - 1 < len(columns) else f"列{i}"
    for r in range(1, 4):
        row = rows[r - 1]
        for c in range(1, 5):
            raw_mapping[f"row_{r}_col_{c}"] = row[c - 1] if c - 1 < len(row) else ""
    html_keys = {"paragraph_or_bullets_left", "paragraph_or_bullets_right", "image_context", "quote_source_or_interpretation"}
    rendered: dict[str, str] = {}
    for key, value in raw_mapping.items():
        rendered[key] = str(value or "") if key in html_keys else esc(value)
    return rendered


def slide_mapping_v2(deck: dict[str, Any], slide: dict[str, Any], index: int) -> dict[str, str]:
    all_points = combine_points(slide)
    content_points = list_points(slide) or all_points
    headings = [heading_text(item, 18) for item in content_points]
    details = [compact_text(item, 64) for item in content_points]
    while len(headings) < 4:
        fallback = compact_text(slide.get("title") or deck.get("deck_title") or "Key Point", 18)
        headings.append(f"{fallback} {len(headings) + 1}")
    while len(details) < 4:
        details.append(compact_text(slide.get("claim") or slide.get("subtitle") or deck.get("subtitle") or "Reusable content block", 64))

    metrics = list(slide.get("metrics") or [])
    while len(metrics) < 4:
        idx = len(metrics)
        metrics.append({"value": f"{idx + 1}", "label": headings[idx], "insight": details[idx]})

    phases = [compact_text(str(x), 36) for x in slide.get("phases") or content_points or all_points]
    while len(phases) < 4:
        phases.append(details[len(phases)])

    table = slide.get("table") or {}
    columns = table.get("columns") or ["Dimension", "Content", "Meaning", "Template"]
    rows = table.get("rows") or [
        [f"{i:02d}", heading_text(item, 16), compact_text(item, 34), compact_text(slide.get("claim") or slide.get("subtitle") or "", 28)]
        for i, item in enumerate(content_points[:3], 1)
    ]
    while len(rows) < 3:
        rows.append(["", "", "", ""])

    raw_mapping = {
        "brand_or_series": "XIAOYI RESEARCH",
        "deck_title": deck.get("deck_title") or slide.get("title"),
        "subtitle": compact_text(slide.get("subtitle") or slide.get("claim") or deck.get("subtitle") or "", 44),
        "presenter": "Xiaoyi Research",
        "date": "2026",
        "cover_visual": slide.get("visual") or "Art History Visual",
        "section_label": f"{index:02d}",
        "agenda_title": slide.get("title") or "Agenda",
        "chapter_index": f"{index:02d}",
        "chapter_title": slide.get("title"),
        "chapter_summary": compact_text(slide.get("subtitle") or slide.get("claim") or (details[0] if details else ""), 64),
        "page_title": slide.get("title"),
        "paragraph_or_bullets_left": bullet_html(content_points[:2], 2, 58) or esc(compact_text(slide.get("subtitle"), 70)),
        "paragraph_or_bullets_right": bullet_html(content_points[2:4], 2, 58) or esc(compact_text(slide.get("visual"), 70)),
        "image_context": compact_text(slide.get("subtitle"), 64) or bullet_html(content_points[:1], 1, 52),
        "image_or_screenshot": slide.get("visual") or "Artwork / Reference Image",
        "quote_context": slide.get("subtitle") or "Core Insight",
        "quote_text": slide.get("quote") or slide.get("title"),
        "quote_source_or_interpretation": bullet_html(content_points[:2], 2, 64) if content_points else compact_text(slide.get("subtitle", ""), 90),
        "chart_title": slide.get("title"),
        "chart_area": slide.get("visual") or "Conceptual Chart",
        "table_title": slide.get("title"),
        "summary_title": slide.get("title"),
        "next_step": compact_text(slide.get("claim") or slide.get("subtitle") or deck.get("subtitle") or "Reusable template conclusion", 72),
        "timeline_title": slide.get("title"),
        "data_title": slide.get("title"),
        "supporting_chart_or_evidence": compact_text(slide.get("visual") or slide.get("claim") or "Evidence Area", 54),
    }
    for i in range(1, 5):
        raw_mapping[f"agenda_item_{i}"] = headings[i - 1]
        raw_mapping[f"phase_{i}"] = phases[i - 1]
        metric = metrics[i - 1]
        raw_mapping[f"metric_{i}"] = metric.get("value", "")
        raw_mapping[f"insight_{i}"] = metric.get("insight") or metric.get("label", "")
        raw_mapping[f"kpi_{i}"] = metric.get("value", "")
        raw_mapping[f"kpi_label_{i}"] = metric.get("label") or metric.get("insight", "")
        raw_mapping[f"takeaway_{i}"] = details[i - 1]
        raw_mapping[f"col_{i}"] = columns[i - 1] if i - 1 < len(columns) else f"Column {i}"
    for i in range(0, 24):
        raw_mapping[f"paragraph_or_bullets_{i}"] = details[i % len(details)] if details else ""
    for r in range(1, 4):
        row = rows[r - 1]
        for c in range(1, 5):
            raw_mapping[f"row_{r}_col_{c}"] = row[c - 1] if c - 1 < len(row) else ""
    html_keys = {"paragraph_or_bullets_left", "paragraph_or_bullets_right", "image_context", "quote_source_or_interpretation"}
    rendered: dict[str, str] = {}
    for key, value in raw_mapping.items():
        rendered[key] = str(value or "") if key in html_keys else esc(value)
    return rendered


def fill_template(template: str, mapping: dict[str, str]) -> str:
    def repl(match: re.Match[str]) -> str:
        key = match.group(1).strip()
        return mapping.get(key, "")

    return re.sub(r"\{\{([^}]+)\}\}", repl, template)


def choose_template_variant(template_dir: Path, slide: dict[str, Any], index: int) -> Path:
    role = slide.get("page_role") or "text"
    variants_dir = template_dir / "variants"
    candidates = sorted(variants_dir.glob(f"{role}_*.html")) if variants_dir.exists() else []
    if not candidates:
        fallback = template_dir / f"{role}.html"
        return fallback if fallback.exists() else template_dir / "text.html"

    names = {p.stem.removeprefix(f"{role}_"): p for p in candidates}
    bullets = list_points(slide)
    metrics = list(slide.get("metrics") or [])
    has_table = bool((slide.get("table") or {}).get("rows"))
    has_visual = bool(slide.get("visual"))
    point_count = len(combine_points(slide))
    dense = len(bullets) >= 7 or point_count >= 8

    preferred_by_role = {
        "agenda": "rail_rows" if index <= 3 else "numbered_grid",
        "chapter_cover": "split_statement" if has_visual else "quote_band",
        "text": "two_column_deep" if dense else ("statement_notes" if point_count <= 2 else "three_columns"),
        "image": "visual_grid" if dense else ("wide_visual_bottom_notes" if has_visual and len(bullets) <= 2 else "left_notes_right_visual"),
        "timeline": "stacked_process" if dense else "horizontal_steps",
        "table": "matrix" if has_table else "comparison_cards",
        "chart": "evidence_panels" if metrics else "visual_with_insights",
        "data_support": "metric_dashboard" if metrics else "kpi_columns",
        "quote": "center_statement" if len(str(slide.get("quote") or slide.get("title") or "")) < 34 else "large_quote",
        "summary": "closing_band" if index % 2 == 0 else "takeaway_columns",
    }
    model_candidates = [path for name, path in sorted(names.items()) if name.startswith("model_")]
    if model_candidates:
        return model_candidates[(index - 1) % len(model_candidates)]
    preferred = preferred_by_role.get(role)
    if preferred in names:
        return names[preferred]
    return candidates[(index - 1) % len(candidates)]


def build_html_slides(deck: dict[str, Any], template_dir: Path, output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template_dir / "common.css", output_dir / "common.css")
    template_assets = template_dir / "assets"
    output_assets = output_dir / "assets"
    if template_assets.exists():
        if output_assets.exists():
            shutil.rmtree(output_assets)
        shutil.copytree(template_assets, output_assets)
    paths: list[Path] = []
    slides = deck.get("slides") or []
    for index, slide in enumerate(slides, 1):
        role = slide.get("page_role") or "text"
        template_path = choose_template_variant(template_dir, slide, index)
        html_text = fill_template(template_path.read_text(encoding="utf-8"), slide_mapping_v2(deck, slide, index))
        out = output_dir / f"slide_{index:02d}_{role}.html"
        out.write_text(html_text, encoding="utf-8")
        paths.append(out)
    return paths


def find_browser() -> str:
    candidates = [
        shutil.which("msedge"),
        shutil.which("chrome"),
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    raise RuntimeError("Could not find Edge or Chrome.")


def render_html_to_png(paths: list[Path], output_dir: Path) -> list[Path]:
    browser = find_browser()
    output_dir.mkdir(parents=True, exist_ok=True)
    pngs: list[Path] = []
    for html_path in paths:
        png = output_dir / f"{html_path.stem}.png"
        subprocess.run(
            [browser, "--headless", "--disable-gpu", "--window-size=1920,1080", f"--screenshot={png}", str(html_path.resolve())],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        pngs.append(png)
    return pngs


def build_pptx_from_pngs(pngs: list[Path], output: Path) -> None:
    from pptx import Presentation
    from pptx.util import Inches

    prs = Presentation()
    prs.slide_width = Inches(13.333333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    for png in pngs:
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(str(png), 0, 0, width=prs.slide_width, height=prs.slide_height)
    output.parent.mkdir(parents=True, exist_ok=True)
    prs.save(output)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate a preview PPTX from DOCX content and an HTML template system.")
    parser.add_argument("docx", type=Path)
    parser.add_argument("--template-system", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--slide-count", type=int, default=14)
    parser.add_argument("--base-url", default=os.environ.get("GLM_BASE_URL") or "https://yunwu.ai")
    parser.add_argument("--model", default=os.environ.get("GLM_MODEL") or "glm-5")
    parser.add_argument("--api-key-env", default=os.environ.get("GLM_API_KEY_ENV") or "GLM_API_KEY")
    parser.add_argument("--request-timeout", type=int, default=240)
    parser.add_argument("--max-chars", type=int, default=34000)
    parser.add_argument("--no-model", action="store_true")
    parser.add_argument("--outline", type=Path, help="Use an existing outline.json instead of calling the model.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    doc_text = read_docx_text(args.docx, args.max_chars)
    if args.outline:
        deck = json.loads(args.outline.read_text(encoding="utf-8-sig"))
    elif args.no_model:
        deck = fallback_outline(doc_text, args.slide_count)
    else:
        layout_md = (args.template_system / "layout.md").read_text(encoding="utf-8")
        constraints_path = args.template_system / "design_constraints.md"
        design_constraints = constraints_path.read_text(encoding="utf-8") if constraints_path.exists() else ""
        api_key = os.environ.get(args.api_key_env) or os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError(f"{args.api_key_env} or OPENAI_API_KEY is required.")
        deck = request_outline(doc_text, layout_md, design_constraints, args.slide_count, args.model, args.base_url, api_key, args.request_timeout)
    deck["slides"] = (deck.get("slides") or [])[: args.slide_count]
    (args.output_dir / "outline.json").write_text(json.dumps(deck, ensure_ascii=False, indent=2), encoding="utf-8")
    html_dir = args.output_dir / "html"
    png_dir = args.output_dir / "preview_png"
    if html_dir.exists():
        shutil.rmtree(html_dir)
    if png_dir.exists():
        shutil.rmtree(png_dir)
    html_paths = build_html_slides(deck, args.template_system / "templates", html_dir)
    pngs = render_html_to_png(html_paths, png_dir)
    build_pptx_from_pngs(pngs, args.output_dir / "xiaoyi_art_history_template_preview.pptx")


if __name__ == "__main__":
    main()
