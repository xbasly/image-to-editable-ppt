"""Shared model configuration loader for SVG template extraction scripts."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict


DEFAULT_CONFIG = {
    "base_url": "https://yunwu.ai",
    "model": "qwen3.5-397b-a17b",
    "api_key_env": "YUNWU_API_KEY",
    "request_timeout": 240,
}


def default_config_path() -> Path:
    return Path(__file__).resolve().parents[1] / "config" / "model_config.json"


def load_model_config(path: Path | None = None) -> Dict[str, Any]:
    config = dict(DEFAULT_CONFIG)
    config_path = path or default_config_path()
    if config_path.exists():
        config.update(json.loads(config_path.read_text(encoding="utf-8-sig")))
    if os.environ.get("PPT_TEMPLATE_BASE_URL"):
        config["base_url"] = os.environ["PPT_TEMPLATE_BASE_URL"]
    if os.environ.get("PPT_TEMPLATE_MODEL"):
        config["model"] = os.environ["PPT_TEMPLATE_MODEL"]
    if os.environ.get("PPT_TEMPLATE_API_KEY_ENV"):
        config["api_key_env"] = os.environ["PPT_TEMPLATE_API_KEY_ENV"]
    if os.environ.get("PPT_TEMPLATE_REQUEST_TIMEOUT"):
        config["request_timeout"] = int(os.environ["PPT_TEMPLATE_REQUEST_TIMEOUT"])
    return config


def resolve_api_key(config: Dict[str, Any]) -> str | None:
    env_name = config.get("api_key_env") or "YUNWU_API_KEY"
    return os.environ.get(env_name) or os.environ.get("OPENAI_API_KEY")
