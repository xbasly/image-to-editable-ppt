#!/usr/bin/env python
"""Generate paginated SVG slides from a style Markdown file and content JSON.

This is intentionally separate from the extraction pipeline so template_style.md
can be tuned independently and rerun against the same content.
"""

from __future__ import annotations

import argparse
import html
import json
import os
import re
import sys
import urllib.error
import urllib.request
import time
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from model_utils import normalize_base_url  # noqa: E402


DEFAULT_WIDTH = 1920
DEFAULT_HEIGHT = 1080


def resolve_api_key(api_key_env: str) -> str:
    api_key = os.environ.get(api_key_env) or os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(f"{api_key_env} or OPENAI_API_KEY is required.")
    return api_key


def extract_svg(text: str) -> str:
    fenced = re.search(r"```(?:svg|xml)?\s*(<svg[\s\S]*?</svg>)\s*```", text, re.IGNORECASE)
    if fenced:
        return fenced.group(1).strip()
    plain = re.search(r"(<svg[\s\S]*?</svg>)", text, re.IGNORECASE)
    if plain:
        return plain.group(1).strip()
    raise ValueError("Could not find an <svg>...</svg> block in model response.")


def repair_svg(svg: str, width: int, height: int) -> str:
    svg = svg.strip()
    svg = re.sub(r"<script[\s\S]*?</script>", "", svg, flags=re.IGNORECASE)
    if not re.search(r"\bviewBox=", svg[:300], re.IGNORECASE):
        svg = svg.replace("<svg", f'<svg viewBox="0 0 {width} {height}"', 1)
    if not re.search(r"\bwidth=", svg[:300], re.IGNORECASE):
        svg = svg.replace("<svg", f'<svg width="{width}"', 1)
    if not re.search(r"\bheight=", svg[:300], re.IGNORECASE):
        svg = svg.replace("<svg", f'<svg height="{height}"', 1)
    if "xmlns=" not in svg[:300]:
        svg = svg.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"', 1)
    return svg


def token_name(index: int) -> str:
    return "{{TXT_%03d}}" % index


def tokenized_slide(slide: dict[str, Any], deck: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str], dict[str, Any]]:
    mapping: dict[str, str] = {}
    counter = 1

    def convert(value: Any, key: str = "") -> Any:
        nonlocal counter
        if isinstance(value, str):
            if key in {"page_role"}:
                return value
            if key in {"visual_hint"}:
                return value
            if not value.strip():
                return value
            token = token_name(counter)
            counter += 1
            mapping[token] = value
            return token
        if isinstance(value, list):
            return [convert(item, key) for item in value]
        if isinstance(value, dict):
            return {k: convert(v, k) for k, v in value.items()}
        return value

    token_slide = convert(slide)
    deck_context = {k: v for k, v in deck.items() if k != "slides"}
    token_deck: dict[str, Any] = {}
    for key, value in deck_context.items():
        token_deck[key] = convert(value, key)
    return token_slide, mapping, token_deck


def replace_text_tokens(svg: str, mapping: dict[str, str]) -> str:
    for token, value in mapping.items():
        svg = svg.replace(token, html.escape(value, quote=False))
    return svg


def relevant_style(style_md: str, page_role: str) -> str:
    style_md = clean_style_for_prompt(style_md)
    role_match = re.search(r"## Page Role Library\s*([\s\S]*?)(?:\n## |\Z)", style_md)
    role_library = role_match.group(1).strip() if role_match else style_md[:4000]
    role_section = ""
    role_pattern = re.compile(rf"^###\s+{re.escape(page_role)}\s*$([\s\S]*?)(?=^###\s+|\Z)", re.MULTILINE)
    match = role_pattern.search(role_library)
    if match:
        role_section = f"### {page_role}\n{match.group(1).strip()}"

    page_notes_match = re.search(r"## Per-Page Layout Notes\s*([\s\S]*?)\Z", style_md)
    matching_pages: list[str] = []
    if page_notes_match:
        for page_match in re.finditer(r"^###\s+(slide_\d+)\s+-\s+([^\n]+)\n([\s\S]*?)(?=^###\s+|\Z)", page_notes_match.group(1), re.MULTILINE):
            if page_match.group(2).strip() == page_role:
                matching_pages.append(f"### {page_match.group(1)} - {page_role}\n{page_match.group(3).strip()}")
            if len(matching_pages) >= 4:
                break

    source_line = style_md.splitlines()[2] if len(style_md.splitlines()) > 2 else ""
    parts = ["# Relevant PDF Template Style", source_line, "", "## Deck-Level Visual DNA", deck_style_directives(style_md), "", "## Matching Role", role_section or role_library[:1800]]
    if matching_pages:
        parts.extend(["", "## Matching Page Examples", "\n\n".join(matching_pages)])
    return "\n".join(parts)[:7000]


def clean_style_for_prompt(style_md: str) -> str:
    cleaned: list[str] = []
    for line in style_md.splitlines():
        stripped = line.strip()
        if stripped.startswith("- Source"):
            continue
        # Keep the style guide semantic and prevent models from copying source
        # Chinese text through a lossy provider-side encoding path.
        if re.search(r"[\u4e00-\u9fff]", stripped):
            continue
        if stripped.startswith("- Fonts:"):
            continue
        if stripped.startswith("- Font sizes:"):
            cleaned.append(line)
            continue
        cleaned.append(line)
    return "\n".join(cleaned)


def deck_style_directives(style_md: str) -> str:
    colors = [m.group(0).upper() for m in re.finditer(r"#[0-9A-Fa-f]{6}", style_md)]
    top_colors = ", ".join(dict.fromkeys(colors[:10]))
    has_black = "#000000" in colors or "#181818" in colors
    has_purple = any(c.startswith(("#60", "#78", "#48", "#30")) and c.endswith(("F0", "FF", "D8")) for c in colors)
    has_corporate_blue = any(c in colors for c in ("#0078C0", "#1878C0", "#0060A8", "#3090C0"))
    has_white = "#FFFFFF" in colors or "#F0F0F0" in colors
    is_art_history = any(token in style_md.lower() for token in ("art-history", "artwork_analysis", "museum", "western painting", "gallery", "humanities"))
    is_template_informed = "template-informed" in style_md.lower() or "source template summary" in style_md.lower()

    common = f"""
- Use 1920x1080 coordinates and preserve a presentation-slide feel.
- Dominant extracted palette: {top_colors or "use colors from the style guide"}.
- Match the source deck's layout density and typography scale. Do not invent a different design system.
- Use large readable text and one dominant content structure per slide.
- Avoid decorative elements that are absent from the source style.
""".strip()

    if has_black and has_purple:
        return common + """
- This source deck is a rough, high-contrast dark technical training deck.
- Normal pages: black background, very large white title at top-left, generous margins, large body text.
- Cover pages: full-slide purple/blue gradient or broad purple field, huge white title, minimal decoration.
- Use purple accent as thick number circles, section bars, or large blocks. Use cyan/blue only as a secondary technical accent.
- Code/screenshot pages should feel like a big dark terminal/browser capture.
- For non-technical topics, adapt content into the same dark/purple training-deck structure: large title, simple list blocks, screenshot/artwork placeholders, and high-contrast diagrams.
- Avoid corporate blue-white layouts, modern dashboard cards, tiny legends, and ornamental line art.
""".strip()

    if has_corporate_blue and has_white:
        return common + """
- This source deck is a blue-and-white enterprise sharing deck.
- Use a flat Tencent-like blue background (#0078C0/#1878C0) for most slides.
- Use white Chinese serif-like titles and subtitles; keep title placement simple and formal.
- Cover pages should be minimal: blue full-bleed background, centered white title, presenter/date below. No modern dashboard cards.
- Content pages should use blue background with white labels, big rounded containers, flow arrows, red/green/white modules, and simple icon placeholders.
- For process pages, use large left-to-right flow diagrams with arrows and boxed modules.
- For table/comparison pages, use white panels or red/green module blocks with high-contrast labels.
- Avoid black technical terminal styling, purple neon accents, page counters, tiny legends, dark SaaS panels, and black table backgrounds.
- This is a template-informed generation: adapt the topic visuals to the source template's blue corporate layout instead of switching to a new topic-native style.
""".strip()

    if is_art_history:
        return common + """
- This deck is an art-history / humanities research presentation.
- Use warm paper or gallery-wall backgrounds, charcoal text, muted burgundy and gold accents.
- Do not use corporate logos, technical terminal blocks, neon gradients, or SaaS dashboard cards.
- Visuals should look like framed artwork placeholders, archive documents, museum labels, timelines, or comparison panels.
- Cover pages should feel like an exhibition wall or research monograph title page.
- Chapter dividers should be sparse, with large period titles and subtle texture.
- Timeline pages should use thin muted-gold lines and era nodes.
- Artwork analysis pages should include a large framed image placeholder and 2-4 callout annotations.
- Comparison pages should use two balanced panels, each with a framed image/idea area and concise notes.
- Quote pages should be calm and editorial, using oversized quote text on warm paper.
""".strip()

    return common + """
- Let the extracted palette and role notes drive the design.
- Cover pages should be simpler than content pages.
- Use the most frequent palette colors as backgrounds and large blocks; use secondary colors only as accents.
- Prefer direct diagrams, tables, and text layouts over decorative redesign.
""".strip()


def slide_prompt(
    style_md: str,
    deck: dict[str, Any],
    slide: dict[str, Any],
    index: int,
    total: int,
    width: int,
    height: int,
    use_text_tokens: bool,
) -> tuple[str, dict[str, str]]:
    style_excerpt = relevant_style(style_md, str(slide.get("page_role") or "text_explainer"))
    if use_text_tokens:
        prompt_slide, token_mapping, prompt_deck = tokenized_slide(slide, deck)
        allowed_tokens = ", ".join(token_mapping.keys())
        text_rule = """
- IMPORTANT: Use text tokens exactly as visible text, such as {{TXT_001}}. Do not write the actual Chinese text in SVG.
- Do not split, translate, rewrite, or garble text tokens. The script will replace tokens after SVG generation.
- Every visible text element must contain either an allowed token or a generic English placeholder like "Artwork Placeholder".
""".strip()
    else:
        prompt_slide = slide
        token_mapping = {}
        prompt_deck = {k: v for k, v in deck.items() if k != "slides"}
        text_rule = "- Use Chinese text from the content. Keep text concise and readable."
    return f"""
You are generating a single editable SVG slide from a PDF-derived PPT style guide.

Canvas:
- width: {width}
- height: {height}
- aspect ratio: 16:9

Style guide Markdown:
{style_excerpt}

Deck context:
{json.dumps(prompt_deck, ensure_ascii=False, indent=2)}

Current slide {index}/{total} content:
{json.dumps(prompt_slide, ensure_ascii=False, indent=2)}

Allowed visible text tokens:
{allowed_tokens if use_text_tokens else "not using tokens"}

Requirements:
- Return exactly one complete SVG document. Do not return explanations.
- Use the current slide's page_role and match the closest role section in the style guide.
- Keep the visual language close to the original PDF, following the Deck-Level Visual DNA above rather than generic modern slide design.
- Use editable SVG text, rect, path, circle, line, polyline, and simple shapes. Do not embed raster screenshots or external images.
- Use placeholder visual blocks when content asks for screenshot/image/chart.
- Preserve a professional presentation layout; avoid overlapping text.
- Keep all text and chart labels at least 28px inside the canvas. For negative chart values, use badges or an above-axis comparison mark instead of drawing bars outside the plot area.
- Treat visual_hint as design instruction only. Never render visual_hint text visibly on the slide.
- For long Chinese titles, use <tspan> line wrapping and reduce font size so the title stays in its safe text area.
- For agenda/table-of-contents pages, use a simple vertical numbered list or column list. Do not use network/node diagrams, radial maps, or scattered labels.
- Never output a single-line text element whose visible text is longer than its containing region. Prefer 2-4 <tspan> lines for Chinese body text.
- Never place artwork frames, charts, or visual placeholders over title/subtitle/body text. On cover slides, reserve the left half for title text and the right half for the visual frame unless the role guide says otherwise.
- Do not add page counters, tiny legends, decorative outline boxes, or generic modern dashboard cards unless the source style explicitly supports them.
- For cover and inner pages, follow the background/title rules in the Deck-Level Visual DNA.
- Put every meaningful element inside the SVG, no CSS imports, no external fonts, no markdown.
- {text_rule}
- All visible text must come from the Current slide content or deck context. Copy Chinese text exactly. Never copy text from the style guide, never invent garbled text, and ignore corrupted font names.
- Use data-role attributes on major groups: cover, title, subtitle, body, table, chart, code, card, quote, footer, visual.
""".strip(), token_mapping


def request_svg(
    style_md: str,
    deck: dict[str, Any],
    slide: dict[str, Any],
    index: int,
    total: int,
    model: str,
    api_key: str,
    base_url: str,
    timeout: int,
    width: int,
    height: int,
    use_text_tokens: bool,
) -> str:
    prompt, token_mapping = slide_prompt(style_md, deck, slide, index, total, width, height, use_text_tokens)
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You recreate the visual style of an existing technical PPT deck. Generate valid, editable SVG only.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.35,
    }
    request = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    last_error: Exception | None = None
    for attempt in range(1, 4):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Model request failed with HTTP {exc.code}: {body[:1000]}") from exc
        except Exception as exc:
            last_error = exc
            if attempt == 3:
                raise
            time.sleep(attempt * 3)
    else:
        raise RuntimeError(f"Model request failed: {last_error}")
    content = data["choices"][0]["message"]["content"]
    svg = repair_svg(extract_svg(content), width, height)
    if token_mapping:
        svg = replace_text_tokens(svg, token_mapping)
    return svg


def generate(
    style_path: Path,
    content_path: Path,
    output_dir: Path,
    model: str,
    base_url: str,
    api_key_env: str,
    timeout: int,
    limit: int | None,
    width: int,
    height: int,
    skip_existing: bool,
    use_text_tokens: bool,
) -> None:
    api_key = resolve_api_key(api_key_env)
    style_md = style_path.read_text(encoding="utf-8-sig")
    deck = json.loads(content_path.read_text(encoding="utf-8-sig"))
    slides = deck.get("slides") or []
    if limit:
        slides = slides[:limit]
    if not slides:
        raise ValueError("Content JSON must contain a non-empty slides array.")
    output_dir.mkdir(parents=True, exist_ok=True)
    for index, slide in enumerate(slides, 1):
        output_path = output_dir / f"slide_{index}.svg"
        if skip_existing and output_path.exists():
            print(f"Skip existing {output_path}")
            continue
        svg = request_svg(style_md, deck, slide, index, len(slides), model, api_key, base_url, timeout, width, height, use_text_tokens)
        output_path.write_text(svg, encoding="utf-8")
        print(f"Wrote {output_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate SVG slides from template_style.md and content JSON using GLM5.")
    parser.add_argument("--style", required=True, type=Path, help="Path to template_style.md.")
    parser.add_argument("--content", required=True, type=Path, help="Path to deck content JSON.")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--base-url", default=os.environ.get("GLM_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or "https://yunwu.ai")
    parser.add_argument("--model", default=os.environ.get("GLM_MODEL") or "glm-5")
    parser.add_argument("--api-key-env", default=os.environ.get("GLM_API_KEY_ENV") or "GLM_API_KEY")
    parser.add_argument("--request-timeout", type=int, default=int(os.environ.get("GLM_REQUEST_TIMEOUT") or "240"))
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--width", type=int, default=DEFAULT_WIDTH)
    parser.add_argument("--height", type=int, default=DEFAULT_HEIGHT)
    parser.add_argument("--skip-existing", action="store_true")
    parser.add_argument("--text-tokens", action="store_true", help="Ask the model to place text tokens, then replace them with source text after generation.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    generate(
        args.style,
        args.content,
        args.output_dir,
        args.model,
        args.base_url,
        args.api_key_env,
        args.request_timeout,
        args.limit,
        args.width,
        args.height,
        args.skip_existing,
        args.text_tokens,
    )


if __name__ == "__main__":
    main()
