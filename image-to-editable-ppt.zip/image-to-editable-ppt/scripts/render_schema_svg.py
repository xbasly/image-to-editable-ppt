#!/usr/bin/env python
"""Render template schema to SVG previews."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any, Dict


def hex_color(value: str | None, fallback: str) -> str:
    if not value:
        return fallback
    value = str(value)
    return value if value.startswith("#") else f"#{value}"


def font_family(style: Dict[str, Any]) -> str:
    family = (style.get("font_family") or "sans").lower()
    if family == "serif":
        return "SimSun, Songti SC, serif"
    if family == "mono":
        return "Consolas, monospace"
    return "Microsoft YaHei, Arial, sans-serif"


def render_text(slot: Dict[str, Any], width: int, height: int, theme: Dict[str, Any]) -> str:
    style = slot.get("style", {})
    x, y = slot.get("x", 0) * width, slot.get("y", 0) * height
    w, h = slot.get("w", 0.1) * width, slot.get("h", 0.05) * height
    text = str(slot.get("content") or slot.get("placeholder") or slot.get("role") or "Text")
    color = hex_color(style.get("color"), theme.get("primary", "#111111"))
    size = float(style.get("font_size") or 12)
    weight = "700" if style.get("bold") else "400"
    anchor = {"center": "middle", "right": "end"}.get(style.get("align"), "start")
    tx = x + (w / 2 if anchor == "middle" else w if anchor == "end" else 0)
    line_height = size * 1.25
    lines = text.splitlines() or [text]
    tspans = []
    for i, line in enumerate(lines[: max(1, int(h / max(1, line_height)) + 1)]):
        dy = 0 if i == 0 else line_height
        tspans.append(f'<tspan x="{tx:.2f}" dy="{dy:.2f}">{html.escape(line)}</tspan>')
    return (
        f'<text x="{tx:.2f}" y="{y + size:.2f}" width="{w:.2f}" height="{h:.2f}" '
        f'font-family="{font_family(style)}" font-size="{size:.2f}" font-weight="{weight}" '
        f'fill="{color}" text-anchor="{anchor}">{"".join(tspans)}</text>'
    )


def render_slot(slot: Dict[str, Any], width: int, height: int, theme: Dict[str, Any]) -> str:
    style = slot.get("style", {})
    x, y = slot.get("x", 0) * width, slot.get("y", 0) * height
    w, h = slot.get("w", 0.1) * width, slot.get("h", 0.1) * height
    kind = slot.get("type")
    if kind in {"group", "repeat"}:
        return ""
    if kind == "text":
        return render_text(slot, width, height, theme)
    if kind == "line":
        stroke = hex_color(style.get("stroke") or style.get("fill"), theme.get("muted", "#999999"))
        return f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{max(1, h):.2f}" fill="{stroke}" />'
    fill = hex_color(style.get("fill"), "#E8E8E8")
    stroke = hex_color(style.get("stroke"), fill)
    label = str(slot.get("placeholder") or slot.get("role") or kind or "")
    rect = f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" fill="{fill}" stroke="{stroke}" />'
    if kind in {"image", "graphic", "logo"} and label:
        rect += (
            f'<text x="{x + w / 2:.2f}" y="{y + h / 2:.2f}" font-family="Arial, sans-serif" '
            f'font-size="{max(10, min(18, h * 0.08)):.2f}" fill="#888888" text-anchor="middle" '
            f'dominant-baseline="middle">{html.escape(label)}</text>'
        )
    return rect


def render_svg(slide: Dict[str, Any]) -> str:
    canvas = slide.get("canvas", {})
    width = int(canvas.get("width") or 1600)
    height = int(canvas.get("height") or 900)
    theme = slide.get("theme", {})
    bg = hex_color(theme.get("background"), "#FFFFFF")
    body = [f'<rect x="0" y="0" width="{width}" height="{height}" fill="{bg}" />']
    for slot in slide.get("slots", []):
        body.append(render_slot(slot, width, height, theme))
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">\n' + "\n".join(body) + "\n</svg>\n"
    )


def render_schema(schema_path: Path, output_dir: Path) -> None:
    schema = json.loads(schema_path.read_text(encoding="utf-8-sig"))
    output_dir.mkdir(parents=True, exist_ok=True)
    for i, slide in enumerate(schema.get("slides", []), 1):
        out = output_dir / f"{slide.get('id') or f'slide_{i}'}.svg"
        out.write_text(render_svg(slide), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render template schema to SVG preview files.")
    parser.add_argument("--schema", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    render_schema(args.schema, args.output_dir)


if __name__ == "__main__":
    main()
