#!/usr/bin/env python
"""Build PDF-derived template assets in two explicit modes.

Modes:
- style-reference: summarize page roles, typography, colors, and layout patterns.
- visual-replica: emit visually faithful PDF-derived SVG pages only.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent


def require_fitz():
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("build_pdf_template.py requires PyMuPDF. Install it with: python -m pip install pymupdf") from exc
    return fitz


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def clean_output_dir(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for child in output_dir.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def rgb_from_int(value: int | None) -> str | None:
    if value is None:
        return None
    return f"#{(value >> 16) & 255:02X}{(value >> 8) & 255:02X}{value & 255:02X}"


def normalize_color(color: Any) -> str | None:
    if color is None:
        return None
    if isinstance(color, int):
        return rgb_from_int(color)
    if isinstance(color, (list, tuple)) and len(color) >= 3:
        vals = [int(clamp(float(v), 0, 1) * 255) if float(v) <= 1 else int(clamp(float(v), 0, 255)) for v in color[:3]]
        return f"#{vals[0]:02X}{vals[1]:02X}{vals[2]:02X}"
    return None


def font_category(font_name: str) -> str:
    name = font_name.lower()
    if any(token in name for token in ("song", "serif", "times", "ming", "simsun", "kaiti", "kai")):
        return "serif"
    if any(token in name for token in ("mono", "consolas", "courier")):
        return "monospace"
    if any(token in name for token in ("hei", "sans", "arial", "yahei", "pingfang", "noto", "source han sans")):
        return "sans"
    return "unknown"


def quantize_hex(hex_color: str, step: int = 24) -> str:
    raw = hex_color.lstrip("#")
    if len(raw) != 6:
        return hex_color
    vals = [int(raw[i : i + 2], 16) for i in (0, 2, 4)]
    vals = [int(round(v / step) * step) for v in vals]
    vals = [int(clamp(v, 0, 255)) for v in vals]
    return f"#{vals[0]:02X}{vals[1]:02X}{vals[2]:02X}"


def top_pixmap_colors(page, max_colors: int = 8) -> list[dict[str, Any]]:
    fitz = require_fitz()
    pix = page.get_pixmap(matrix=fitz.Matrix(0.18, 0.18), alpha=False)
    data = pix.samples
    counts: Counter[str] = Counter()
    stride = max(1, pix.n)
    for i in range(0, len(data), stride * 6):
        if i + 2 >= len(data):
            continue
        color = quantize_hex(f"#{data[i]:02X}{data[i + 1]:02X}{data[i + 2]:02X}")
        counts[color] += 1
    total = sum(counts.values()) or 1
    return [{"color": color, "ratio": round(count / total, 4)} for color, count in counts.most_common(max_colors)]


def rect_to_dict(rect, width: float, height: float) -> dict[str, float]:
    return {
        "x": round(rect.x0, 2),
        "y": round(rect.y0, 2),
        "w": round(max(0.0, rect.x1 - rect.x0), 2),
        "h": round(max(0.0, rect.y1 - rect.y0), 2),
        "x_pct": round(rect.x0 / width, 4) if width else 0,
        "y_pct": round(rect.y0 / height, 4) if height else 0,
        "w_pct": round(max(0.0, rect.x1 - rect.x0) / width, 4) if width else 0,
        "h_pct": round(max(0.0, rect.y1 - rect.y0) / height, 4) if height else 0,
    }


def extract_text_blocks(page, width: float, height: float) -> tuple[list[dict[str, Any]], Counter[str], Counter[str], Counter[float], Counter[str]]:
    text_dict = page.get_text("dict")
    blocks: list[dict[str, Any]] = []
    fonts: Counter[str] = Counter()
    categories: Counter[str] = Counter()
    sizes: Counter[float] = Counter()
    colors: Counter[str] = Counter()

    for block in text_dict.get("blocks", []):
        if block.get("type") != 0:
            continue
        spans: list[dict[str, Any]] = []
        text_parts: list[str] = []
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span.get("text", "")
                if not text.strip():
                    continue
                font = str(span.get("font") or "")
                size = round(float(span.get("size") or 0), 1)
                color = rgb_from_int(span.get("color"))
                fonts[font] += len(text)
                categories[font_category(font)] += len(text)
                sizes[size] += len(text)
                if color:
                    colors[color] += len(text)
                text_parts.append(text)
                spans.append(
                    {
                        "text": text[:80],
                        "font": font,
                        "font_category": font_category(font),
                        "size": size,
                        "color": color,
                        "flags": span.get("flags"),
                    }
                )
        full_text = "".join(text_parts).strip()
        if not full_text:
            continue
        rect_vals = block.get("bbox", [0, 0, 0, 0])
        rect = require_fitz().Rect(rect_vals)
        main_span = spans[0] if spans else {}
        blocks.append(
            {
                "text_sample": full_text[:140],
                "char_count": len(full_text),
                "bbox": rect_to_dict(rect, width, height),
                "font": main_span.get("font"),
                "font_category": main_span.get("font_category"),
                "font_size": main_span.get("size"),
                "color": main_span.get("color"),
                "span_count": len(spans),
            }
        )
    return blocks, fonts, categories, sizes, colors


def extract_shapes(page, width: float, height: float) -> tuple[list[dict[str, Any]], Counter[str]]:
    shapes: list[dict[str, Any]] = []
    colors: Counter[str] = Counter()
    for drawing in page.get_drawings():
        rect = drawing.get("rect")
        if not rect:
            continue
        fill = normalize_color(drawing.get("fill"))
        stroke = normalize_color(drawing.get("color"))
        if fill:
            colors[fill] += 1
        if stroke:
            colors[stroke] += 1
        area = max(0.0, (rect.x1 - rect.x0) * (rect.y1 - rect.y0))
        if area < width * height * 0.001:
            continue
        shapes.append(
            {
                "bbox": rect_to_dict(rect, width, height),
                "fill": fill,
                "stroke": stroke,
                "kind": drawing.get("type") or "drawing",
            }
        )
    return shapes[:80], colors


def coarse_region(rect: dict[str, float]) -> str:
    cx = rect["x_pct"] + rect["w_pct"] / 2
    cy = rect["y_pct"] + rect["h_pct"] / 2
    horizontal = "left" if cx < 0.36 else "right" if cx > 0.64 else "center"
    vertical = "top" if cy < 0.28 else "bottom" if cy > 0.72 else "middle"
    return f"{vertical}_{horizontal}"


def layout_signature(text_blocks: list[dict[str, Any]], image_blocks: list[dict[str, Any]], shapes: list[dict[str, Any]]) -> dict[str, Any]:
    all_regions = Counter(coarse_region(item["bbox"]) for item in text_blocks + image_blocks)
    text_regions = Counter(coarse_region(item["bbox"]) for item in text_blocks)
    image_regions = Counter(coarse_region(item["bbox"]) for item in image_blocks)
    wide_text_blocks = [b for b in text_blocks if b["bbox"]["w_pct"] > 0.45]
    compact_blocks = [b for b in text_blocks + shapes if b["bbox"]["w_pct"] < 0.32 and b["bbox"]["h_pct"] < 0.28]
    has_large_right_visual = any(b["bbox"]["x_pct"] > 0.42 and b["bbox"]["w_pct"] > 0.28 for b in image_blocks + shapes)
    has_left_text = any(b["bbox"]["x_pct"] < 0.42 and b["char_count"] > 12 for b in text_blocks)
    has_grid = len(compact_blocks) >= 4
    has_table_like_text = is_table_like(text_blocks)
    has_chart_like_shapes = len(shapes) >= 12 and len(text_blocks) <= 14
    has_flow_like_shapes = len(shapes) >= 6 and len({round(s["bbox"]["y_pct"], 1) for s in shapes}) <= 3
    if has_left_text and has_large_right_visual:
        pattern = "image_text_mix"
    elif has_table_like_text:
        pattern = "table_matrix"
    elif has_chart_like_shapes:
        pattern = "chart_or_diagram"
    elif has_flow_like_shapes:
        pattern = "process_flow"
    elif image_regions and sum(image_regions.values()) >= max(1, len(text_blocks)):
        pattern = "visual_dominant"
    elif has_grid:
        pattern = "card_grid"
    elif text_regions.get("top_center", 0) and len(text_blocks) <= 4:
        pattern = "title_centered"
    elif wide_text_blocks and len(text_blocks) <= 5:
        pattern = "quote_or_statement"
    else:
        pattern = "text_explainer"
    return {
        "pattern": pattern,
        "occupied_regions": [region for region, _ in all_regions.most_common()],
        "text_regions": [region for region, _ in text_regions.most_common()],
        "image_regions": [region for region, _ in image_regions.most_common()],
        "text_block_count": len(text_blocks),
        "image_block_count": len(image_blocks),
        "shape_block_count": len(shapes),
        "table_like": has_table_like_text,
        "chart_like": has_chart_like_shapes,
        "flow_like": has_flow_like_shapes,
    }


def is_table_like(text_blocks: list[dict[str, Any]]) -> bool:
    if len(text_blocks) < 8:
        return False
    xs = [round(b["bbox"]["x_pct"] / 0.08) for b in text_blocks if b["bbox"]["w_pct"] < 0.45]
    ys = [round(b["bbox"]["y_pct"] / 0.06) for b in text_blocks]
    return len(set(xs)) >= 3 and len(set(ys)) >= 3


def text_join(text_blocks: list[dict[str, Any]]) -> str:
    return " ".join(str(b.get("text_sample") or "") for b in text_blocks).lower()


def monospace_weight(text_blocks: list[dict[str, Any]]) -> int:
    return sum(int(b.get("char_count") or 0) for b in text_blocks if b.get("font_category") == "monospace")


def classify_page_role(index: int, total: int, text_blocks: list[dict[str, Any]], image_blocks: list[dict[str, Any]], layout: dict[str, Any]) -> str:
    text_count = len(text_blocks)
    image_count = len(image_blocks)
    max_size = max((float(b.get("font_size") or 0) for b in text_blocks), default=0)
    total_chars = sum(int(b.get("char_count") or 0) for b in text_blocks)
    large_title = max_size >= 24 or (text_blocks and max_size >= max(18, sum(float(b.get("font_size") or 0) for b in text_blocks) / len(text_blocks) * 1.6))
    text = text_join(text_blocks)
    mono_chars = monospace_weight(text_blocks)

    if index == 1 and large_title:
        return "cover"
    if index == total and text_count <= 5 and total_chars <= 160:
        return "closing"
    if any(token in text for token in ("目录", "agenda", "contents", "大纲")) and text_count >= 3:
        return "agenda"
    if large_title and text_count <= 5 and total_chars <= 220 and image_count <= 2:
        return "chapter_divider"
    if mono_chars >= max(80, total_chars * 0.35) or any(token in text for token in ("http", "www.", "def ", "function", "select ", "curl ", "python", "javascript")):
        return "code_or_screenshot"
    if layout["table_like"] and text_count >= 10 and mono_chars < total_chars * 0.2:
        return "table"
    if layout["chart_like"]:
        return "chart"
    if layout["flow_like"]:
        return "process_flow"
    if layout["pattern"] in {"image_text_mix", "visual_dominant"}:
        return "image_text_mix"
    if layout["pattern"] == "card_grid":
        return "card_grid"
    if layout["pattern"] == "quote_or_statement" or (large_title and text_count <= 3 and total_chars <= 120):
        return "quote"
    if text_count >= 8 and image_count == 0:
        return "dense_text"
    return "text_explainer"


def image_blocks_from_page(page, width: float, height: float) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    text_dict = page.get_text("dict")
    for block in text_dict.get("blocks", []):
        if block.get("type") != 1:
            continue
        rect_vals = block.get("bbox", [0, 0, 0, 0])
        rect = require_fitz().Rect(rect_vals)
        blocks.append({"bbox": rect_to_dict(rect, width, height), "kind": "image"})
    return blocks


def summarize_page(page, index: int, total: int) -> dict[str, Any]:
    width = float(page.rect.width)
    height = float(page.rect.height)
    text_blocks, fonts, font_categories, sizes, text_colors = extract_text_blocks(page, width, height)
    image_blocks = image_blocks_from_page(page, width, height)
    shapes, shape_colors = extract_shapes(page, width, height)
    palette = Counter()
    for item in top_pixmap_colors(page):
        palette[item["color"]] += int(item["ratio"] * 10000)
    palette.update(text_colors)
    palette.update(shape_colors)
    layout = layout_signature(text_blocks, image_blocks, shapes)
    page_role = classify_page_role(index, total, text_blocks, image_blocks, layout)

    return {
        "id": f"slide_{index}",
        "page_index": index,
        "page_role": page_role,
        "canvas": {"width": round(width, 2), "height": round(height, 2), "aspect_ratio": round(width / height, 4) if height else None},
        "layout": layout,
        "palette": [{"color": color, "weight": count} for color, count in palette.most_common(10)],
        "typography": {
            "font_families": [{"font": font, "weight": count} for font, count in fonts.most_common(8)],
            "font_categories": [{"category": cat, "weight": count} for cat, count in font_categories.most_common()],
            "font_sizes": [{"size": size, "weight": count} for size, count in sizes.most_common(8)],
            "text_colors": [{"color": color, "weight": count} for color, count in text_colors.most_common(8)],
        },
        "text_blocks": sorted(text_blocks, key=lambda b: (b["bbox"]["y"], b["bbox"]["x"]))[:40],
        "image_blocks": image_blocks[:30],
        "shape_blocks": shapes[:40],
        "usage_notes": role_usage_notes(page_role, layout["pattern"]),
    }


def role_usage_notes(page_role: str, pattern: str) -> str:
    notes = {
        "cover": "Use for deck title, presenter, date, and brand-led opening pages.",
        "agenda": "Use for contents, outline, navigation, or meeting agenda pages.",
        "chapter_divider": "Use as a section divider with a short heading and minimal supporting copy.",
        "image_text_mix": "Use for pages that combine one main narrative area with a large image, screenshot, product visual, or case example.",
        "card_grid": "Use for feature lists, key points, metrics, team members, or grouped comparisons.",
        "table": "Use for structured comparisons, datasets, checklists, schedules, or row/column information.",
        "chart": "Use for KPI, trend, distribution, funnel, or chart-led analytical pages.",
        "process_flow": "Use for step-by-step flows, pipelines, architecture, timelines, or relationship diagrams.",
        "code_or_screenshot": "Use for technical examples, code snippets, terminal output, browser screenshots, or product UI captures.",
        "quote": "Use for a strong statement, conclusion, principle, quote, or one-message emphasis page.",
        "dense_text": "Use for explanation-heavy pages with multiple paragraphs or detailed bullet content.",
        "text_explainer": "Use for normal content pages with title, body copy, and small supporting visuals.",
        "closing": "Use for thanks, contact information, summary, or final call-to-action pages.",
    }
    return f"{notes.get(page_role, notes['text_explainer'])} Detected layout pattern: {pattern}."


def aggregate_by_role(slides: list[dict[str, Any]]) -> dict[str, Any]:
    roles: dict[str, Any] = {}
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for slide in slides:
        grouped[slide["page_role"]].append(slide)
    for role, items in grouped.items():
        patterns = Counter(item["layout"]["pattern"] for item in items)
        colors = Counter()
        fonts = Counter()
        sizes = Counter()
        for item in items:
            colors.update({p["color"]: p["weight"] for p in item["palette"]})
            fonts.update({f["font"]: f["weight"] for f in item["typography"]["font_families"]})
            sizes.update({str(s["size"]): s["weight"] for s in item["typography"]["font_sizes"]})
        roles[role] = {
            "slide_ids": [item["id"] for item in items],
            "count": len(items),
            "common_patterns": [{"pattern": pattern, "count": count} for pattern, count in patterns.most_common()],
            "recommended_palette": [{"color": color, "weight": weight} for color, weight in colors.most_common(8)],
            "recommended_fonts": [{"font": font, "weight": weight} for font, weight in fonts.most_common(6)],
            "recommended_font_sizes": [{"size": size, "weight": weight} for size, weight in sizes.most_common(6)],
            "selection_hint": role_usage_notes(role, patterns.most_common(1)[0][0] if patterns else "unknown"),
        }
    return roles


def build_markdown(style: dict[str, Any]) -> str:
    lines = [
        "# PDF Template Style",
        "",
        f"- Source: {style['source']}",
        f"- Page count: {style['page_count']}",
        "",
        "## Page Role Library",
        "",
    ]
    for role, info in style["role_library"].items():
        lines.extend(
            [
                f"### {role}",
                f"- Slides: {', '.join(info['slide_ids'])}",
                f"- Use case: {info['selection_hint']}",
                f"- Common patterns: {', '.join(p['pattern'] for p in info['common_patterns'])}",
                f"- Palette: {', '.join(p['color'] for p in info['recommended_palette'][:6])}",
                f"- Fonts: {', '.join(f['font'] for f in info['recommended_fonts'][:4])}",
                f"- Font sizes: {', '.join(str(s['size']) for s in info['recommended_font_sizes'][:5])}",
                "",
            ]
        )
    lines.append("## Per-Page Layout Notes")
    lines.append("")
    for slide in style["slides"]:
        palette = ", ".join(p["color"] for p in slide["palette"][:6])
        fonts = ", ".join(f["font"] for f in slide["typography"]["font_families"][:4])
        regions = ", ".join(slide["layout"]["occupied_regions"][:6])
        lines.extend(
            [
                f"### {slide['id']} - {slide['page_role']}",
                f"- Pattern: {slide['layout']['pattern']}",
                f"- Regions: {regions}",
                f"- Palette: {palette}",
                f"- Fonts: {fonts}",
                f"- Usage: {slide['usage_notes']}",
                "",
            ]
        )
    return "\n".join(lines)


def build_style_reference(pdf: Path, output_dir: Path) -> None:
    fitz = require_fitz()
    clean_output_dir(output_dir)

    doc = fitz.open(pdf)
    try:
        slides = [summarize_page(page, index, len(doc)) for index, page in enumerate(doc, 1)]
    finally:
        doc.close()

    style = {
        "schema_version": "1.0",
        "source": str(pdf),
        "mode": "style-reference",
        "page_count": len(slides),
        "role_library": aggregate_by_role(slides),
        "slides": slides,
    }
    (output_dir / "template_style.md").write_text(build_markdown(style), encoding="utf-8")


def build_visual_replica(pdf: Path, output_dir: Path) -> None:
    clean_output_dir(output_dir)
    run([sys.executable, str(SCRIPT_DIR / "pdf_to_svg.py"), str(pdf), "--output-dir", str(output_dir)])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build PDF template outputs in style-reference or visual-replica mode.")
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--mode", choices=["style-reference", "visual-replica"], default="style-reference")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.mode == "style-reference":
        build_style_reference(args.pdf, args.output_dir)
    else:
        build_visual_replica(args.pdf, args.output_dir)


if __name__ == "__main__":
    main()
