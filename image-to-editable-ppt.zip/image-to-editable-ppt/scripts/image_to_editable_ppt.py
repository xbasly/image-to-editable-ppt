#!/usr/bin/env python
"""Create an editable PPTX template from slide screenshots.

This is a heuristic first-pass generator. It favors editable rectangles, lines,
and text placeholders over flattened image fidelity.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Emu, Pt


Color = Tuple[int, int, int]


@dataclass
class Box:
    x: int
    y: int
    w: int
    h: int
    color: Color
    kind: str = "shape"

    @property
    def area(self) -> int:
        return self.w * self.h

    def intersects(self, other: "Box") -> bool:
        return not (
            self.x + self.w <= other.x
            or other.x + other.w <= self.x
            or self.y + self.h <= other.y
            or other.y + other.h <= self.y
        )

    def intersection_area(self, other: "Box") -> int:
        x1 = max(self.x, other.x)
        y1 = max(self.y, other.y)
        x2 = min(self.x + self.w, other.x + other.w)
        y2 = min(self.y + self.h, other.y + other.h)
        if x2 <= x1 or y2 <= y1:
            return 0
        return (x2 - x1) * (y2 - y1)

    def contains_center_of(self, other: "Box") -> bool:
        cx = other.x + other.w / 2
        cy = other.y + other.h / 2
        return self.x <= cx <= self.x + self.w and self.y <= cy <= self.y + self.h


def quantize_color(color: Color, bucket: int = 24) -> Color:
    return tuple(min(255, int(round(channel / bucket) * bucket)) for channel in color)  # type: ignore[return-value]


def color_distance(a: Color, b: Color) -> int:
    return sum(abs(x - y) for x, y in zip(a, b))


def dominant_color(img: Image.Image) -> Color:
    sample = img.resize((96, max(1, int(96 * img.height / img.width))))
    colors = [quantize_color(pixel[:3], 16) for pixel in sample.convert("RGB").getdata()]
    return Counter(colors).most_common(1)[0][0]


def scale_box(box: Box, src_w: int, src_h: int, dst_w: int, dst_h: int) -> Box:
    return Box(
        x=round(box.x * dst_w / src_w),
        y=round(box.y * dst_h / src_h),
        w=max(1, round(box.w * dst_w / src_w)),
        h=max(1, round(box.h * dst_h / src_h)),
        color=box.color,
        kind=box.kind,
    )


def component_boxes(
    mask: List[List[bool]],
    colors: List[List[Color]],
    min_area: int,
    match_color: bool = True,
) -> List[Box]:
    height = len(mask)
    width = len(mask[0]) if height else 0
    seen = [[False] * width for _ in range(height)]
    boxes: List[Box] = []

    for y in range(height):
        for x in range(width):
            if seen[y][x] or not mask[y][x]:
                continue
            target = colors[y][x]
            queue = deque([(x, y)])
            seen[y][x] = True
            xs: List[int] = []
            ys: List[int] = []
            component_colors: List[Color] = []

            while queue:
                cx, cy = queue.popleft()
                xs.append(cx)
                ys.append(cy)
                component_colors.append(colors[cy][cx])
                for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                    if nx < 0 or ny < 0 or nx >= width or ny >= height:
                        continue
                    if seen[ny][nx] or not mask[ny][nx]:
                        continue
                    if match_color and color_distance(colors[ny][nx], target) > 36:
                        continue
                    seen[ny][nx] = True
                    queue.append((nx, ny))

            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
            box = Box(
                min_x,
                min_y,
                max_x - min_x + 1,
                max_y - min_y + 1,
                Counter(component_colors).most_common(1)[0][0],
            )
            if box.area >= min_area:
                boxes.append(box)

    return boxes


def crop_dominant_color(img: Image.Image, box: Box) -> Color:
    crop = img.crop((box.x, box.y, box.x + box.w, box.y + box.h))
    sample_w = min(80, max(1, crop.width))
    sample_h = max(1, round(crop.height * sample_w / max(1, crop.width)))
    sample = crop.resize((sample_w, sample_h)).convert("RGB")
    colors = [quantize_color(pixel[:3], 16) for pixel in sample.getdata()]
    return Counter(colors).most_common(1)[0][0]


def color_complexity(img: Image.Image, box: Box) -> int:
    crop = img.crop((box.x, box.y, box.x + box.w, box.y + box.h))
    sample_w = min(96, max(1, crop.width))
    sample_h = max(1, round(crop.height * sample_w / max(1, crop.width)))
    sample = crop.resize((sample_w, sample_h)).convert("RGB")
    return len({quantize_color(pixel[:3], 20) for pixel in sample.getdata()})


def sample_text_color(img: Image.Image, box: Box, bg: Color) -> Color:
    x1 = max(0, box.x)
    y1 = max(0, box.y)
    x2 = min(img.width, box.x + box.w)
    y2 = min(img.height, box.y + box.h)
    crop = img.crop((x1, y1, x2, y2)).convert("RGB")
    colors = [
        pixel[:3]
        for pixel in crop.getdata()
        if color_distance(pixel[:3], bg) > 45
    ]
    if not colors:
        return contrast_color_tuple(bg)
    return Counter(quantize_color(c, 16) for c in colors).most_common(1)[0][0]


def contrast_color_tuple(color: Color) -> Color:
    luma = 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2]
    return (32, 32, 32) if luma > 150 else (245, 245, 245)


def parse_hex_color(value: str | None, fallback: Color) -> Color:
    if not value:
        return fallback
    value = value.strip()
    if value.startswith("#"):
        value = value[1:]
    if len(value) != 6:
        return fallback
    try:
        return (int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))
    except ValueError:
        return fallback


def clamp01(value: Any, fallback: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = fallback
    return max(0.0, min(1.0, number))


def detect_media_regions(img: Image.Image, bg: Color) -> List[Box]:
    """Find large complex raster areas, such as photos, to keep as one placeholder."""
    max_w = 260
    small_w = min(max_w, img.width)
    small_h = max(1, round(img.height * small_w / img.width))
    small = img.convert("RGB").resize((small_w, small_h))
    rows: List[List[Color]] = []
    mask: List[List[bool]] = []
    for y in range(small_h):
        color_row: List[Color] = []
        mask_row: List[bool] = []
        for x in range(small_w):
            c = quantize_color(small.getpixel((x, y)), 20)
            color_row.append(c)
            mask_row.append(color_distance(c, bg) > 46)
        rows.append(color_row)
        mask.append(mask_row)

    raw = component_boxes(mask, rows, min_area=max(80, int(small_w * small_h * 0.01)), match_color=False)
    boxes = [scale_box(b, small_w, small_h, img.width, img.height) for b in raw]
    media: List[Box] = []
    for box in boxes:
        large_enough = box.w >= img.width * 0.12 and box.h >= img.height * 0.11
        not_full_bleed = box.area <= img.width * img.height * 0.55
        if not (large_enough and not_full_bleed):
            continue
        complexity = color_complexity(img, box)
        if complexity >= 42:
            media.append(Box(box.x, box.y, box.w, box.h, crop_dominant_color(img, box), "media"))
    return merge_similar_boxes(media, img.width, img.height)[:20]


def detect_flat_regions(img: Image.Image, bg: Color, suppress: List[Box] | None = None) -> List[Box]:
    suppress = suppress or []
    max_w = 360
    small_w = min(max_w, img.width)
    small_h = max(1, round(img.height * small_w / img.width))
    small = img.convert("RGB").resize((small_w, small_h))
    rows: List[List[Color]] = []
    mask: List[List[bool]] = []
    for y in range(small_h):
        color_row: List[Color] = []
        mask_row: List[bool] = []
        for x in range(small_w):
            c = quantize_color(small.getpixel((x, y)), 24)
            color_row.append(c)
            mask_row.append(color_distance(c, bg) > 42)
        rows.append(color_row)
        mask.append(mask_row)

    raw = component_boxes(mask, rows, min_area=max(30, int(small_w * small_h * 0.002)))
    boxes = [scale_box(b, small_w, small_h, img.width, img.height) for b in raw]
    boxes = [b for b in boxes if b.w >= img.width * 0.025 and b.h >= img.height * 0.012]
    boxes = [b for b in boxes if not any(s.contains_center_of(b) or b.intersection_area(s) > b.area * 0.45 for s in suppress)]
    return merge_similar_boxes(boxes, img.width, img.height)


def detect_text_regions(img: Image.Image, bg: Color, suppress: List[Box] | None = None) -> List[Box]:
    suppress = suppress or []
    gray = img.convert("L")
    max_w = 420
    small_w = min(max_w, img.width)
    small_h = max(1, round(img.height * small_w / img.width))
    small = gray.resize((small_w, small_h))
    bg_luma = int(0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2])
    rows: List[List[Color]] = []
    mask: List[List[bool]] = []
    for y in range(small_h):
        color_row: List[Color] = []
        mask_row: List[bool] = []
        for x in range(small_w):
            luma = small.getpixel((x, y))
            color_row.append((luma, luma, luma))
            mask_row.append(abs(luma - bg_luma) > 58)
        rows.append(color_row)
        mask.append(mask_row)

    raw = component_boxes(mask, rows, min_area=4)
    scaled = [scale_box(b, small_w, small_h, img.width, img.height) for b in raw]
    candidates = [
        b
        for b in scaled
        if 3 <= b.h <= img.height * 0.14
        and 3 <= b.w <= img.width * 0.9
        and b.area <= img.width * img.height * 0.04
    ]
    candidates = [
        b
        for b in candidates
        if not any(s.contains_center_of(b) or b.intersection_area(s) > b.area * 0.2 for s in suppress)
    ]
    grouped = group_text_boxes(candidates, img.width, img.height)
    result: List[Box] = []
    for box in grouped:
        suppressed_area = sum(box.intersection_area(s) for s in suppress)
        if box.area > img.width * img.height * 0.12:
            continue
        if any(s.contains_center_of(box) for s in suppress) or suppressed_area > box.area * 0.18:
            continue
        box.color = sample_text_color(img, box, bg)
        result.append(box)
    return result


def group_text_boxes(boxes: List[Box], width: int, height: int) -> List[Box]:
    if not boxes:
        return []
    boxes = sorted(boxes, key=lambda b: (b.y, b.x))
    lines: List[Box] = []
    used = [False] * len(boxes)
    for i, box in enumerate(boxes):
        if used[i]:
            continue
        used[i] = True
        x1, y1 = box.x, box.y
        x2, y2 = box.x + box.w, box.y + box.h
        colors = [box.color]
        changed = True
        while changed:
            changed = False
            for j, other in enumerate(boxes):
                if used[j]:
                    continue
                same_line = abs((other.y + other.h / 2) - ((y1 + y2) / 2)) <= max(8, (y2 - y1) * 0.8)
                close = other.x <= x2 + width * 0.04 and other.x + other.w >= x1 - width * 0.01
                if same_line and close:
                    used[j] = True
                    x1 = min(x1, other.x)
                    y1 = min(y1, other.y)
                    x2 = max(x2, other.x + other.w)
                    y2 = max(y2, other.y + other.h)
                    colors.append(other.color)
                    changed = True
        w, h = x2 - x1, y2 - y1
        if w >= width * 0.02 and h >= height * 0.008:
            lines.append(Box(x1, y1, w, h, Counter(colors).most_common(1)[0][0], "text"))
    return merge_nearby_text_lines(lines, width, height)


def merge_nearby_text_lines(lines: List[Box], width: int, height: int) -> List[Box]:
    merged: List[Box] = []
    for line in sorted(lines, key=lambda b: (b.x // max(1, width // 8), b.y)):
        matched = None
        for existing in merged:
            x_overlap = min(existing.x + existing.w, line.x + line.w) - max(existing.x, line.x)
            same_column = x_overlap > min(existing.w, line.w) * 0.35
            close_y = 0 <= line.y - (existing.y + existing.h) <= height * 0.04
            if same_column and close_y:
                matched = existing
                break
        if matched:
            x1 = min(matched.x, line.x)
            y1 = min(matched.y, line.y)
            x2 = max(matched.x + matched.w, line.x + line.w)
            y2 = max(matched.y + matched.h, line.y + line.h)
            matched.x, matched.y, matched.w, matched.h = x1, y1, x2 - x1, y2 - y1
        else:
            merged.append(line)
    return merged[:40]


def merge_similar_boxes(boxes: List[Box], width: int, height: int) -> List[Box]:
    result: List[Box] = []
    for box in sorted(boxes, key=lambda b: b.area, reverse=True):
        if box.area > width * height * 0.75:
            continue
        if any(box.intersects(existing) and box.area < existing.area * 0.65 for existing in result):
            continue
        result.append(box)
    return result[:55]


def classify_shape(box: Box, slide_w: int, slide_h: int) -> str:
    if box.h <= slide_h * 0.015 and box.w >= slide_w * 0.12:
        return "line"
    if box.w <= slide_w * 0.012 and box.h >= slide_h * 0.08:
        return "line"
    if box.area >= slide_w * slide_h * 0.045:
        return "placeholder"
    return "shape"


def to_emu(value: float, pixels: int, emu_total: int) -> Emu:
    return Emu(round(value * emu_total / pixels))


def add_rect(slide, box: Box, img_w: int, img_h: int, prs: Presentation, label: str | None = None) -> None:
    left = to_emu(box.x, img_w, prs.slide_width)
    top = to_emu(box.y, img_h, prs.slide_height)
    width = to_emu(box.w, img_w, prs.slide_width)
    height = to_emu(box.h, img_h, prs.slide_height)
    shape = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(*box.color)
    shape.line.color.rgb = RGBColor(*box.color)
    if label:
        shape.text = label
        shape.text_frame.margin_left = 0
        shape.text_frame.margin_right = 0
        shape.text_frame.margin_top = 0
        shape.text_frame.margin_bottom = 0
        para = shape.text_frame.paragraphs[0]
        para.alignment = PP_ALIGN.CENTER
        run = para.runs[0]
        run.font.size = Pt(max(8, min(18, box.h * 0.08)))
        run.font.color.rgb = contrast_color(box.color)


def add_text(slide, box: Box, img_w: int, img_h: int, prs: Presentation, text: str) -> None:
    margin_x = max(4, round(box.w * 0.06))
    margin_y = max(3, round(box.h * 0.28))
    left = to_emu(max(0, box.x - margin_x), img_w, prs.slide_width)
    top = to_emu(max(0, box.y - margin_y), img_h, prs.slide_height)
    width = to_emu(min(img_w - box.x, box.w + margin_x * 2), img_w, prs.slide_width)
    height = to_emu(min(img_h - box.y, box.h + margin_y * 2), img_h, prs.slide_height)
    tx = slide.shapes.add_textbox(left, top, width, height)
    tx.text = text
    tx.text_frame.margin_left = 0
    tx.text_frame.margin_right = 0
    tx.text_frame.margin_top = 0
    tx.text_frame.margin_bottom = 0
    tx.text_frame.word_wrap = True
    para = tx.text_frame.paragraphs[0]
    para.alignment = PP_ALIGN.LEFT
    run = para.runs[0]
    run.font.size = Pt(max(7, min(34, box.h * 0.48)))
    run.font.color.rgb = RGBColor(*box.color)


def contrast_color(color: Color) -> RGBColor:
    luma = 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2]
    return RGBColor(32, 32, 32) if luma > 150 else RGBColor(245, 245, 245)


def placeholder_label(box: Box, img_w: int, img_h: int) -> str:
    ratio = box.w / max(1, box.h)
    if box.w > img_w * 0.35 and box.h > img_h * 0.2:
        return "Image"
    if ratio > 2.2:
        return "Chart"
    if ratio < 0.65 and box.h > img_h * 0.15:
        return "Image"
    return "Placeholder"


def text_label(index: int, box: Box, img_w: int, img_h: int) -> str:
    if box.y < img_h * 0.22 and box.h > img_h * 0.025:
        return "Title" if index == 0 else "Subtitle"
    if box.h > img_h * 0.035:
        return "Section"
    if box.w < img_w * 0.12:
        return "Label"
    return "Body text"


def set_slide_background(slide, color: Color) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(*color)


def align_from_string(value: str | None) -> PP_ALIGN:
    if value == "center":
        return PP_ALIGN.CENTER
    if value == "right":
        return PP_ALIGN.RIGHT
    return PP_ALIGN.LEFT


def font_name_from_family(value: str | None) -> str:
    value = (value or "sans").lower()
    if value == "serif":
        return "SimSun"
    if value == "mono":
        return "Consolas"
    return "Microsoft YaHei"


def add_layout_text(slide, element: Dict[str, Any], prs: Presentation) -> None:
    x = clamp01(element.get("x"))
    y = clamp01(element.get("y"))
    w = clamp01(element.get("w"), 0.1)
    h = clamp01(element.get("h"), 0.05)
    tx = slide.shapes.add_textbox(
        Emu(round(x * prs.slide_width)),
        Emu(round(y * prs.slide_height)),
        Emu(round(w * prs.slide_width)),
        Emu(round(h * prs.slide_height)),
    )
    tx.text_frame.margin_left = 0
    tx.text_frame.margin_right = 0
    tx.text_frame.margin_top = 0
    tx.text_frame.margin_bottom = 0
    tx.text_frame.word_wrap = True
    text = element.get("text") or element.get("label") or "Text"
    tx.text = str(text)
    para = tx.text_frame.paragraphs[0]
    para.alignment = align_from_string(element.get("align"))
    if para.runs:
        run = para.runs[0]
    else:
        run = para.add_run()
        run.text = str(text)
    run.font.size = Pt(float(element.get("font_size") or 12))
    run.font.bold = bool(element.get("bold", False))
    run.font.name = font_name_from_family(element.get("font_family"))
    run.font.color.rgb = RGBColor(*parse_hex_color(element.get("color"), (32, 32, 32)))


def add_layout_rect(slide, element: Dict[str, Any], prs: Presentation, label: str | None = None) -> None:
    x = clamp01(element.get("x"))
    y = clamp01(element.get("y"))
    w = clamp01(element.get("w"), 0.1)
    h = clamp01(element.get("h"), 0.05)
    fill = parse_hex_color(element.get("fill"), (230, 230, 230))
    stroke = parse_hex_color(element.get("stroke"), fill)
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        Emu(round(x * prs.slide_width)),
        Emu(round(y * prs.slide_height)),
        Emu(round(w * prs.slide_width)),
        Emu(round(h * prs.slide_height)),
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(*fill)
    shape.line.color.rgb = RGBColor(*stroke)
    if label:
        shape.text = label
        shape.text_frame.margin_left = 0
        shape.text_frame.margin_right = 0
        shape.text_frame.margin_top = 0
        shape.text_frame.margin_bottom = 0
        para = shape.text_frame.paragraphs[0]
        para.alignment = PP_ALIGN.CENTER
        run = para.runs[0]
        run.font.size = Pt(float(element.get("font_size") or 12))
        run.font.color.rgb = contrast_color(fill)


def add_layout_line(slide, element: Dict[str, Any], prs: Presentation) -> None:
    x = clamp01(element.get("x"))
    y = clamp01(element.get("y"))
    w = clamp01(element.get("w"), 0.1)
    h = clamp01(element.get("h"), 0.002)
    fill = parse_hex_color(element.get("stroke") or element.get("fill"), (120, 120, 120))
    if w >= h:
        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.RECTANGLE,
            Emu(round(x * prs.slide_width)),
            Emu(round(y * prs.slide_height)),
            Emu(round(w * prs.slide_width)),
            Emu(max(1, round(h * prs.slide_height))),
        )
    else:
        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.RECTANGLE,
            Emu(round(x * prs.slide_width)),
            Emu(round(y * prs.slide_height)),
            Emu(max(1, round(w * prs.slide_width))),
            Emu(round(h * prs.slide_height)),
        )
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(*fill)
    shape.line.fill.background()


def render_layout_json(layout_path: Path, output: Path) -> None:
    data = json.loads(layout_path.read_text(encoding="utf-8-sig"))
    slides_data = data.get("slides", [])
    if not slides_data:
        raise ValueError("Layout JSON must contain a non-empty slides array.")

    first = slides_data[0]
    src_w = float(first.get("width") or 16)
    src_h = float(first.get("height") or 9)
    prs = Presentation()
    prs.slide_width = Emu(9144000)
    prs.slide_height = Emu(round(9144000 * src_h / src_w))
    blank = prs.slide_layouts[6]

    for slide_data in slides_data:
        slide = prs.slides.add_slide(blank)
        bg = parse_hex_color(slide_data.get("background"), (255, 255, 255))
        set_slide_background(slide, bg)
        elements = slide_data.get("elements") or []

        # Render large backgrounds and placeholders first, text last.
        for element in elements:
            kind = str(element.get("type", "rect")).lower()
            if kind in {"rect", "logo"}:
                add_layout_rect(slide, element, prs, element.get("label") if kind == "logo" else None)
            elif kind == "media":
                add_layout_rect(slide, element, prs, element.get("label") or "Image")
            elif kind == "line":
                add_layout_line(slide, element, prs)
        for element in elements:
            if str(element.get("type", "")).lower() == "text":
                add_layout_text(slide, element, prs)

    output.parent.mkdir(parents=True, exist_ok=True)
    prs.save(output)


def build_presentation(image_paths: Iterable[Path], output: Path) -> None:
    images = [Path(p) for p in image_paths]
    if not images:
        raise ValueError("At least one input image is required.")

    first = Image.open(images[0])
    prs = Presentation()
    prs.slide_width = Emu(9144000)
    prs.slide_height = Emu(round(9144000 * first.height / first.width))
    blank = prs.slide_layouts[6]

    for image_path in images:
        img = Image.open(image_path).convert("RGB")
        bg = dominant_color(img)
        slide = prs.slides.add_slide(blank)
        set_slide_background(slide, bg)

        media_boxes = detect_media_regions(img, bg)
        shape_boxes = detect_flat_regions(img, bg, suppress=media_boxes)
        text_boxes = detect_text_regions(img, bg, suppress=media_boxes)

        for box in media_boxes:
            add_rect(slide, box, img.width, img.height, prs, placeholder_label(box, img.width, img.height))

        for box in shape_boxes:
            kind = classify_shape(box, img.width, img.height)
            if kind == "placeholder":
                add_rect(slide, box, img.width, img.height, prs, placeholder_label(box, img.width, img.height))
            else:
                add_rect(slide, box, img.width, img.height, prs)

        for i, box in enumerate(text_boxes):
            add_text(slide, box, img.width, img.height, prs, text_label(i, box, img.width, img.height))

    if len(prs.slides) > len(images):
        xml_slides = prs.slides._sldIdLst  # pylint: disable=protected-access
        rel_id = xml_slides[0].rId
        prs.part.drop_rel(rel_id)
        xml_slides.remove(xml_slides[0])

    output.parent.mkdir(parents=True, exist_ok=True)
    prs.save(output)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create an editable PPTX template from slide images.")
    parser.add_argument("images", nargs="*", type=Path, help="Input slide screenshots/images.")
    parser.add_argument("-o", "--output", required=True, type=Path, help="Output .pptx path.")
    parser.add_argument("--layout-json", type=Path, help="Vision-generated layout JSON to render.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.layout_json:
        render_layout_json(args.layout_json, args.output)
    else:
        build_presentation(args.images, args.output)


if __name__ == "__main__":
    main()
