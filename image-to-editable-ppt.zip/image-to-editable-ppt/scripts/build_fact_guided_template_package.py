#!/usr/bin/env python
"""Build a fact-guided SVG template package from a PPTX file."""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def build_package(
    pptx: Path,
    output_dir: Path,
    config: Path | None,
    max_slides: int | None,
    max_objects: int,
) -> None:
    raw_dir = output_dir / "raw"
    facts_dir = raw_dir / "pptx_facts"
    svg_dir = output_dir / "visual_templates"
    schema_path = output_dir / "template.schema.json"
    review_pptx = output_dir / "review.pptx"
    review_visual_pptx = output_dir / "review_visual.pptx"

    output_dir.mkdir(parents=True, exist_ok=True)
    if facts_dir.exists():
        shutil.rmtree(facts_dir)
    if svg_dir.exists():
        shutil.rmtree(svg_dir)

    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "extract_pptx_facts.py"),
            str(pptx),
            "--output-dir",
            str(facts_dir),
        ]
    )
    generate_cmd = [
        sys.executable,
        str(SCRIPT_DIR / "generate_svg_from_pptx_facts.py"),
        "--facts-dir",
        str(facts_dir),
        "--output-dir",
        str(svg_dir),
        "--max-objects",
        str(max_objects),
    ]
    if config:
        generate_cmd.extend(["--config", str(config)])
    if max_slides:
        generate_cmd.extend(["--max-slides", str(max_slides)])
    run(generate_cmd)
    facts_assets = facts_dir / "assets"
    svg_assets = svg_dir / "assets"
    if facts_assets.exists():
        if svg_assets.exists():
            shutil.rmtree(svg_assets)
        shutil.copytree(facts_assets, svg_assets)
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "svg_to_template_schema.py"),
            "--svg-dir",
            str(svg_dir),
            "--output",
            str(schema_path),
        ]
    )
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "render_schema_pptx.py"),
            "--schema",
            str(schema_path),
            "--output",
            str(review_pptx),
        ]
    )
    run(
        [
            sys.executable,
            str(SCRIPT_DIR / "render_svg_pptx.py"),
            "--svg-dir",
            str(svg_dir),
            "--output",
            str(review_visual_pptx),
        ]
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a fact-guided SVG template package from PPTX.")
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--max-slides", type=int, help="Useful for quick trials before processing a full deck.")
    parser.add_argument("--max-objects", type=int, default=40)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    build_package(args.pptx, args.output_dir, args.config, args.max_slides, args.max_objects)


if __name__ == "__main__":
    main()
