#!/usr/bin/env python
"""Convert PDF pages to SVG files for SVG-first template extraction."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


def sanitize_svg_xml(text: str) -> str:
    return re.sub(r"&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9A-Fa-f]+;)", "&amp;", text)


def page_to_svg(page) -> str:
    try:
        return page.get_svg_image(text_as_path=False)
    except TypeError:
        return page.get_svg_image()


def convert_pdf_to_svg(pdf_path: Path, output_dir: Path, prefix: str = "slide") -> None:
    try:
        import fitz
    except ImportError as exc:
        raise RuntimeError("pdf_to_svg.py requires PyMuPDF. Install it with: python -m pip install pymupdf") from exc

    output_dir.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(pdf_path)
    try:
        for index, page in enumerate(doc, 1):
            svg = sanitize_svg_xml(page_to_svg(page))
            (output_dir / f"{prefix}_{index}.svg").write_text(svg, encoding="utf-8")
    finally:
        doc.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert PDF pages to SVG files.")
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--prefix", default="slide")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    convert_pdf_to_svg(args.pdf, args.output_dir, args.prefix)


if __name__ == "__main__":
    main()
