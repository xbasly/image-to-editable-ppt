#!/usr/bin/env python
"""Generate slot-annotated SVG templates from slide screenshots."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

from PIL import Image

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from analyze_slide_layout import image_to_data_url, normalize_base_url  # noqa: E402
from model_config import load_model_config, resolve_api_key  # noqa: E402


PROMPT = """Create a reusable SVG template from this PowerPoint slide screenshot.

Return SVG only. Do not wrap it in Markdown. Do not explain.

Goal:
- Produce an SVG that visually previews the slide template layout.
- It will later be parsed into a PPT template schema.
- Use placeholders, not exact content reproduction.

Rules:
- Preserve the screenshot's layout, spacing, hierarchy, background color, approximate typography, and major visual blocks.
- All text must be editable SVG <text> elements with placeholder wording.
- Photos, logos, complex graphics, charts, maps, screenshots, watermarks, and abstract artwork must be single placeholder <rect> blocks, not decomposed fragments.
- Every meaningful element must include:
  data-slot-id="stable_snake_case_id"
  data-type="text|image|graphic|logo|shape|line"
  data-role="title|subtitle|body|logo|image|graphic|feature_item|caption|button|footer|metric|separator"
- Every <text> element must also include its intended text box:
  data-box-x="left"
  data-box-y="top"
  data-box-w="width"
  data-box-h="height"
  These values should match the source text region, not the placeholder text length.
- Use normalized-looking stable IDs, e.g. main_title, body_copy, brand_logo, hero_graphic, city_image_1.
- Use viewBox="0 0 IMAGE_WIDTH IMAGE_HEIGHT" and width/height equal to the source image size.
- For text style, include font-family, font-size, font-weight, fill, and text-anchor when useful.
- For multi-line text, keep one <text> element with <tspan> children and the same data-box-* bounding box.
- Escape XML special characters inside text nodes and attributes, especially & as &amp;.
- For placeholder graphics/images/logos, use light neutral fills and a centered label.
- Keep repeated structures expanded as separate elements. Do not output one abstract repeat block.
- Do not embed raster images or use the original screenshot as a background.

SVG quality target:
- A designer should recognize the slide template structure from the SVG preview.
- The SVG does not need exact text content.
- Complex visuals should be represented by correctly sized placeholders.
"""


def extract_svg(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:svg|xml)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)
    start = text.find("<svg")
    end = text.rfind("</svg>")
    if start == -1 or end == -1:
        raise ValueError(f"Model did not return SVG: {text[:500]}")
    return text[start : end + len("</svg>")]


def request_svg(image_path: Path, model: str, api_key: str, base_url: str, timeout: int) -> str:
    with Image.open(image_path) as img:
        width, height = img.size
    body: Dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": f"{PROMPT}\nSource image size: {width}x{height}."},
                    {"type": "image_url", "image_url": {"url": image_to_data_url(image_path)}},
                ],
            }
        ],
    }
    req = urllib.request.Request(
        f"{normalize_base_url(base_url)}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Vision API error {exc.code}: {detail}") from exc
    return extract_svg(payload["choices"][0]["message"]["content"])


def generate_svgs(image_paths: List[Path], output_dir: Path, model: str, base_url: str, timeout: int, api_key_env: str) -> None:
    api_key = resolve_api_key({"api_key_env": api_key_env})
    if not api_key:
        raise RuntimeError(f"{api_key_env} or OPENAI_API_KEY is required.")
    output_dir.mkdir(parents=True, exist_ok=True)
    for i, image_path in enumerate(image_paths, 1):
        svg = request_svg(image_path, model, api_key, base_url, timeout)
        (output_dir / f"slide_{i}.svg").write_text(svg, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate slot-annotated SVG templates from screenshots.")
    parser.add_argument("images", nargs="+", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--config", type=Path, help="Model config JSON. Defaults to ../config/model_config.json.")
    parser.add_argument("--model")
    parser.add_argument("--base-url")
    parser.add_argument("--api-key-env")
    parser.add_argument("--request-timeout", type=int)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_model_config(args.config)
    model = args.model or config["model"]
    base_url = args.base_url or config["base_url"]
    api_key_env = args.api_key_env or config["api_key_env"]
    timeout = args.request_timeout or int(config["request_timeout"])
    generate_svgs(args.images, args.output_dir, model, base_url, timeout, api_key_env)


if __name__ == "__main__":
    main()
