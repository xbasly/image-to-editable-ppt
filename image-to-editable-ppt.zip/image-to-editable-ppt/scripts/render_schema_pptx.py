#!/usr/bin/env python
"""Render reusable template schema to editable PPTX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Tuple

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Emu, Pt


Color = Tuple[int, int, int]


def parse_color(value: str | None, fallback: Color) -> Color:
    if not value:
        return fallback
    value = str(value).strip()
    if value.startswith("#"):
        value = value[1:]
    if len(value) != 6:
        return fallback
    try:
        return (int(value[:2], 16), int(value[2:4], 16), int(value[4:], 16))
    except ValueError:
        return fallback


def family_name(value: str | None) -> str:
    value = (value or "sans").lower()
    if value == "serif":
        return "SimSun"
    if value == "mono":
        return "Consolas"
    return "Microsoft YaHei"


def align(value: str | None) -> PP_ALIGN:
    return {"center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT}.get(value, PP_ALIGN.LEFT)


def emu_x(prs: Presentation, value: float) -> Emu:
    return Emu(round(value * prs.slide_width))


def emu_y(prs: Presentation, value: float) -> Emu:
    return Emu(round(value * prs.slide_height))


def set_bg(slide, color: Color) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(*color)


def add_text(slide, prs: Presentation, slot: Dict[str, Any], theme: Dict[str, Any]) -> None:
    style = slot.get("style", {})
    shape = slide.shapes.add_textbox(
        emu_x(prs, float(slot.get("x", 0))),
        emu_y(prs, float(slot.get("y", 0))),
        emu_x(prs, float(slot.get("w", 0.1))),
        emu_y(prs, float(slot.get("h", 0.05))),
    )
    tf = shape.text_frame
    tf.margin_left = 0
    tf.margin_right = 0
    tf.margin_top = 0
    tf.margin_bottom = 0
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.TOP
    text = str(slot.get("content") or slot.get("placeholder") or slot.get("role") or "Text")
    lines = text.splitlines() or [text]
    font_size = fit_font_size(
        float(style.get("font_size") or 12),
        float(slot.get("h", 0.05)),
        len(lines),
        prs,
    )
    color = parse_color(style.get("color"), parse_color(theme.get("primary"), (17, 17, 17)))
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align(style.get("align"))
        p.space_before = Pt(0)
        p.space_after = Pt(0)
        run = p.add_run()
        run.text = line
        run.font.name = family_name(style.get("font_family") or theme.get("font_family"))
        run.font.size = Pt(font_size)
        run.font.bold = bool(style.get("bold", False))
        run.font.color.rgb = RGBColor(*color)


def fit_font_size(requested: float, box_h_norm: float, line_count: int, prs: Presentation) -> float:
    """Constrain font size so multiline placeholders do not explode outside slots."""
    box_points = (box_h_norm * prs.slide_height) / 12700
    max_by_height = max(6.0, box_points / max(1, line_count) / 1.25)
    return max(5.5, min(requested, max_by_height))


def add_rect(slide, prs: Presentation, slot: Dict[str, Any], theme: Dict[str, Any], label: bool = False) -> None:
    style = slot.get("style", {})
    fill_value = str(style.get("fill") or "").strip().lower()
    stroke_value = str(style.get("stroke") or "").strip().lower()
    fill = parse_color(style.get("fill"), (232, 232, 232))
    stroke = parse_color(style.get("stroke"), fill)
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        emu_x(prs, float(slot.get("x", 0))),
        emu_y(prs, float(slot.get("y", 0))),
        emu_x(prs, float(slot.get("w", 0.1))),
        emu_y(prs, float(slot.get("h", 0.1))),
    )
    if fill_value in {"none", "transparent"}:
        shape.fill.background()
    else:
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor(*fill)
    if stroke_value in {"none", "transparent"}:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = RGBColor(*stroke)
    if label:
        shape.text = str(slot.get("content") or slot.get("placeholder") or slot.get("role") or "Placeholder")
        tf = shape.text_frame
        tf.margin_left = 0
        tf.margin_right = 0
        tf.margin_top = 0
        tf.margin_bottom = 0
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.runs[0]
        run.font.name = family_name(theme.get("font_family"))
        run.font.size = Pt(float(style.get("font_size") or 12))
        run.font.color.rgb = RGBColor(*parse_color(style.get("color"), (140, 140, 140)))


def add_line(slide, prs: Presentation, slot: Dict[str, Any], theme: Dict[str, Any]) -> None:
    style = slot.get("style", {})
    line_slot = dict(slot)
    line_slot["h"] = max(float(slot.get("h", 0.002)), 0.002)
    line_slot["style"] = {"fill": style.get("stroke") or style.get("fill") or theme.get("muted") or "#999999"}
    add_rect(slide, prs, line_slot, theme)


def render_schema(schema_path: Path, output: Path) -> None:
    schema = json.loads(schema_path.read_text(encoding="utf-8-sig"))
    slides_data = schema.get("slides", [])
    if not slides_data:
        raise ValueError("Schema has no slides.")
    first_canvas = slides_data[0].get("canvas", {})
    aspect = float(first_canvas.get("aspect") or (16 / 9))
    prs = Presentation()
    prs.slide_width = Emu(9144000)
    prs.slide_height = Emu(round(9144000 / aspect))
    blank = prs.slide_layouts[6]
    for slide_data in slides_data:
        slide = prs.slides.add_slide(blank)
        theme = slide_data.get("theme", {})
        set_bg(slide, parse_color(theme.get("background"), (255, 255, 255)))
        for slot in slide_data.get("slots", []):
            kind = slot.get("type")
            if kind == "text":
                add_text(slide, prs, slot, theme)
            elif kind == "line":
                add_line(slide, prs, slot, theme)
            elif kind in {"image", "graphic", "logo"}:
                add_rect(slide, prs, slot, theme, label=True)
            elif kind in {"group", "repeat"}:
                continue
            else:
                add_rect(slide, prs, slot, theme)
    output.parent.mkdir(parents=True, exist_ok=True)
    prs.save(output)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render template schema to editable PPTX.")
    parser.add_argument("--schema", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    render_schema(args.schema, args.output)


if __name__ == "__main__":
    main()
