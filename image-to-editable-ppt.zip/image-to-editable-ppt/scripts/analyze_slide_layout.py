#!/usr/bin/env python
"""Analyze slide screenshots with an OpenAI-compatible vision model and emit layout JSON."""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

from PIL import Image


PROMPT = """Analyze this slide screenshot as a PowerPoint template.

Return JSON only. Do not describe the image in prose.

Goal: create an editable PPTX template, not pixel-perfect raster duplication.
Use semantic layout reconstruction:
- Identify major layout regions using a 12-column grid when useful.
- Preserve visual hierarchy, spacing, alignment, background, and approximate colors.
- Use editable text boxes for text-like content. Exact text can be placeholder text.
- Use media placeholders for photos, screenshots, complex charts, maps, icons, or illustrations.
- Avoid splitting photos or complex raster art into many small objects.
- Coordinates must be normalized floats from 0 to 1 relative to the slide.
- Keep the object list concise and meaningful.

Element types:
- text: editable text box
- rect: editable filled rectangle/panel/card
- line: editable separator or rule
- media: editable placeholder rectangle for photo/chart/map/screenshot/complex visual
- logo: editable approximate logo or brand mark placeholder

Return a JSON object matching this shape:
{
  "slides": [
    {
      "width": image_pixel_width,
      "height": image_pixel_height,
      "background": "#RRGGBB",
      "notes": "short reconstruction notes",
      "elements": [
        {
          "type": "text|rect|line|media|logo",
          "x": 0.0,
          "y": 0.0,
          "w": 0.1,
          "h": 0.1,
          "text": "placeholder or recognized text",
          "fill": "#RRGGBB",
          "stroke": "#RRGGBB",
          "color": "#RRGGBB",
          "font_size": 12,
          "bold": false,
          "align": "left|center|right",
          "label": "Image|Chart|Logo|..."
        }
      ]
    }
  ]
}
"""


def image_to_data_url(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "image/png"
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def response_text(response: Dict[str, Any]) -> str:
    choices = response.get("choices")
    if choices:
        message = choices[0].get("message", {})
        content = message.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = [part.get("text", "") for part in content if isinstance(part, dict)]
            return "\n".join(part for part in parts if part)

    texts: List[str] = []
    for item in response.get("output", []):
        for content in item.get("content", []):
            if content.get("type") in {"output_text", "text"} and "text" in content:
                texts.append(content["text"])
    if texts:
        return "\n".join(texts)
    if "output_text" in response:
        return str(response["output_text"])
    raise ValueError("Could not find text output in OpenAI response.")


def extract_json(text: str) -> Dict[str, Any]:
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"Model did not return a JSON object: {text[:500]}")
    return json.loads(text[start : end + 1])


def normalize_base_url(base_url: str) -> str:
    base_url = base_url.rstrip("/")
    if base_url.endswith("/v1"):
        return base_url
    return f"{base_url}/v1"


def request_layout(image_path: Path, model: str, api_key: str, base_url: str) -> Dict[str, Any]:
    with Image.open(image_path) as img:
        width, height = img.size

    body = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": f"{PROMPT}\nImage size: {width}x{height}."},
                    {"type": "image_url", "image_url": {"url": image_to_data_url(image_path)}},
                ],
            }
        ],
        "response_format": {"type": "json_object"},
    }

    endpoint = f"{normalize_base_url(base_url)}/chat/completions"
    req = urllib.request.Request(
        endpoint,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Vision API error {exc.code}: {detail}") from exc

    parsed = extract_json(response_text(payload))
    slide = parsed["slides"][0]
    slide.setdefault("width", width)
    slide.setdefault("height", height)
    slide["source_image"] = str(image_path)
    return slide


def analyze_images(image_paths: List[Path], output: Path, model: str, base_url: str) -> None:
    api_key = os.environ.get("YUNWU_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("YUNWU_API_KEY or OPENAI_API_KEY is required for vision layout analysis.")
    slides = [request_layout(path, model, api_key, base_url) for path in image_paths]
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"slides": slides}, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create editable slide layout JSON from screenshots using vision.")
    parser.add_argument("images", nargs="+", type=Path, help="Input slide screenshots/images.")
    parser.add_argument("-o", "--output", required=True, type=Path, help="Output layout JSON path.")
    parser.add_argument("--model", default="qwen3.5-397b-a17b", help="Vision-capable model.")
    parser.add_argument(
        "--base-url",
        default=os.environ.get("YUNWU_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or "https://yunwu.ai",
        help="OpenAI-compatible API base URL. /v1 is appended if omitted.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    analyze_images(args.images, args.output, args.model, args.base_url)


if __name__ == "__main__":
    main()
