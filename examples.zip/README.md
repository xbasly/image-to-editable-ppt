# PPTX 模板逐页解析与单页生成

项目只包含两个流程。

## 1. 解析模板

对任意 PPTX 按页解析。页码从 1 开始，每页分别输出文本槽和图片槽。
整页背景、越界背景素材和同一图片在组合形状中的重复引用不会计入图片槽，
而是单独记录在 `decorativeImages` 中。

```powershell
python .\run.py inspect `
  --template ".\模板.pptx" `
  --output ".\output\模板解析\模板_逐页槽位清单.json"
```

同时生成：

- JSON：程序读取，包含完整位置、尺寸、字体和图片关系；
- Markdown：人工查看，按页列出 shape ID 和模板原内容。

文本槽示例：

```json
{
  "slotId": "text:50",
  "shapeId": 50,
  "shapeName": "文本框 9",
  "originalText": "模板原文字",
  "geometry": {
    "left": 100,
    "top": 100,
    "width": 1000,
    "height": 300
  },
  "styles": []
}
```

图片槽示例：

```json
{
  "slotId": "image:46",
  "shapeId": 46,
  "shapeName": "图片占位符 7",
  "geometry": {},
  "relationshipIds": ["rId2"],
  "media": []
}
```

## 2. 生成指定模板页

准备单页内容 JSON：

```json
{
  "text": {
    "50": "新标题",
    "51": "新副标题",
    "52": "新正文"
  },
  "images": {
    "46": "assets/sample-image.jpeg"
  }
}
```

键就是第一步输出的 shape ID。图片路径相对于单页内容 JSON 所在目录。

执行：

```powershell
python .\run.py generate-page `
  --template ".\模板.pptx" `
  --page 8 `
  --content ".\examples\single-page-content.json" `
  --output ".\output\单页生成结果.pptx"
```

输出 PPTX 只包含一页，即模板第 8 页的克隆结果。没有传入的槽位继续保留模板
原内容；传入的文本和图片会被替换。图片替换不会改变模板原有坐标、尺寸、裁剪、
蒙版或层级。

## 代码结构

```text
run.py
src/pptx_pipeline/
├─ cli.py                 # inspect / generate-page 参数
├─ pipeline.py            # 两个流程的步骤编排和中文输出
├─ template_inspector.py  # 按页解析文本槽和图片槽
├─ page_content.py        # 单页内容 JSON 校验
├─ ooxml_generator.py     # 单页克隆、文本替换、图片替换
├─ validator.py           # 输出 PPTX 校验
└─ logger.py              # 中文步骤日志
```
