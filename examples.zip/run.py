"""PPTX 模板逐页解析与单页生成的唯一运行入口。

使用方式一：解析模板
--------------------
按页输出模板中的文本槽、可替换图片槽，以及不参与填槽的背景/装饰图片。

python run.py inspect ^
  --template "C:\\path\\模板.pptx" ^
  --output "output\\模板_逐页槽位清单.json"

执行后会同时生成：
1. JSON 槽位清单，供程序读取；
2. 同名 Markdown 槽位清单，供人工查看。


使用方式二：生成单页 PPTX
------------------------
从模板中选择一页，用单页内容 JSON 替换指定的文本和图片槽。

python run.py generate-page ^
  --template "C:\\path\\模板.pptx" ^
  --page 4 ^
  --content "examples\\page-04.json" ^
  --output "output\\page-04.pptx"

其中：
- --page 从 1 开始，对应第一步槽位清单中的 pageNumber；
- --content 是单页内容 JSON；
- --output 最终只包含一页。


单页内容 JSON 格式
------------------
{
  "text": {
    "42": "新的页标题",
    "25": "新的内容标题"
  },
  "images": {
    "34": "assets/new-image.jpg"
  }
}

text 和 images 中的键都是模板槽位清单中的 shapeId。
图片路径相对于单页内容 JSON 所在目录。
没有提供的槽位继续保留模板原内容。
"""

import sys
from pathlib import Path


# 将 src 加入模块搜索路径。运行入口只负责启动，不承载业务逻辑。
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from pptx_pipeline.cli import main


if __name__ == "__main__":
    main(PROJECT_ROOT)
