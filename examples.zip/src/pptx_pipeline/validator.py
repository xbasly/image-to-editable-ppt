"""对生成结果执行轻量结构校验。"""

import zipfile

from pptx import Presentation


def validate_pptx(path, expected_slide_count):
    if not path.is_file() or path.stat().st_size == 0:
        raise ValueError(f"输出文件不存在或为空：{path}")
    if not zipfile.is_zipfile(path):
        raise ValueError(f"输出文件不是有效的 OOXML 压缩包：{path}")

    presentation = Presentation(path)
    actual_slide_count = len(presentation.slides)
    if actual_slide_count != expected_slide_count:
        raise ValueError(
            f"页数校验失败：计划 {expected_slide_count} 页，实际 {actual_slide_count} 页"
        )
    return {
        "slides": actual_slide_count,
        "bytes": path.stat().st_size,
        "width": presentation.slide_width,
        "height": presentation.slide_height,
    }
