"""统一输出中文流程日志。"""

import sys


def configure_console_encoding():
    """Windows 控制台优先使用 UTF-8，避免中文步骤输出乱码。"""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")


class PipelineLogger:
    def __init__(self, total_steps):
        configure_console_encoding()
        self.total_steps = total_steps

    def step(self, number, message):
        print(f"\n【步骤 {number}/{self.total_steps}】{message}")

    @staticmethod
    def detail(label, value):
        print(f"  - {label}：{value}")

    @staticmethod
    def success(message):
        print(f"  [完成] {message}")
