"""编排模板解析与单页 PPTX 生成两个独立流程。"""

from pathlib import Path

from .logger import PipelineLogger
from .ooxml_generator import generate_single_page
from .page_content import load_page_content
from .template_inspector import inspect_template, write_manifest
from .validator import validate_pptx


def inspect_template_slots(template_path, output_path):
    logger = PipelineLogger(total_steps=2)
    template_path = Path(template_path).resolve()
    output_path = Path(output_path).resolve()

    logger.step(1, "按页解析 PPTX 模板")
    logger.detail("模板路径", template_path)
    manifest = inspect_template(template_path)
    text_count = sum(page["textSlotCount"] for page in manifest["pages"])
    image_count = sum(page["imageSlotCount"] for page in manifest["pages"])
    logger.detail("模板页数", manifest["pageCount"])
    logger.detail("文本槽总数", text_count)
    logger.detail("图片槽总数", image_count)
    logger.success("所有页面的文本槽和图片槽解析完成")

    logger.step(2, "输出逐页槽位清单")
    markdown_path = write_manifest(manifest, output_path)
    logger.detail("JSON 清单", output_path)
    logger.detail("中文清单", markdown_path)
    logger.success("可按页码和 shape ID 准备单页内容")
    return manifest


def generate_page(template_path, page_number, content_path, output_path):
    logger = PipelineLogger(total_steps=3)
    template_path = Path(template_path).resolve()
    content_path = Path(content_path).resolve()
    output_path = Path(output_path).resolve()

    logger.step(1, "读取模板页序号和单页内容")
    content, content_base_dir = load_page_content(content_path)
    logger.detail("模板路径", template_path)
    logger.detail("模板页序号", page_number)
    logger.detail("单页内容", content_path)
    logger.detail("文本替换数", len(content.get("text", {})))
    logger.detail("图片替换数", len(content.get("images", {})))
    logger.success("单页内容格式校验通过")

    logger.step(2, "克隆指定模板页并填充文本与图片")
    result = generate_single_page(
        template_path,
        page_number,
        content,
        output_path,
        content_base_dir,
    )
    logger.detail("PPTX 输出", result["output"])
    logger.success("仅生成指定的一页，模板几何、裁剪和样式已保留")

    logger.step(3, "校验单页 PPTX")
    validation = validate_pptx(output_path, 1)
    logger.detail("实际页数", validation["slides"])
    logger.detail("文件大小", f"{validation['bytes'] / 1024 / 1024:.2f} MB")
    logger.success("单页 PPTX 结构校验通过")
    return validation
