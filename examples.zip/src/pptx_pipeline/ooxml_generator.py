"""克隆指定模板页，并替换该页的文本槽和图片槽。"""

from copy import deepcopy
from pathlib import Path

from pptx import Presentation
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.oxml.ns import qn
from pptx.parts.image import Image, ImagePart


def iter_shapes(shapes):
    for shape in shapes:
        yield shape
        if hasattr(shape, "shapes"):
            yield from iter_shapes(shape.shapes)


def _apply_relationship_map(element, relationship_map):
    """一次性应用映射，避免 rId2→rId3→rId4 发生连锁误替换。"""
    for node in element.iter():
        for attribute in (qn("r:embed"), qn("r:link"), qn("r:id")):
            old_rid = node.get(attribute)
            if old_rid in relationship_map:
                node.set(attribute, relationship_map[old_rid])


def _clone_slide(presentation, source_slide):
    destination = presentation.slides.add_slide(source_slide.slide_layout)
    cloned_element = deepcopy(source_slide._element)
    destination.part._element = cloned_element
    destination._element = cloned_element
    destination.__dict__.pop("shapes", None)

    relationship_map = {}
    relations = sorted(source_slide.part.rels.items(), key=lambda item: int(item[0][3:]))
    for old_rid, relation in relations:
        if relation.reltype in {RT.SLIDE_LAYOUT, RT.NOTES_SLIDE}:
            continue
        new_rid = destination.part.rels._add_relationship(
            relation.reltype, relation._target, relation.is_external
        )
        relationship_map[old_rid] = new_rid
    _apply_relationship_map(cloned_element, relationship_map)
    return destination


def _replace_text_preserving_style(shape, value):
    text_body = shape.text_frame._txBody
    source_paragraphs = [deepcopy(item) for item in text_body.findall(qn("a:p"))]
    if not source_paragraphs:
        shape.text = str(value)
        return
    for paragraph in list(text_body.findall(qn("a:p"))):
        text_body.remove(paragraph)

    for index, line in enumerate(str(value).split("\n")):
        paragraph = deepcopy(source_paragraphs[min(index, len(source_paragraphs) - 1)])
        runs = paragraph.findall(qn("a:r"))
        if not runs:
            shape.text = str(value)
            return
        retained_run = runs[0]
        for child in list(paragraph):
            if child.tag in (qn("a:r"), qn("a:br"), qn("a:fld")) and child is not retained_run:
                paragraph.remove(child)
        text_nodes = retained_run.findall(qn("a:t"))
        if not text_nodes:
            shape.text = str(value)
            return
        text_nodes[0].text = line
        for extra_node in text_nodes[1:]:
            retained_run.remove(extra_node)
        text_body.append(paragraph)


def _replace_shape_image(slide, shape, image_path):
    blips = [
        node for node in shape._element.iter(qn("a:blip"))
        if node.get(qn("r:embed"))
    ]
    if not blips:
        raise ValueError(f"shape_id={shape.shape_id} 不包含可替换的嵌入图片")

    image_blob = Path(image_path).read_bytes()
    image_part = ImagePart.new(slide.part.package, Image.from_blob(image_blob))
    new_rid = slide.part.relate_to(image_part, RT.IMAGE)
    for blip in blips:
        blip.set(qn("r:embed"), new_rid)


def _remove_original_slides(presentation, original_count):
    for index in range(original_count - 1, -1, -1):
        slide_id = presentation.slides._sldIdLst[index]
        presentation.part.drop_rel(slide_id.rId)
        presentation.slides._sldIdLst.remove(slide_id)


def _fill_cloned_slide(slide, page_number, content, content_base_dir):
    shape_map = {str(shape.shape_id): shape for shape in iter_shapes(slide.shapes)}

    for shape_id, value in content.get("text", {}).items():
        shape = shape_map.get(str(shape_id))
        if shape is None or not shape.has_text_frame:
            raise KeyError(f"第 {page_number} 页不存在文本槽 shape_id={shape_id}")
        _replace_text_preserving_style(shape, value)

    for shape_id, image_value in content.get("images", {}).items():
        shape = shape_map.get(str(shape_id))
        if shape is None:
            raise KeyError(f"第 {page_number} 页不存在图片槽 shape_id={shape_id}")
        image_path = Path(image_value)
        if not image_path.is_absolute():
            image_path = Path(content_base_dir) / image_path
        if not image_path.is_file():
            raise FileNotFoundError(f"替换图片不存在：{image_path}")
        _replace_shape_image(slide, shape, image_path)


def generate_single_page(template_path, page_number, content, output_path, content_base_dir):
    presentation = Presentation(template_path)
    source_slides = list(presentation.slides)
    if page_number < 1 or page_number > len(source_slides):
        raise IndexError(f"模板页序号超出范围：{page_number}，模板共 {len(source_slides)} 页")

    slide = _clone_slide(presentation, source_slides[page_number - 1])
    _fill_cloned_slide(slide, page_number, content, content_base_dir)
    _remove_original_slides(presentation, len(source_slides))
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    presentation.save(output_path)
    return {"slides": 1, "templatePage": page_number, "output": output_path}


def generate_page_collection(template_path, page_specs, output_path):
    """测试辅助：把多个单页填槽结果合并为一个便于预览的 PPTX。"""
    presentation = Presentation(template_path)
    source_slides = list(presentation.slides)
    for specification in page_specs:
        page_number = int(specification["page"])
        if page_number < 1 or page_number > len(source_slides):
            raise IndexError(f"模板页序号超出范围：{page_number}")
        slide = _clone_slide(presentation, source_slides[page_number - 1])
        _fill_cloned_slide(
            slide,
            page_number,
            specification["content"],
            specification["contentBaseDir"],
        )
    _remove_original_slides(presentation, len(source_slides))
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    presentation.save(output_path)
    return {"slides": len(page_specs), "output": output_path}
