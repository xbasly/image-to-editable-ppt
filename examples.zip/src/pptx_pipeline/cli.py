"""最小命令行层。"""

import argparse

from .logger import configure_console_encoding
from .pipeline import generate_page, inspect_template_slots


def _parser():
    parser = argparse.ArgumentParser(description="PPTX 模板逐页解析与单页生成")
    commands = parser.add_subparsers(dest="command", required=True)

    inspect = commands.add_parser("inspect", help="按页输出模板的文本槽和图片槽")
    inspect.add_argument("--template", required=True, help="PPTX 模板路径")
    inspect.add_argument("--output", required=True, help="槽位清单 JSON 输出路径")

    generate = commands.add_parser("generate-page", help="根据模板页序号生成单页 PPTX")
    generate.add_argument("--template", required=True, help="PPTX 模板路径")
    generate.add_argument("--page", required=True, type=int, help="模板页序号，从 1 开始")
    generate.add_argument("--content", required=True, help="单页内容 JSON 路径")
    generate.add_argument("--output", required=True, help="单页 PPTX 输出路径")
    return parser


def main(project_root=None):
    configure_console_encoding()
    args = _parser().parse_args()
    if args.command == "inspect":
        inspect_template_slots(args.template, args.output)
    elif args.command == "generate-page":
        generate_page(args.template, args.page, args.content, args.output)
