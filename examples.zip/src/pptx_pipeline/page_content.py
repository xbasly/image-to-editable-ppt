"""读取单页填槽内容 JSON。"""

import json
from pathlib import Path


def load_page_content(path):
    path = Path(path).resolve()
    content = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(content.get("text", {}), dict):
        raise ValueError("单页内容的 text 必须是以 shape ID 为键的对象")
    if not isinstance(content.get("images", {}), dict):
        raise ValueError("单页内容的 images 必须是以 shape ID 为键的对象")
    return content, path.parent
