"""对任意 PPTX 按页输出文本槽和图片槽，不依赖固定模板配置。"""

import json
from pathlib import Path

from pptx import Presentation
from pptx.oxml.ns import qn

from .ooxml_generator import iter_shapes


def _geometry(shape):
    return {
        "left": shape.left,
        "top": shape.top,
        "width": shape.width,
        "height": shape.height,
        "rotation": shape.rotation,
    }


def _text_style(shape):
    styles = []
    for paragraph_index, paragraph in enumerate(shape.text_frame.paragraphs):
        for run_index, run in enumerate(paragraph.runs):
            font = run.font
            color = None
            try:
                if font.color.rgb:
                    color = str(font.color.rgb)
                elif font.color.theme_color:
                    color = str(font.color.theme_color)
            except (AttributeError, TypeError):
                pass
            styles.append({
                "paragraph": paragraph_index,
                "run": run_index,
                "fontName": font.name,
                "fontSizePt": round(font.size.pt, 1) if font.size else None,
                "bold": font.bold,
                "italic": font.italic,
                "color": color,
            })
    return styles


def _image_slot(slide, shape, slide_width, slide_height):
    relationship_ids = []
    media = []
    for blip in shape._element.iter(qn("a:blip")):
        relationship_id = blip.get(qn("r:embed"))
        if not relationship_id:
            continue
        relationship_ids.append(relationship_id)
        relation = slide.part.rels.get(relationship_id)
        if relation and not relation.is_external:
            media.append({
                "partName": str(relation.target_part.partname),
                "contentType": relation.target_part.content_type,
                "bytes": len(relation.target_part.blob),
            })
    if not relationship_ids:
        return None
    result = {
        "slotId": f"image:{shape.shape_id}",
        "shapeId": shape.shape_id,
        "shapeName": shape.name,
        "geometry": _geometry(shape),
        "relationshipIds": relationship_ids,
        "media": media,
    }
    area_ratio = (shape.width * shape.height) / (slide_width * slide_height)
    result["areaRatio"] = round(area_ratio, 4)
    result["extendsOutsideSlide"] = (
        shape.left < 0
        or shape.top < 0
        or shape.left + shape.width > slide_width
        or shape.top + shape.height > slide_height
    )
    for name in ("crop_left", "crop_top", "crop_right", "crop_bottom"):
        if hasattr(shape, name):
            result[name] = getattr(shape, name)
    return result


def inspect_template(template_path):
    presentation = Presentation(template_path)
    pages = []
    for page_number, slide in enumerate(presentation.slides, 1):
        text_slots = []
        image_slots = []
        decorative_images = []
        for shape in iter_shapes(slide.shapes):
            if shape.has_text_frame:
                text_slots.append({
                    "slotId": f"text:{shape.shape_id}",
                    "shapeId": shape.shape_id,
                    "shapeName": shape.name,
                    "originalText": shape.text,
                    "geometry": _geometry(shape),
                    "styles": _text_style(shape),
                })
        # 图片只从顶层 shape 采集。组合形状的 XML 已包含全部子形状 blip，
        # 若继续递归会把同一张照片在 group/freeform 层重复计算。
        seen_relationship_ids = set()
        for shape in slide.shapes:
            image_slot = _image_slot(
                slide, shape, presentation.slide_width, presentation.slide_height
            )
            if not image_slot:
                continue
            relationship_ids = set(image_slot["relationshipIds"])
            if relationship_ids and relationship_ids.issubset(seen_relationship_ids):
                continue
            seen_relationship_ids.update(relationship_ids)
            is_decorative = (
                image_slot["extendsOutsideSlide"]
                or image_slot["areaRatio"] >= 0.45
            )
            if is_decorative:
                image_slot["reason"] = "背景或越界装饰图片，不作为内容填槽"
                decorative_images.append(image_slot)
            else:
                image_slots.append(image_slot)
        pages.append({
            "pageNumber": page_number,
            "textSlotCount": len(text_slots),
            "imageSlotCount": len(image_slots),
            "decorativeImageCount": len(decorative_images),
            "textSlots": text_slots,
            "imageSlots": image_slots,
            "decorativeImages": decorative_images,
        })
    return {
        "template": str(Path(template_path).resolve()),
        "slideWidth": presentation.slide_width,
        "slideHeight": presentation.slide_height,
        "pageCount": len(pages),
        "pages": pages,
    }


def write_manifest(manifest, output_path):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    lines = [
        "# PPTX 模板逐页槽位清单",
        "",
        f"- 模板页数：{manifest['pageCount']}",
        f"- 页面尺寸：{manifest['slideWidth']} × {manifest['slideHeight']} EMU",
    ]
    for page in manifest["pages"]:
        lines.extend([
            "",
            f"## 第 {page['pageNumber']} 页",
            "",
            f"- 文本槽：{page['textSlotCount']} 个",
            f"- 图片槽：{page['imageSlotCount']} 个",
            f"- 背景/装饰图片：{page['decorativeImageCount']} 个（不参与填槽）",
            "",
            "### 文本槽",
            "",
            "| shape ID | shape 名称 | 模板原文 |",
            "|---:|---|---|",
        ])
        for slot in page["textSlots"]:
            original = slot["originalText"].replace("\n", "<br>")
            lines.append(f"| {slot['shapeId']} | {slot['shapeName']} | {original} |")
        lines.extend(["", "### 图片槽", "", "| shape ID | shape 名称 | 图片关系数 |", "|---:|---|---:|"])
        for slot in page["imageSlots"]:
            lines.append(
                f"| {slot['shapeId']} | {slot['shapeName']} | {len(slot['relationshipIds'])} |"
            )
    markdown_path = output_path.with_suffix(".md")
    markdown_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return markdown_path
