"""PPTX 模板逐页槽位解析与单页生成。"""

from .pipeline import generate_page, inspect_template_slots

__all__ = ["inspect_template_slots", "generate_page"]
